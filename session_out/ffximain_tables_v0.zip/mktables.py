#!/usr/bin/env python3
"""Table builder for unpacked FFXiMain.dll. No RTTI, so vtables are found as
runs of code pointers in rdata/data that are referenced from code."""
import numpy as np, struct, csv, re

BASE = 0x10000000
data = open('FFXiMain.unpacked.dll','rb').read()
TEXT_LO, TEXT_HI = 0x1000, 0x1000 + 0x3275EE          # .text RVA range
RD_LO, RD_HI     = 0x329000, 0x329000 + 152981        # .rdata
DA_LO, DA_HI     = 0x34f000, 0x34f000 + 544768        # .data initialized part only
code_lo, code_hi = BASE+TEXT_LO, BASE+TEXT_HI

buf = np.frombuffer(data, dtype=np.uint8)
def dwords_at_all_offsets(lo, hi):
    """every 32-bit LE value at every byte offset in [lo,hi)"""
    seg = buf[lo:hi]
    return (seg[:-3].astype(np.uint32) | (seg[1:-2].astype(np.uint32)<<8)
            | (seg[2:-1].astype(np.uint32)<<16) | (seg[3:].astype(np.uint32)<<24))

# ---- all VAs referenced as imm32/disp32 anywhere in .text ----
text_vals = dwords_at_all_offsets(TEXT_LO, TEXT_HI)
referenced = set(np.unique(text_vals[(text_vals >= BASE) & (text_vals < BASE+0xC15000)]).tolist())
print(f"unique VA-like dwords referenced from .text: {len(referenced)}")

# ---- vtable scan: aligned code-pointer runs in .rdata + .data ----
vtables = []
for lo, hi, secname in [(RD_LO,RD_HI,'.rdata'), (DA_LO,DA_HI,'.data')]:
    n = (hi-lo)//4
    arr = np.frombuffer(data, dtype='<u4', count=n, offset=lo)
    is_code = (arr >= code_lo) & (arr < code_hi)
    i = 0
    while i < n:
        if is_code[i]:
            start = i
            while i < n and is_code[i]:
                # a referenced address that's not the run start begins a new vtable
                if i > start and (BASE+lo+i*4) in referenced:
                    break
                i += 1
            slots = i - start
            va = BASE + lo + start*4
            if slots >= 1 and va in referenced:
                vtables.append((va, slots, secname))
        else:
            i += 1
print(f"vtable candidates (referenced, >=1 slot): {len(vtables)}")
multi = [v for v in vtables if v[1] >= 2]
print(f"  with >=2 slots: {len(multi)}, >=5 slots: {len([v for v in vtables if v[1]>=5])}")
with open('tables_vtables.csv','w',newline='') as f:
    w = csv.writer(f); w.writerow(['vtable_va','slots','section','slot_targets_first8'])
    for va, slots, sec in vtables:
        off = va - BASE
        tgts = [hex(struct.unpack_from('<I', data, off+j*4)[0]) for j in range(min(slots,8))]
        w.writerow([hex(va), slots, sec, ' '.join(tgts)])

# ---- function starts ----
# seeds: call rel32 targets + prologues + vtable slot targets
funcs = set()
text = data[TEXT_LO:TEXT_HI]
# E8 call targets
pos = -1
call_targets = set()
while True:
    pos = text.find(b'\xe8', pos+1)
    if pos < 0: break
    if pos+5 > len(text): break
    rel = struct.unpack_from('<i', text, pos+1)[0]
    tgt = TEXT_LO + pos + 5 + rel
    if TEXT_LO <= tgt < TEXT_HI: call_targets.add(tgt)
# filter call targets: preceded by ret/int3/nop/jmp or at section start, or has prologue
PRO = (b'\x55\x8b\xec',)  # push ebp; mov ebp,esp
good = set()
for t in call_targets:
    b3 = data[t:t+3]
    prev = data[t-1]
    if b3[:3] in PRO or prev in (0xc3, 0xcc, 0x90, 0xc2) or data[t] in (0x55,):
        good.add(t)
# vtable slot targets
slot_targets = set()
for va, slots, sec in vtables:
    off = va - BASE
    for j in range(slots):
        tgt = struct.unpack_from('<I', data, off+j*4)[0] - BASE
        slot_targets.add(tgt)
funcs = good | slot_targets
print(f"call targets: {len(call_targets)}, plausible func starts: {len(good)}, vtable slot funcs: {len(slot_targets)}")
print(f"total function-start table: {len(funcs)}")
with open('tables_functions.csv','w',newline='') as f:
    w = csv.writer(f); w.writerow(['va','rva','seed'])
    for t in sorted(funcs):
        seed = ('call+vt' if t in good and t in slot_targets else 'vtable' if t in slot_targets else 'call')
        w.writerow([hex(BASE+t), hex(t), seed])

# ---- strings with RVAs (ascii + sjis-ish), only ones referenced from code ----
rows = []
for m in re.finditer(rb'[\x20-\x7e\x81-\x9f\xe0-\xfc][\x20-\x7e\x81-\x9f\xe0-\xfc\x0a\x0d\t]{3,400}\x00', data[:DA_HI]):
    va = BASE + m.start()
    if va in referenced:
        s = m.group()[:-1]
        try: txt = s.decode('cp932')
        except: txt = s.decode('latin1')
        rows.append((hex(va), len(s), txt[:200]))
print(f"referenced strings: {len(rows)}")
with open('tables_strings.csv','w',newline='') as f:
    w = csv.writer(f); w.writerow(['va','len','text']); w.writerows(rows)
