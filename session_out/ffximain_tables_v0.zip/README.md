# ffximain tables v0 (2026-10-02)

Input: FFXiMain.dll retail Win client, md5 fb7464073c06489268fdd9215c3e5313, PE32 MSVC6 (linker 6.0), POL1-packed.

## Contents
- unpack.py            static unpacker (POL1 LZSS: flagbyte MSB-first, 12-bit offset / 4-bit len+3, off==0 ends). Only .text is packed. Real OEP 0x1031672F.
- FFXiMain.unpacked.dll  12.6MB, raw==virtual layout, loads straight into Ghidra/IDA at base 0x10000000.
- mktables.py          table builder (numpy)
- tables_vtables.csv     1059 referenced vtables (va, slots, first 8 slot targets). No RTTI in this binary (/GR-), found via code-pointer runs + xref evidence.
- tables_functions.csv   16010 function-start seeds (call targets w/ prologue filter + vtable slots). Bootstrap grade; Ghidra pass will be authoritative.
- tables_strings.csv     3581 strings referenced from code (cp932 decoded), with VAs.
- tables_classnames.csv  113 class names present as allocator/debug tag strings (CXiActor, CMo*, CYy*...).
- tables_src_paths.txt   96 leaked source paths: 89 dancer engine (sq* modules), 5 FFXi_Win game code, 2 pol.

## Repro
1. python3 unpack.py FFXiMain.dll FFXiMain.unpacked.dll
2. python3 mktables.py
3. Import FFXiMain.unpacked.dll into Ghidra (x86, 32-bit, base 0x10000000) for the authoritative pass.
