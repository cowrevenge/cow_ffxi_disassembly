#!/usr/bin/env python3
"""Static unpacker for PlayOnline POL1-packed DLLs (FFXiMain.dll etc).

The POL1 stub is an LZSS variant:
  flag byte, MSB first; bit=1 -> literal byte
  bit=0 -> two bytes b1,b2: offset = ((b1&0x0F)<<8)|b2 (back-ref from dst, 1..4095)
           length = (b1>>4)+3; offset==0 terminates the stream.
Only .text is packed (POL1 holds the stream); other sections are raw.
Output: an unpacked PE with raw==virtual layout, EP set to the real OEP.
"""
import pefile, struct, sys

def lzss_unpack(src, expected=None):
    out = bytearray()
    i = 0
    while True:
        flags = src[i]; i += 1
        for bit in range(8):
            if flags & (0x80 >> bit):
                out.append(src[i]); i += 1
            else:
                b1, b2 = src[i], src[i+1]
                off = ((b1 & 0x0F) << 8) | b2
                if off == 0:
                    return bytes(out), i + 2
                i += 2
                ln = (b1 >> 4) + 3
                for _ in range(ln):
                    out.append(out[-off])
        if expected and len(out) > expected + 16:
            raise RuntimeError("overran expected size, bad stream")

def main(inp, outp):
    pe = pefile.PE(inp)
    raw = open(inp, 'rb').read()
    base = pe.OPTIONAL_HEADER.ImageBase
    secs = {s.Name.rstrip(b'\x00').decode(): s for s in pe.sections}
    pol = secs['POL1']
    text = secs['.text']
    stream = raw[pol.PointerToRawData : pol.PointerToRawData + pol.SizeOfRawData]
    expected = 0x3275EE  # from the stub; == .text VirtualSize
    unpacked, consumed = lzss_unpack(stream, expected)
    print(f"decompressed {len(unpacked):#x} bytes (expected {expected:#x}), consumed {consumed:#x} of POL1")
    assert len(unpacked) == expected == text.Misc_VirtualSize, "size mismatch"

    # Build a flat memory image, then emit PE with raw==virtual alignment
    img_end = max(s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData) for s in pe.sections)
    align = pe.OPTIONAL_HEADER.SectionAlignment
    img = bytearray((img_end + align - 1) // align * align)
    hdr = raw[:pe.OPTIONAL_HEADER.SizeOfHeaders]
    img[:len(hdr)] = hdr
    for s in pe.sections:
        img[s.VirtualAddress : s.VirtualAddress + s.SizeOfRawData] = \
            raw[s.PointerToRawData : s.PointerToRawData + s.SizeOfRawData]
    img[text.VirtualAddress : text.VirtualAddress + len(unpacked)] = unpacked

    # Fix headers in the image copy: raw ptr/size = virtual, new EP
    pe2 = pefile.PE(data=bytes(img))
    OEP = 0x31672F
    pe2.OPTIONAL_HEADER.AddressOfEntryPoint = OEP
    for s in pe2.sections:
        s.PointerToRawData = s.VirtualAddress
        s.SizeOfRawData = (s.Misc_VirtualSize + align - 1) // align * align
    out = pe2.write()
    # pefile writes over original buffer; ensure length covers image
    out = bytes(out)
    if len(out) < len(img): out = out + bytes(img[len(out):])
    open(outp, 'wb').write(out)
    print(f"wrote {outp}: {len(out):#x} bytes, OEP {OEP:#x}")

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv)>1 else 'FFXiMain.dll',
         sys.argv[2] if len(sys.argv)>2 else 'FFXiMain.unpacked.dll')
