--[[
    bovinefh.lua - HorizonXI packet/command auto-fisher (Ashita v4)

    One file, no memory scanning. The whole thing is driven from the ImGui
    panel. (It does use file IO -- dated logs, persisted settings, fish
    tables -- and it shells out to detached PowerShell for the file pickers
    and the GitHub updater, neither of which ever blocks the render thread.)

      - Auto-fish loop (cast -> wait for bite -> catch -> repeat),
        catching either by injecting the catch packet or by sending Enter.
      - Manual buttons for each action.
      - Live tracking of player status, bite, 0x115 fields, results, counts.

    The only slash command is bare /bfh, which shows/hides the panel.
]]

-- Single source of truth for the addon name. Used for addon.name, the
-- /addon unload string fired by the window X, etc.
local ADDON_NAME = 'bovinefh'

addon.name    = ADDON_NAME
addon.author  = ''
addon.version = '4.2'
addon.desc    = 'GUI packet/command auto-fisher for FFXI fishing.'

require('common')
local imgui = require('imgui')

----------------------------------------------------------------------------------------------------
-- Constants
----------------------------------------------------------------------------------------------------

local PLAYER_STATUS_NAMES = {
    [0]  = 'Idle',
    [1]  = 'Engaged',
    [2]  = 'Dead',
    [3]  = 'Engaged_Dead',
    [4]  = 'Knockback',
    [5]  = 'Resting',
    [33] = 'Event',
    [38] = 'Mounted',
    [44] = 'Cutscene',
    [50] = 'Sitting',
    [56] = 'Fishing',         -- cast in progress / waiting for bite
    [57] = 'FishBite',        -- bite occurred (fish/monster/item)
    [58] = 'Obtained',        -- caught successfully
    [59] = 'RodBreak',
    [60] = 'LineBreak',
    [61] = 'CatchMonster',
    [62] = 'LostCatch',
}

-- Plain substring matches. Order matters: "...hook!" is a substring of
-- "...hook!!!", so large MUST be tested before small.
local BITE_STRINGS = {
    monster    = 'Something clamps onto your line ferociously',
    item       = 'You feel something pulling at your line.',
    fish_large = 'Something caught the hook!!!',
    fish_small = 'Something caught the hook!',
}

-- ORDERED list, same reason BITE_STRINGS is ordered: classify_end returns the
-- FIRST match, so if two needles ever both hit a line the winner must be fixed
-- rather than whatever pairs() happened to yield that run. Most specific first,
-- broadest last -- 'regretfully' is a bare adverb and the likeliest to collide
-- with something unrelated, so it sits at the bottom.
local END_STRINGS = {
    { 'command_rejected', 'You cannot use that command at this time' },
    { 'wrong_pos',        'You cannot fish here'                     },
    { 'lost_too_small',   'too small to catch with this rod'         },
    { 'line_broke',       'Your line breaks'                         },
    { 'fish_got_away',    'The fish got away'                        },
    { 'lost_catch',       'You lost your catch'                      },
    { 'no_catch',         "You didn't catch anything"                },
    { 'no_bait',          'without bait'                             },
    { 'no_rod',           'without a rod'                            },
    { 'no_room_inv',      'cannot carry any more items'              },
    { 'no_room_inv2',     'inventory is full'                        },
    { 'no_room_inv3',     'regretfully'                              },
}

-- Catch lines are third-person with the player's name. Longest article first.
local CATCH_PATTERNS = {
    '(.-) caught the (.-)!',
    '(.-) caught an (.-)!',
    '(.-) caught a (.-)!',
    '(.-) catches the (.-)!',
    '(.-) catches an (.-)!',
    '(.-) catches a (.-)!',
    '(.-) finds the (.-)!',
    '(.-) finds an (.-)!',
    '(.-) finds a (.-)!',
}

local QUALITY_STRINGS = {
    terrible = 'You have a terrible feeling',
    bad      = 'You have a bad feeling',
    good     = 'You have a good feeling',
}

-- Terminal status codes that are authoritative result signals.
local STATUS_TO_RESULT = {
    [58] = 'caught',
    [59] = 'rod_broke',
    [60] = 'line_broke',
    [62] = 'lost_catch',
}

local NO_ROOM_TAGS = {
    no_room_inv  = true,
    no_room_inv2 = true,
    no_room_inv3 = true,
}

----------------------------------------------------------------------------------------------------
-- Namespace tables
----------------------------------------------------------------------------------------------------
-- Lua caps a function at 200 local slots and the main chunk of this file sits
-- right on that line, so anything that would otherwise be a file-scope `local`
-- gets parked in one of these instead. Three tables cost three slots between
-- them and hold as many entries as we like. Keys keep their original names, so
-- CAST_INTERVAL_MIN is now TUNE.CAST_INTERVAL_MIN and nothing else changes.
--   TUNE  = tuning constants (timings, retry/failure limits, tolerances)
--   DB    = the parsed fish/rod data tables, filled by load_data_tables()
--   PATHS = on-disk locations (addon dirs, settings, dialog helper scripts)
local TUNE  = {}
local DB    = {}
local PATHS = {}

----------------------------------------------------------------------------------------------------
-- State (live, in-memory; the panel reads this)
----------------------------------------------------------------------------------------------------

local state = {
    player = { name = '', status = 0, status_name = 'Idle', x = 0, y = 0, z = 0 },

    -- Player-detector timings. Kept on state (not as bare locals) because the
    -- main function is at Lua's 200-local cap. soft = continuous presence
    -- before a pause commits (passersby who blink out before this never
    -- trigger); leave = hold after they're gone before resuming.
    PLAYER_DETECT = { soft = 20.0, leave = 30.0 },

    bite = {
        kind = nil, fish_size = nil, quality = nil, text = '', time = 0,
    },

    packet_0x115 = {
        captured = false, stamina = 0, arrow_duration = 0, regen_modifier = 0,
        arrow_frequency = 0, stamina_depletion = 0, depletion_x20 = 0,
        unknown_0e = 0, catch_delay = 0, flags = 0, size_bit = 0,
        gold_arrow_chance = 0, time = 0,
    },

    last_result = { kind = nil, name = nil, text = '', time = 0, source = nil },

    -- GUI checkbox ({bool} table for imgui). Lives in state rather than as a
    -- standalone local because the d3d_present closure is already at Lua
    -- 5.1's 60-upvalue cap -- a new top-level local would overflow it.
    recast_delay = { true },   -- 0.5-0.75s randomized Idle dwell before recast
    extend_release = { true }, -- +0.75-1.25s on top of the base pre-release delay
}

-- Exact server arrow-damage (the 0x115 dep_x20 value), replicating the C++
-- float32 math: floor( diff * ((fa+lgdBonus)/100.0f) * 20.0f ). Done in 32-bit
-- float (via struct pack/unpack) so our prediction matches the packet bit-for-
-- bit -- double-precision math rounds one off on some values (diff26/fa70 ->
-- 364 vs the server's 363). On `state` so it adds no top-level local.
function state.arrow_dmg(diff, fa, lgd_bonus)
    local f = function(x) return struct.unpack('f', struct.pack('f', x)) end
    local ratio = f((fa + (lgd_bonus or 0)) / 100.0)
    return math.floor(f(f(diff * ratio) * 20.0))
end

-- Running tallies for the panel.
local stats = { caught = 0, lost = 0, casts = 0, tells = 0, released = 0, skillups = 0, skillgain = 0.0 }

----------------------------------------------------------------------------------------------------
-- UPDATE / GITHUB CONFIG  <-- EDIT HERE
----------------------------------------------------------------------------------------------------
-- Everything the auto-updater needs. Hung off `state` rather than declared as
-- top-level locals: the main chunk is close to Lua 5.1's 200-local ceiling and
-- the render closure is at the 60-upvalue ceiling, and `state` is already an
-- upvalue of both. Same escape valve state.pool / state.ui use.
--
-- TOKEN: leave `token` EMPTY if the repo is public. For a PRIVATE repo, use a
-- fine-grained PAT scoped to this one repo with Contents: Read (and nothing
-- else). Three places it can live, checked in this order:
--
--   1. <addon>/gitvar.dat          <- PREFERRED. Plain text despite the .dat
--                                     name: one line, the token, nothing else.
--                                     Add it to .gitignore.
--   2. <addon>/settings/gitvar.dat <- same thing, if you'd rather keep it with
--                                     the other sidecar files.
--   3. state.UPDATE.token below    <- fallback for a quick local test only.
--
-- A token pasted below WILL be committed if you push this file. Anyone you
-- hand the addon to also gets read access to the repo. Use gitvar.dat.
state.UPDATE = {
    repo   = 'cowrevenge/bovinefh',   -- owner/name
    branch = 'main',
    file   = 'bovinefh.lua',          -- path to the addon file inside the repo
    token  = '',                      -- see note above; prefer the sidecar file
}
-- Working paths (under the addon dir). Created on first use.
state.UPDATE.dir     = addon.path .. 'update/'
state.UPDATE.ps      = state.UPDATE.dir .. 'update.ps1'
state.UPDATE.payload = state.UPDATE.dir .. 'remote.lua'
state.UPDATE.result  = state.UPDATE.dir .. 'update.result'
state.UPDATE.target  = addon.path .. ADDON_NAME .. '.lua'   -- the file we replace

-- Live updater state read by the panel. Never holds the token.
state.upd = {
    status   = 'idle',   -- idle | checking | uptodate | available | error | applying
    message  = '',
    pending  = false,    -- a download is in flight
    ready    = false,    -- a check found a newer version; Update Now is armed
    remote_v = nil,
    sha_remote = nil,    -- git blob SHA-1 of the downloaded file
    sha_local  = nil,    -- git blob SHA-1 of the file on disk
    older    = false,    -- remote version is BEHIND local (applying = downgrade)
    started  = 0.0,
    auto_apply = false,  -- set by the on-load check so upd_poll applies without a click
}

-- Player-ID bytes (offset 4-7) + inner-header bytes (offset 12-13) captured
-- from real outbound 0x110s, re-used to build the injected catch packet so
-- the bytes match the client exactly. byte 12 varies day to day (observed
-- 0x0A and 0x06) -- NEVER hardcoded, always captured live.
local last_cast_player_id_bytes = nil
local last_inner_header_bytes   = nil

----------------------------------------------------------------------------------------------------
-- GUI-bound settings (all mutable single-element tables for imgui widgets)
----------------------------------------------------------------------------------------------------

local ui_visible = { true }      -- panel shown on load
-- UI scaling. Attached to `state` (not a fresh local) to stay under Lua's
-- 200-local cap on the main chunk -- same escape valve as state.pool.
-- .scale is lazy (set on first render from imgui.GetIO().DisplaySize.y,
-- baseline 1440p); .w(x) scales a hardcoded pixel width, safe pre-init.
state.ui = { scale = nil }
state.ui.w = function(x) return state.ui.scale and math.floor(x * state.ui.scale) or x end
local auto_fish  = { false }     -- master auto-fish toggle

-- GUI-bound settings, bundled into one table so the big render closure
-- captures a single upvalue (S) instead of ~20 individual locals. Lua 5.1
-- caps upvalues per function at 60 and the render closure sits at that
-- ceiling; grouping here keeps headroom for future panel additions. Each
-- field is still a mutable single-element table for its imgui widget.
local S = {
    stop_full    = { true },      -- stop auto-fish when inventory is full
    shutdown_full = { false },    -- on inventory full: stop, wait 15s, then /shutdown
    full_bot     = { false },     -- OFF (default): fish only 5x then stop (test). ON: fish normally.
    pause_on_player = { true },   -- ON by default: pause fishing while another player is nearby; resume 30s after they leave
    asshole_list = { '' },        -- named players: if any detected -> hard stop, then /shutdown when idle
    asshole_add  = { '' },        -- input buffer for adding a name to the asshole list
    friends_list = { '' },        -- named players: skipped by the pause-on-player detector (fish next to them freely)
    friends_add  = { '' },        -- input buffer for adding a name to the friends list
    auto_drop    = { false },     -- drop caught item matching S.drop_name
    drop_name    = { '' },        -- item name buffer for auto/manual drop
    bait_name    = { 'Insect Ball' },  -- bait item name buffer (slot 1)
    bait2_name   = { 'Shrimp Lure' },   -- backup bait, promoted when slot 1 runs dry
    rod_name     = { 'Halcyon Rod' },   -- rod item name buffer
    tell_watch   = { true },      -- stop auto-fish on a burst of incoming /tells
    rel_monsters = { true },      -- release monster bites
    rel_items    = { true },      -- release item bites
    catch_jackpot = { true },     -- KEEP item bites worth >= TUNE.JACKPOT_MIN even if rel_items is on
    rel_terrible = { false },     -- release "terrible feeling" fish
    rel_bad      = { false },     -- release "bad feeling" fish
    rel_positive = { false },     -- release "positive skill" fish
    rel_small    = { false },     -- release small fish (caught the hook!)
    rel_large    = { false },     -- release large fish (caught the hook!!!)
    skip_name    = { '' },        -- Skip Fish: NAME blacklist (release on name match)
    catch_unknown = { false },    -- Catch Only Known: release fish whose NAME isn't in S.known_name
    known_name   = { 'Tavnazian goby,Gold Carp' }, -- NAMES to keep when Catch Only Known is on
    stop_moved   = { true },      -- stop auto-fish if the character moves from baseline
    auto_move    = { false },     -- Auto Move On Full: sweep caught fish to satchel when inv full
    auto_move_name = { 'Tavnazian goby' }, -- which fish to sweep (one-way inv -> satchel)
    rand_timing  = { true },      -- jitter cast interval + pre-release delay
    sound_alerts = { true },      -- play WAV on stop/pause edges (Game_stopped.wav / Game_paused.wav in addon folder)
    pause_pool   = { true },      -- ON: pause 1h when fish-bite ratio drops below the pool.THRESHOLD (spot is fished out)
    pool_low_thresh = { false },  -- ON: use 15% threshold (rarer/tougher fish); OFF: use 30% (default, common fish)
    swap_on_dead_pool = { false },-- ON: on depletion, try bait 2 (if configured and different) before resting; opens fallback fish (e.g. worms hitting gold carp when goby is dead)
    debug        = { true },      -- print what the bot is doing to the chat log
    auto_update  = { false },     -- check GitHub for a newer bovinefh.lua on load and apply it (only while stopped)
}

-- File logging: one dated file per day under <addon>/logs/. The file captures
-- EVERYTHING (cast/bite/catch/release/equip/key/stop) regardless of the chat
-- Debug toggle, so a lockup or odd run can be reviewed afterwards.
PATHS.LOG_DIR = addon.path .. 'logs/'
local log_dir_ready = false
local function log_write(msg)
    if not log_dir_ready then
        os.execute(string.format('mkdir "%s" 2>nul', PATHS.LOG_DIR:gsub('/', '\\')))
        log_dir_ready = true
    end
    local f = io.open(PATHS.LOG_DIR .. 'bovinefh_' .. os.date('%Y-%m-%d') .. '.log', 'a')
    if f == nil then return end
    f:write(string.format('[%s] %s\n', os.date('%Y-%m-%d %H:%M:%S'), msg))
    f:close()
end

-- Chat logging. Defined early so every helper below can use it. Both also write
-- to the dated log file; dnote goes to chat only when Debug is on, file always.
local function note(msg)
    print(string.format('\31\200[bfh]\30\01 %s', msg))
    log_write(msg)
end
-- Debug line: chat only when the Debug toggle is on; the file always records it.
local function dnote(msg)
    if S.debug[1] then print(string.format('\31\200[bfh]\30\01 [dbg] %s', msg)) end
    log_write('[dbg] ' .. msg)
end

-- Dump an incoming packet as hex to logs/statusdebug.txt. Used during the
-- post-catch window to capture the server's resolution packets (char status,
-- animation-stop, catch result) so Recovery can replay-inject them.
local function status_dump(id, data)
    if not log_dir_ready then
        os.execute(string.format('mkdir "%s" 2>nul', PATHS.LOG_DIR:gsub('/', '\\')))
        log_dir_ready = true
    end
    local f = io.open(PATHS.LOG_DIR .. 'statusdebug.txt', 'a')
    if f == nil then return end
    local hex = {}
    for i = 1, #data do hex[i] = string.format('%02X', string.byte(data, i)) end
    f:write(string.format('[%s] id=0x%03X size=%d\n  %s\n',
        os.date('%H:%M:%S'), id, #data, table.concat(hex, ' ')))
    f:close()
end

-- Known-fish table, editable in the GUI (locked while running) and persisted.
-- These string buffers are the source of truth; fight_duration() parses them.
-- Each known row: FishID + min/max fight seconds. unk_row is the fallback for
-- any FishID not listed. Add/edit rows here (and they persist).
local fish_rows = {
    { id = { 'Tavnazian goby' }, min = { '5.0' }, max = { '5.8' } },
    { id = { 'Gold Carp' },      min = { '5.0' }, max = { '6.0' } },
}
local unk_row = { min = { '4.5' }, max = { '5.5' } }
local loaded_file_name = 'River Lufaise'   -- label shown on Fish Time; updated on file load
local loaded_area = ''                      -- AREA= marker from the pool file; '' = unset

local function new_fish_row(id, mn, mx)
    return { id = { id or '' }, min = { mn or '4.5' }, max = { mx or '5.5' } }
end

-- "Load" opens a native file picker and reads the chosen fish-table file:
-- one fish per line as "id,min,max" (# = comment, whitespace ignored).
-- Replaces the current rows.
local function load_fish_file(path)
    if path == nil or path == '' then return end
    local f = io.open(path, 'r')
    if not f then note('could not open: ' .. path); return end
    local rows = {}
    local area = ''
    for line in f:lines() do
        local l = line:gsub('^%s+', ''):gsub('%s+$', '')   -- trim ends only (keep internal spaces in names)
        local a = l:match('^[Aa][Rr][Ee][Aa]%s*=%s*(.+)$')  -- AREA= marker
        if a then
            area = a:gsub('%s+$', '')
        elseif l ~= '' and l:sub(1, 1) ~= '#' then
            local id, mn, mx = l:match('([^,]+),%s*([^,]+),%s*([^,]+)')
            if id then
                id = id:gsub('%s+$', '')                    -- trim trailing space before comma
                rows[#rows + 1] = new_fish_row(id, mn:gsub('%s', ''), mx:gsub('%s', '')) end
        end
    end
    f:close()
    if #rows == 0 then note('no fish rows parsed from ' .. path); return end
    while #fish_rows > 0 do table.remove(fish_rows) end
    for _, r in ipairs(rows) do fish_rows[#fish_rows + 1] = r end
    loaded_area = area   -- '' if the file had no AREA= marker
    -- Remember the file's base name (strip directory + .txt) for the header.
    loaded_file_name = path:gsub('[/\\]+$', ''):match('([^/\\]+)$') or path
    loaded_file_name = loaded_file_name:gsub('%.[Tt][Xx][Tt]$', '')
    if area ~= '' then
        note(string.format('loaded %d fish (AREA=%s) from %s', #rows, area, loaded_file_name))
    else
        note(string.format('loaded %d fish (no AREA marker) from %s', #rows, loaded_file_name))
    end
end

-- Non-blocking file picker. Clicking Load writes a tiny PowerShell script,
-- launches it DETACHED (so the game keeps rendering -- no freeze), and the
-- dialog writes the chosen path to PATHS.PICK_RESULT. poll_pick() (called every
-- frame) picks that up when it appears and loads the table.
-- Folder layout (all under the addon dir):
--   /settings       -- pick.ps1 + dialog .result handshake files
--   /pool_timings   -- per-pool fight-time .txt files (Load/Save default here)
--   /data_tables    -- fish_tables.txt, rod_tables.txt (static reference data)
PATHS.SETTINGS_DIR   = addon.path .. 'settings/'
PATHS.POOL_DIR       = addon.path .. 'pool_timings/'
PATHS.DATA_DIR       = addon.path .. 'data_tables/'
-- Ensure the folders exist (fresh deploy / new fleet bot won't have them yet,
-- and the Save/Load dialog's Resolve-Path on pool_timings would otherwise throw).
for _, d in ipairs({ PATHS.SETTINGS_DIR, PATHS.POOL_DIR, PATHS.DATA_DIR }) do
    os.execute(string.format('mkdir "%s" 2>nul', d:gsub('/', '\\')))
end
PATHS.PICK_SCRIPT = PATHS.SETTINGS_DIR .. 'pick.ps1'
PATHS.PICK_RESULT = PATHS.SETTINGS_DIR .. 'pick.result'
local pick_pending = false

-- Save-dialog state (forward-declared here so poll_pick, defined below, can
-- close over them; the functions are assigned further down).
PATHS.SAVE_RESULT = PATHS.SETTINGS_DIR .. 'save.result'
local save_pending = false
local save_fish_file   -- forward decl

-- Polled every frame: if the dialog has written its result, load it.
local function poll_pick()
    -- Load dialog result
    if pick_pending then
        local f = io.open(PATHS.PICK_RESULT, 'r')
        if f then
            local path = f:read('*l')
            f:close()
            os.remove(PATHS.PICK_RESULT)
            pick_pending = false
            if path and path ~= '' then load_fish_file((path:gsub('%s+$', ''))) end
        end
    end
    -- Save dialog result
    if save_pending then
        local f = io.open(PATHS.SAVE_RESULT, 'r')
        if f then
            local path = f:read('*l')
            f:close()
            os.remove(PATHS.SAVE_RESULT)
            save_pending = false
            if path and path ~= '' then save_fish_file((path:gsub('%s+$', ''))) end
        end
    end
end

-- serialize_fish_table: render the current rows in load_fish_file's format
-- ("id,min,max" per line, with a comment header).
local function serialize_fish_table()
    local lines = {
        '# bovinefh fish table',
        '# format: fish_name,minSeconds,maxSeconds   ( # = comment )',
    }
    if loaded_area ~= '' then
        lines[#lines + 1] = 'AREA=' .. loaded_area
    end
    for _, r in ipairs(fish_rows) do
        local id = r.id and r.id[1] or ''
        local mn = r.min and r.min[1] or ''
        local mx = r.max and r.max[1] or ''
        if id ~= '' then
            lines[#lines + 1] = string.format('%s,%s,%s', id, mn, mx)
        end
    end
    return table.concat(lines, '\n') .. '\n'
end

save_fish_file = function(path)
    if path == nil or path == '' then return end
    local f = io.open(path, 'w')
    if not f then note('could not write: ' .. path); return end
    f:write(serialize_fish_table())
    f:close()
    -- Update the header label to the saved file's base name.
    loaded_file_name = path:gsub('[/\\]+$', ''):match('([^/\\]+)$') or path
    loaded_file_name = loaded_file_name:gsub('%.[Tt][Xx][Tt]$', '')
    note(string.format('saved %d fish to %s', #fish_rows, path))
end


-- Single dialog dispatcher (one upvalue for the GUI instead of two pickers).
--   open_dialog('load')  -> OpenFileDialog -> load_fish_file
--   open_dialog('save')  -> SaveFileDialog (OverwritePrompt) -> save_fish_file
local function open_dialog(kind)
    if kind == 'load' then
        if pick_pending or save_pending then return end
        os.remove(PATHS.PICK_RESULT)
        local ps = io.open(PATHS.PICK_SCRIPT, 'w')
        if not ps then note('could not write picker script'); return end
        ps:write(
            "Add-Type -AssemblyName System.Windows.Forms\n" ..
            "Set-Location -LiteralPath $PSScriptRoot\n" ..
            "$d = New-Object System.Windows.Forms.OpenFileDialog\n" ..
            "$d.Filter = 'Fish tables (*.txt)|*.txt|All files (*.*)|*.*'\n" ..
            "$d.Title = 'Select pool timing table'\n" ..
            "$d.InitialDirectory = (Resolve-Path (Join-Path $PSScriptRoot '..\\pool_timings')).Path\n" ..
            "$out = Join-Path $PSScriptRoot 'pick.result'\n" ..
            "if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {\n" ..
            "  Set-Content -Path $out -Value $d.FileName\n" ..
            "} else { Set-Content -Path $out -Value '' }\n")
        ps:close()
        os.execute('start "" /b powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "'
            .. PATHS.PICK_SCRIPT .. '"')
        pick_pending = true
        note('file picker open (game keeps running)...')
    elseif kind == 'save' then
        if pick_pending or save_pending then return end
        os.remove(PATHS.SAVE_RESULT)
        local default_name = (loaded_file_name or 'fishtable'):gsub('[\\/:%*%?"<>|]', '_')
        local ps = io.open(PATHS.PICK_SCRIPT, 'w')
        if not ps then note('could not write picker script'); return end
        ps:write(
            "Add-Type -AssemblyName System.Windows.Forms\n" ..
            "Set-Location -LiteralPath $PSScriptRoot\n" ..
            "$d = New-Object System.Windows.Forms.SaveFileDialog\n" ..
            "$d.Filter = 'Fish tables (*.txt)|*.txt|All files (*.*)|*.*'\n" ..
            "$d.Title = 'Save pool timing table'\n" ..
            "$d.InitialDirectory = (Resolve-Path (Join-Path $PSScriptRoot '..\\pool_timings')).Path\n" ..
            "$d.FileName = '" .. default_name .. ".txt'\n" ..
            "$d.OverwritePrompt = $true\n" ..
            "$d.AddExtension = $true\n" ..
            "$d.DefaultExt = 'txt'\n" ..
            "$out = Join-Path $PSScriptRoot 'save.result'\n" ..
            "if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {\n" ..
            "  Set-Content -Path $out -Value $d.FileName\n" ..
            "} else { Set-Content -Path $out -Value '' }\n")
        ps:close()
        os.execute('start "" /b powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "'
            .. PATHS.PICK_SCRIPT .. '"')
        save_pending = true
        note('save dialog open (game keeps running)...')
    end
end

----------------------------------------------------------------------------------------------------
-- Auto-update (GitHub)
----------------------------------------------------------------------------------------------------
-- Transport is the SAME idiom as the file pickers above: write a tiny .ps1,
-- launch it DETACHED, and poll for a result file from d3d_present. Nothing
-- blocks the render thread, so a slow or dead network can't hitch the game.
-- No sockets, no LuaSocket, no extra dependencies.
--
-- Endpoint is the GitHub CONTENTS API with the raw Accept header:
--   https://api.github.com/repos/<repo>/contents/<file>?ref=<branch>
-- One code path covers both cases -- public repo with no token, private repo
-- with a fine-grained PAT. (raw.githubusercontent.com would need a second path
-- for private repos, so we don't use it.)
--
-- All functions hang off `state` so they cost no top-level locals and add no
-- upvalues to the render closure.

-- Read the token: gitvar.dat first (addon root, then settings/), and only then
-- the inline state.UPDATE.token. Returns '' when there is none (public repo).
state.upd_token = function()
    if state.upd_token_cache ~= nil then return state.upd_token_cache end
    state.upd_token_cache = state.upd_token_read()
    return state.upd_token_cache
end

-- Uncached read. Split out so the panel can call state.upd_token() every frame
-- without touching the disk every frame -- the sidecar file is only re-read on
-- a reload, which is also when you'd have just edited it.
state.upd_token_read = function()
    -- Read the FIRST line only and strip all whitespace, so a trailing newline
    -- or a stray CR from a Windows editor can't end up inside the header value
    -- (which would fail auth with a confusing 401).
    for _, path in ipairs({ addon.path .. 'gitvar.dat',
                            PATHS.SETTINGS_DIR .. 'gitvar.dat' }) do
        local f = io.open(path, 'r')
        if f then
            local t = f:read('*l') or ''
            f:close()
            t = t:gsub('%s', '')
            if t ~= '' then return t end
        end
    end
    return (tostring(state.UPDATE.token or ''):gsub('%s', ''))
end

-- Pull `addon.version = 'x.y'` out of a chunk of Lua source.
state.upd_parse_version = function(src)
    if type(src) ~= 'string' then return nil end
    return src:match("addon%.version%s*=%s*['\"]([^'\"]+)['\"]")
end

-- Dotted-numeric compare. Returns -1 (a<b), 0 (equal), 1 (a>b). Non-numeric
-- segments compare as 0, so a garbage version never reads as "newer".
state.upd_vercmp = function(a, b)
    local function parts(v)
        local t = {}
        for n in tostring(v or ''):gmatch('[^%.]+') do t[#t + 1] = tonumber(n) or 0 end
        return t
    end
    local pa, pb = parts(a), parts(b)
    local n = math.max(#pa, #pb)
    for i = 1, n do
        local x, y = pa[i] or 0, pb[i] or 0
        if x < y then return -1 end
        if x > y then return 1 end
    end
    return 0
end

-- Kick off a check. Non-blocking: writes the script, launches it detached, and
-- returns immediately. state.upd_poll() picks up the result.
state.upd_check = function()
    local u = state.upd
    if u.pending then return end
    os.execute(string.format('mkdir "%s" 2>nul', state.UPDATE.dir:gsub('/', '\\')))
    os.remove(state.UPDATE.result)
    os.remove(state.UPDATE.payload)
    os.remove(state.UPDATE.ps)      -- never reuse a stale script

    local url = string.format('https://api.github.com/repos/%s/contents/%s?ref=%s',
        state.UPDATE.repo, state.UPDATE.file, state.UPDATE.branch)
    local token = state.upd_token()

    local ps = io.open(state.UPDATE.ps, 'w')
    if not ps then
        u.status, u.message = 'error', 'could not write update script'
        return
    end
    -- The TOKEN IS NEVER WRITTEN TO THIS FILE. It's handed to the child
    -- process through an environment variable set by the same cmd invocation
    -- that launches it, so the secret lives only in a transient process
    -- environment and never touches disk. (The first version inlined it into
    -- the script, which meant every check left a plaintext copy of the PAT in
    -- update/update.ps1 -- and that file is inside the repo tree.)
    -- Belt and braces: the script also deletes itself in a finally block.
    -- Single-quoted PS strings: no interpolation, so the URL can't be
    -- reinterpreted as code.
    ps:write(
        "$ErrorActionPreference = 'Stop'\n" ..
        "$out = '" .. state.UPDATE.payload .. "'\n" ..
        "$res = '" .. state.UPDATE.result  .. "'\n" ..
        "$loc = '" .. state.UPDATE.target  .. "'\n" ..
        -- GIT blob SHA-1, not a plain file hash: sha1("blob <len>\0" + bytes).
        -- Same value GitHub prints for a blob, so it can be eyeballed against
        -- the web UI. Computed here rather than in Lua because Ashita's Lua has
        -- no crypto and a pure-Lua SHA-1 would be ~100 lines for no gain.
        "function Get-BlobSha([string]$p) {\n" ..
        "  if (-not (Test-Path -LiteralPath $p)) { return '-' }\n" ..
        "  $b = [IO.File]::ReadAllBytes($p)\n" ..
        "  $hd = [Text.Encoding]::ASCII.GetBytes('blob ' + $b.Length + [char]0)\n" ..
        "  $a = New-Object byte[] ($hd.Length + $b.Length)\n" ..
        "  [Array]::Copy($hd,0,$a,0,$hd.Length)\n" ..
        "  [Array]::Copy($b,0,$a,$hd.Length,$b.Length)\n" ..
        "  $sh = [Security.Cryptography.SHA1]::Create()\n" ..
        "  return ((($sh.ComputeHash($a)) | ForEach-Object { $_.ToString('x2') }) -join '')\n" ..
        "}\n" ..
        "try {\n" ..
        "  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12\n" ..
        "  $h = @{ 'User-Agent' = 'bovinefh'; 'Accept' = 'application/vnd.github.raw' }\n" ..
        "  $tok = $env:BFH_GH_TOK\n" ..
        -- Record whether the header actually went out. A 404 on a private repo
        -- is identical whether the token was never sent or was sent and lacks
        -- access, so the error line has to say which -- otherwise there's no
        -- way to tell an addon-side handoff failure from a GitHub-side scope
        -- problem without hand-running the request.
        "  if ($tok) { $h['Authorization'] = 'Bearer ' + $tok; $sent = 'auth=sent' }\n" ..
        "  else { $sent = 'auth=MISSING' }\n" ..
        "  Invoke-WebRequest -Uri '" .. url .. "' -Headers $h -OutFile $out -UseBasicParsing\n" ..
        "  Set-Content -Path $res -Value ('OK ' + (Get-BlobSha $out) + ' ' + (Get-BlobSha $loc))\n" ..
        "} catch {\n" ..
        "  Set-Content -Path $res -Value ('ERR [' + $sent + '] ' + $_.Exception.Message)\n" ..
        "} finally {\n" ..
        "  Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue\n" ..
        "}\n")
    ps:close()

    -- `set` then `start` in one cmd invocation: the launched powershell
    -- inherits the variable. No token on the command line either, so it never
    -- shows up in a process list.
    local launch = 'start "" /b powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "'
        .. state.UPDATE.ps .. '"'
    if token ~= '' then
        launch = 'set "BFH_GH_TOK=' .. token .. '" && ' .. launch
    end
    os.execute(launch)
    u.pending  = true
    u.ready    = false
    u.remote_v = nil
    u.started  = os.clock()
    u.status   = 'checking'
    u.message  = 'checking ' .. state.UPDATE.repo .. '...'
end

-- Polled every frame from d3d_present. Reads the result file once the detached
-- script has written it, then compares versions. CHECK ONLY -- never writes to
-- the addon file. Times out after 30s so a hung powershell doesn't wedge us.
state.upd_poll = function()
    local u = state.upd
    if not u.pending then return end

    if (os.clock() - u.started) > 30.0 then
        u.pending = false
        u.status, u.message = 'error', 'timed out after 30s'
        return
    end

    local f = io.open(state.UPDATE.result, 'r')
    if not f then return end
    local line = f:read('*l') or ''
    f:close()
    os.remove(state.UPDATE.result)
    u.pending = false

    local auto = u.auto_apply
    u.auto_apply = false

    local err = line:match('^ERR%s*(.*)$')
    if err then
        -- 404 on a private repo almost always means the token is missing or
        -- lacks Contents: Read -- GitHub hides private repos rather than 403ing.
        if err:find('404') then
            if err:find('auth=MISSING', 1, true) then
                -- Token was loaded in Lua but never arrived at the child
                -- process: the env-var handoff failed, not GitHub.
                err = err .. '  -> token never reached the request'
            elseif state.upd_token() == '' then
                err = err .. '  (private repo? no gitvar.dat found)'
            else
                -- Sent and still 404: GitHub hides private repos it won't show
                -- you rather than returning 403, so this is a scope problem.
                err = err .. '  -> token sent but cannot see the repo (scope?)'
            end
        end
        u.status, u.message = 'error', err
        if auto then note('[update] check failed: ' .. err) end
        return
    end

    -- 'OK <remote_sha> <local_sha>'. Tolerates a bare 'OK' from an old script.
    u.sha_remote, u.sha_local = line:match('^OK%s+(%S+)%s+(%S+)')

    local pf = io.open(state.UPDATE.payload, 'rb')
    if not pf then
        u.status, u.message = 'error', 'download reported OK but no file landed'
        return
    end
    local remote = pf:read('*a') or ''
    pf:close()

    local rv = state.upd_parse_version(remote)
    if rv == nil or #remote < 1000 then
        u.status, u.message = 'error', 'downloaded file does not look like the addon'
        return
    end
    u.remote_v = rv

    -- CONTENT is the authority, not addon.version. A version string is just a
    -- number somebody remembered to bump. Byte equality is also strictly
    -- stronger than comparing hashes (no collision question at all), so the
    -- SHAs are for display and for matching against GitHub -- the decision
    -- below is made on the bytes.
    local lf = io.open(state.UPDATE.target, 'rb')
    local localsrc = lf and lf:read('*a') or ''
    if lf then lf:close() end

    local cmp = state.upd_vercmp(rv, addon.version)
    u.older = (cmp < 0)

    if localsrc ~= '' and localsrc == remote then
        u.ready   = false
        u.status  = 'uptodate'
        u.message = string.format('Up to date! (v%s, files identical)', addon.version)
        return
    end

    u.ready  = true
    u.status = 'available'
    if cmp > 0 then
        u.message = string.format('Update available: v%s (have v%s)', rv, addon.version)
    elseif cmp == 0 then
        u.message = string.format('Files differ, same version (v%s)', rv)
    else
        -- Remote is BEHIND local. Still offered, because content is the
        -- authority, but applying it is a downgrade -- never automatic.
        u.message = string.format('Remote is OLDER: v%s (have v%s) - applying = downgrade',
            rv, addon.version)
    end

    if auto then
        if u.older then
            note('[update] ' .. u.message .. ' -> auto-update SKIPPED (would downgrade)')
        else
            note('[update] ' .. u.message)
            state.upd_apply()
        end
    end
end

-- Apply the downloaded payload over the addon file and reload. Refuses while
-- the bot is running -- swapping the file out from under an active fishing run
-- would reload mid-cast and strand the line.
state.upd_apply = function()
    local u = state.upd
    if not u.ready then return end
    if auto_fish[1] then
        u.status, u.message = 'error', 'STOP the bot before updating'
        return
    end

    local pf = io.open(state.UPDATE.payload, 'rb')
    if not pf then
        u.status, u.message = 'error', 'no downloaded file - run Check first'
        return
    end
    local remote = pf:read('*a') or ''
    pf:close()

    -- Sanity gate. Never overwrite a working addon with a truncated download,
    -- an HTML error page, or somebody else's file.
    if #remote < 1000
       or state.upd_parse_version(remote) == nil
       or not remote:find("ADDON_NAME = '" .. ADDON_NAME .. "'", 1, true) then
        u.status, u.message = 'error', 'payload failed sanity check - not applied'
        return
    end

    -- Back up the current file first, timestamped, so a bad push is one copy
    -- away from being undone.
    local lf = io.open(state.UPDATE.target, 'rb')
    if lf then
        local cur = lf:read('*a')
        lf:close()
        -- 'wb' for the same reason as the target write below: a backup that
        -- silently gains a \r per line is not a backup you can restore from.
        local bk = io.open(state.UPDATE.dir .. ADDON_NAME .. '_v' .. addon.version
            .. '_' .. os.date('%Y%m%d-%H%M%S') .. '.lua.bak', 'wb')
        if bk then bk:write(cur); bk:close() end
    end

    -- BINARY on purpose. Windows text mode ('w') expands every \n to \r\n on
    -- write, so a CRLF payload lands as \r\r\n and an LF payload lands as
    -- \r\n. Either way the file on disk stops matching the blob GitHub served,
    -- and every later Check reports "files differ" forever with no way to
    -- converge. Read is 'rb' everywhere; the write has to match it.
    local wf = io.open(state.UPDATE.target, 'wb')
    if not wf then
        u.status, u.message = 'error', 'could not write ' .. state.UPDATE.target
        return
    end
    wf:write(remote)
    wf:close()

    u.ready   = false
    u.status  = 'applying'
    u.message = string.format('Updated to v%s, reloading...', u.remote_v or '?')
    note(u.message)
    -- Reload on the next command tick so this frame finishes cleanly first.
    AshitaCore:GetChatManager():QueueCommand(1, '/addon reload ' .. ADDON_NAME)
end

----------------------------------------------------------------------------------------------------
-- Persistence: bait/rod, toggles, and release filters survive reloads.
-- Same approach nomount.lua uses (a serialized Lua table at
-- addon.path/settings/settings.lua via io.open + load) -- NOT the Ashita
-- settings library, which neither of the working addons rely on.
-- auto_fish is intentionally NOT persisted -- the bot never auto-starts.
----------------------------------------------------------------------------------------------------

PATHS.SETTINGS_PATH = addon.path .. 'settings/settings.lua'
-- One-time migration source: the old sgtisaloser addon's config (same format
-- and keys). Used only if bovinefh has no settings of its own yet.
PATHS.OLD_SETTINGS = addon.path:gsub('[/\\]' .. ADDON_NAME .. '[/\\]?$', '')
    .. '/sgtisaloser/settings/settings.lua'
-- Shipped seed config. This one IS committed to the repo; settings.lua is not.
-- On a fresh clone there's no settings.lua, so load_cfg falls back to this and
-- the user starts with the maintained lists (friends / assholes / fish rows)
-- instead of bare defaults. From then on their own settings.lua wins and this
-- file is never read again -- so their edits are never overwritten by an update.
local SETTINGS_SEED = addon.path .. 'settings/settings.default.lua'

local defaults = {
    bait = 'Insect Ball', bait2 = 'Shrimp Lure', rod = 'Halcyon Rod',
    drop_name = '', skip_name = '', known_name = 'Tavnazian goby,Gold Carp',
    auto_move = false, auto_move_name = 'Tavnazian goby',
    auto_drop = false, stop_full = true, tell_watch = true, stop_moved = true,
    rand_timing = true, debug = true, recast_delay = true, extend_release = true,
    rel_monsters = true, rel_items = true, catch_jackpot = true, rel_terrible = false, rel_bad = false,
    rel_positive = false, rel_small = false, rel_large = false, catch_unknown = false,
    auto_update = false,
    -- These were previously absent, so apply_settings(defaults) left them at
    -- whatever the S declarations happened to hold. Load still worked, but a
    -- reset-to-defaults would have silently skipped them. Values here MUST
    -- track the S declarations above.
    shutdown_full = false, full_bot = false, pause_on_player = true,
    asshole_list = '', friends_list = '', sound_alerts = true,
    pause_pool = true, pool_low_thresh = false, swap_on_dead_pool = false,
}

-- Flat serializer: strings and booleans only (all our settings are one or
-- the other). Matches nomount's serialize_settings shape.
local function serialize_settings(data)
    local lines = { 'return {' }
    for k, v in pairs(data) do
        if type(v) == 'boolean' then
            lines[#lines + 1] = string.format('  %s = %s,', k, tostring(v))
        elseif type(v) == 'string' then
            lines[#lines + 1] = string.format('  %s = %q,', k, v)
        end
    end
    lines[#lines + 1] = '}'
    return table.concat(lines, '\n')
end

local function gather_settings()
    local t = {
        bait = S.bait_name[1], bait2 = S.bait2_name[1], rod = S.rod_name[1],
        drop_name = S.drop_name[1], skip_name = S.skip_name[1], known_name = S.known_name[1],
        auto_drop = S.auto_drop[1], stop_full = S.stop_full[1], shutdown_full = S.shutdown_full[1], full_bot = S.full_bot[1], pause_on_player = S.pause_on_player[1], asshole_list = S.asshole_list[1], friends_list = S.friends_list[1], tell_watch = S.tell_watch[1],
        stop_moved = S.stop_moved[1], auto_move = S.auto_move[1], auto_move_name = S.auto_move_name[1], rand_timing = S.rand_timing[1], sound_alerts = S.sound_alerts[1], pause_pool = S.pause_pool[1], pool_low_thresh = S.pool_low_thresh[1], swap_on_dead_pool = S.swap_on_dead_pool[1],
        debug = S.debug[1], auto_update = S.auto_update[1], recast_delay = state.recast_delay[1],
        extend_release = state.extend_release[1],
        rel_monsters = S.rel_monsters[1], rel_items = S.rel_items[1], catch_jackpot = S.catch_jackpot[1], rel_terrible = S.rel_terrible[1],
        rel_bad = S.rel_bad[1], rel_positive = S.rel_positive[1], rel_small = S.rel_small[1],
        rel_large = S.rel_large[1], catch_unknown = S.catch_unknown[1],
    }
    for i, r in ipairs(fish_rows) do
        t['fish' .. i .. '_id']  = r.id[1]
        t['fish' .. i .. '_min'] = r.min[1]
        t['fish' .. i .. '_max'] = r.max[1]
    end
    t.fish_count = tostring(#fish_rows)
    t.unk_min = unk_row.min[1]
    t.unk_max = unk_row.max[1]
    return t
end

-- Apply a (partial) settings table onto the widgets. Each field is only
-- written when present and the right type, so a missing/garbage key in the
-- file keeps the declared default rather than nil-ing a widget.
local function apply_settings(data)
    local function s(key, w) if type(data[key]) == 'string'  then w[1] = data[key] end end
    local function b(key, w) if type(data[key]) == 'boolean' then w[1] = data[key] end end
    s('bait', S.bait_name);     s('bait2', S.bait2_name);   s('rod', S.rod_name)
    s('drop_name', S.drop_name); s('skip_name', S.skip_name); s('known_name', S.known_name)
    b('auto_drop', S.auto_drop);   b('stop_full', S.stop_full);   b('shutdown_full', S.shutdown_full); b('full_bot', S.full_bot); b('pause_on_player', S.pause_on_player); s('asshole_list', S.asshole_list);   s('friends_list', S.friends_list);   b('tell_watch', S.tell_watch)
    b('stop_moved', S.stop_moved); b('auto_move', S.auto_move); s('auto_move_name', S.auto_move_name); b('rand_timing', S.rand_timing); b('sound_alerts', S.sound_alerts); b('pause_pool', S.pause_pool); b('pool_low_thresh', S.pool_low_thresh); b('swap_on_dead_pool', S.swap_on_dead_pool)
    b('debug', S.debug); b('auto_update', S.auto_update); b('recast_delay', state.recast_delay)
    b('extend_release', state.extend_release)
    b('rel_monsters', S.rel_monsters); b('rel_items', S.rel_items); b('catch_jackpot', S.catch_jackpot); b('rel_terrible', S.rel_terrible)
    b('rel_bad', S.rel_bad);       b('rel_positive', S.rel_positive); b('rel_small', S.rel_small)
    b('rel_large', S.rel_large);   b('catch_unknown', S.catch_unknown)
    -- Resize the fish table to the saved row count before restoring each row.
    local n = tonumber(data.fish_count)
    if n and n >= 0 then
        while #fish_rows > n do table.remove(fish_rows) end
        while #fish_rows < n do fish_rows[#fish_rows + 1] = new_fish_row() end
    end
    for i, r in ipairs(fish_rows) do
        s('fish' .. i .. '_id', r.id); s('fish' .. i .. '_min', r.min); s('fish' .. i .. '_max', r.max)
    end
    s('unk_min', unk_row.min); s('unk_max', unk_row.max)
end

local function save_cfg()
    local dir = addon.path .. 'settings'
    os.execute('mkdir "' .. dir .. '" 2>nul')
    local f = io.open(PATHS.SETTINGS_PATH, 'w')
    if f then
        f:write(serialize_settings(gather_settings()))
        f:close()
    else
        print('\31\200[bfh]\30\01 could not save settings to ' .. PATHS.SETTINGS_PATH)
    end
end

-- Deterministic signature of all settings (sorted keys) for change detection,
-- so config edits auto-save without needing START/STOP or a clean unload.
local function cfg_signature()
    local t = gather_settings()
    local keys = {}
    for k in pairs(t) do keys[#keys + 1] = k end
    table.sort(keys)
    local parts = {}
    for _, k in ipairs(keys) do parts[#parts + 1] = k .. '=' .. tostring(t[k]) end
    return table.concat(parts, '|')
end
local last_cfg_sig = nil   -- baseline set on first frame (loaded state)
local cfg_dirty_at = 0.0   -- os.clock() of the last change pending save (0 = none)

local function load_cfg()
    apply_settings(defaults)   -- baseline
    local f = io.open(PATHS.SETTINGS_PATH, 'r')
    if not f then
        -- First run for bovinefh: migrate the old sgtisaloser config if present.
        f = io.open(PATHS.OLD_SETTINGS, 'r')
        if f then note('first run -> migrating config from sgtisaloser') end
    end
    if not f then
        -- Fresh clone: seed from the committed default. Only ever reached when
        -- the user has no settings.lua of their own.
        f = io.open(SETTINGS_SEED, 'r')
        if f then note('first run -> seeding config from settings.default.lua') end
    end
    if not f then return end
    local src = f:read('*a')
    f:close()
    if not src or src == '' then return end
    local ok, data = pcall(function()
        local fn = load(src)
        return fn and fn()
    end)
    if ok and type(data) == 'table' then apply_settings(data) end
end

load_cfg()

-- Auto-fish pacing.
-- Base recast interval is RANDOMIZED per cycle (1-2s) rather than a flat
-- constant, so the cast cadence is never mechanical. cast_gap holds the value
-- chosen for the current cycle (see pick_cast_gap). The recast-delay jitter
-- (0.5-0.75s) is added on top later when that toggle is on.
TUNE.CAST_INTERVAL_MIN = 1.0
TUNE.CAST_INTERVAL_MAX = 2.0
local function pick_cast_gap()
    return TUNE.CAST_INTERVAL_MIN + math.random() * (TUNE.CAST_INTERVAL_MAX - TUNE.CAST_INTERVAL_MIN)
end
local cast_gap        = pick_cast_gap() -- the gap to wait before the next cast
local last_cast_clock = 0.0
TUNE.GEAR_SETTLE     = 5.0      -- wait this long after an equip before the next /fish
                                 -- (must exceed the cast gap or it'd be hidden;
                                 -- ~3s wasn't enough for the equip to register)
local gear_settle_until = 0.0    -- os.clock() the next cast may fire after an equip
local cast_pending = false       -- a /fish was sent; waiting for status to leave Idle

-- Randomized "extend" dwell (seconds) added on top of the base cast_gap each
-- time we return to Idle, when the Recast delay option is on. Gives a
-- gearswap addon a comfortable window to equip fishing gear before the next
-- cast, and adds a second layer of cadence variation.
TUNE.IDLE_JITTER_MIN = 0.5
TUNE.IDLE_JITTER_MAX = 0.75
-- When status last returned to Idle, and the cast-allowed time for THIS
-- Idle period (idle_since + cast_gap + jitter). The cast throttle paces
-- from here, NOT from the last cast: pacing from last_cast_clock meant any
-- fight longer than cast_gap left the gap already expired, so the next
-- cast fired the instant we hit Idle (zero dwell, no swap window).
local idle_since    = 0.0
local idle_cast_at  = 0.0
local cast_fail    = 0           -- consecutive casts that never registered
TUNE.CAST_FAIL_LIMIT = 3        -- stop after this many dead casts (broken keybind / can't fish)
-- Cast-stall watchdog: status 56 (Fishing) is the cast-in-progress state. It
-- normally resolves to a bite (57) or back to Idle (0) within a few seconds.
-- On a dead connection (e.g. the FFXI-3101 "Transmission error with lobby
-- server" popup) no packets arrive, status freezes at 56, and the bot would
-- otherwise sit in "Casting" forever -- the 0x00B char-select halt never fires
-- because the client hasn't zoned out. If status stays at 56 past this ceiling
-- with no advance, treat it as a stalled cast / lost connection and stop.
local cast_stall_at = 0.0        -- os.clock() status first entered 56 (0 = not casting)
TUNE.CAST_STALL_LIMIT = 30.0    -- secs at status 56 with no resolution -> stop
local bite_handled    = false    -- guards one catch/release action per bite
local bite_seen_at    = 0.0      -- os.clock() when status first hit FishBite (0 = none)
TUNE.BITE_GRACE      = 1.5      -- secs to wait for quality/depletion before deciding
TUNE.JACKPOT_MIN     = 1400     -- item NPC value at/above which Catch Jackpot keeps the item
local catch_action_at = 0.0      -- os.clock() when the catch was sent (0 = none pending)
local catch_at        = 0.0      -- os.clock() to send the catch (stamina fight delay)
local fight_start_clock = 0.0    -- os.clock() when the current fight began (for timing)
local catch_sent_clock  = 0.0    -- os.clock() the catch packet went out (0 = none this fight)
local status_capture_until = 0.0 -- while os.clock() < this, log incoming packets to statusdebug.txt
-- Most recent copies of the two packets that resolve a catch (end the fishing
-- animation / finalize the line). Captured live from the incoming stream and
-- re-injected client-side by the Recovery button when the client misses them
-- and gets stuck in the fishing stance. 0x037 = char status (animation reset),
-- 0x01E = inventory finalize. Stored as byte strings, replayed via AddIncomingPacket.
local last_0x037_bytes = nil
local last_0x01E_bytes = nil
local fight_fish_id     = 0      -- FishID snapshot at fight start (0x115 is cleared post-catch)
local fight_fish_name   = nil    -- resolved fish NAME at fight start (rod-independent)
local fight_fish_ambig  = nil    -- collision list {n1,n2,..} when key is ambiguous in-zone
-- Display string: "Goby" normally, or "Goby or Noble Lady" when the in-zone key
-- is ambiguous between multiple fish.
-- Title-case a display name so casing is consistent no matter which path
-- produced it ("gold carp" / "Gold Carp" both -> "Gold Carp"). Capitalizes the
-- first letter of each word but NOT letters following an apostrophe (so
-- "Lu Shang's" stays correct, not "Lu Shang'S"). The lowercase " or " joiner
-- used for ambiguous pairs is preserved by capitalizing per-name, not on the
-- joined string.
local function titlecase(s)
    if not s or s == '' then return s end
    -- Title-case: capitalize the first letter of every word, lowercasing the
    -- rest. Word boundary = start of string or after a space (apostrophes are
    -- left alone so "Lu Shang's" stays correct, not "Lu Shang'S").
    s = tostring(s):lower()
    return (s:gsub('()(%a)', function(pos, ch)
        if pos == 1 then return ch:upper() end
        if s:sub(pos - 1, pos - 1) == ' ' then return ch:upper() end
        return ch
    end))
end

local function fish_display()
    if fight_fish_ambig and #fight_fish_ambig > 1 then
        local t = {}
        for _, n in ipairs(fight_fish_ambig) do t[#t + 1] = titlecase(n) end
        return table.concat(t, ' or ')   -- join AFTER per-name casing
    end
    return fight_fish_name and titlecase(fight_fish_name) or '?'
end
local catch_resent    = 0        -- 0/1/2: how many fast resends have fired this bite
-- catch_resend_gap lives on state (upvalue cap); see state.catch_resend_gap
-- Release watchdog (bundled in one table to keep upvalue count down). 'at' is
-- the os.clock() the release packet actually fired (set inside the delayed
-- task, not at the decision). Resend at most twice if still at FishBite -- one
-- quick (3s), one longer (10s) -- then give up and stop (never loops forever).
local relw = { at = 0.0, tries = 0, due = 0.0 }
TUNE.RELEASE_FIRST   = 3.0      -- secs before the first (quick) release resend
TUNE.RELEASE_CD      = 10.0     -- secs before the second (longer) resend / final give-up
TUNE.RELEASE_MAX     = 2        -- cap: one quick resend, one longer resend, then stop
local logged_in       = true     -- false at char select (0x00B); gates auto-fish
local current_player_name = ''   -- live player name, refreshed each frame from GetPlayerEntity
local fail_streak = 0            -- consecutive no_bait / no_rod errors
TUNE.FAIL_LIMIT  = 3            -- trigger a retry after this many in a row
local reject_streak = 0          -- consecutive "command rejected" (zoning / lag / too-fast)
TUNE.REJECT_LIMIT  = 5          -- tolerate transient rejects; retry only after this many
TUNE.RETRY_COOLDOWN = 90.0      -- seconds to wait before an auto-retry (long reset)
TUNE.RETRY_MAX      = 5         -- give up for good after this many retries
local retry_attempts  = 0        -- retries used; resets to 0 on any accepted bite
local retry_resume_at = 0.0      -- os.clock() to resume casting (0 = not waiting)
local active_bait_slot  = 1      -- 1 = primary bait, 2 = backup (after a no_bait swap)
local current_bait               -- forward decl: defined below, called by send_cast above it
local last_retry_reason = nil    -- reason of the pending retry (drives the bait swap)
local move_base = nil            -- {x,y,z} baseline captured when fishing starts
TUNE.MOVE_TOLERANCE = 0.5       -- units; FFXI positions wobble slightly when still
local consec_bad = 0             -- consecutive releases OR no-catches (one shared streak)
TUNE.SAFETY_STREAK_LIMIT = 5    -- bad results (release/miss) in a row -> cooldown
-- Safety cooldown is a randomized 3-5s anti-flag hold that fires ONLY after a
-- streak of TUNE.SAFETY_STREAK_LIMIT bad results in a row. It is NOT the per-cast
-- dwell (that's the 0.5-0.75s IDLE_JITTER recast delay above). It's armed via
-- state.safety_cooldown_pending and the timer starts when we next return to
-- Idle, so the hold begins AFTER the fish animation finishes.
local safety_resume_at = 0.0     -- os.clock() to resume after the safety cooldown
TUNE.TELL_WINDOW = 90           -- seconds for the rolling tell window
TUNE.TELL_LIMIT  = 2            -- tells inside the window that trip the response
TUNE.TELL_PAUSE  = 15 * 60      -- pause this long on the first tell burst (15 min)
-- Tell state in one table -- keeps the render function under Lua's 60-upvalue cap.
local tellp = {
    times        = {},    -- os.time() of recent incoming tells
    pause_until  = 0.0,   -- os.clock() to resume after a tell pause (0 = none)
    regime_start = 0.0,   -- os.clock() the current tell-pause regime began
    hard_stop    = false, -- a hard stop is queued; runs once the fight resolves
}

-- Pool depletion cooldown: if the fish-bite ratio across the last WINDOW
-- casts drops below THRESHOLD, the spot's fished out -- pause for PAUSE
-- to let it regen. Only casts feed the ring (fish = 1, item/monster/lost = 0),
-- so wall-clock pauses can't dilute it AND non-target species (say,
-- grindylow when we're minnow-fishing goby) still count as fish -- the
-- pool as a whole is what regens, not one species. Gated by S.pause_pool.
-- Evaluation starts at EARLY_MIN casts so we don't burn the full window
-- before recognising an obviously dead spot (partial-fill ratio math is
-- handled below). Kept on `state` to spare the module's 200-local budget.
state.pool = {
    WINDOW    = 25,
    EARLY_MIN = 18,   -- start evaluating once we've got at least this many casts
    THRESHOLD_HIGH = 0.30,  -- default: common/mid fish, plenty of bites expected
    THRESHOLD_LOW  = 0.15,  -- rare/tough fish, natural ratio is lower so trigger later
    PAUSE     = 20 * 60,
    ring      = {},   -- last WINDOW cast outcomes (1 = fish, 0 = item/monster/no-bite)
    i         = 1,    -- next write index
    n         = 0,    -- current fill (up to WINDOW)
    resume_at = 0.0,  -- os.clock() to resume after the cooldown
    pending   = false,-- true from cast fire until the outcome is recorded (bite or lost)
}

-- Push one cast outcome (by kind) and arm the pool cooldown if the rolling
-- fish ratio drops below threshold. Fish = 1, everything else = 0
-- (item / monster / no-bite lost_catch). Called from the bite decision
-- site with state.bite.kind and from the terminal status site with nil
-- when the cast resolved without a bite.
state.record_bite_outcome = function(kind)
    if not S.pause_pool[1] then return end
    local p = state.pool
    p.pending = false
    p.ring[p.i] = (kind == 'fish') and 1 or 0
    p.i = (p.i % p.WINDOW) + 1
    if p.n < p.WINDOW then p.n = p.n + 1 end
    -- Evaluate as soon as we've got EARLY_MIN samples so an obviously dead
    -- spot doesn't have to burn the full window before we bail.
    if p.n < p.EARLY_MIN then return end
    -- Sum only the filled portion (p.n slots) so partial fills report the
    -- true ratio -- summing across the whole WINDOW would count nil slots
    -- as 0 and drag the ratio down artificially.
    local sum = 0
    for k = 1, p.n do sum = sum + (p.ring[k] or 0) end
    local ratio = sum / p.n
    local thresh = S.pool_low_thresh[1] and p.THRESHOLD_LOW or p.THRESHOLD_HIGH
    if ratio < thresh and p.resume_at == 0 then
        local samples = p.n
        -- Reset the ring first, so any rotation/pause starts with a fresh window.
        p.ring = {}; p.i = 1; p.n = 0
        -- If the user wants us to try bait 2 before resting, and it hasn't been
        -- tried already for this depletion event, attempt the swap. If the swap
        -- goes through we stay fishing on bait 2 (log the reason, no pause);
        -- if bait 2 can't help (empty, same as bait 1, already active, or we've
        -- already rotated once), fall through to the normal pause.
        if S.swap_on_dead_pool[1] and not p.rotated_this_run
           and state.try_bait2_rotation
           and state.try_bait2_rotation(string.format(
               'pool depleted (%.0f%% fish < %.0f%% over last %d casts)',
               ratio * 100, thresh * 100, samples)) then
            p.rotated_this_run = true
            return
        end
        p.resume_at = os.clock() + p.PAUSE
        note(string.format('pool depleted (%.0f%% fish < %.0f%% over last %d casts) -> pause %dm',
            ratio * 100, thresh * 100, samples, p.PAUSE / 60))
        if state.pause_now then state.pause_now('pool depleted') end
    end
end

-- Current fish ratio over the ring, as a percentage (0-100). Returns nil
-- if the ring is empty (nothing to show yet).
state.pool_ratio_pct = function()
    local p = state.pool
    if p.n == 0 then return nil end
    local sum = 0
    for k = 1, p.n do sum = sum + (p.ring[k] or 0) end
    return (sum / p.n) * 100
end

----------------------------------------------------------------------------------------------------
-- Output helper
----------------------------------------------------------------------------------------------------

-- Fire-and-forget WAV playback via Ashita's native play_sound (Windows
-- PlaySound API, async).
--
-- Diagnostic behavior: PlaySound plays the Windows default sound (a beep)
-- when it can't load the file, so a beep = call succeeded but file failed
-- to load. We check the file exists in Lua first (io.open) and, on miss,
-- print the exact path we tried instead of calling play_sound (no beep).
-- If the file IS found and PlaySound still beeps, the WAV format is the
-- problem: PlaySound only handles uncompressed PCM WAV (no float, no
-- codecs). Re-export as 16-bit PCM in that case.
--
-- Lives on `state` (not a local) because the main-chunk 200-locals ceiling
-- is already crowded -- same reason S bundles GUI toggles.
state.play_alert = function(name)
    if not S.sound_alerts[1] then return end
    -- Guarantee a trailing separator (some Ashita builds don't include one)
    -- and force backslashes, which Win32 file APIs are happiest with.
    local base = addon.path
    local last = base:sub(-1)
    if last ~= '/' and last ~= '\\' then base = base .. '\\' end
    local path = (base .. name):gsub('/', '\\')
    -- Existence check: if the file isn't there, don't hand PlaySound
    -- something bad -- it would beep and mask the real problem.
    local f = io.open(path, 'rb')
    if not f then
        note('[sound] MISSING file: ' .. path)
        return
    end
    f:close()
    pcall(function() ashita.misc.play_sound(path) end)
end

-- state.stop_now / state.pause_now / state.end_current_fishing_event are
-- assigned further down, after inject_release_packet exists. Fields on the
-- `state` table don't count against the 200-locals ceiling and forward-decl
-- naturally (nil until assigned; nobody calls them at module-load time).

-- Why auto-fish last stopped (nil = never / manual). Shown on the button.
local stop_reason = nil
local function stop_fishing(reason)
    auto_fish[1] = false
    stop_reason  = reason
    cast_stall_at = 0   -- clear the cast-stall watchdog
    note('stopped: ' .. reason)
end

-- A greyed (?) after the previous widget that shows a tooltip on hover.
local function help_marker(text)
    imgui.SameLine()
    imgui.TextDisabled('(?)')
    if imgui.IsItemHovered() then
        imgui.SetTooltip(text)
    end
end

----------------------------------------------------------------------------------------------------
-- Bait / lure / rod pick-lists (in-game names) for the GUI dropdowns
----------------------------------------------------------------------------------------------------
-- type 0 = BAIT (consumed per catch); type 1 = LURE (reusable). Split so the
-- dropdown groups them. Sourced from the fishing_bait table.
local BAIT_LIST = {
    'Crayfish Ball', 'Insect Ball', 'Sardine Ball', 'Trout Ball',
    'Dried Squid', 'Drill Calamary', 'Dwarf Pugil', 'Giant Shell Bug',
    'Goliath Worm', 'Little Worm', 'Lufaise Fly', 'Lugworm', 'Meatball',
    'Peeled Crayfish', 'Peeled Lobster', 'Rotten Meat', 'Sea Dragon Liver',
    'Shell Bug', 'Slice of Bluetail', 'Sliced Cod', 'Slice of Carp',
    'Sliced Sardine', 'Super Scoop',
}
local LURE_LIST = {
    'Fly Lure', 'Frog Lure', 'Lizard Lure', 'Minnow', 'Robber Rig',
    'Rogue Rig', 'Sabiki Rig', 'Shrimp Lure', 'Sinking Minnow', 'Worm Lure',
}
local ROD_LIST = {
    "Lu Shang's F. Rod", 'Lu Sh. F. Rod +1',
    'Glass Fiber F. Rod', 'S.H. Fishing Rod', 'Carbon Fish. Rod',
    'Comp. Fishing Rod', 'Halcyon Rod', 'Tarutaru F. Rod',
    'Fastwater F. Rod', 'Hume Fishing Rod', 'Mithran Fish. Rod',
    'Bamboo Fish. Rod', 'Yew Fishing Rod', 'Clothespole',
    'Ebisu Fishing Rod', 'Ebisu F. Rod +1', 'Goldfish Basket',
    'Willow Fish. Rod',
}

-- A combo (dropdown) over a flat list. Writes the chosen string into buf[1].
-- Keeps the current value selectable even if it's not in the list (custom).
local function combo_box(label, buf, list)
    local current = buf[1] or ''
    if imgui.BeginCombo(label, current) then
        for _, name in ipairs(list) do
            local selected = (name == current)
            if imgui.Selectable(name, selected) then
                buf[1] = name
            end
            if selected then imgui.SetItemDefaultFocus() end
        end
        imgui.EndCombo()
    end
end

-- A combo for BAIT slots: shows two labelled groups (Baits, then Lures) in one
-- dropdown so you can pick either kind for a slot. Headers are non-selectable.
local function combo_bait(label, buf)
    local current = buf[1] or ''
    if imgui.BeginCombo(label, current) then
        imgui.TextDisabled('-- Baits --')
        for _, name in ipairs(BAIT_LIST) do
            local selected = (name == current)
            if imgui.Selectable(name, selected) then buf[1] = name end
            if selected then imgui.SetItemDefaultFocus() end
        end
        imgui.Separator()
        imgui.TextDisabled('-- Lures --')
        for _, name in ipairs(LURE_LIST) do
            local selected = (name == current)
            if imgui.Selectable(name, selected) then buf[1] = name end
            if selected then imgui.SetItemDefaultFocus() end
        end
        imgui.EndCombo()
    end
end

----------------------------------------------------------------------------------------------------
-- Chat classification
----------------------------------------------------------------------------------------------------

-- KEEN ANGLER'S SENSE. On a critical bite the server sends an extra line that
-- NAMES the catch outright: "Your keen angler's senses tell you that this is
-- the pull of a bluetail!"  (LSB FISHINGSENSETYPE_KEEN_ANGLERS_SENSE, pushed
-- via TALKNUMWORK carrying response->catchid, so the client renders the real
-- name.) classify_bite knows only four strings, none of them this one, so a
-- critical bite left bite_kind nil and resolve_fish_name bailed at its first
-- gate -- predict=? with a perfectly correct fish row and rod attack.
--
-- The name here is ground truth and beats the dep_x20 resolver outright: no rod
-- table, no bait list, no difficulty lookup, and no ambiguity when two fish tie
-- on a key. Returns the name lowercase, or nil.
--
-- On `state`, not a top-level local: one more local overflows Lua 5.1's
-- 200-local cap on the main chunk (verified, luac refuses to compile).
state.keen_sense_name = function(text)
    return text:match("keen angler's senses tell you that this is the pull of an? (.-)!")
        or text:match('keen angler.s senses tell you that this is the pull of an? (.-)!')
end

local function classify_bite(text)
    if text:find(BITE_STRINGS.monster, 1, true)    then return 'monster' end
    if text:find(BITE_STRINGS.item, 1, true)       then return 'item' end
    if text:find(BITE_STRINGS.fish_large, 1, true) then return 'fish_large' end
    if text:find(BITE_STRINGS.fish_small, 1, true) then return 'fish_small' end
    return nil
end

local function classify_end(text)
    for _, row in ipairs(END_STRINGS) do
        if text:find(row[2], 1, true) then return row[1] end
    end
    return nil
end

local function classify_quality(text)
    if text:find(QUALITY_STRINGS.terrible, 1, true) then return 'terrible' end
    if text:find(QUALITY_STRINGS.bad,      1, true) then return 'bad'      end
    if text:find(QUALITY_STRINGS.good,     1, true) then return 'good'     end
    if text:lower():find('positive', 1, true)       then return 'positive' end
    return nil
end

-- Strip FFXI in-chat color/format codes (2-byte pairs led by 0x1E/0x1F/0x7F).
local function strip_codes(s)
    return (s:gsub('[\030\031\127].', ''))
end

local function trim(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
end

-- Tell / mention capture. Writes the full cleaned line to a separate dated
-- file (bovinefh_tells_<date>.log) so incoming /tells and any line that names
-- the current character are never lost to an AFK session. The "mention" needle
-- is the first 3 letters of the live player name (lowercased) rather than a
-- hard-coded handle, so the file/needle don't reveal which character this is.
local function tell_log(tag, text)
    if not log_dir_ready then
        os.execute(string.format('mkdir "%s" 2>nul', PATHS.LOG_DIR:gsub('/', '\\')))
        log_dir_ready = true
    end
    local f = io.open(PATHS.LOG_DIR .. 'bovinefh_tells_' .. os.date('%Y-%m-%d') .. '.log', 'a')
    if f == nil then return end
    f:write(string.format('[%s] [%s] %s\n', os.date('%Y-%m-%d %H:%M:%S'), tag, text))
    f:close()
end

-- Append a line to the SEPARATE GM log only. Called once per GM line (in
-- addition to that line's normal tell/say entry in the main log), so GM contact
-- is collected in one place for context without duplicating it in the main log.
state.gm_log = function(text)
    if not log_dir_ready then
        os.execute(string.format('mkdir "%s" 2>nul', PATHS.LOG_DIR:gsub('/', '\\')))
        log_dir_ready = true
    end
    local g = io.open(PATHS.LOG_DIR .. 'bovinefh_GM_' .. os.date('%Y-%m-%d') .. '.log', 'a')
    if g == nil then return end
    g:write(string.format('[%s] %s\n', os.date('%Y-%m-%d %H:%M:%S'), text))
    g:close()
end

-- Lowercased first-3-letters needle for the live player name. Empty until the
-- name is known (char select / not yet logged in).
local function name_needle()
    local n = current_player_name
    if type(n) ~= 'string' or #n < 3 then return nil end
    return n:sub(1, 3):lower()
end

local function extract_catch_name(text, player_name)
    if player_name == nil or player_name == '' then return nil end
    local clean = strip_codes(text)
    for _, pat in ipairs(CATCH_PATTERNS) do
        local who, what = clean:match(pat)
        if who and what and what ~= '' then
            who  = trim(who)
            what = trim(what)
            if who == player_name or who:sub(-#player_name) == player_name then
                return what
            end
        end
    end
    return nil
end

local function clear_bite_latch()
    state.bite.kind      = nil
    state.bite.fish_size = nil
    state.bite.quality   = nil
    state.bite.text      = ''
    state.bite.time      = 0
    state.packet_0x115.captured = false
    state.packet_0x115.stamina  = 0
    relw.due = 0.0   -- cancel any pending release countdown for this bite
end

----------------------------------------------------------------------------------------------------
-- Sends: commands + keys
----------------------------------------------------------------------------------------------------

-- Current zone as "Name (id)" for tagging the cast log. Reads the party
-- member-0 zone id (the local player) and resolves the name via resources.
-- Falls back to just the id, or '?' if memory isn't ready.
local function current_region()
    local ok, id = pcall(function()
        return AshitaCore:GetMemoryManager():GetParty():GetMemberZone(0)
    end)
    if not ok or id == nil then return '?' end
    local name = nil
    local okn, res = pcall(function()
        return AshitaCore:GetResourceManager():GetString('zones.names', id)
    end)
    if okn and res ~= nil and res ~= '' then name = res end
    if name then return string.format('%s (%d)', name, id) end
    return tostring(id)
end

-- Normalize an item name for comparison: drop embedded nulls (FFXI resource
-- strings are fixed-width and can be null/space padded), trim, lowercase.
local function clean_name(s)
    if type(s) ~= 'string' then return '' end
    s = s:gsub('%z', ''):gsub('^%s+', ''):gsub('%s+$', '')
    -- Apostrophe fail-safe: FFXI/the client may return item names with a
    -- typographic apostrophe (U+2019, UTF-8 E2 80 99) or other variants, while
    -- our tables use ASCII '. Fold them all to ASCII ' so names like
    -- "Lu Shang's F. Rod" match no matter which apostrophe glyph is used.
    s = s:gsub('\226\128\153', "'")   -- U+2019 right single quote
          :gsub('\226\128\152', "'")   -- U+2018 left single quote
          :gsub('\239\188\135', "'")   -- U+FF07 fullwidth apostrophe
          :gsub('`', "'")              -- backtick
          :gsub('\180', "'")           -- acute accent (Latin-1 0xB4)
    return s:lower()
end

-- ===================================================================
-- DATA TABLES: fish difficulties + rod fishAttack, loaded from
-- /data_tables. These let us turn the rod-dependent 0x115 "key" value
-- into a real FISH NAME at hook time, so everything downstream keys on
-- names (rod-independent) instead of brittle per-rod numeric IDs.
--
-- The 0x115 carries dep_x20 = the server's "arrow damage", computed as:
--   CalculateAttack = floor( diff * ((fishAttack + lgdBonus)/100.0f) * 20.0f )
-- The server does this in 32-bit FLOAT, dividing by 100 FIRST. Double-precision
-- Lua math (diff*fa/100*20) can round one off (e.g. diff26/fa70 -> 364 vs the
-- server's 363). We replicate the float32 arithmetic exactly so our predicted
-- dep_x20 matches the packet bit-for-bit -- no tolerance/smudging needed.
-- ===================================================================
-- The exact server arrow-damage (dep_x20) for a fish difficulty + rod
-- fishAttack is floor( diff * ((fa+lgdBonus)/100.0f) * 20.0f ), all in float32.
-- Defined on the `state` table (state.arrow_dmg) so it adds no top-level local
-- (Lua caps a function at 200 locals). See state definition above.

DB.fish_diff   = {}   -- lowercased name -> difficulty
DB.diff_to_fish = {}  -- difficulty -> { name, name, ... }  (collision list)
DB.fish_areas  = {}   -- lowercased name -> { lowercased area, ... }
DB.area_fish   = {}   -- lowercased area -> { original-case name, ... }
DB.fish_baits  = {}   -- lowercased name -> { lowercased bait, ... } or {'any'}
DB.fish_type   = {}   -- lowercased name -> 'small'|'large'|'item' (legendary suffix kept separately)
DB.fish_legend = {}   -- lowercased name -> true if legendary
DB.fish_value  = {}   -- lowercased name -> NPC value (items only; fish default 0)
DB.rod_attack  = {}   -- lowercased rod name -> fishAttack
DB.data_tables_ready = false
DB.equipped_item_name = nil  -- forward decl: filled below; used by current_rod_attack

local function load_data_tables()
    -- fish_tables.txt : fishid,name,skill,difficulty,base_delay,base_move,disabled,areas,baits
    -- areas = ; -separated zones ; baits = ; -separated bait names or 'ANY'.
    local ff = io.open(PATHS.DATA_DIR .. 'fish_tables.txt', 'r')
    if ff then
        for line in ff:lines() do
            if line:sub(1,1) ~= '#' and not line:lower():find('^fishid') then
                local cols = {}
                for c in (line .. ','):gmatch('([^,]*),') do cols[#cols+1] = c end
                local oname = cols[2]
                local name = oname and clean_name(oname) or nil
                local diff = cols[4] and tonumber(cols[4]) or nil
                local areas = cols[8] or ''
                local baits = cols[9] or ''
                if name and name ~= '' and diff then
                    DB.fish_diff[name] = diff
                    DB.diff_to_fish[diff] = DB.diff_to_fish[diff] or {}
                    DB.diff_to_fish[diff][#DB.diff_to_fish[diff]+1] = oname
                    DB.fish_areas[name] = {}
                    for az in tostring(areas):gmatch('([^;]+)') do
                        local a = clean_name(az)
                        if a ~= '' then
                            DB.fish_areas[name][#DB.fish_areas[name]+1] = a
                            DB.area_fish[a] = DB.area_fish[a] or {}
                            DB.area_fish[a][#DB.area_fish[a]+1] = oname
                        end
                    end
                    DB.fish_baits[name] = {}
                    for bz in tostring(baits):gmatch('([^;]+)') do
                        local b = clean_name(bz)
                        if b ~= '' then DB.fish_baits[name][#DB.fish_baits[name]+1] = b end
                    end
                    local ftype = cols[10] and clean_name(cols[10]) or ''
                    DB.fish_legend[name] = ftype:find('legendary') ~= nil
                    if ftype:find('item') then DB.fish_type[name] = 'item'
                    elseif ftype:find('large') then DB.fish_type[name] = 'large'
                    elseif ftype:find('small') then DB.fish_type[name] = 'small'
                    else DB.fish_type[name] = '' end
                end
            end
        end
        ff:close()
    else
        note('WARN: /data_tables/fish_tables.txt not found - name resolution off')
    end
    -- item_tables.txt : fishid,name,skill,difficulty,base_delay,base_move,disabled,areas,baits,npc
    -- Loaded into the SAME maps with type='item'; the resolver's type filter
    -- (item-bite only matches type=='item') keeps them separate from fish.
    local itf = io.open(PATHS.DATA_DIR .. 'item_tables.txt', 'r')
    if itf then
        for line in itf:lines() do
            if line:sub(1,1) ~= '#' and not line:lower():find('^fishid') then
                local cols = {}
                for c in (line .. ','):gmatch('([^,]*),') do cols[#cols+1] = c end
                local oname = cols[2]
                local name = oname and clean_name(oname) or nil
                local diff = cols[4] and tonumber(cols[4]) or nil
                local areas = cols[8] or ''
                local baits = cols[9] or ''
                if name and name ~= '' and diff then
                    DB.fish_diff[name] = diff
                    DB.fish_type[name] = 'item'
                    DB.fish_value[name] = cols[10] and tonumber(cols[10]) or 0
                    DB.fish_areas[name] = {}
                    for az in tostring(areas):gmatch('([^;]+)') do
                        local a = clean_name(az)
                        if a ~= '' then
                            DB.fish_areas[name][#DB.fish_areas[name]+1] = a
                            DB.area_fish[a] = DB.area_fish[a] or {}
                            DB.area_fish[a][#DB.area_fish[a]+1] = oname
                        end
                    end
                    DB.fish_baits[name] = {}
                    for bz in tostring(baits):gmatch('([^;]+)') do
                        local b = clean_name(bz)
                        if b ~= '' then DB.fish_baits[name][#DB.fish_baits[name]+1] = b end
                    end
                end
            end
        end
        itf:close()
    end
    -- monster_tables.txt : monid,name,skill,difficulty,base_delay,base_move,disabled,areas,baits,type
    -- Same maps, type='monster'. The resolver's monster-bite path matches only
    -- type=='monster' so monsters stay separate from fish/items. Lets a released
    -- (or hooked) monster resolve to its NAME via dep_x20 like any fish.
    local mtf = io.open(PATHS.DATA_DIR .. 'monster_tables.txt', 'r')
    if mtf then
        for line in mtf:lines() do
            if line:sub(1,1) ~= '#' and not line:lower():find('^monid') then
                local cols = {}
                for c in (line .. ','):gmatch('([^,]*),') do cols[#cols+1] = c end
                local oname = cols[2]
                local name = oname and clean_name(oname) or nil
                local diff = cols[4] and tonumber(cols[4]) or nil
                local areas = cols[8] or ''
                local baits = cols[9] or ''
                if name and name ~= '' and diff then
                    DB.fish_diff[name] = diff
                    DB.fish_type[name] = 'monster'
                    DB.fish_areas[name] = {}
                    for az in tostring(areas):gmatch('([^;]+)') do
                        local a = clean_name(az)
                        if a ~= '' then
                            DB.fish_areas[name][#DB.fish_areas[name]+1] = a
                            DB.area_fish[a] = DB.area_fish[a] or {}
                            DB.area_fish[a][#DB.area_fish[a]+1] = oname
                        end
                    end
                    DB.fish_baits[name] = {}
                    for bz in tostring(baits):gmatch('([^;]+)') do
                        local b = clean_name(bz)
                        if b ~= '' then DB.fish_baits[name][#DB.fish_baits[name]+1] = b end
                    end
                end
            end
        end
        mtf:close()
    end
    -- rod_tables.txt : rodid,name,fishAttack,raw_columns
    local rf = io.open(PATHS.DATA_DIR .. 'rod_tables.txt', 'r')
    if rf then
        for line in rf:lines() do
            if line:sub(1,1) ~= '#' and not line:lower():find('^rodid') then
                local cols = {}
                for c in (line .. ','):gmatch('([^,]*),') do cols[#cols+1] = c end
                local name = cols[2] and clean_name(cols[2]) or nil
                local fa   = cols[3] and tonumber(cols[3]) or nil
                -- Do NOT "correct" fa from raw_columns field 6. Field 6 is the
                -- LSB/retail value; Horizon applies a -30 offset to rod fish
                -- attack and the fishAttack column already carries the Horizon
                -- value (Lu Shang's 110 -> 80). Verified against live 0x115
                -- keys: 24 diff * 80 / 100 * 20 = 384 -> key 19.
                if name and name ~= '' and fa then
                    DB.rod_attack[name] = fa
                    -- Legendary bonus attack: on legendary fish the server adds
                    -- this to fishAttack (e.g. Lu Shang's 80 -> 100 on legendary
                    -- fish). It lives in raw_columns field 7 (after the quote:
                    -- material,size,flags,min_rank,max_rank,fish_attack,LGD_BONUS,..).
                    -- Extract the quoted raw block and read field 7.
                    state.rod_lgd = state.rod_lgd or {}
                    local raw = line:match('"([^"]*)"')
                    if raw then
                        local rc = {}
                        for v in (raw .. ','):gmatch('([^,]*),') do rc[#rc+1] = v end
                        local lgd = rc[7] and tonumber(rc[7]) or 0
                        state.rod_lgd[name] = lgd or 0
                    end
                end
            end
        end
        rf:close()
    else
        note('WARN: /data_tables/rod_tables.txt not found - name resolution off')
    end
    DB.data_tables_ready = (next(DB.fish_diff) ~= nil and next(DB.rod_attack) ~= nil)
end

-- Current rod's fishAttack, read live from the equipped slot at start/hook.
-- Returns: fa, base_name, matched(boolean). matched=false means the equipped
-- rod name is NOT in rod_tables -- a real error (resolution can't work), as
-- opposed to simply having no rod equipped. Callers surface this loudly rather
-- than silently treating it as fa=0.
local function current_rod_attack()
    local rn = DB.equipped_item_name and DB.equipped_item_name(2) or nil  -- range slot
    if rn == nil then return 0, '(no rod)', false end
    -- DB.equipped_item_name returns "Name (id)" or a name; strip the id suffix.
    local base = clean_name((tostring(rn):gsub('%s*%(%d+%)%s*$', '')))
    local fa = DB.rod_attack[base]
    if fa == nil then
        return 0, base, false   -- equipped rod name not found in rod_tables
    end
    return fa, base, true
end

-- Current AREA = the live zone name (sans the "(id)" suffix), lowercased.
local function current_area()
    local region = current_region()
    local base = tostring(region):gsub('%s*%(%d+%)%s*$', '')
    return clean_name(base)
end

-- Currently equipped bait, lowercased (ammo slot). '' if unreadable.
local function current_bait_name()
    local b = DB.equipped_item_name and DB.equipped_item_name(3) or nil  -- ammo slot
    if b == nil then return '' end
    return clean_name((tostring(b):gsub('%s*%(%d+%)%s*$', '')))
end

-- Does fish `nm` (lowercased) bite on bait `bait` (lowercased)?
-- 'any' bait list (item-type fish) matches everything. Empty bait list or
-- empty bait arg = don't filter (treat as match) so a missing field never
-- wrongly excludes a fish.
-- All bait names -- dropdown, defaults, and data tables -- use the BG-Wiki
-- in-game item names, which is also what the inventory checker reads. So a
-- plain normalize (lowercase/trim) is all that's needed for comparison.
local function norm_bait(name)
    return clean_name(name or '')
end

local function fish_bites_on(nm, bait)
    if bait == '' then return true end
    local list = DB.fish_baits[nm]
    if not list or #list == 0 then return true end
    local want = norm_bait(bait)
    for _, b in ipairs(list) do
        if b == 'any' or norm_bait(b) == want then return true end
    end
    return false
end

-- Resolve a hooked fish's NAME from the 0x115 key, filtered by ZONE + BAIT +
-- Resolution order (matches the bite the server gives us):
--   FISH bite: search fish entries -> size (small/large) -> stamina key -> bait
--   ITEM bite: search item entries -> stamina key -> bait   (items have no size)
-- bite_kind: 'fish'|'item'|'monster'; bite_size: 'small'|'large'|nil.

local function resolve_fish_name(dep_x20, bite_kind, bite_size)
    -- Every early return records WHY. resolve_fish_name has six silent nil
    -- exits and the panel just shows '?', so a non-resolution was impossible to
    -- tell apart from a bad table row without adding prints by hand each time.
    state.resolve_why = nil
    if not DB.data_tables_ready then state.resolve_why = 'data tables not loaded'; return nil end
    if dep_x20 == nil or dep_x20 == 0 then state.resolve_why = 'no depletion_x20 in packet'; return nil end
    -- STEP 1: pick the list by bite kind. fish + items can share a stamina key
    -- (Gold Carp vs Arrowwood Log), so an unknown kind stays unresolved until
    -- the bite chat classifies it. 'monster' resolves against the monster table.
    if bite_kind ~= 'fish' and bite_kind ~= 'item' and bite_kind ~= 'monster' then
        state.resolve_why = 'bite kind unknown (bite line not classified)'
        return nil
    end
    local fa, rn, matched = current_rod_attack()
    if not matched then
        -- The equipped rod isn't in rod_tables -- resolution can't work. Warn
        -- once per distinct rod name so it's obvious instead of silently
        -- turning every catch into Unknown.
        if state.last_warned_rod ~= rn then
            state.last_warned_rod = rn
            note(string.format('[!] equipped rod "%s" not in rod_tables - resolution OFF. Fix the rod name/list.', rn))
        end
        state.resolve_why = 'rod "' .. tostring(rn) .. '" not in rod_tables'
        return nil
    end
    if fa == 0 then state.resolve_why = 'rod attack = 0'; return nil end
    local area = current_area()
    if area == '' or area == '?' then state.resolve_why = 'area unknown'; return nil end
    local candidates = DB.area_fish[area]
    if not candidates then
        state.resolve_why = 'no fish list for area "' .. area .. '"'
        return nil
    end
    local bait = current_bait_name()

    -- Match on the FULL-PRECISION packet value: dep_x20 = floor(diff*fa/100*20).
    -- The old code matched floor(dep_x20/20) == floor(diff*fa/100), which threw
    -- away the *20 precision and merged fish one difficulty apart (e.g. Dark
    -- Bass diff23 and Black Eel diff24 both collapsed to key 16). Comparing the
    -- raw dep_x20 keeps them distinct.
    local matches = {}
    -- Stage counters: which filter emptied the list. Counted, not logged, so
    -- this costs nothing per candidate -- one summary line only on failure.
    local n_key, n_kind, n_size = 0, 0, 0
    for _, oname in ipairs(candidates) do
        local nm = clean_name(oname)
        local t  = DB.fish_type[nm]
        local ok = false
        local diff = DB.fish_diff[nm]
        -- Exact server arrow-damage (float32). On LEGENDARY fish the server adds
        -- the rod's legendary bonus to fishAttack (e.g. Lu Shang's 80 -> 100),
        -- so we must add it too or the legendary fish won't resolve.
        local lgd = (DB.fish_legend[nm] and state.rod_lgd and state.rod_lgd[rn]) or 0
        local want = diff and state.arrow_dmg(diff, fa, lgd) or nil
        if want == dep_x20 then n_key = n_key + 1 end
        if bite_kind == 'fish' then
            -- FISH: must be a fish entry (not an item).
            if t ~= 'item' and want == dep_x20 then
                n_kind = n_kind + 1
                -- size filter (small/large) when known
                local size_ok = true
                if bite_size == 'small' and t == 'large' then size_ok = false end
                if bite_size == 'large' and t == 'small' then size_ok = false end
                if size_ok then
                    n_size = n_size + 1
                    if fish_bites_on(nm, bait) then ok = true end
                end
            end
        else  -- bite_kind == 'item' or 'monster'
            if bite_kind == 'monster' then
                -- MONSTER: must be a monster entry; matches on dep_x20 + bait.
                -- Monsters all bite as large (!!!), so no size filter.
                if t == 'monster' and want == dep_x20 and fish_bites_on(nm, bait) then
                    ok = true
                end
            else
                -- ITEM: must be an item entry; no size. stamina then bait.
                if t == 'item' and want == dep_x20 and fish_bites_on(nm, bait) then
                    ok = true
                end
            end
        end
        if ok then matches[#matches + 1] = oname end
    end

    if #matches == 1 then return matches[1] end
    if #matches > 1 then return matches[1], matches end
    -- Zero matches: say which stage emptied the list. Read it as a funnel --
    -- the first number that goes to 0 is the filter that dropped the fish, and
    -- the table it points at is the one to fix. key= is the FULL dep_x20, not
    -- the /20 'key' the catch line prints.
    state.resolve_why = string.format(
        'no match: key=%d area=%s cands=%d keyhit=%d kind=%d size=%d bait=%d (bait=%s size=%s)',
        dep_x20, area, #candidates, n_key, n_kind, n_size, #matches,
        tostring(bait), tostring(bite_size))
    return nil
end

-- Read the item ACTUALLY equipped in a gear slot (ammo=3, range=2) and resolve
-- its name from resources. Returns nil if the slot is empty or unreadable.
-- This is the source of truth for what we're really fishing with -- the config
-- string (current_bait/S.rod_name) is only an intent, and a failed/!throttled
-- equip can leave the slot holding something else. The cast log must reflect
-- the slot, not the intent, or the data lies (see Little-Worm-vs-Minnow bug).
DB.equipped_item_name = function(eslot)
    local ok, name = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        local eq  = inv:GetEquippedItem(eslot)   -- {Index, ...} into a container
        if eq == nil or eq.Index == nil or eq.Index == 0 then return nil end
        -- Equipped index encodes container in high byte, slot in low byte.
        local cid  = bit.band(bit.rshift(eq.Index, 8), 0xFF)
        local cslot = bit.band(eq.Index, 0xFF)
        local item = inv:GetContainerItem(cid, cslot)
        if item == nil or item.Id == 0 then return nil end
        local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
        if res == nil or res.Name == nil then return tostring(item.Id) end
        for k = 0, 3 do
            local cand = res.Name[k]
            if cand ~= nil and clean_name(cand) ~= '' then return clean_name(cand) end
        end
        return tostring(item.Id)
    end)
    if ok and name ~= nil then return name end
    return nil
end

local EQUIP_SLOT_AMMO  = 3
local EQUIP_SLOT_RANGE = 2

-- Clear a stuck fishing action. After certain server states the client
-- holds the line "out" and rejects every new /fish with "You cannot use
-- that command at this time." Sending /fish while the line is out toggles
-- it back in (cancels the stuck action); the NEXT /fish then casts cleanly.
local function send_fishing_cancel()
    AshitaCore:GetChatManager():QueueCommand(1, '/fish')
end

-- 0x0DF (char update: HP/MP/stats) precedes the 0x037 in 100% of catch
-- resolutions. Only its sequence (0x02-0x03) varies; the rest is the stable
-- char state. Injecting it before the 0x037 primes char state the same way a
-- real catch does. 0x48-byte packet; trailing zeros omitted are fine.
local CHAR_0x0DF_TEMPLATE = {
    0xDF,0x14,0x4D,0x05,0x73,0x1C,0x02,0x00,0x98,0x03,0x00,0x00,0xA2,0x02,0x00,0x00,
    0x00,0x00,0x00,0x00,0x02,0x04,0x5E,0x64,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
}

-- 0x037 (char status) template captured from real catches. Only 4 bytes ever
-- vary catch-to-catch: the packet sequence (0x02-0x03) and a timestamp
-- (0x40-0x43). Everything else -- the animation/status payload that ends the
-- fishing stance, plus the player ID at 0x24-0x27 -- is constant. We rebuild a
-- fresh one on demand so Recovery works even when the original 0x037 was
-- DROPPED and never seen (nothing to replay). Player ID and sequence are
-- filled from live data so the packet is valid for the current session.
local STATUS_0x037_TEMPLATE = {
    0x37,0x30,0x4D,0x05,0xFD,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
    0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
    0xFF,0xFF,0xFF,0xFF,0x73,0x1C,0x02,0x00,0x20,0x01,0x5E,0x02,0x28,0x00,0x50,0x00,
    0x3A,0x8F,0x9F,0xBF,0x00,0x00,0x20,0x00,0x00,0x01,0x00,0x00,0x20,0xA0,0x03,0x00,
    0xFE,0xAC,0xF2,0x2D,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x10,0x04,0x00,0x00,0x7B,0x00,0x00,0x00,
}

-- Latest incoming packet's sequence bytes (0x02-0x03) and the live timestamp
-- (0x40-0x43, captured from real 0x037s), so a rebuilt 0x037 carries
-- current-session values rather than stale template ones.
local last_in_seq_lo, last_in_seq_hi = nil, nil
local last_0x037_ts = nil   -- 4 raw bytes (string) of the 0x40-0x43 tick

-- RECOVERY: build a fresh 0x037 (catch resolution / animation reset) and inject
-- it to the CLIENT ONLY (AddIncomingPacket -- nothing leaves to the server).
-- This un-sticks a client frozen in the fishing stance, whether it ignored the
-- real resolution OR never received it. Player ID comes from the cast's 0x110
-- if we captured one; sequence from the latest incoming packet.
local function do_recovery()
    local pm = AshitaCore:GetPacketManager()

    -- 0x0DF char update first (primes char state, as in a real catch). Only its
    -- sequence varies; fill from live, plus player ID for safety.
    local d = {}
    for i = 1, #CHAR_0x0DF_TEMPLATE do d[i] = CHAR_0x0DF_TEMPLATE[i] end
    if last_in_seq_lo ~= nil then d[3] = last_in_seq_lo; d[4] = last_in_seq_hi end
    if last_cast_player_id_bytes ~= nil and #last_cast_player_id_bytes >= 4 then
        d[5] = string.byte(last_cast_player_id_bytes, 1)
        d[6] = string.byte(last_cast_player_id_bytes, 2)
        d[7] = string.byte(last_cast_player_id_bytes, 3)
        d[8] = string.byte(last_cast_player_id_bytes, 4)
    end
    pm:AddIncomingPacket(0x0DF, d)

    local t = {}
    if last_0x037_bytes ~= nil and #last_0x037_bytes >= 68 then
        -- Best: clone the most recent REAL 0x037 (correct update-flags at 0x04,
        -- correct timestamp, everything), then just advance the sequence below.
        for i = 1, #last_0x037_bytes do t[i] = string.byte(last_0x037_bytes, i) end
    else
        -- Fallback (no 0x037 seen yet this session): build from the template.
        for i = 1, #STATUS_0x037_TEMPLATE do t[i] = STATUS_0x037_TEMPLATE[i] end
        -- template timestamp from last live capture if we have it
        if last_0x037_ts ~= nil and #last_0x037_ts >= 4 then
            t[65] = string.byte(last_0x037_ts, 1)
            t[66] = string.byte(last_0x037_ts, 2)
            t[67] = string.byte(last_0x037_ts, 3)
            t[68] = string.byte(last_0x037_ts, 4)
        end
    end

    -- Live player ID from the cast's 0x110 (bytes at out-packet offset 4-7),
    -- written into 0x037 offset 0x24-0x27 (Lua index 37-40). Falls back to the
    -- template's own ID if we have no cast capture yet.
    if last_cast_player_id_bytes ~= nil and #last_cast_player_id_bytes >= 4 then
        t[37] = string.byte(last_cast_player_id_bytes, 1)
        t[38] = string.byte(last_cast_player_id_bytes, 2)
        t[39] = string.byte(last_cast_player_id_bytes, 3)
        t[40] = string.byte(last_cast_player_id_bytes, 4)
    end

    -- Live sequence from the latest incoming packet (0x02-0x03, Lua index 3-4).
    if last_in_seq_lo ~= nil then
        t[3] = last_in_seq_lo
        t[4] = last_in_seq_hi
    end

    pm:AddIncomingPacket(0x037, t)
    -- Also finalize inventory if we have a recent 0x01E (optional, best-effort).
    if last_0x01E_bytes ~= nil then
        local e = {}
        for i = 1, #last_0x01E_bytes do e[i] = string.byte(last_0x01E_bytes, i) end
        pm:AddIncomingPacket(0x01E, e)
    end
    note(string.format('[recovery] injected 0x0DF + built 0x037 (player=%02X%02X%02X%02X seq=%02X%02X) client-only',
        t[37], t[38], t[39], t[40], t[3], t[4]))
end

local function send_cast()
    AshitaCore:GetChatManager():QueueCommand(1, '/fish')
    stats.casts = stats.casts + 1
    state.pool.pending = true   -- outcome not yet recorded for this cast
    -- New cast: clear the previous event's result so the status line shows
    -- "Casting" (and the name line "(No Data)") instead of bleeding the last
    -- catch into the new cycle.
    state.last_result.kind = nil
    state.last_result.name = nil
    -- Prefer the REAL equipped slot; fall back to config intent if unreadable,
    -- tagging the fallback so the log shows it was inferred, not observed.
    local bait = DB.equipped_item_name(EQUIP_SLOT_AMMO)  or ('?cfg:' .. tostring(current_bait()))
    local rod  = DB.equipped_item_name(EQUIP_SLOT_RANGE) or ('?cfg:' .. tostring(S.rod_name[1]))
    local fa, _, matched = current_rod_attack()
    dnote(string.format('cast  bait=%s  rod=%s (fa=%d%s)  region=%s',
        bait, rod, fa, matched and '' or ' UNMATCHED', current_region()))
end

-- Find an equippable item by name in the main inventory (container 0).
-- Returns { slot, id, count, name } or nil. Shared by equip + auto-drop.
-- Containers an item can be equipped from: Inventory (0) + Mog Wardrobe 1 (8)
-- and Wardrobe 2 (10). Bait/rod frequently live in a wardrobe. DROP uses
-- inventory only -- it must never reach into the other boxes.
local INVENTORY_ONLY    = { 0 }

----------------------------------------------------------------------------------------------------
-- Storage / offbag groundwork
----------------------------------------------------------------------------------------------------
-- FFXI container IDs. Inventory is the only place fish can be CAUGHT; offbags
-- are storage we sweep caught fish into so long runs don't choke at 60/60.
local CONTAINER = {
    inventory = 0,
    safe      = 1,
    storage   = 2,
    temporary = 3,
    locker    = 4,
    satchel   = 5,
    sack      = 6,
    case      = 7,
    wardrobe  = 8,
    wardrobe2 = 10,
}
-- Name -> id, for the /put command's location argument (case-insensitive).
local function container_id(name)
    if name == nil then return nil end
    return CONTAINER[tostring(name):lower()]
end

-- Read a container's capacity + how many slots are used/free. Reads the LIVE
-- inventory so we never try to shove a stack into an already-full bag or move
-- from an empty slot. Returns { max, used, free } or nil on failure.
local function container_space(cid)
    local ok, res = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        -- Max slots for this container (GetContainerCountMax); used = occupied.
        local max = inv:GetContainerCountMax(cid)
        if max == nil or max == 0 then max = 80 end   -- safe fallback
        local used = 0
        for i = 1, max do
            local item = inv:GetContainerItem(cid, i)
            if item ~= nil and item.Id ~= 0 then used = used + 1 end
        end
        return { max = max, used = used, free = max - used }
    end)
    if ok then return res end
    return nil
end

-- Find a slot in `cid` holding `item_name`. Optionally require a FULL stack
-- (only_full) so we sweep complete 12-stacks and leave the partial accruing,
-- mirroring how the Windower stow addons behave.
local function find_stack_in_container(item_name, cid, only_full)
    local want = clean_name(item_name)
    if want == '' then return nil end
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    for i = 1, 80 do
        local item = inv:GetContainerItem(cid, i)
        if item ~= nil and item.Id ~= 0 then
            local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
            if res ~= nil and res.Name ~= nil then
                for k = 0, 3 do
                    local cand = res.Name[k]
                    if cand ~= nil and clean_name(cand) == want then
                        local res2 = AshitaCore:GetResourceManager():GetItemById(item.Id)
                        local stacksize = (res2 and res2.StackSize) or 12
                        if (not only_full) or item.Count >= stacksize then
                            return { slot = i, id = item.Id, count = item.Count,
                                     name = tostring(cand), container = cid,
                                     stacksize = stacksize }
                        end
                    end
                end
            end
        end
    end
    return nil
end

-- Build + send the 0x29 "move item between containers" packet. Moves `count`
-- of the item at (src_container, src_slot) into dst_container. This DOES go to
-- the server (it tracks item location) -- same action a player or a Windower
-- stow addon performs. Caller is responsible for pacing (see the move queue).
-- Layout mirrors the standard outbound 0x29: count(u32), src_bag, dst_bag,
-- src_index, dst_index(0 = let server place).
local function send_storage_move(count, src_container, dst_container, src_slot)
    -- 0x029 GP_CLI_COMMAND_ITEM_MOVE fields (after the 4-byte header):
    --   uint32 ItemNum     -- quantity to move
    --   uint8  Category1    -- source container
    --   uint8  Category2    -- destination container
    --   uint8  ItemIndex1   -- source slot
    --   uint8  ItemIndex2   -- destination slot
    -- When moving a WHOLE stack, ItemIndex2 < 82 makes the server try to COMBINE
    -- into an existing item at that dest slot; an empty/invalid dest slot (e.g. 0)
    -- is rejected ("unite items with invalid item"). ItemIndex2 >= 82 instead
    -- does a plain move to the destination's first free slot (MoveItemTo). So we
    -- send 0x52 (82) as the dest slot to mean "just place it, no combine".
    local payload_str = struct.pack('bbxxIBBBB', 0x29, 0x04,
        count, src_container, dst_container, src_slot, 0x52)
    local payload = {}
    for i = 1, #payload_str do payload[i] = payload_str:byte(i) end
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x029, payload)
end

-- Paced move queue. The Windower stow addons stress ~1s between moves to avoid
-- desync/rejection, so we never fire 0x29s back-to-back: enqueue jobs and drain
-- one per TUNE.MOVE_INTERVAL during the fishing idle window.
TUNE.MOVE_INTERVAL = 1.1          -- seconds between queued moves
-- How long inventory must READ full before we believe it. The client shows
-- 60/60 for a moment after a catch, then stacks/sorts back down to 59/60, so
-- acting on the first full read stops the bot one fish early.
TUNE.FULL_CONFIRM = 3.0            -- seconds to re-verify a full inventory
local move_queue    = {}           -- list of { count, src, dst, slot, label }
local next_move_at  = 0.0

local function queue_storage_move(count, src, dst, slot, label)
    move_queue[#move_queue + 1] = { count = count, src = src, dst = dst,
                                    slot = slot, label = label or '' }
end

-- Drain one queued move if the interval has elapsed. Re-reads space on the
-- destination right before sending so a bag that filled up mid-drain is
-- skipped rather than overstuffed. Call this from the main tick.
local function process_move_queue()
    if #move_queue == 0 then return end
    local now = os.clock()
    if now < next_move_at then return end
    local job = table.remove(move_queue, 1)
    local space = container_space(job.dst)
    if space ~= nil and space.free <= 0 then
        -- Destination filled up mid-burst. Everything else queued for the same
        -- bag is dead too -- drop it all now rather than skip-spamming one job
        -- per tick with a note each time.
        local dropped = 1
        for i = #move_queue, 1, -1 do
            if move_queue[i].dst == job.dst then
                table.remove(move_queue, i)
                dropped = dropped + 1
            end
        end
        note(string.format('[stow] destination full - dropped %d queued move%s',
            dropped, (dropped == 1) and '' or 's'))
        return
    end
    send_storage_move(job.count, job.src, job.dst, job.slot)
    next_move_at = now + TUNE.MOVE_INTERVAL
    dnote(string.format('[stow] moved %s (x%d) slot %d -> bag %d',
        job.label, job.count, job.slot, job.dst))
end

-- /put <location> "<item name>"  -- queue a move of one stack of the named
-- item from inventory into the given offbag, if there's room. Reads live space
-- first. This is the manual command; auto-sweep (GUI) will reuse queue/move.
local function put_item(location, item_name)
    local dst = container_id(location)
    if dst == nil then
        note('[put] unknown location: ' .. tostring(location)
            .. ' (satchel/sack/case/storage/locker/safe)')
        return
    end
    if dst == CONTAINER.inventory then
        note('[put] destination cannot be inventory')
        return
    end
    local found = find_stack_in_container(item_name, CONTAINER.inventory, false)
    if found == nil then
        note('[put] not in inventory: ' .. tostring(item_name))
        return
    end
    local space = container_space(dst)
    if space == nil then
        note('[put] cannot read ' .. location .. ' space')
        return
    end
    if space.free <= 0 then
        note(string.format('[put] %s is full (%d/%d)', location, space.used, space.max))
        return
    end
    -- /put is a manual one-shot: fire the move now, no queue / pacing.
    dnote(string.format('[put] found: %s x%d, inv slot %d, id %d',
        found.name, found.count, found.slot, found.id))
    dnote(string.format('[put] packet 0x029: count=%d src=%d(inv) dst=%d(%s) srcslot=%d dstslot=82(place)',
        found.count, CONTAINER.inventory, dst, location, found.slot))
    send_storage_move(found.count, CONTAINER.inventory, dst, found.slot)
    dnote('[put] packet sent')
    note(string.format('[put] %s -> %s (%d free)', found.name, location, space.free))
end

-- Send the 0x084 (sell req, whole stack) + 0x085 (confirm) for one stack at the
-- given inventory slot. Returns the count sold, or 0 if the slot is empty.
state.sell_one_stack = function(slot)
    local inv  = AshitaCore:GetMemoryManager():GetInventory()
    local item = inv:GetContainerItem(CONTAINER.inventory, slot)
    if item == nil or item.Id == 0 then return 0, 0, '?' end
    local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
    local nm  = (res and res.Name and res.Name[1]) and tostring(res.Name[1]) or ('id ' .. item.Id)
    -- 0x084 SHOP_SELL_REQ: ItemNum(u32 qty=full stack), ItemNo(u16 id),
    -- ItemIndex(u8 slot), padding. Then 0x085 SHOP_SELL_SET: SellFlag=1.
    local p84 = struct.pack('bbxxIHBB', 0x84, 0x06, item.Count, item.Id, slot, 0)
    local a84 = {}; for i = 1, #p84 do a84[i] = p84:byte(i) end
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x084, a84)
    local p85 = struct.pack('bbxxHH', 0x85, 0x04, 1, 0)
    local a85 = {}; for i = 1, #p85 do a85[i] = p85:byte(i) end
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x085, a85)
    dnote(string.format('[sell] 0x084 qty=%d id=%d slot=%d -> 0x085 confirm', item.Count, item.Id, slot))
    return item.Count, item.Id, nm
end

-- Count how many stacks of the given item id are in inventory.
-- Scan the entity table for the Asshole Detector. Uses the same entity access
-- as the XIUI enemy list: GetEntity(idx) returns a struct with .Name, .HPPercent
-- and .Distance (Distance is SQUARED -> sqrt for yalms). Validity is the render-
-- flag check (visible bit set, hidden bit clear). Returns nearby entities with a
-- type tag (GM / Player / NPC / Mob) sorted GM -> Player -> others, nearer first.
state.scan_entities = function()
    local out = {}
    -- Render flag bits (Ashita): 0x200 = visible, 0x4000 = hidden. Fall back to
    -- showing an entity if we can't read flags rather than hiding everything.
    local RF_VISIBLE, RF_HIDDEN = 0x200, 0x4000
    local ok_em, em = pcall(function() return AshitaCore:GetMemoryManager():GetEntity() end)
    if not ok_em or em == nil then return out end
    for i = 1, 2303 do
        local ok, ent = pcall(function() return GetEntity(i) end)
        if ok and ent ~= nil and ent.Name ~= nil and ent.Name ~= '' then
            -- Validity: visible and not hidden (skip unrendered array slots).
            local flags = select(2, pcall(function() return em:GetRenderFlags0(i) end)) or 0
            local visible = bit.band(flags, RF_VISIBLE) ~= 0
            local hidden  = bit.band(flags, RF_HIDDEN) ~= 0
            if visible and not hidden then
                local nm = tostring(ent.Name)
                -- GM detection: confirmed via 4-way render-flag capture, SAME
                -- method XIUI uses. Staff carry bit 0x1000 in RenderFlags2;
                -- normal players and self do not. Use bit.band exactly like XIUI
                -- -- the earlier math.floor(f2/0x1000) version broke because
                -- Flags2 values with 0x80000000 set come back NEGATIVE in Lua,
                -- which corrupted the division/modulo and false-flagged people.
                local f2 = select(2, pcall(function() return em:GetRenderFlags2(i) end)) or 0
                local is_gm = bit.band(f2, 0x1000) ~= 0   -- 0x1000 = staff (GM or GMDev)
                -- Type from SpawnFlags: 0x01 player, 0x02 NPC, 0x10 mob. Our own
                -- character is tagged 'Self' so it never counts as another player.
                local sf = ent.SpawnFlags or 0
                local kind
                if current_player_name ~= '' and clean_name(nm) == clean_name(current_player_name) then
                    kind = 'Self'
                elseif is_gm then kind = 'GM'
                elseif bit.band(sf, 0x01) ~= 0 then kind = 'Player'
                elseif bit.band(sf, 0x10) ~= 0 then kind = 'Mob'
                elseif bit.band(sf, 0x02) ~= 0 then kind = 'NPC'
                else kind = '?' end
                local dist = nil
                if ent.Distance ~= nil and ent.Distance > 0 then
                    dist = math.sqrt(ent.Distance)   -- Distance is stored squared
                end
                out[#out+1] = { name = nm, kind = kind, dist = dist,
                                hpp = ent.HPPercent, idx = i }
            end
        end
    end
    local rank = { GM = 1, Player = 2, NPC = 3, Mob = 4, Self = 5, ['?'] = 6 }
    table.sort(out, function(a, b)
        if rank[a.kind] ~= rank[b.kind] then return rank[a.kind] < rank[b.kind] end
        return (a.dist or 1e9) < (b.dist or 1e9)
    end)
    return out
end

-- Cached wrapper. scan_entities walks 2303 indices with a pcall per entity;
-- the detector calls it every tick AND the panel called it again every frame
-- while the Asshole Detector header was open, so the sweep ran twice per frame
-- for identical data. One scan per max_age seconds is shared by both. 0.5s is
-- far below the 20s soft-detect and 30s leave windows, so nothing downstream
-- can notice the staleness.
state.scan_cached = function(max_age)
    local now = os.clock()
    if state.scan_cache == nil or (now - (state.scan_cache_at or 0)) > (max_age or 0.5) then
        state.scan_cache    = state.scan_entities()
        state.scan_cache_at = now
    end
    return state.scan_cache
end

-- Detector safety, evaluated every tick while auto-fishing. TWO behaviors:
--  1) GM present  -> ALWAYS hard-stop (not toggleable). A GM in your entity
--     list means eyes on you; stop immediately.
--  2) Pause on Player (toggle): while any NON-party player is nearby, hold
--     casting; once they're all gone, resume 30 seconds later (so you don't pop
--     back to fishing the instant someone walks off screen).
--     EXCEPTION: if the pause never actually stopped anything -- we were
--     mid-fish for their whole visit and the line never came out of the water
--     -- there's nothing to ease back into, so we skip the leave hold entirely.
-- Returns 'gm_stop', 'player_pause', 'player_wait' (post-leave cooldown), or nil.
state.detector_check = function()
    if not auto_fish[1] then return nil end
    local ents = state.scan_cached()
    local gm_here, player_here = false, false
    -- Build the asshole name set (lowercased) from the saved list.
    local asshole_set = {}
    for tok in tostring(S.asshole_list[1] or ''):gmatch('[^,;]+') do
        local n = clean_name(tok)
        if n ~= '' then asshole_set[n] = true end
    end
    -- Build the friends (whitelist) set the same way. Whitelisted players are
    -- ignored by the Pause-on-Player detector but still counted for GM /
    -- asshole checks (both of which run on kind, not name; asshole runs on
    -- name but the whitelist wouldn't overlap unless the user asked for it).
    local friends_set = {}
    for tok in tostring(S.friends_list[1] or ''):gmatch('[^,;]+') do
        local n = clean_name(tok)
        if n ~= '' then friends_set[n] = true end
    end
    local asshole_here = nil
    for _, en in ipairs(ents) do
        if en.kind == 'GM' then gm_here = true end
        if en.kind == 'Player' then
            local nm_key = clean_name(en.name)
            if next(asshole_set) ~= nil and asshole_set[nm_key] then
                asshole_here = en.name
            end
            if not friends_set[nm_key] then
                player_here = true
            end
        end
    end
    state.scan_has_player = player_here   -- keep status accurate even if panel is collapsed

    -- 0) Named asshole present -> hard stop AND arm shutdown-on-idle.
    if asshole_here then
        state.asshole_shutdown = true   -- /shutdown once we reach Idle (see tick)
        state.stop_now('asshole detected (' .. asshole_here .. ') - shutting down')
        return 'asshole_stop'
    end

    -- 1) GM -> always hard stop.
    if gm_here then
        state.stop_now('GM detected - hard stop')
        return 'gm_stop'
    end

    -- 2) Player pause (only if enabled).
    -- Soft-detect: require state.PLAYER_DETECT.soft of continuous presence before
    -- actually pausing. People who walk by and blink out (chunk load/unload,
    -- edge-of-range fade) never trigger a pause. Timer resets the moment
    -- nobody's on scan.
    if S.pause_on_player[1] then
        if player_here then
            if not state.player_pause_active then
                -- Not yet paused. Start / continue the soft-detect timer.
                if state.player_first_seen == nil then
                    state.player_first_seen = os.clock()
                    return 'player_soft'   -- seen, but not pausing yet
                end
                if (os.clock() - state.player_first_seen) < state.PLAYER_DETECT.soft then
                    return 'player_soft'   -- still inside grace window
                end
                -- Grace exceeded -> commit to pause. Log the edge with count.
                local n = 0
                for _, en in ipairs(ents) do
                    if en.kind == 'Player' and not friends_set[clean_name(en.name)] then
                        n = n + 1
                    end
                end
                note(string.format('[detector] %d player(s) present >%ds -> pausing fishing',
                    n, math.floor(state.PLAYER_DETECT.soft)))
                -- Fresh pause: nothing has actually been held back yet. The
                -- tick flips this true the first time the hold blocks a cast.
                state.player_pause_held = false
                state.pause_now(string.format('%d player(s) nearby', n))
            end
            state.player_pause_since = os.clock()   -- refresh while they're here
            state.player_pause_active = true
            return 'player_pause'
        else
            -- Nobody visible. Reset the soft-detect timer so a later blip
            -- starts fresh.
            state.player_first_seen = nil
            if state.player_pause_active then
                -- The pause never actually held anything: we were mid-cast/fight
                -- the entire time they were around, the animation never stopped,
                -- and they walked before we hit Idle. Nobody saw the bot stand
                -- still, so there's nothing to wait out -- clear it now.
                if not state.player_pause_held then
                    state.player_pause_active = false
                    state.player_pause_since = nil
                    note('[detector] players gone, fishing never stopped -> resuming immediately')
                    return nil
                end
                -- They've left. Hold state.PLAYER_DETECT.leave more, then resume.
                if (os.clock() - (state.player_pause_since or 0)) >= state.PLAYER_DETECT.leave then
                    state.player_pause_active = false
                    state.player_pause_since = nil
                    state.player_pause_held  = false
                    note(string.format('[detector] players gone %ds -> resuming fishing',
                        math.floor(state.PLAYER_DETECT.leave)))
                    return nil
                end
                return 'player_wait'
            end
        end
    else
        state.player_pause_active = false
        state.player_first_seen = nil
        state.player_pause_held = false
    end
    return nil
end

state.count_stacks_of = function(item_id)
    if item_id == nil or item_id == 0 then return 0 end
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    local max = inv:GetContainerCountMax(CONTAINER.inventory)
    local n = 0
    for slot = 1, max do
        local it = inv:GetContainerItem(CONTAINER.inventory, slot)
        if it ~= nil and it.Id == item_id then n = n + 1 end
    end
    return n
end

-- Start a "Sell All" run for the fish the vendor just quoted. Captures the fish
-- id/name from the quoted slot, then the paced driver (sell_all_tick) sells one
-- stack of that fish each ~1s until none remain. Gated on state.sell_ready.
state.sell_fish = function()
    if not state.sell_ready then
        note('[sell] no sale prompt - select a fish in the vendor menu first')
        return
    end
    local inv  = AshitaCore:GetMemoryManager():GetInventory()
    local item = inv:GetContainerItem(CONTAINER.inventory, state.sell_slot)
    if item == nil or item.Id == 0 then
        note('[sell] quoted slot is empty')
        state.sell_ready = false
        return
    end
    local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
    state.sell_all_id   = item.Id
    state.sell_all_name = (res and res.Name and res.Name[1]) and tostring(res.Name[1]) or ('id ' .. item.Id)
    state.sell_all_next = 0          -- fire the first stack immediately
    state.sell_all_sold = 0
    note(string.format('[sell] selling all %s (%d stacks)',
        state.sell_all_name, state.count_stacks_of(item.Id)))
end

-- Paced "Sell All" driver: called every frame from d3d_present. Sells one stack
-- of the target fish per ~1s until no stacks remain, then finishes.
state.sell_all_tick = function()
    if state.sell_all_id == nil then return end
    local now = os.clock()
    if now < (state.sell_all_next or 0) then return end
    -- Find the next stack of the target fish.
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    local max = inv:GetContainerCountMax(CONTAINER.inventory)
    local slot = nil
    for s = 1, max do
        local it = inv:GetContainerItem(CONTAINER.inventory, s)
        if it ~= nil and it.Id == state.sell_all_id then slot = s; break end
    end
    if slot == nil then
        -- Done: no more stacks of this fish. Show a "Sale complete" banner that
        -- holds for 5s (or until the next fish quote arrives), then resets.
        local sold = state.sell_all_sold or 0
        note(string.format('[sell] done - sold %d %s', sold, state.sell_all_name or 'fish'))
        state.sell_done_name  = state.sell_all_name
        state.sell_done_sold  = sold
        state.sell_done_until = os.clock() + 5.0
        state.sell_all_id   = nil
        state.sell_all_next = nil
        state.sell_ready    = false   -- clear the stale quote so the box resets
        return
    end
    local cnt = state.sell_one_stack(slot)
    if cnt > 0 then
        state.sell_all_sold = (state.sell_all_sold or 0) + cnt
        note(string.format('[sell] %s x%d @ %d gil', state.sell_all_name, cnt, state.sell_price or 0))
    end
    state.sell_all_next = now + 2.0   -- pace: one stack per 2s
end

-- Auto Move On Full: triggers only when inventory is FULL (0 free) after a
-- catch. Reads live Satchel free space, then moves UP TO that many VERIFIED
-- FULL stacks of the configured fish from inventory -> satchel, one per ~1s
-- (handled by the paced move queue). Fishing is held until the dump drains
-- (see auto_dump_active). One-way only; never moves partials; never overstuffs.
-- If inventory AND satchel are both full, returns 'both_full' so the caller
-- can stop fishing (when the stop toggle is on).

-- Collect every VERIFIED FULL stack of `name` in inventory (count >= stacksize).
local function find_full_stacks(name, max_n)
    local out = {}
    local want = clean_name(name)
    if want == '' then return out end
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    for i = 1, 80 do
        if #out >= max_n then break end
        local item = inv:GetContainerItem(CONTAINER.inventory, i)
        if item ~= nil and item.Id ~= 0 then
            local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
            if res ~= nil and res.Name ~= nil then
                for k = 0, 3 do
                    local cand = res.Name[k]
                    if cand ~= nil and clean_name(cand) == want then
                        local stacksize = (res.StackSize and res.StackSize > 0)
                            and res.StackSize or 12
                        -- VERIFIED FULL only.
                        if item.Count >= stacksize then
                            out[#out + 1] = { slot = i, id = item.Id,
                                count = item.Count, name = tostring(cand) }
                        end
                        break
                    end
                end
            end
        end
    end
    return out
end

-- Returns: 'idle' (nothing to do), 'dumping' (queued moves), or 'both_full'
-- (inventory full and satchel has no room -> caller should stop).
-- Caller guarantees inventory has been CONFIRMED full (see the debounce in the
-- fisher gate), so there's no settle timer in here. This fires ONE burst: read
-- how many free slots the satchel has, grab up to that many verified-full
-- stacks, and queue them all. The paced queue drains them one per ~1.1s. With a
-- normal run that's a single burst per session -- it fills every free satchel
-- slot at once, and the next time inventory fills the satchel is full too, so
-- we return 'both_full' and the caller stops.
local function auto_move_on_full()
    if not S.auto_move[1] then return 'idle' end
    local inv = container_space(CONTAINER.inventory)
    if inv == nil or inv.free > 0 then return 'idle' end

    local sat = container_space(CONTAINER.satchel)
    if sat == nil or sat.free <= 0 then
        return 'both_full'                                  -- nowhere to dump
    end

    local name = S.auto_move_name[1] or ''
    if clean_name(name) == '' then return 'idle' end

    -- Fire ONCE per full event. Set a guard before queueing so subsequent ticks
    -- can't re-enter and re-queue the same work.
    if state.auto_move_fired then return 'pending' end

    -- Take as many full stacks as the satchel has room for. Fewer full stacks
    -- than free slots is fine -- we move what exists and fill the rest later.
    local stacks = find_full_stacks(name, sat.free)
    if #stacks == 0 then return 'nothing_to_move' end

    state.auto_move_fired = true
    for _, st in ipairs(stacks) do
        queue_storage_move(st.count, CONTAINER.inventory, CONTAINER.satchel,
            st.slot, st.name)
    end
    note(string.format('[stow] inventory full -> queued %d %s stack%s to satchel (%d slots free)',
        #stacks, name, (#stacks == 1) and '' or 's', sat.free))
    return 'dumping'
end

-- True while queued auto-move work is still draining; fishing holds until clear.
local function auto_dump_active()
    return #move_queue > 0
end



local EQUIP_CONTAINERS  = { 0, 8, 10 }

local function find_inventory_item_by_name(item_name, containers)
    containers = containers or INVENTORY_ONLY
    local want = clean_name(item_name)
    if want == '' then return nil end
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    for _, cid in ipairs(containers) do
        for i = 1, 80 do
            local item = inv:GetContainerItem(cid, i)
            if item ~= nil and item.Id ~= 0 then
                local resItem = AshitaCore:GetResourceManager():GetItemById(item.Id)
                if resItem ~= nil and resItem.Name ~= nil then
                    -- Check every name form the resource exposes (index varies
                    -- by build / language slot) rather than assuming Name[1].
                    for k = 0, 3 do
                        local cand = resItem.Name[k]
                        if cand ~= nil and clean_name(cand) == want then
                            return { slot = i, id = item.Id, count = item.Count,
                                     name = tostring(cand), container = cid }
                        end
                    end
                end
            end
        end
    end
    return nil
end

-- Authoritative inventory read: total count of an item across Inventory +
-- Wardrobes 1 & 2. This is the ONLY thing trusted to decide "out of bait" --
-- a chat error, a failed equip, or a single search miss can all false-negative,
-- so we swap to the lure only when inventory itself reports a total of 0.
local function item_total_count(item_name)
    local want = clean_name(item_name)
    if want == '' then return 0 end
    local total = 0
    local inv = AshitaCore:GetMemoryManager():GetInventory()
    for _, cid in ipairs(EQUIP_CONTAINERS) do
        for i = 1, 80 do
            local item = inv:GetContainerItem(cid, i)
            if item ~= nil and item.Id ~= 0 then
                local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
                if res ~= nil and res.Name ~= nil then
                    for k = 0, 3 do
                        if res.Name[k] ~= nil and clean_name(res.Name[k]) == want then
                            total = total + (item.Count or 0)
                            break
                        end
                    end
                end
            end
        end
    end
    return total
end

-- Equip bait (Ammo) / rod (Range) by INJECTING the 0x050 Equip packet instead
-- of the '/equip <slot> "<name>"' text command. Ashita's command queue mangles
-- the quoted multi-word item name before it reaches the game, so the text
-- command silently fails on names like "Insect Ball". Looking the item up in
-- inventory and equipping by slot index sidesteps quoting entirely.
-- FFXI equipment-slot ids: ammo = 3, range = 2. Per-key 2s throttle.
local EQUIP_SLOT_ID = { bait = 3, rod = 2 }
local item_last = {}
-- Returns 'equipped' (packet sent), 'throttled' (too soon), or 'notfound'
-- (item not in inventory/wardrobes). On a bait equip it arms a read-verify:
-- after the settle we confirm the bait is actually on the hook.
local function equip_gear(key, name)
    if name == nil or name == '' then return 'notfound' end
    local eslot = EQUIP_SLOT_ID[key]
    if eslot == nil then return 'notfound' end
    local now = os.clock()
    if (now - (item_last[key] or 0)) < 2.0 then return 'throttled' end
    item_last[key] = now
    local found = find_inventory_item_by_name(name, EQUIP_CONTAINERS)
    if found == nil then
        dnote(string.format('equip %s: "%s" not in inventory/wardrobe', key, name))
        return 'notfound'
    end
    -- 0x050 Equip: [id 0x50][size 0x02 words][sync xx][itemIndex][equipSlot][container][pad]
    local payload_str = struct.pack('bbxxBBBB', 0x50, 0x02, found.slot, eslot, found.container, 0)
    local payload = {}
    for i = 1, #payload_str do payload[i] = payload_str:byte(i) end
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x050, payload)
    gear_settle_until = now + TUNE.GEAR_SETTLE   -- let the equip land before we cast
    dnote(string.format('equip %s "%s" (cont %d slot %d)', key, found.name, found.container, found.slot))
    return 'equipped'
end

-- Bait name for the active slot (slot 2 after a no_bait auto-swap).
current_bait = function()
    if active_bait_slot == 2 and S.bait2_name[1] ~= '' then return S.bait2_name[1] end
    return S.bait_name[1]
end

-- Shared bait-2 swap. Returns true if we actually moved from bait 1 to bait 2,
-- false otherwise (already on bait 2, or bait 2 empty / same as bait 1). Used
-- by the out-of-bait fallback (promote_or_stop) AND by the pool-depletion
-- rotation (S.swap_on_dead_pool). Kept on `state` so callers defined before
-- equip_gear (like state.record_bite_outcome) can invoke it via runtime lookup.
state.try_bait2_rotation = function(reason)
    if active_bait_slot ~= 1 then return false end
    local b2 = S.bait2_name[1]
    if b2 == nil or b2 == '' or b2 == S.bait_name[1] then return false end
    active_bait_slot = 2
    note(string.format('%s -> switching to bait 2 (%s)', reason, b2))
    equip_gear('bait', b2)
    return true
end

-- Out of the current bait: promote bait 2 (the lure) if we're still on slot 1
-- and one is configured, otherwise stop. Equipping the lure re-arms the
-- settle + read-verify, so the lure is confirmed before we cast.
local function promote_or_stop(reason)
    if not state.try_bait2_rotation(reason) then
        state.stop_now('out of bait')
    end
end

----------------------------------------------------------------------------------------------------
-- Packet faker: inject the catch packet
----------------------------------------------------------------------------------------------------

local function inject_ready()
    return last_cast_player_id_bytes ~= nil
       and last_inner_header_bytes  ~= nil
       and state.packet_0x115.captured
end

-- Build + send the 0x110 catch packet (action=03) echoing the gold token
-- from the most recent 0x115. verbose=true prints a chat confirmation.
local function inject_catch_packet(verbose)
    -- Arms itself on the first /fish: the cast's outbound 0x110 supplies
    -- the player-ID + inner-header bytes, and the bite's 0x115 supplies
    -- the token. Until both exist this is a silent no-op.
    if not inject_ready() then
        return false
    end

    local gold = state.packet_0x115.gold_arrow_chance or 0
    local pb1 = string.byte(last_cast_player_id_bytes, 1)
    local pb2 = string.byte(last_cast_player_id_bytes, 2)
    local pb3 = string.byte(last_cast_player_id_bytes, 3)
    local pb4 = string.byte(last_cast_player_id_bytes, 4)
    local ih1 = string.byte(last_inner_header_bytes, 1)
    local ih2 = string.byte(last_inner_header_bytes, 2)

    -- 20-byte packet as a byte TABLE (sol2 wants a table, not a string).
    -- Bytes 0-3 are placeholder zeros; AddOutgoingPacket fills the real
    -- ID/size/sequence. Inner-header bytes 12-13 are captured, never hardcoded.
    local packet = {
        0, 0, 0, 0,
        pb1, pb2, pb3, pb4,
        0, 0, 0, 0,
        ih1, ih2, 0x03, 0x00,
        gold % 256, 0, 0, 0,
    }
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x110, packet)
    -- Arm the post-catch incoming-packet capture (Debug only). The server's
    -- catch resolution (char status / animation-stop / catch result) arrives
    -- in the next ~2s; capturing those bytes gives us the exact packet to
    -- replay-inject for Recovery when the client misses the resolution.
    if S.debug[1] then
        status_capture_until = os.clock() + 2.0
    end
    if verbose then
        note(string.format('catch packet injected (token=0x%02X / %d, header=%02X%02X)',
            gold % 256, gold, ih1, ih2))
    end
    return true
end

-- Build + send the 0x110 release packet (action=03, byte8=0xC8 "let go", no
-- token) -- the let-go the client emits on ESCAPE during a bite. Same captured
-- fish-cycle bytes as the catch; only byte 8 differs (0xC8 vs 0x00 = catch).
local function inject_release_packet(verbose)
    if not inject_ready() then
        return false
    end

    local pb1 = string.byte(last_cast_player_id_bytes, 1)
    local pb2 = string.byte(last_cast_player_id_bytes, 2)
    local pb3 = string.byte(last_cast_player_id_bytes, 3)
    local pb4 = string.byte(last_cast_player_id_bytes, 4)
    local ih1 = string.byte(last_inner_header_bytes, 1)
    local ih2 = string.byte(last_inner_header_bytes, 2)

    local packet = {
        0, 0, 0, 0,
        pb1, pb2, pb3, pb4,
        0xC8, 0, 0, 0,
        ih1, ih2, 0x03, 0x00,
        0, 0, 0, 0,
    }
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x110, packet)
    if verbose then
        note(string.format('release packet injected (header=%02X%02X)', ih1, ih2))
    end
    return true
end

-- Push an ESC-equivalent to end whatever fishing event is in progress:
--   status 56 (Fishing, line in water)  -> /fish cancel (send_fishing_cancel)
--   status 57 (FishBite, bite pending)  -> release packet (0x110 byte8=0xC8)
--   status 58 (Obtained)                -> nothing, animation ends on its own
--   anything else                       -> no-op
-- Safe to call from any pause/stop path; if nothing's active it does nothing.
state.end_current_fishing_event = function()
    -- Read the LIVE status from the entity, NOT the cached state.player.status
    -- (that only updates on transitions and can be stale -- firing /fish at the
    -- wrong stance is what spammed "You cannot use that command").
    local st = 0
    do
        local ok, p = pcall(GetPlayerEntity)
        if ok and p ~= nil then st = p.Status or 0 end
    end
    if st == 57 then
        -- Bite in progress: a release fired the instant the bite lands doesn't
        -- register. Wait 1-2s, then send it (abort_release_at, d3d_present).
        state.abort_release_at = os.clock() + 1.0 + math.random()
        dnote('[abort] bite in progress -> release in ~1-2s')
    elseif st == 56 then
        send_fishing_cancel()
        dnote('[abort] cast in progress -> /fish cancel sent')
        state.abort_verify_at = os.clock() + 3.0   -- confirm stance clears; one re-ESC if not
    end
    -- Also clear any pending release countdown so watchdogs don't chase it.
    if relw then relw.due = 0.0; relw.tries = 0 end
end

-- Full stop. Any place that used to call stop_fishing directly now goes
-- through here so the abort + sound happen once, in the same order.
state.stop_now = function(reason)
    state.end_current_fishing_event()
    stop_fishing(reason)
    state.play_alert('Game_stopped.wav')
end

-- Pause edge. Doesn't touch auto_fish[1] -- each pause path owns its own flag
-- (player_pause_active / gm_tell_pause / interaction_pause_until / tellp).
-- SOFT pauses (player nearby / tells / interaction) do NOT abort the current
-- fish -- it plays out normally and the pause holds only the next cast
-- (aborting mid-fight snaps the line / breaks the rod). Only HARD pauses
-- (GM contact) pass hard=true, which ESCs/releases the current event.
state.pause_now = function(reason, hard)
    if hard then
        state.end_current_fishing_event()
    end
    if reason then dnote('[pause] ' .. reason) end
    state.play_alert('Game_paused.wav')
end

-- Catch the current bite. Always via the injected packet; Enter is only a
-- fallback for the rare frame where the capture isn't armed yet.
local function do_catch(verbose)
    catch_sent_clock = os.clock()   -- end of the fight the bot performed (hook -> here)
    if inject_catch_packet(verbose) then
        dnote('catch packet sent')
    else
        -- Not armed yet: do NOT press a key or release -- never lose a fish/lure.
        -- The resend watchdog will try again; if it never arms it stops instead.
        dnote('catch not armed yet')
    end
end

----------------------------------------------------------------------------------------------------
-- Inventory drop packet
----------------------------------------------------------------------------------------------------

-- Build + send the 12-byte 0x028 Drop packet. Returns ok, info_or_err.
local function drop_item_by_name(item_name)
    if item_name == nil or item_name == '' then return false, 'no item name' end
    local found = find_inventory_item_by_name(item_name)
    if found == nil then return false, 'not in inventory' end
    local payload_str = struct.pack('bbxxIBBH', 0x28, 0x03, found.count, found.container, found.slot, 0)
    local payload = {}
    for i = 1, #payload_str do payload[i] = payload_str:byte(i) end
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x028, payload)
    return true, found
end

----------------------------------------------------------------------------------------------------
-- Auto-fish state machine (runs each frame, throttled by status)
----------------------------------------------------------------------------------------------------

-- Parse a comma/semicolon/space separated list of numbers into a set.
local function parse_num_set(s)
    local set = {}
    for tok in tostring(s or ''):gmatch('[^,;%s]+') do
        local n = tonumber(tok)
        if n then set[n] = true end
    end
    return set
end

-- Parse a comma/semicolon-separated list of FISH NAMES into a lookup set
-- keyed by clean_name (case-insensitive, trimmed). Names may contain spaces,
-- so only comma/semicolon separate entries -- not whitespace.
local function parse_name_set(s)
    local set = {}
    for tok in tostring(s or ''):gmatch('[^,;]+') do
        local n = clean_name(tok)
        if n ~= '' then set[n] = true end
    end
    return set
end

-- Should the current bite be released (Esc) instead of caught? Mirrors
-- apimain's _should_release plus Skip Fish # (depletion blacklist) and
-- Catch Unknown (depletion whitelist). Robust to nil fields.
local function should_release(kind, size, quality, fishname, captured)
    if kind == 'monster' then return S.rel_monsters[1] end
    if kind == 'item' then
        -- Jackpot override: if this item resolves to a name worth >= TUNE.JACKPOT_MIN
        -- (e.g. Mythril Sword 4100, Coral Fragment 1750), KEEP it even though
        -- rel_items would normally toss all items.
        if S.catch_jackpot[1] and fishname then
            local v = DB.fish_value[clean_name(fishname)] or 0
            if v >= TUNE.JACKPOT_MIN then
                note(string.format('JACKPOT: keeping %s (%dg)', fishname, v))
                return false   -- keep it
            end
        end
        return S.rel_items[1]
    end
    if kind == 'fish' then
        if captured then
            local nm = fishname and clean_name(fishname) or nil
            -- Skip Fish: release any fish whose NAME is on the blacklist.
            if S.skip_name[1] ~= '' and nm and parse_name_set(S.skip_name[1])[nm] then
                return true
            end
            -- Catch Only Known: release any fish NOT on the known/whitelist.
            -- Unresolved names (nm == nil) are treated as unknown -> released
            -- in whitelist mode, so the bot never keeps a fish it can't name.
            if S.catch_unknown[1] then
                if nm == nil or not parse_name_set(S.known_name[1])[nm] then
                    return true
                end
            end
        end
        if quality == 'terrible' and S.rel_terrible[1] then return true end
        if quality == 'bad'      and S.rel_bad[1]      then return true end
        if quality == 'positive' and S.rel_positive[1] then return true end
        if size == 'small' and S.rel_small[1] then return true end
        if size == 'large' and S.rel_large[1] then return true end
    end
    return false
end

-- Long reset. A halt-worthy transient error (server reject / out of bait
-- or rod) holds off casting for TUNE.RETRY_COOLDOWN, up to TUNE.RETRY_MAX times.
-- The budget resets to 0 on any accepted bite (see text_in), so one
-- transient hiccup in a long run doesn't pin the bot on a 90s cycle.
-- After TUNE.RETRY_MAX consecutive retries with no catch between them, stop for
-- good -- that pattern means a broken state another retry won't fix.
local function schedule_retry(reason)
    last_retry_reason = reason
    if retry_attempts >= TUNE.RETRY_MAX then
        retry_attempts  = 0
        retry_resume_at = 0
        state.stop_now(string.format('max retries (%d) - %s', TUNE.RETRY_MAX, reason))
        return
    end
    retry_attempts  = retry_attempts + 1
    retry_resume_at = os.clock() + TUNE.RETRY_COOLDOWN
    note(string.format('%s -> retry %d/%d in %ds',
        reason, retry_attempts, TUNE.RETRY_MAX, math.floor(TUNE.RETRY_COOLDOWN)))
end

-- Resolve a FishID to its (min,max) fight range by parsing the editable
-- fish_rows buffers. Unknown IDs use unk_row. The buffers (declared up top)
-- are the single source of truth -- the GUI edits them, fight_duration reads
-- them, and they persist.
-- Resolve a FISH NAME to its (min,max) fight range by parsing the editable
-- fish_rows buffers. Unknown names use unk_row. Matching is case-insensitive.
local function fish_entry(name)
    if name ~= nil then
        local want = clean_name(tostring(name))
        for _, r in ipairs(fish_rows) do
            if clean_name(r.id[1]) == want then
                local lo = tonumber(r.min[1]) or 0
                local hi = tonumber(r.max[1]) or lo
                return lo, hi
            end
        end
    end
    return (tonumber(unk_row.min[1]) or 4.5), (tonumber(unk_row.max[1]) or 5.5)
end

-- How long to "fight" before sending the catch, from the FishID time table
-- so catches aren't instant (instant catches are a ban flag). Extend Fishing
-- adds 1-2s on top of the table range. The base and extend components are
-- stashed (last_fight_base / last_fight_extend) so the catch report can show
-- them split as Base + Extend = Total.
local last_fight_base   = 0.0
local last_fight_extend = 0.0

-- Pick the fight (lo,hi) range for the hooked fish. Normal case: look up the
-- resolved name. Ambiguous case (fight_fish_ambig has 2+ names): we can't tell
-- which fish it is, so pick the SAFEST timing = the LONGEST max among all the
-- candidates AND the Unknown fallback (an instant/too-short catch is a ban
-- flag, so longer is always the safe error). Log it so the collision is
-- visible and can be designed out later.
local function resolve_fight_range()
    -- Unambiguous: single resolved name (or fall back to the raw key string).
    if not (fight_fish_ambig and #fight_fish_ambig > 1) then
        return fish_entry(fight_fish_name or state.packet_0x115.stamina_depletion or 0)
    end
    -- Ambiguous: use the LONGEST range among the candidates that are actually in
    -- the fish table. Ignore Unknown entirely unless NONE of the candidates have
    -- a table row (only then is Unknown the right fallback).
    local best_lo, best_hi, found = nil, nil, false
    local ranges_differ = false
    local first_lo, first_hi
    for _, nm in ipairs(fight_fish_ambig) do
        local want = clean_name(tostring(nm))
        for _, r in ipairs(fish_rows) do
            if clean_name(r.id[1]) == want then
                local lo = tonumber(r.min[1]) or 0
                local hi = tonumber(r.max[1]) or lo
                if not found then
                    first_lo, first_hi = lo, hi
                else
                    if lo ~= first_lo or hi ~= first_hi then ranges_differ = true end
                end
                if not found or hi > best_hi then best_lo, best_hi = lo, hi end
                found = true
                break
            end
        end
    end
    if not found then
        best_lo = tonumber(unk_row.min[1]) or 4.5
        best_hi = tonumber(unk_row.max[1]) or 5.5
    end
    -- Reporting: stay quiet when the candidates are all in the table with the
    -- SAME min/max (nothing actionable -- debug only). Warn loudly only when
    -- they share a stamina key but have DIFFERENT min/max (a table mismatch to
    -- reconcile). If none were in the table, that's the old debug note.
    if found and ranges_differ then
        note(string.format('%s have same stamina but different min/max - using longest (%.1f-%.1fs)',
            table.concat(fight_fish_ambig, ' and '), best_lo, best_hi))
    else
        dnote(string.format('ambiguous %s -> %.1f-%.1fs',
            table.concat(fight_fish_ambig, ' or '), best_lo, best_hi))
    end
    return best_lo, best_hi
end

local function fight_duration()
    local lo, hi = resolve_fight_range()
    if hi < lo then hi = lo end
    local base = lo + math.random() * (hi - lo)
    local extend = 0.0
    if S.rand_timing[1] then extend = 1.0 + math.random() * 1.0 end  -- Extend Fishing: +1-2s
    last_fight_base   = base
    last_fight_extend = extend
    return base + extend
end

local function auto_fish_tick()
    if not auto_fish[1] then return end
    if not logged_in then return end

    -- Detector gate. HARD stops (GM entity / asshole) abort the current fish
    -- (ESC/release with stance verify inside stop_now) and return. SOFT pauses
    -- (player nearby / interaction probe) must NOT abandon a fish mid-fight --
    -- that snaps the line and can break the rod. Soft holds only prevent the
    -- NEXT cast: mid-cast/fight the tick keeps running so the fish resolves
    -- normally; once back at Idle the hold returns before a new cast fires.
    local soft_hold   = false
    local player_hold = false
    do
        local d = state.detector_check()
        if d == 'gm_stop' or d == 'asshole_stop' then return end   -- stopped + aborted
        if d == 'player_pause' or d == 'player_wait' then
            soft_hold   = true
            player_hold = true
        end
    end
    if state.gm_tell_pause then
        -- HARD pause (GM /tell or GMPROMPT): abort the current fish immediately
        -- (ESC/release; the 3s stance-verify in d3d_present re-fires ESC if the
        -- stance didn't clear), then hold forever until manual restart.
        if not state.gm_abort_done then
            state.gm_abort_done = true
            state.end_current_fishing_event()
        end
        return
    end
    if state.interaction_pause_until and os.clock() < state.interaction_pause_until then
        soft_hold = true
    end
    if soft_hold then
        -- Only hold when truly idle (nothing in the water, nothing resolving).
        -- Mid-cast/fight falls through so the current fish finishes cleanly.
        if state.player.status == 0 and catch_at == 0 and catch_action_at == 0 then
            -- This is the moment a player pause actually costs us a cast. Until
            -- it happens the pause is theoretical (we fished straight through),
            -- and detector_check skips the leave cooldown on that basis.
            if player_hold then state.player_pause_held = true end
            return
        end
    end

    -- Inventory gate -- runs BEFORE any fishing state machine logic. If
    -- inventory is full the bot has no business casting/equipping/anything,
    -- so handle the full state first and return. The fisher only runs when
    -- there's room to catch into.
    local _inv = container_space(CONTAINER.inventory)
    if _inv ~= nil and _inv.free <= 0 then
        -- A queued auto-move is still draining -> wait it out.
        if auto_dump_active() then return end

        -- CONFIRM the full before acting on it. A fresh catch lands in a new
        -- slot and only stacks/sorts a moment later, so inventory reads 60/60
        -- for a beat and settles back to 59/60. Hold for TUNE.FULL_CONFIRM seconds
        -- and re-read: if it cleared on its own, we keep fishing (the reset
        -- below runs on the next tick once free > 0). Only a full that survives
        -- the whole window counts as real.
        if state.inv_full_since == nil then
            state.inv_full_since = os.clock()
            dnote('[stow] inventory reads full - confirming...')
            return
        end
        if os.clock() - state.inv_full_since < TUNE.FULL_CONFIRM then return end
        -- Previous auto-move fired and finished draining -> verify it freed
        -- inventory. The server needs a moment to process the move and send the
        -- inventory update back, so wait a short settle after the queue emptied
        -- before judging. Reading inv.free too early always shows still-full.
        if state.auto_move_fired then
            if state.auto_move_verify_at == nil then
                state.auto_move_verify_at = os.clock() + 3.0   -- settle for the server update
                return
            end
            if os.clock() < state.auto_move_verify_at then return end
            -- Settle elapsed and still full -> the move genuinely did nothing.
            state.auto_move_fired = false
            state.auto_move_verify_at = nil
            state.stop_now('auto-move did nothing - inventory still full')
            return
        end
        if S.auto_move[1] then
            local r = auto_move_on_full()
            -- dumping / pending -> hold the whole tick while the queue drains
            if r == 'dumping' or r == 'pending' then return end
            -- both_full / nothing_to_move -> can't clear by moving; stop if the
            -- stop-on-full toggle is on, else just hold (don't cast into full).
            if S.stop_full[1] then
                state.stop_now('inventory full')
            end
            return
        end
        -- auto_move off and inv full -> stop if toggle on, else hold.
        if S.stop_full[1] then state.stop_now('inventory full') end
        return
    end
    -- inv has room -> the move worked, or the "full" was just a pre-sort blip
    -- that cleared during the confirm window. Reset all the guards so the next
    -- full event starts clean.
    state.inv_full_since = nil
    state.auto_move_fired = false
    state.auto_move_verify_at = nil

    -- Move-detection shutdown: any axis past TUNE.MOVE_TOLERANCE from the
    -- baseline (snapshotted when fishing started) means GM warp / walked
    -- off / knockback -> stop. Gated on the checkbox.
    if S.stop_moved[1] and move_base ~= nil then
        if math.abs(state.player.x - move_base[1]) > TUNE.MOVE_TOLERANCE
        or math.abs(state.player.y - move_base[2]) > TUNE.MOVE_TOLERANCE
        or math.abs(state.player.z - move_base[3]) > TUNE.MOVE_TOLERANCE then
            state.stop_now('moved')
            return
        end
    end

    local s = state.player.status

    -- Bite: wait for enough info, decide release vs catch, then watch the
    -- catch resolve.
    if s == 57 then
        if not bite_handled then
            if bite_seen_at == 0 then bite_seen_at = os.clock() end
            local waited = os.clock() - bite_seen_at
            -- Wait (up to TUNE.BITE_GRACE) for the data a release filter needs:
            -- the quality 'feeling' line and/or the 0x115 depletion.
            local need_q = S.rel_terrible[1] or S.rel_bad[1] or S.rel_positive[1]
            local ready  = (state.bite.kind ~= nil)
            if need_q and state.bite.quality == nil then ready = false end
            -- Always wait for 0x115: the catch needs its gold token, and
            -- fight_duration() needs the real depletion (otherwise it falls
            -- back to the wider unknown range and the timing is less accurate).
            if not state.packet_0x115.captured then ready = false end
            if waited >= TUNE.BITE_GRACE then ready = true end  -- give up waiting

            if ready then
                bite_handled = true
                bite_seen_at = 0
                state.record_bite_outcome(state.bite.kind)
                if should_release(state.bite.kind, state.bite.fish_size,
                                  state.bite.quality, fight_fish_name,
                                  state.packet_0x115.captured) then
                    stats.released  = stats.released + 1
                    consec_bad      = consec_bad + 1
                    catch_action_at = 0   -- released: no catch watchdog
                    relw.at = 0.0; relw.tries = 0
                    dnote(string.format('release: %s%s%s',
                        fight_fish_name or tostring(state.bite.kind),
                        state.bite.fish_size and ('/' .. state.bite.fish_size) or '',
                        state.bite.quality and (' ' .. state.bite.quality) or ''))
                    -- Always wait a beat before the release -- an instant
                    -- let-go on every unwanted bite is a detectable pattern.
                    -- Extend Release adds another 0.75-1.25s on top when on.
                    local rel_delay = 1.0 + math.random() * 0.5
                    if state.extend_release[1] then
                        rel_delay = rel_delay + 0.75 + math.random() * 0.5
                    end
                    relw.due = os.clock() + rel_delay   -- when the release fires (for the status countdown)
                    ashita.tasks.once(rel_delay,
                        function()
                            inject_release_packet(false)
                            relw.at = os.clock()   -- arm the resend watchdog
                            relw.due = 0.0         -- release fired; stop the countdown
                        end)
                    -- Anti-flag: TUNE.SAFETY_STREAK_LIMIT bad results in a row -> a
                    -- 3-5s cooldown (separate from the normal per-cast dwell).
                    -- Don't arm the timer NOW (the fish animation is still
                    -- playing); mark it pending so the hold starts when we
                    -- return to Idle -- a real 3-5s of stillness.
                    if consec_bad >= TUNE.SAFETY_STREAK_LIMIT then
                        state.safety_cooldown_pending = true
                        consec_bad       = 0
                        note(string.format('%d in a row -> safety cooldown (on idle)',
                            TUNE.SAFETY_STREAK_LIMIT))
                    end
                else
                    -- Catch: do NOT inject instantly -- that auto-flags.
                    relw.at = 0.0; relw.tries = 0
                    -- Fight delay measured FROM THE 0x115 PACKET arrival
                    -- (fight_start_clock, the same anchor the report uses), so
                    -- the catch fires at exactly anchor + base + extend and the
                    -- measured total equals base+extend.
                    local dur     = fight_duration()
                    local anchor  = (fight_start_clock > 0) and fight_start_clock or os.clock()
                    catch_at      = anchor + dur
                    -- Safety catch-all (NOT part of our timing): if a fish table
                    -- is misconfigured with a sub-1.5s duration, an instant-ish
                    -- catch is a ban flag. Floor it and S.debug-echo so the bad
                    -- table row is visible. With sane tables this never fires.
                    local floor_at = os.clock() + 1.5
                    if catch_at < floor_at then
                        catch_at = floor_at
                        dnote(string.format('[floor] dur %.1fs below 1.5s safety floor -- check fish table (id %d)',
                            dur, fight_fish_id))
                    end
                    dnote(string.format('fighting ~%.1fs (from 0x115)', dur))
                end
            end
        elseif catch_at > 0 then
            -- Fight in progress: send the catch when the timer elapses.
            if os.clock() >= catch_at then
                catch_at        = 0
                catch_action_at = os.clock()
                catch_resent    = 0
                state.catch_resend_gap = 3.0 + math.random() * 2.0   -- 1st resend wait: 3-5s
                do_catch(false)
            end
        elseif catch_action_at > 0 then
            -- Catch was sent but status is still FishBite (57) -- the inject was
            -- dropped or the server lagged. The fish is only catchable while the
            -- minigame is live, so resend FAST and only while status == 57:
            --   1st resend at ~4s, 2nd resend at ~7s after that. If both fail
            -- the fish is gone -- give up this bite (clear and move on), no long
            -- cooldown (a long wait is pointless, the fish left long ago).
            local now = os.clock()
            -- If we left FishBite, the fish resolved or fled -> stop the watchdog.
            if state.player.status ~= 57 then
                catch_action_at = 0
                catch_resent    = 0
            elseif (now - catch_action_at) >= (state.catch_resend_gap or 4.0) then
                if catch_resent == 0 then
                    catch_resent    = 1
                    catch_action_at = now
                    state.catch_resend_gap = 5.0 + math.random() * 5.0   -- 2nd wait: 5-10s
                    note('[recovery] catch not acknowledged -> resend 1 (fast)')
                    do_catch(false)
                elseif catch_resent == 1 then
                    catch_resent    = 2
                    catch_action_at = now
                    note('[recovery] catch not acknowledged -> resend 2 (fast)')
                    do_catch(false)
                else
                    -- Both fast resends failed and still at 57 -> fish is gone.
                    catch_action_at = 0
                    catch_resent    = 0
                    note('[recovery] catch lost (2 resends failed) - moving on')
                    clear_bite_latch()
                end
            end
        elseif relw.at > 0 then
            -- Still at FishBite after the release packet fired: it was dropped
            -- or ignored. Resend at most twice -- one quick (3s), one longer
            -- (10s) -- then give up and stop. Never loops forever.
            local now  = os.clock()
            local wait = (relw.tries == 0) and TUNE.RELEASE_FIRST or TUNE.RELEASE_CD
            if (now - relw.at) >= wait then
                if relw.tries < TUNE.RELEASE_MAX then
                    relw.tries = relw.tries + 1
                    relw.at    = now
                    dnote(string.format('[recovery] release not acknowledged -> resend %d/%d',
                        relw.tries, TUNE.RELEASE_MAX))
                    inject_release_packet(false)
                else
                    relw.at = 0.0
                    state.stop_now('stuck (release not acknowledged)')
                end
            end
        end
        return
    else
        bite_handled    = false
        bite_seen_at    = 0
        catch_at        = 0   -- bite resolved -> cancel any pending fight timer
        catch_action_at = 0   -- bite resolved (caught / lost / cast) -> clear watchdog
        relw.at         = 0.0 -- bite resolved -> clear release watchdog
        relw.tries      = 0
        if s ~= 0 then
            cast_pending = false   -- status left Idle -> the cast registered
            cast_fail    = 0
        end

        -- Cast-stall watchdog: status 56 is "cast in progress". Arm a timer
        -- the first frame we see it; if it never resolves (no bite, no return
        -- to Idle) within TUNE.CAST_STALL_LIMIT, the connection is dead (3101
        -- transmission error / silent d/c) and we'd hang on "Casting" forever.
        -- Any status other than 56 clears the timer.
        if s == 56 then
            if cast_stall_at == 0 then cast_stall_at = os.clock() end
            if (os.clock() - cast_stall_at) >= TUNE.CAST_STALL_LIMIT then
                cast_stall_at = 0
                state.stop_now('cast stalled (lost connection?)')
                return
            end
        else
            cast_stall_at = 0
        end
    end

    -- Idle and standing: cast (throttled). Held off during a retry cooldown.
    if s == 0 then
        local now = os.clock()

        -- (Inventory full handling lives at the TOP of auto_fish_tick now; if
        -- we reach here, inventory has room and the fisher is free to run.)

        -- A safety cooldown tripped by a bad-result STREAK (5 releases/misses
        -- in a row) starts counting HERE, now that we've returned to Idle and
        -- the fish animation is done -- so it's a real 3-5s of stillness, not a
        -- timer that began while the catch/release was still animating. This is
        -- SEPARATE from the 0.5-0.75s per-cast recast dwell below.
        if state.safety_cooldown_pending then
            state.safety_cooldown_pending = false
            safety_resume_at = now + 3.0 + math.random() * 2.0   -- 3-5s
        end

        -- A cast that never registers produces NO status transition (status
        -- stays Idle), and the fire/fail-count gate below is behind
        -- `idle_cast_at > 0`. With idle_cast_at consumed (0) and no transition
        -- to re-arm it, a dead cast would sit forever and the retry could never
        -- run. So if Idle with a cast still pending and nothing armed, re-arm
        -- the normal recast dwell here so the retry path stays reachable.
        if cast_pending and idle_cast_at == 0 then
            idle_cast_at = now + cast_gap
            if state.recast_delay[1] then
                idle_cast_at = idle_cast_at + TUNE.IDLE_JITTER_MIN
                    + math.random() * (TUNE.IDLE_JITTER_MAX - TUNE.IDLE_JITTER_MIN)
            end
        end

        -- A queued hard stop (repeat tell burst) runs now that the fight is
        -- done, so we never abandon a fish mid-fight.
        if tellp.hard_stop then
            tellp.hard_stop = false
            tellp.pause_until  = 0
            tellp.regime_start = 0
            state.stop_now('repeat tells')
            return
        end
        -- Tell pause: hold casting until it expires, then resume.
        if tellp.pause_until > 0 then
            if now < tellp.pause_until then return end
            tellp.pause_until  = 0
            tellp.regime_start = 0
            tellp.times        = {}
            note('tell pause over -> resuming')
        end
        if retry_resume_at > 0 then
            if now < retry_resume_at then return end
            -- Cooldown just elapsed (one-time). If the halt was no_bait on
            -- slot 1 and a backup bait is set, promote it and start fresh.
            retry_resume_at = 0
            if last_retry_reason == 'no_bait'
               and active_bait_slot == 1
               and S.bait2_name[1] ~= '' then
                active_bait_slot = 2
                retry_attempts   = 0
                note(string.format('bait 1 dry -> promoting bait 2 (%s)', S.bait2_name[1]))
                equip_gear('bait', S.bait2_name[1])
                -- equip_gear arms gear_settle_until; the settle block below
                -- arms the cast once the equip lands.
            elseif idle_cast_at == 0 then
                -- Plain retry (lag error, no re-equip) -> arm the cast with the
                -- normal recast dwell (the dwell prevents server spam).
                idle_since   = now
                idle_cast_at = now + cast_gap
                if state.recast_delay[1] then
                    idle_cast_at = idle_cast_at + TUNE.IDLE_JITTER_MIN
                        + math.random() * (TUNE.IDLE_JITTER_MAX - TUNE.IDLE_JITTER_MIN)
                end
            end
            last_retry_reason = nil
        end
        if safety_resume_at > 0 then
            if now < safety_resume_at then return end
            safety_resume_at = 0
        end
        if state.pool.resume_at > 0 then
            if now < state.pool.resume_at then return end
            state.pool.resume_at = 0
            -- Start the ring fresh on resume so any stray outcomes recorded
            -- during the pause window can't bias the next depletion check.
            state.pool.ring    = {}
            state.pool.i       = 1
            state.pool.n       = 0
            state.pool.pending = false
            note('pool regen done -> resuming (ring reset)')
        end
        -- Post-equip settle: after a bait/rod swap, wait for the equip to land
        -- before the next /fish, so we don't re-cast into the same no_bait.
        if gear_settle_until > 0 then
            if now < gear_settle_until then return end
            gear_settle_until = 0
            -- Settle done -> arm the "try to fish again" cast. (A swap/equip has
            -- no status->0 reel-in transition to arm it, so do it here.) Use the
            -- normal recast dwell, not immediate -- the dwell prevents server
            -- spam. A good cast resets the retry ladder below.
            if idle_cast_at == 0 then
                idle_since   = now
                idle_cast_at = now + cast_gap
                if state.recast_delay[1] then
                    idle_cast_at = idle_cast_at + TUNE.IDLE_JITTER_MIN
                        + math.random() * (TUNE.IDLE_JITTER_MAX - TUNE.IDLE_JITTER_MIN)
                end
            end
        end
        -- Cast throttle: wait until idle_cast_at (set on the Idle transition
        -- to idle_since + cast_gap + jitter). Paced from when we returned to
        -- Idle, NOT from the last cast -- the old (now - last_cast_clock)
        -- gate expired during any fight longer than cast_gap, firing the
        -- next cast with zero Idle dwell and no gear-swap window.
        if idle_cast_at > 0 and now >= idle_cast_at then
            -- A cast that was sent but never left Idle didn't register. Count
            -- the dead casts; after TUNE.CAST_FAIL_LIMIT, hand off to the existing
            -- long cooldown (schedule_retry: 90s hold, resume, re-check) --
            -- a dead cast is almost always server lag, so back off rather than
            -- hard-stop. Leave the reason in the log either way.
            if cast_pending then
                cast_fail = cast_fail + 1
                note(string.format('[cast] cast did not register (%d/%d)', cast_fail, TUNE.CAST_FAIL_LIMIT))
                if cast_fail >= TUNE.CAST_FAIL_LIMIT then
                    cast_fail    = 0
                    cast_pending = false
                    schedule_retry('casts not registering (lag?)')
                    return
                end
            end
            last_cast_clock = now
            cast_gap = pick_cast_gap()   -- re-roll the base interval (1-2s)
            cast_pending = true
            idle_cast_at = 0   -- consumed; re-armed on the next Idle transition
            -- ROD SYNC: the game only errors 'no_rod' when NOTHING is equipped,
            -- so a WRONG rod (e.g. Halcyon on while config says Hume) never
            -- triggers a swap on its own. If the equipped rod != configured rod
            -- and we own the configured one, equip it and skip THIS cast so the
            -- swap lands; the next tick casts with the correct rod.
            do
                local cfg_rod = S.rod_name[1] or ''
                if cfg_rod ~= '' then
                    local eq_rod = DB.equipped_item_name(EQUIP_SLOT_RANGE)
                    if clean_name(eq_rod or '') ~= clean_name(cfg_rod)
                       and item_total_count(cfg_rod) > 0 then
                        if equip_gear('rod', cfg_rod) == 'equipped' then
                            note(string.format('rod sync: "%s" -> "%s" (settling)',
                                eq_rod or 'none', cfg_rod))
                            cast_pending = false
                            return
                        end
                    end
                end
            end
            -- Test mode: when Full Bot is OFF, fish only 5 times then stop.
            -- (Full Bot ON = fish normally, no cap.)
            if not S.full_bot[1] and (state.run_casts or 0) >= 5 then
                state.stop_now('test done (5 casts) - enable Full Bot to run')
                return
            end
            state.run_casts = (state.run_casts or 0) + 1
            send_cast()
        end
    end
end

----------------------------------------------------------------------------------------------------
-- Event handlers
----------------------------------------------------------------------------------------------------

local prev_status = nil
local prev_name   = ''
local prev_visible = true   -- detect the window X flipping ui_visible off

-- Two-line status: returns line1 (state), line2 (detail/name), colour.
-- The render block prints line1 then line2 in this colour.
local function activity_status()
    local now = os.clock()
    if not auto_fish[1] then
        return (stop_reason and ('Stopped - ' .. stop_reason) or 'Stopped'), '', { 0.7, 0.7, 0.7, 1 }
    end
    if tellp.pause_until > 0 and now < tellp.pause_until and catch_at == 0 and state.player.status ~= 57 then
        local left = tellp.pause_until - now
        return string.format('Tell pause %dm %ds', math.floor(left / 60), math.floor(left % 60)), '', { 1, 0.8, 0.3, 1 }
    end
    -- Detector pauses (only surface when not mid-fight, so a bite still shows).
    if state.player.status ~= 57 and catch_at == 0 then
        if state.gm_tell_pause then
            return 'Paused - GM contact (AFK)', 'manual restart required', { 1, 0.4, 0.4, 1 }
        end
        if state.interaction_pause_until and now < state.interaction_pause_until then
            return 'Paused - say/emote probe', string.format('%.0fs', state.interaction_pause_until - now), { 1, 0.6, 0.3, 1 }
        end
        if state.player_pause_active then
            if state.scan_has_player then
                return 'Paused - player nearby', '', { 1, 0.8, 0.3, 1 }
            else
                local left = state.PLAYER_DETECT.leave - (now - (state.player_pause_since or 0))
                if left > 0 then
                    return 'Paused - player left', string.format('resume %.0fs', left), { 1, 0.8, 0.3, 1 }
                end
            end
        end
    end
    if retry_resume_at > 0 and now < retry_resume_at then
        return string.format('Error - retry %d/%d in %ds',
            retry_attempts, TUNE.RETRY_MAX, math.ceil(retry_resume_at - now)), '', { 1, 0.5, 0.3, 1 }
    end
    if gear_settle_until > 0 and now < gear_settle_until and state.player.status == 0 then
        return string.format('Equipped - settling %.1fs', gear_settle_until - now), '', { 0.8, 0.9, 1, 1 }
    end

    -- The currently-hooked name (line 2 during a bite). Monster has no table
    -- name; fall back to the capitalized bite kind for anything unresolved.
    local hooked_name = '(No Data)'
    if state.bite.kind == 'monster' then
        -- Use the resolved monster name (via dep_x20) if we have one; the
        -- resolver may return a single name or an ambiguous "X or Y" list.
        local n = fish_display()
        hooked_name = (n and n ~= '?' and n ~= '') and n or 'Monster'
    elseif state.packet_0x115.captured then
        local n = fish_display()
        if n and n ~= '?' and n ~= '' then
            hooked_name = n
        elseif state.bite.kind then
            hooked_name = state.bite.kind:sub(1,1):upper() .. state.bite.kind:sub(2)
        end
    end

    local s = state.player.status

    -- CASTING / FISHING: line1 only, no timer.
    if s == 56 then
        return 'Casting/Fishing', '', { 0.5, 1.0, 0.6, 1 }
    end

    -- HOOKED (Bite): line1 = "Bite! (Sleeping X)" countdown from the fish
    -- min/max table (catch_at, the system's real fight timing), line2 = name.
    -- Only while a bite is latched -- clear_bite_latch() nils bite.kind the
    -- instant the catch/release resolves so it never sticks past the event.
    if s == 57 and state.bite.kind ~= nil then
        local bang = (state.bite.fish_size == 'large') and '!!!' or '!'
        -- A release was scheduled for this bite -> count down to the let-go.
        if relw.due > 0 and now < relw.due then
            return string.format('Bite%s (Release %.1fs)', bang, relw.due - now), hooked_name, { 0.5, 0.9, 1, 1 }
        end
        -- Otherwise the catch is pending: count down catch_at (fish min/max table).
        if catch_at > 0 and now < catch_at then
            return string.format('Bite%s (Sleeping %.1fs)', bang, catch_at - now), hooked_name, { 0.5, 0.9, 1, 1 }
        end
        return 'Bite' .. bang, hooked_name, { 0.5, 0.9, 1, 1 }
    end

    -- RESULT: line1 = result label, line2 = the fish name. Shown ONLY during
    -- the reel-in animation -- i.e. before the status->0 transition arms the
    -- recast sleep (idle_cast_at == 0). Once the sleep is armed we've truly
    -- returned to Idle, so the Idle/Sleeping line below takes over instead of
    -- the result sitting there forever.
    if idle_cast_at == 0 and safety_resume_at == 0 then
        local RESULT_LABEL = {
            caught     = { 'Caught!',     { 0.6, 1.0, 0.6, 1 } },
            released   = { 'Release',     { 0.7, 0.8, 1.0, 1 } },
            no_catch   = { 'No Catch',    { 0.8, 0.8, 0.8, 1 } },
            lost_catch = { 'No Catch',    { 0.8, 0.8, 0.8, 1 } },
            fish_got_away = { 'No Catch', { 0.8, 0.8, 0.8, 1 } },
            line_broke = { 'Line Broke',  { 1.0, 0.6, 0.4, 1 } },
            rod_broke  = { 'Rod Broke',   { 1.0, 0.5, 0.4, 1 } },
            lost_too_small = { 'Too Small', { 0.9, 0.8, 0.5, 1 } },
        }
        local lbl = state.last_result.kind and RESULT_LABEL[state.last_result.kind]
        if lbl then
            local nm = state.last_result.name and state.last_result.name ~= ''
                and titlecase(state.last_result.name) or '(No Data)'
            return lbl[1], nm, lbl[2]
        end
    end

    -- IDLE: line2 shows the wait before the next cast.
    --  * safety cooldown (3-5s) if active -> show it (the longer hold)
    --  * else the recast-delay countdown (idle_cast_at), which is only armed
    --    AFTER the reel-in animation finishes (status returns to Idle). During
    --    the animation idle_cast_at is 0 -> bare "Idle", which is correct: the
    --    sleep hasn't started yet. Do NOT fake a countdown here.
    if state.pool.resume_at > 0 and now < state.pool.resume_at then
        local left = state.pool.resume_at - now
        return 'Paused', string.format('Pool regen %dm%02ds', math.floor(left / 60), math.floor(left) % 60), { 1, 0.6, 0.3, 1 }
    end
    if safety_resume_at > 0 and now < safety_resume_at then
        return 'Idle', string.format('Cooldown %.1fs', safety_resume_at - now), { 1, 0.8, 0.3, 1 }
    end
    if idle_cast_at > 0 and now < idle_cast_at then
        return 'Idle', string.format('Sleeping %.1fs', idle_cast_at - now), { 0.7, 0.9, 0.7, 1 }
    end
    return 'Idle', '', { 0.7, 0.9, 0.7, 1 }
end

-- Reset all per-run budgets/timers when auto-fish starts. Lives in its own
-- function so the render callback doesn't carry all these as upvalues
-- (Lua caps a function at 60 upvalues).
local function begin_run()
    stop_reason       = nil
    fail_streak       = 0
    reject_streak     = 0
    retry_attempts    = 0
    retry_resume_at   = 0
    active_bait_slot  = 1
    state.run_casts   = 0   -- per-run cast count (for the 5-cast test when Full Bot is off)
    last_retry_reason = nil
    consec_bad        = 0
    safety_resume_at  = 0
    state.pool.resume_at = 0
    state.pool.ring      = {}
    state.pool.i         = 1
    state.pool.n         = 0
    state.pool.pending   = false
    cast_pending      = false
    cast_fail         = 0
    cast_stall_at     = 0
    state.gm_tell_pause = false          -- clear GM hard-AFK on manual restart
    state.gm_abort_done = false          -- re-arm the hard-abort edge
    state.abort_verify_at = nil          -- drop any pending stance-verify
    state.abort_release_at = nil         -- and any pending delayed abort-release
    state.player_pause_active = false    -- START resets the player leave-cooldown...
    state.player_pause_since = nil       -- ...(detector re-pauses instantly if someone's still there)
    state.player_pause_held  = false     -- ...and the "did the pause actually stop a cast" edge
    state.interaction_pause_until = nil  -- and the say/emote probe hold
    state.pool.rotated_this_run = false  -- and re-arm the one-shot bait-2 rotation
    state.run_started_at = os.clock()     -- grace period: ignore chat backlog on login/zone
    cast_gap          = pick_cast_gap()
    gear_settle_until = 0
    idle_since        = 0
    idle_cast_at      = 0
    -- On START: if we're already standing at Idle (status 0), arm the first
    -- cast now with the recast delay so "Idle (Sleeping XXX)" shows then casts.
    -- If we START mid-fishing (casting/bite), DON'T arm here -- just read the
    -- live status and pick up from there; the real reel-in (status->0)
    -- transition will arm the next cast normally.
    if state.player.status == 0 then
        idle_since   = os.clock()
        idle_cast_at = idle_since + cast_gap
        if state.recast_delay[1] then
            idle_cast_at = idle_cast_at + TUNE.IDLE_JITTER_MIN
                + math.random() * (TUNE.IDLE_JITTER_MAX - TUNE.IDLE_JITTER_MIN)
        end
    end
    tellp.pause_until  = 0
    tellp.regime_start = 0
    tellp.hard_stop    = false
    tellp.times        = {}
    move_base = { state.player.x, state.player.y, state.player.z }
    -- Area-lock sanity: warn if the loaded pool's AREA != the zone we're in.
    if loaded_area ~= '' then
        local region = current_region()
        local zone_base = tostring(region):gsub('%s*%(%d+%)%s*$', '')
        if zone_base ~= '' and zone_base ~= '?' and clean_name(zone_base) ~= clean_name(loaded_area) then
            note(string.format('WARN: loaded pool AREA "%s" != current zone "%s" - wrong table?',
                loaded_area, zone_base))
        end
    end
end

ashita.events.register('d3d_present', 'bfh_present', function()
    poll_pick()   -- non-blocking: pick up load/save file-dialog results if any landed
    state.upd_poll()   -- non-blocking: pick up an in-flight GitHub version check
    process_move_queue()   -- drain at most one paced storage move per interval
    state.sell_all_tick()  -- paced "Sell All": one stack of the target fish per ~1s
    -- Hard-abort delayed release: a bite-in-progress abort waits 1-2s (release
    -- doesn't register right as the bite lands), then fires here. Live status.
    if state.abort_release_at and os.clock() >= state.abort_release_at then
        state.abort_release_at = nil
        local st = 0
        local ok, p = pcall(GetPlayerEntity)
        if ok and p ~= nil then st = p.Status or 0 end
        if st == 57 then
            if inject_release_packet(false) then
                dnote('[abort] release packet sent')
            end
            state.abort_verify_at = os.clock() + 3.0
        end
    end
    -- Hard-abort stance verify: after an ESC/release abort, confirm the fishing
    -- stance actually cleared. If still at 56/57 3s later, press ESC ONCE more
    -- -- one retry only, never a loop (anti-spam). Live status.
    if state.abort_verify_at and os.clock() >= state.abort_verify_at then
        state.abort_verify_at = nil
        local st = 0
        local ok, p = pcall(GetPlayerEntity)
        if ok and p ~= nil then st = p.Status or 0 end
        if st == 56 or st == 57 then
            dnote('[abort] stance still active -> ESC once more')
            state.end_current_fishing_event()
            state.abort_verify_at = nil   -- consume the re-arm: single retry, no loop
        end
    end
    local ok, p = pcall(GetPlayerEntity)
    if ok and p ~= nil then
        local s    = p.Status
        local name = p.Name or ''
        if name ~= '' then current_player_name = name end

        -- Position (Ashita v4 layout: ent.Movement.LocalPosition).
        local lp = p.Movement and p.Movement.LocalPosition
        if lp then
            state.player.x = tonumber(lp.X) or state.player.x
            state.player.y = tonumber(lp.Y) or state.player.y
            state.player.z = tonumber(lp.Z) or state.player.z
        end

        if name ~= prev_name then
            state.player.name = name
            prev_name = name
        end

        if s ~= nil and s ~= prev_status then
            state.player.status      = s
            state.player.status_name = PLAYER_STATUS_NAMES[s] or string.format('Unknown(%d)', s)

            local result = STATUS_TO_RESULT[s]
            if result then
                -- Pool ratio: no-bite casts still count as a miss (a dying
                -- pool doesn't just switch to items -- it stops biting too).
                -- The bite site clears .pending; if it's still true here, no
                -- bite ever came in and this is a naked lost_catch.
                if state.pool.pending and result ~= 'caught' then
                    state.record_bite_outcome(nil)
                end
                if result == 'caught' then
                    stats.caught    = stats.caught + 1
                    consec_bad      = 0   -- a catch breaks the anti-flag streak
                else
                    stats.lost = stats.lost + 1
                    -- Lost / no-catch: feed the same anti-flag defence as
                    -- releases. A long run of misses in a row is a pattern,
                    -- so cool down before the next cast.
                    consec_bad = consec_bad + 1
                    if consec_bad >= TUNE.SAFETY_STREAK_LIMIT then
                        state.safety_cooldown_pending = true
                        consec_bad       = 0
                        note(string.format('%d in a row -> safety cooldown (on idle)',
                            TUNE.SAFETY_STREAK_LIMIT))
                    end
                end
                -- A deliberate RELEASE arrives here as lost_catch (status 62)
                -- when it comes via status rather than chat. If we armed a
                -- release (relw.at set), relabel it to 'released' so the result
                -- reflects the intentional let-go (monsters, items, bad fish).
                if result == 'lost_catch' and relw.at > 0 then
                    result = 'released'
                    relw.at = 0.0
                end
                state.last_result.kind   = result
                state.last_result.text   = string.format('player.Status=%d (%s)',
                                                s, state.player.status_name)
                state.last_result.time   = os.time()
                state.last_result.source = 'status'
                if result ~= 'caught' then
                    -- Keep the resolved name for the line-2 display during the
                    -- brief result window. fish_display() returns the resolved
                    -- fish/monster name (or an ambiguous "X or Y" list); fall
                    -- back to the bite kind so a released monster shows its name
                    -- when resolved, "Monster" when not, never "(No Data)".
                    local disp = fish_display()
                    if disp and disp ~= '?' and disp ~= '' then
                        state.last_result.name = disp
                    elseif state.bite.kind == 'monster' then
                        state.last_result.name = 'Monster'
                    elseif state.bite.kind == 'item' then
                        state.last_result.name = 'Item'
                    elseif state.bite.kind then
                        state.last_result.name = titlecase(state.bite.kind)
                    else
                        state.last_result.name = nil
                    end
                    dnote('result: ' .. result)   -- caught is reported by the chat handler
                end
                clear_bite_latch()
            end

            prev_status = s

            -- Just returned to Idle (fight/cast resolved) -> arm the next cast
            -- at base cast_gap (1-2s) plus the 0.5-0.75s recast-delay extend,
            -- leaving room for the gearswap addon to equip fishing gear.
            if s == 0 then
                -- Asshole shutdown: a listed player was detected -> we've now
                -- reached Idle (any fish in progress finished), so wait 2s then
                -- /shutdown. One-shot.
                if state.asshole_shutdown and not state.asshole_shutdown_armed then
                    state.asshole_shutdown_armed = true
                    note('[asshole] idle reached -> /shutdown in 2s')
                    ashita.tasks.once(2.0, function()
                        AshitaCore:GetChatManager():QueueCommand(1, '/shutdown')
                    end)
                end
                -- Smart retry: returning to Idle means the fight/cast resolved.
                -- If the catch watchdog or a pending retry cooldown was armed (we
                -- were stuck at FishBite and the lagged catch finally went
                -- through), clear them -- no recovery is needed now that we're
                -- cleanly idle. Just resume the normal cast cadence.
                if catch_action_at > 0 then catch_action_at = 0 end
                if retry_resume_at > 0 then retry_resume_at = 0 end
                idle_since   = os.clock()
                idle_cast_at = idle_since + cast_gap
                if state.recast_delay[1] then
                    idle_cast_at = idle_cast_at + TUNE.IDLE_JITTER_MIN
                        + math.random() * (TUNE.IDLE_JITTER_MAX - TUNE.IDLE_JITTER_MIN)
                end
            end
        end
    end

    auto_fish_tick()

    if ui_visible[1] then
        -- UI scaling: baseline is 1440p (looks good at 2560x1440). At lower
        -- render heights, shrink hardcoded widget widths proportionally so
        -- the window still fits. Font is left at 1.0 -- imgui's default
        -- atlas doesn't downscale cleanly, and readable-but-slightly-large
        -- beats blurry. Computed once on first render, then cached.
        if state.ui.scale == nil then
            -- Ashita v4 exposes ImGuiIO as the property `imgui.io`, NOT as a
            -- function `imgui.GetIO()`. Wrapped in pcall so any binding quirk
            -- (missing io, DisplaySize shape difference across Ashita builds)
            -- falls back to scale=1.0 rather than erroring every frame.
            local ok, h = pcall(function()
                return imgui.io and imgui.io.DisplaySize and imgui.io.DisplaySize.y
            end)
            h = (ok and type(h) == 'number' and h > 0) and h or 1440
            state.ui.scale = math.max(0.6, math.min(1.0, h / 1440))
        end

        local win_flags = bit.bor(ImGuiWindowFlags_NoScrollbar, ImGuiWindowFlags_AlwaysAutoResize)
        -- Floor the width so AlwaysAutoResize can't shrink the window narrower
        -- than the longest status string ("Fish!!! Sleeping 99.9s") or clip the
        -- Configuration/Logs collapse labels. Height stays unconstrained.
        imgui.SetNextWindowSizeConstraints({ state.ui.w(180), 0 }, { 100000, 100000 })
        -- Theme (matches bovinebattle): softer rounding, roomier padding, and a
        -- dark blue-grey window/frame/header palette. Pushed BEFORE Begin and
        -- popped AFTER End so the 11-color / 7-var counts always balance
        -- regardless of which return path fires. (Buttons/title stay Ashita's
        -- default red -- only the frame/header/window colors are overridden.)
        imgui.PushStyleVar(ImGuiStyleVar_WindowRounding,   8.0)
        imgui.PushStyleVar(ImGuiStyleVar_FrameRounding,    5.0)
        imgui.PushStyleVar(ImGuiStyleVar_ChildRounding,    6.0)
        imgui.PushStyleVar(ImGuiStyleVar_PopupRounding,    5.0)
        imgui.PushStyleVar(ImGuiStyleVar_GrabRounding,     4.0)
        imgui.PushStyleVar(ImGuiStyleVar_FramePadding,     {7, 4})
        imgui.PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0)
        imgui.PushStyleColor(ImGuiCol_WindowBg,       {0.07, 0.07, 0.09, 0.95})
        imgui.PushStyleColor(ImGuiCol_Border,         {0.30, 0.32, 0.40, 0.60})
        imgui.PushStyleColor(ImGuiCol_FrameBg,        {0.16, 0.17, 0.21, 1.0})
        imgui.PushStyleColor(ImGuiCol_FrameBgHovered, {0.22, 0.24, 0.30, 1.0})
        imgui.PushStyleColor(ImGuiCol_FrameBgActive,  {0.28, 0.30, 0.38, 1.0})
        imgui.PushStyleColor(ImGuiCol_Header,         {0.20, 0.22, 0.28, 1.0})
        imgui.PushStyleColor(ImGuiCol_HeaderHovered,  {0.28, 0.31, 0.40, 1.0})
        imgui.PushStyleColor(ImGuiCol_HeaderActive,   {0.34, 0.37, 0.48, 1.0})
        imgui.PushStyleColor(ImGuiCol_CheckMark,      {0.45, 0.85, 0.50, 1.0})
        imgui.PushStyleColor(ImGuiCol_Separator,      {0.30, 0.32, 0.40, 0.50})
        imgui.PushStyleColor(ImGuiCol_Text,           {0.92, 0.92, 0.94, 1.0})
        -- Action buttons: bright blue-steel so they read as clickable
        -- (matches bovinebattle's button styling).
        imgui.PushStyleColor(ImGuiCol_Button,         {0.28, 0.42, 0.66, 1.0})
        imgui.PushStyleColor(ImGuiCol_ButtonHovered,  {0.36, 0.53, 0.80, 1.0})
        imgui.PushStyleColor(ImGuiCol_ButtonActive,   {0.44, 0.63, 0.92, 1.0})
        -- Title bar: slate to match the panel (was falling through to
        -- imgui's default red-ish title color).
        imgui.PushStyleColor(ImGuiCol_TitleBg,          {0.13, 0.14, 0.18, 1.0})
        imgui.PushStyleColor(ImGuiCol_TitleBgActive,    {0.18, 0.20, 0.26, 1.0})
        imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, {0.13, 0.14, 0.18, 1.0})
        if imgui.Begin(ADDON_NAME, ui_visible, win_flags) then
            -- ---- Auto ----
            -- Button fills the current content width (-1) rather than forcing a
            -- fixed 300px, so the window sizes to the real content. The stop
            -- reason is a separate line below, not on the button.
            local btn_label = auto_fish[1] and 'STOP' or 'START'
            -- Running -> green "active, tap to stop"; stopped -> normal
            -- blue-steel. Same go/active color language as bovinebattle.
            local _running = auto_fish[1] == true
            if _running then
                imgui.PushStyleColor(ImGuiCol_Button,        {0.22, 0.50, 0.28, 1.0})
                imgui.PushStyleColor(ImGuiCol_ButtonHovered, {0.28, 0.60, 0.34, 1.0})
                imgui.PushStyleColor(ImGuiCol_ButtonActive,  {0.34, 0.70, 0.40, 1.0})
            end
            if imgui.Button(btn_label, { -1, 28 }) then
                auto_fish[1] = not auto_fish[1]
                if auto_fish[1] then
                    begin_run()
                else
                    stop_reason = nil   -- manual stop
                    move_base   = nil
                end
                save_cfg()   -- persist any edits made while stopped
            end
            if _running then
                imgui.PopStyleColor(3)
            end
            if (not auto_fish[1]) and stop_reason then
                imgui.TextColored({ 1, 0.6, 0.3, 1 }, 'stopped: ' .. stop_reason)
            end

            -- ---- Activity: two-line status (state, then detail/name) ----
            local act_txt, act_name, act_col = activity_status()
            imgui.TextColored(act_col, act_txt)
            imgui.TextColored(act_col, act_name)

            imgui.Separator()

            -- ---- Updates (collapsible): GitHub version check + apply ----
            -- Only `state` is touched here, so this section adds no upvalues
            -- to the render closure (which is at Lua 5.1's 60-upvalue cap).
            if imgui.CollapsingHeader('Updates') then
                local u = state.upd
                if imgui.Button('Check Updates', { state.ui.w(120), 0 }) then
                    state.upd_check()
                end
                -- Update Now only exists once a check actually found something,
                -- so the two buttons can never contradict each other.
                if u.ready then
                    imgui.SameLine()
                    if imgui.Button('Update Now', { state.ui.w(110), 0 }) then
                        state.upd_apply()
                    end
                end
                if u.message ~= '' then
                    local col = { 0.7, 0.7, 0.7, 1 }
                    if     u.status == 'uptodate'  then col = { 0.5, 0.9, 0.5, 1 }
                    elseif u.status == 'available' then col = { 1, 0.8, 0.3, 1 }
                    elseif u.status == 'error'     then col = { 1, 0.4, 0.4, 1 }
                    elseif u.status == 'applying'  then col = { 0.6, 0.8, 1, 1 } end
                    imgui.TextColored(col, u.message)
                end
                if u.ready and auto_fish[1] then
                    imgui.TextColored({ 1, 0.6, 0.3, 1 }, 'stop the bot to apply')
                end
                if u.ready and u.older then
                    imgui.TextColored({ 1, 0.5, 0.2, 1 },
                        'DOWNGRADE: your local file is newer than the repo')
                end
                -- Git blob SHA-1 of each side. These are the values GitHub
                -- shows for the blob, so they can be compared against the web
                -- UI directly when something looks wrong.
                if u.sha_local or u.sha_remote then
                    imgui.TextDisabled(string.format('local  %s',
                        u.sha_local and u.sha_local:sub(1, 10) or '?'))
                    imgui.TextDisabled(string.format('remote %s',
                        u.sha_remote and u.sha_remote:sub(1, 10) or '?'))
                end
                imgui.Checkbox('Auto-update on load', S.auto_update)
                help_marker('On load, check GitHub and apply a newer version automatically, then reload. Only ever applies while the bot is STOPPED. The previous file is backed up to update/ first.')
                imgui.TextDisabled(string.format('local v%s  |  %s@%s',
                    addon.version, state.UPDATE.repo, state.UPDATE.branch))
                if state.upd_token() == '' then
                    imgui.TextDisabled('no gitvar.dat (public repo mode)')
                else
                    imgui.TextDisabled('token loaded from gitvar.dat')
                end
            end

            -- ---- Configuration (collapsible): everything under START ----
            if imgui.CollapsingHeader('Configuration') then
                imgui.Checkbox('Full Bot', S.full_bot)
                if imgui.IsItemHovered() then
                    imgui.SetTooltip('On: fish normally. Off (default): fish only 5 times then stop (test mode).')
                end
                imgui.Checkbox('Debug (log to chat)', S.debug)
                if auto_fish[1] then
                    -- Running: settings locked (Ashita imgui has no BeginDisabled),
                    -- so show a read-only summary instead of the widgets.
                    imgui.TextDisabled(string.format('bait: %s / %s',
                        S.bait_name[1], S.bait2_name[1]))
                    imgui.TextDisabled(string.format('rod: %s', S.rod_name[1]))
                    imgui.TextDisabled(string.format('Active bait slot: %d', active_bait_slot))
                    local rels = {}
                    if S.rel_monsters[1] then rels[#rels + 1] = 'mon' end
                    if S.rel_items[1]    then rels[#rels + 1] = 'item' end
                    if S.rel_terrible[1] then rels[#rels + 1] = 'terrible' end
                    if S.rel_bad[1]      then rels[#rels + 1] = 'bad' end
                    if S.rel_positive[1] then rels[#rels + 1] = 'positive' end
                    if S.rel_small[1]    then rels[#rels + 1] = 'small' end
                    if S.rel_large[1]    then rels[#rels + 1] = 'large' end
                    imgui.TextDisabled('release: ' .. (#rels > 0 and table.concat(rels, ',') or 'none'))
                    if S.skip_name[1] ~= '' then imgui.TextDisabled('skip: ' .. S.skip_name[1]) end
                    if S.catch_unknown[1] then imgui.TextDisabled('known-only: ' .. S.known_name[1]) end
                    local opts = {}
                    if S.stop_full[1]   then opts[#opts + 1] = 'inv-full' end
                    if S.tell_watch[1]  then opts[#opts + 1] = 'tells' end
                    if S.stop_moved[1]  then opts[#opts + 1] = 'moved' end
                    if S.rand_timing[1] then opts[#opts + 1] = 'extend' end
                    if state.recast_delay[1] then opts[#opts + 1] = 'recast-delay' end
                    if state.extend_release[1] then opts[#opts + 1] = 'extend-release' end
                    if S.auto_drop[1]   then opts[#opts + 1] = 'drop:' .. S.drop_name[1] end
                    -- Print 2 options per line so a long list doesn't stretch
                    -- the panel width; first line carries the label.
                    if #opts == 0 then
                        imgui.TextDisabled('stops/opts: none')
                    else
                        for i = 1, #opts, 2 do
                            local pair = opts[i] .. (opts[i + 1] and (',' .. opts[i + 1]) or '')
                            if i == 1 then
                                imgui.TextDisabled('stops/opts: ' .. pair)
                            else
                                imgui.TextDisabled('  ' .. pair)
                            end
                        end
                    end
                else
                    imgui.Checkbox('Auto move on full', S.auto_move)
                    help_marker('When inventory is full, sweep the fish below into your Mog Satchel (one-way, inventory -> satchel). Only moves if the satchel has space; never overstuffs. Paced ~1s per stack.')
                    if S.auto_move[1] then
                        imgui.PushItemWidth(state.ui.w(130))
                        imgui.InputText('##automovename', S.auto_move_name, 64)
                        imgui.PopItemWidth()
                    end
                    imgui.Checkbox('Stop when inventory full', S.stop_full)
                    imgui.Checkbox('Shutdown on full', S.shutdown_full)
                    if imgui.IsItemHovered() then
                        imgui.SetTooltip('On inventory full: stop the bot, wait 15s, then issue /shutdown.')
                    end
                    imgui.Checkbox('Stop on tells', S.tell_watch)
                    imgui.Checkbox('Stop if moved', S.stop_moved)
                    imgui.Checkbox('Sound alerts', S.sound_alerts)
                    help_marker('Plays Game_stopped.wav on any stop and Game_paused.wav on any pause edge. Files live in addons/bovineFH/.')
                    imgui.Checkbox('Rest depleted pool', S.pause_pool)
                    help_marker('When the rolling fish ratio (over the last 25 cast outcomes, evaluated from 18) falls below the threshold, pauses for 20 minutes to let the pool regen. Fish bites count as a hit; item bites, monster bites, and no-bite casts all count as a miss. Live ratio shown as "Fish XX%" in the log panel.')
                    if S.pause_pool[1] then
                        imgui.Indent(state.ui.w(20))
                        imgui.Checkbox('Low threshold (15 pct)', S.pool_low_thresh)
                        imgui.Checkbox('Rotate to bait 2 before resting', S.swap_on_dead_pool)
                        help_marker('On depletion, swap to bait 2 once instead of resting. Only rotates if bait 2 is set and different from bait 1; if bait 2 also dies, the rest fires.')
                        imgui.Unindent(state.ui.w(20))
                    end
                    imgui.Checkbox('Extend fishing', S.rand_timing)
                    help_marker('Adds 1-2s on top of the FishID fight timer before the catch packet is sent. The catch always uses the FishID time table -- this just extends it a little so the timing is less mechanical.')
                    imgui.Checkbox('Recast delay', state.recast_delay)
                    help_marker('Waits an extra 0.5-0.75s (randomized) in Idle before each recast. Gives a gearswap addon time to equip fishing gear, and varies the cast cadence. On by default.')
                    imgui.Checkbox('Extend release', state.extend_release)
                    help_marker('Adds 0.75-1.25s (randomized) on top of the base pre-release delay before the Escape/let-go is sent. The release is always randomized; this just adds more. On by default.')
                    imgui.Checkbox('Auto-drop catch', S.auto_drop)
                    if S.auto_drop[1] then
                        imgui.PushItemWidth(state.ui.w(130))
                        imgui.InputText('##dropname', S.drop_name, 64)
                        imgui.PopItemWidth()
                    end
                    imgui.PushItemWidth(state.ui.w(210))   -- wider dropdowns for full bait/rod names
                    combo_bait('Bait', S.bait_name)
                    help_marker('Primary bait/lure. Baits (worms, paste, etc.) are consumed per catch; Lures (Minnow, Shrimp Lure, rigs) are reusable.')
                    combo_bait('Bait 2', S.bait2_name)
                    help_marker('Backup, promoted when bait 1 runs dry. Use a reusable Lure here so the bot never fully stops.')
                    combo_box('Rod', S.rod_name, ROD_LIST)
                    imgui.PopItemWidth()
                    -- Live detected zone (what resolution actually uses). If
                    -- this doesn't match where you are, area detection is the
                    -- problem -- not the fish list.
                    do
                        local livearea = current_area()
                        local col = (livearea == '' or livearea == '?')
                            and { 1, 0.5, 0.3, 1 } or { 0.6, 0.8, 1, 1 }
                        imgui.TextColored(col, string.format('Zone: %s',
                            livearea ~= '' and livearea or '(unknown)'))
                    end
                    imgui.Text(string.format('Active bait slot: %d', active_bait_slot))
                    do
                        local fa, rn, matched = current_rod_attack()
                        imgui.Text(string.format('Equipped Rod:  %s',  DB.equipped_item_name(EQUIP_SLOT_RANGE) or 'none'))
                        if matched then
                            imgui.TextColored({ 0.7, 0.9, 0.7, 1 },
                                string.format('  -> matched "%s" fa=%d', rn, fa))
                        else
                            imgui.TextColored({ 1, 0.3, 0.3, 1 },
                                string.format('  !! ROD NOT IN TABLE: "%s" -> resolution OFF', rn))
                        end
                        -- Existence check for the CONFIGURED rod name. Suppress
                        -- the warning if that rod is currently equipped (it's on
                        -- you), and flag a config-vs-equipped name mismatch so
                        -- you know to update the dropdown selection instead.
                        local rodcfg = S.rod_name[1] or ''
                        if rodcfg ~= '' then
                            local eq_rn = clean_name((tostring(DB.equipped_item_name(EQUIP_SLOT_RANGE) or '')
                                :gsub('%s*%(%d+%)%s*$', '')))
                            local cfgn = clean_name(rodcfg)
                            if item_total_count(rodcfg) > 0 then
                                imgui.TextColored({ 0.5, 0.9, 0.5, 1 },
                                    string.format('  -> rod "%s" in bags', rodcfg))
                            elseif eq_rn == cfgn then
                                imgui.TextColored({ 0.5, 0.9, 0.5, 1 },
                                    string.format('  -> rod "%s" equipped', rodcfg))
                            elseif eq_rn ~= '' and matched then
                                imgui.TextColored({ 1, 0.6, 0.3, 1 },
                                    string.format('  ? config "%s" != equipped "%s"', rodcfg, eq_rn))
                            else
                                imgui.TextColored({ 1, 0.3, 0.3, 1 },
                                    string.format('  !! "%s" NOT in inventory/wardrobe', rodcfg))
                            end
                        end
                    end
                    imgui.Text(string.format('Equipped Bait: %s',  DB.equipped_item_name(EQUIP_SLOT_AMMO)  or 'none'))
                    -- Per bait slot: green if the bait is a KNOWN name (in the
                    -- bait/lure lists = "in the data") AND present in Inventory/
                    -- Wardrobe 1/2; red if missing from bags; orange if it's an
                    -- unrecognized name.
                    do
                        -- build a quick known-name set from the dropdown lists
                        local function is_known_bait(nm)
                            local want = clean_name(nm)
                            for _, b in ipairs(BAIT_LIST) do if clean_name(b) == want then return true end end
                            for _, l in ipairs(LURE_LIST) do if clean_name(l) == want then return true end end
                            return false
                        end
                        for _, slot in ipairs({ { 'bait', S.bait_name[1] }, { 'bait 2', S.bait2_name[1] } }) do
                            local label, nm = slot[1], slot[2] or ''
                            if nm ~= '' then
                                local known = is_known_bait(nm)
                                local n = item_total_count(nm)
                                if not known then
                                    imgui.TextColored({ 1, 0.6, 0.3, 1 },
                                        string.format('  ? %s "%s" not a known bait name', label, nm))
                                elseif n == 0 then
                                    imgui.TextColored({ 1, 0.3, 0.3, 1 },
                                        string.format('  !! %s "%s" NOT in inventory/wardrobe', label, nm))
                                else
                                    imgui.TextColored({ 0.5, 0.9, 0.5, 1 },
                                        string.format('  -> %s "%s" ok (x%d in bags)', label, nm, n))
                                end
                            end
                        end
                    end
                    imgui.Separator()
                    imgui.Text('Release')
                    imgui.Checkbox('Monsters', S.rel_monsters)
                    imgui.SameLine(); imgui.Checkbox('Items', S.rel_items)
                    imgui.Checkbox('Catch jackpot items', S.catch_jackpot)
                    help_marker('Overrides "release items": keeps any item worth >= 1400g (e.g. Mythril Sword 4100, Coral Fragment 1750) even when items are otherwise released. Requires item_tables.txt loaded.')
                    imgui.Checkbox('terrible', S.rel_terrible)
                    imgui.SameLine(); imgui.Checkbox('bad', S.rel_bad)
                    imgui.SameLine(); imgui.Checkbox('positive', S.rel_positive)
                    imgui.Checkbox('small (!)', S.rel_small)
                    imgui.SameLine(); imgui.Checkbox('large (!!!)', S.rel_large)
                    imgui.PushItemWidth(state.ui.w(105))
                    imgui.InputText('Skip fish', S.skip_name, 64)
                    imgui.PopItemWidth()
                    help_marker('Comma/semicolon-separated FISH NAMES to throw back before fighting (e.g. "Tricolored Carp,Moat Carp"). Matched case-insensitively against the resolved fish name.')
                    imgui.Checkbox('Catch only known fish', S.catch_unknown)
                    if S.catch_unknown[1] then
                        imgui.PushItemWidth(state.ui.w(105))
                        imgui.InputText('Known fish', S.known_name, 64)
                        imgui.PopItemWidth()
                        help_marker('With this on, any fish whose NAME is NOT listed is released. List names comma/semicolon-separated, e.g. "Tavnazian goby,Gold Carp". Unresolved/unknown fish are also released.')
                    end

                end
                imgui.Separator()
                if loaded_file_name then
                    local n = loaded_file_name
                    if #n > 17 then n = n:sub(1, 17) .. '..' end
                    imgui.Text('Fish Time'); imgui.SameLine()
                    imgui.TextDisabled('- ' .. n)
                else
                    imgui.Text('Fish Time')
                end
                if auto_fish[1] then
                    imgui.TextDisabled(string.format('  %-18s %5s %5s', 'name', 'min', 'max'))
                    for _, r in ipairs(fish_rows) do
                        imgui.Text(string.format('  %-18s %5s %5s',
                            r.id[1], r.min[1], r.max[1]))
                    end
                    imgui.Text(string.format('  %-18s %5s %5s',
                        'Unknown', unk_row.min[1], unk_row.max[1]))
                else
                    imgui.TextDisabled('   name              min     max')
                    local remove_idx = nil
                    for i, r in ipairs(fish_rows) do
                        imgui.PushItemWidth(state.ui.w(130))
                        imgui.InputText('##fid' .. i, r.id, 64)
                        imgui.PopItemWidth()
                        imgui.PushItemWidth(state.ui.w(46))
                        imgui.SameLine(); imgui.InputText('##fmin' .. i, r.min, 8)
                        imgui.SameLine(); imgui.InputText('##fmax' .. i, r.max, 8)
                        imgui.PopItemWidth()
                        imgui.SameLine()
                        if imgui.Button('-##frm' .. i, { 22, 0 }) then remove_idx = i end
                    end
                    if remove_idx then table.remove(fish_rows, remove_idx) end
                    if imgui.Button('+ Add fish') then
                        fish_rows[#fish_rows + 1] = new_fish_row()
                    end
                    if imgui.Button('Load from file...') then open_dialog('load') end
                    imgui.SameLine()
                    if imgui.Button('Save to file...') then open_dialog('save') end
                    imgui.PushItemWidth(state.ui.w(46))
                    imgui.Text('Unk'); imgui.SameLine()
                    imgui.InputText('##umin', unk_row.min, 8)
                    imgui.SameLine(); imgui.InputText('##umax', unk_row.max, 8)
                    imgui.PopItemWidth()
                end
            end  -- /Configuration

            imgui.Separator()
            -- ---- Asshole Detector: everyone the client can see (players/GMs) ----
            if imgui.CollapsingHeader('Asshole Detector') then
                -- Asshole List: named players that trigger an instant hard stop
                -- + /shutdown-on-idle when detected. Click to expand the manager
                -- inline (add/remove names) right here in the detector.
                if imgui.Button('Asshole List') then
                    state.show_asshole_list = not (state.show_asshole_list == true)
                end
                imgui.SameLine()
                do
                    local n = 0
                    for tok in tostring(S.asshole_list[1] or ''):gmatch('[^,;]+') do
                        if tok:gsub('%s','') ~= '' then n = n + 1 end
                    end
                    imgui.TextDisabled(string.format('(%d names)', n))
                end
                if state.show_asshole_list == true then
                    imgui.TextColored({ 1.0, 0.85, 0.3, 1 },
                        'Detected -> hard stop, then /shutdown at idle')
                    -- Add row: text box + Add button.
                    imgui.PushItemWidth(state.ui.w(150))
                    imgui.InputText('##assholeadd', S.asshole_add, 64)
                    imgui.PopItemWidth()
                    imgui.SameLine()
                    if imgui.Button('Add') then
                        local nm = (S.asshole_add[1] or ''):gsub('^%s+',''):gsub('%s+$','')
                        if nm ~= '' then
                            local exists = false
                            for tok in tostring(S.asshole_list[1] or ''):gmatch('[^,;]+') do
                                if clean_name(tok) == clean_name(nm) then exists = true end
                            end
                            if not exists then
                                local cur = S.asshole_list[1] or ''
                                S.asshole_list[1] = (cur == '') and nm or (cur .. ',' .. nm)
                                save_cfg()
                            end
                            S.asshole_add[1] = ''
                        end
                    end
                    -- List with a remove [x] per name.
                    local names = {}
                    for tok in tostring(S.asshole_list[1] or ''):gmatch('[^,;]+') do
                        local t = tok:gsub('^%s+',''):gsub('%s+$','')
                        if t ~= '' then names[#names+1] = t end
                    end
                    if #names == 0 then
                        imgui.TextDisabled('(list empty - add a name above)')
                    else
                        for i, nm in ipairs(names) do
                            if imgui.Button('x##ah' .. i) then
                                local kept = {}
                                for j, o in ipairs(names) do
                                    if j ~= i then kept[#kept+1] = o end
                                end
                                S.asshole_list[1] = table.concat(kept, ',')
                                save_cfg()
                            end
                            imgui.SameLine()
                            imgui.Text(nm)
                        end
                    end
                end

                -- Friends List: named players ignored by the pause-on-player
                -- detector. Same shape as the Asshole List above (button toggles
                -- an inline manager), just with the opposite effect.
                imgui.Separator()
                if imgui.Button('Friends List') then
                    state.show_friends_list = not (state.show_friends_list == true)
                end
                imgui.SameLine()
                do
                    local n = 0
                    for tok in tostring(S.friends_list[1] or ''):gmatch('[^,;]+') do
                        if tok:gsub('%s','') ~= '' then n = n + 1 end
                    end
                    imgui.TextDisabled(string.format('(%d names)', n))
                end
                if state.show_friends_list == true then
                    imgui.TextColored({ 0.5, 1.0, 0.5, 1 },
                        'Ignored by Pause on Player Detect')
                    imgui.PushItemWidth(state.ui.w(150))
                    imgui.InputText('##friendadd', S.friends_add, 64)
                    imgui.PopItemWidth()
                    imgui.SameLine()
                    if imgui.Button('Add##fr') then
                        local nm = (S.friends_add[1] or ''):gsub('^%s+',''):gsub('%s+$','')
                        if nm ~= '' then
                            local exists = false
                            for tok in tostring(S.friends_list[1] or ''):gmatch('[^,;]+') do
                                if clean_name(tok) == clean_name(nm) then exists = true end
                            end
                            if not exists then
                                local cur = S.friends_list[1] or ''
                                S.friends_list[1] = (cur == '') and nm or (cur .. ',' .. nm)
                                save_cfg()
                            end
                            S.friends_add[1] = ''
                        end
                    end
                    local fnames = {}
                    for tok in tostring(S.friends_list[1] or ''):gmatch('[^,;]+') do
                        local t = tok:gsub('^%s+',''):gsub('%s+$','')
                        if t ~= '' then fnames[#fnames+1] = t end
                    end
                    if #fnames == 0 then
                        imgui.TextDisabled('(list empty - add a name above)')
                    else
                        for i, nm in ipairs(fnames) do
                            if imgui.Button('x##fr' .. i) then
                                local kept = {}
                                for j, o in ipairs(fnames) do
                                    if j ~= i then kept[#kept+1] = o end
                                end
                                S.friends_list[1] = table.concat(kept, ',')
                                save_cfg()
                            end
                            imgui.SameLine()
                            imgui.Text(nm)
                        end
                    end
                end
                imgui.Separator()

                -- Pause on Player: hold casting while a player is nearby,
                -- resume state.PLAYER_DETECT.leave seconds after they leave. Toggleable.
                imgui.Checkbox('Pause on Player Detect', S.pause_on_player)
                if imgui.IsItemHovered() then
                    imgui.SetTooltip(string.format(
                        'Pause fishing while another player is nearby.\nResumes %d seconds after they leave.',
                        math.floor(state.PLAYER_DETECT.leave)))
                end
                -- Hard Stop on GM: ALWAYS ON. Rendered as a ticked, disabled-look
                -- checkbox so it reads as a permanent safety, not a toggle. This
                -- is a "don't be a dumbass" guard -- a GM in view = instant stop.
                local gm_always = { true }
                imgui.Checkbox('Hard Stop on GM  [X]', gm_always)
                gm_always[1] = true   -- force it back on no matter what was clicked
                if imgui.IsItemHovered() then
                    imgui.SetTooltip("Always on. A GM in your entity list = instant\nhard stop. Not toggleable -- don't be a dumbass.")
                end
                -- Live pause/stop status line.
                -- Live pause/stop status line.
                if state.gm_tell_pause then
                    imgui.TextColored({ 1, 0.4, 0.4, 1 }, 'HARD AFK - GM contact (manual restart)')
                end
                if state.interaction_pause_until and os.clock() < state.interaction_pause_until then
                    imgui.TextColored({ 1, 0.6, 0.3, 1 }, string.format(
                        'PAUSED - interaction probe (%.0fs)', state.interaction_pause_until - os.clock()))
                end
                if state.player_pause_active then
                    local left = state.PLAYER_DETECT.leave - (os.clock() - (state.player_pause_since or 0))
                    if left > 0 and not state.scan_has_player then
                        imgui.TextColored({ 1, 0.8, 0.3, 1 }, string.format(
                            'PAUSED - resuming in %.0fs after player left', left))
                    else
                        imgui.TextColored({ 1, 0.8, 0.3, 1 }, 'PAUSED - player nearby')
                    end
                end
                imgui.Separator()

                local ents = state.scan_cached()
                local players, gms = 0, 0
                for _, en in ipairs(ents) do
                    if en.kind == 'Player' then players = players + 1
                    elseif en.kind == 'GM' then gms = gms + 1 end
                end
                state.scan_has_player = players > 0
                imgui.TextColored({ 0.8, 0.9, 1, 1 }, string.format(
                    '%d players, %d GMs, %d entities total', players, gms, #ents))
                imgui.Separator()
                -- Show players and GMs prominently; list others below.
                for _, en in ipairs(ents) do
                    local col = { 0.7, 0.7, 0.7, 1 }
                    if en.kind == 'GM' then col = { 1.0, 0.4, 0.4, 1 }
                    elseif en.kind == 'Player' then col = { 1.0, 0.85, 0.3, 1 }
                    elseif en.kind == 'NPC' then col = { 0.6, 0.9, 0.7, 1 }
                    elseif en.kind == 'Mob' then col = { 0.8, 0.6, 0.9, 1 } end
                    local dtxt = en.dist and string.format('%.0fy', en.dist) or '-'
                    imgui.TextColored(col, string.format('[%s] %s  (%s)', en.kind, en.name, dtxt))
                end
                if #ents == 0 then
                    imgui.TextDisabled('(nothing detected)')
                end
            end

            imgui.Separator()
            -- ---- Logs (collapsible): bite/packet detail + running tallies ----
            if imgui.CollapsingHeader('Logs') then
                -- Sell All: select a fish in the open shop menu -> the server
                -- quotes a price (state.sell_ready) and we read which fish + how
                -- many stacks are in inventory. Clicking sells every stack of
                -- that fish, one per ~1s (sell_all_tick). This imgui binding has
                -- no BeginDisabled, so the button is only live when ready.
                if state.sell_all_id ~= nil then
                    -- A run is in progress -> show progress + a Stop button.
                    imgui.TextColored({ 1.0, 0.85, 0.3, 1 }, string.format(
                        'Selling %s ... %d sold, %d stacks left',
                        state.sell_all_name or 'fish', state.sell_all_sold or 0,
                        state.count_stacks_of(state.sell_all_id)))
                    if imgui.Button('Stop') then
                        note(string.format('[sell] aborted - sold %d %s',
                            state.sell_all_sold or 0, state.sell_all_name or 'fish'))
                        -- Show the same completion banner on abort.
                        state.sell_done_name  = state.sell_all_name
                        state.sell_done_sold  = state.sell_all_sold or 0
                        state.sell_done_until = os.clock() + 5.0
                        state.sell_all_id   = nil
                        state.sell_all_next = nil
                        state.sell_ready    = false
                    end
                elseif state.sell_done_until ~= nil and os.clock() < state.sell_done_until then
                    -- Sale complete banner: held 5s (or until the next fish
                    -- quote clears sell_done_until), then this branch lapses.
                    imgui.TextColored({ 0.6, 1.0, 0.6, 1 }, string.format(
                        'Sale complete - sold %d %s',
                        state.sell_done_sold or 0, state.sell_done_name or 'fish'))
                elseif state.sell_ready == true then
                    -- Read the quoted fish from the slot for the label.
                    local inv  = AshitaCore:GetMemoryManager():GetInventory()
                    local item = inv:GetContainerItem(CONTAINER.inventory, state.sell_slot)
                    local nm, stacks = '?', 0
                    if item ~= nil and item.Id ~= 0 then
                        local res = AshitaCore:GetResourceManager():GetItemById(item.Id)
                        nm = (res and res.Name and res.Name[1]) and tostring(res.Name[1]) or ('id ' .. item.Id)
                        stacks = state.count_stacks_of(item.Id)
                    end
                    if imgui.Button('Sell All') then
                        state.sell_fish()
                    end
                    imgui.SameLine()
                    imgui.TextColored({ 0.6, 1.0, 0.6, 1 }, string.format(
                        '%s  (%d stacks)  @ %d gil', nm, stacks, state.sell_price or 0))
                else
                    imgui.TextDisabled('Sell All  (select a fish to sell)')
                end
                imgui.Separator()

                imgui.Text(string.format('Bite: %s%s   q:%s',
                    tostring(state.bite.kind),
                    state.bite.fish_size and ('/' .. state.bite.fish_size) or '',
                    tostring(state.bite.quality)))
                if state.packet_0x115.captured then
                    imgui.Text(string.format('0x115: stam=%d key=%d',
                        state.packet_0x115.stamina,
                        state.packet_0x115.stamina_depletion))
                    imgui.Text(string.format('token=%d',
                        state.packet_0x115.gold_arrow_chance))
                    -- Resolved name on its OWN line so a long item/fish name (or
                    -- an ambiguous "X or Y") doesn't stretch the panel width.
                    imgui.Text(fish_display())
                else
                    imgui.Text('0x115: (Waiting)')
                end
                imgui.Text(string.format('Last: %s%s',
                    tostring(state.last_result.kind),
                    state.last_result.name and (' (' .. state.last_result.name .. ')') or ''))
                imgui.Text(string.format('Caught:%d  Lost:%d  Rel:%d',
                    stats.caught, stats.lost, stats.released))
                imgui.Text(string.format('Casts:%d  Tells:%d', stats.casts, stats.tells))
                local pr = state.pool_ratio_pct()
                if pr ~= nil then
                    local thresh = S.pool_low_thresh[1] and state.pool.THRESHOLD_LOW or state.pool.THRESHOLD_HIGH
                    local col = (pr < thresh * 100) and { 1, 0.5, 0.3, 1 } or { 0.7, 0.9, 0.7, 1 }
                    imgui.TextColored(col, string.format('Fish %.0f%% (%d/%d)',
                        pr, state.pool.n, state.pool.WINDOW))
                end
                imgui.Text(string.format('Skill Up:%d', stats.skillups))
            end
        end
        imgui.End()
        imgui.PopStyleColor(17)
        imgui.PopStyleVar(7)
    end

    -- The window's X (or a /bfh that hides it) flipped ui_visible off.
    -- Treat closing the panel as unloading the whole addon.
    if prev_visible and not ui_visible[1] then
        AshitaCore:GetChatManager():QueueCommand(1, '/addon unload ' .. ADDON_NAME)
    end
    prev_visible = ui_visible[1]

    -- Auto-save config shortly after the last change (debounced), so settings
    -- like Auto-drop persist even without pressing START/STOP or a clean unload.
    local sig = cfg_signature()
    if last_cfg_sig == nil then
        last_cfg_sig = sig                       -- baseline = loaded state
    elseif sig ~= last_cfg_sig then
        last_cfg_sig = sig
        cfg_dirty_at = os.clock()                -- change seen; wait for it to settle
    elseif cfg_dirty_at > 0 and (os.clock() - cfg_dirty_at) > 0.75 then
        cfg_dirty_at = 0
        save_cfg()                               -- stable for 0.75s -> persist
    end
end)

-- Chat: classify bites / quality / ends / catches; handle stop-full + auto-drop.
ashita.events.register('text_in', 'bfh_text_in', function(e)
    local text = e.message_modified or e.message or ''
    if text == '' then return end

    -- Ignore our OWN console output. note()/dnote() call print(), and Ashita
    -- feeds addon prints back through text_in classified as mode 1 (shout). If
    -- we processed those, our own "[bfh] ..." lines would be read as incoming
    -- shouts -> trigger the probe pause -> which prints again -> feedback loop.
    -- That is the phantom "shout" pause. Drop anything carrying our tag.
    if text:find('[bfh]', 1, true) then
        return
    end

    -- GM catch, MODE-INDEPENDENT. A GM can address you via /tell, /say, /shout,
    -- system message, or any channel -- the reliable marker is the "[GM]" tag.
    -- Catch it here regardless of mode and copy to the SEPARATE GM log only.
    -- The line ALSO logs once in the main log via its natural tell/say handler
    -- below (so it's in both files, but never duplicated within one file). The
    -- de-dupe guard stops a repeated identical line from stacking the GM log.
    --
    -- This block also OWNS the GM hard-AFK. Any [GM] tagged line on any channel
    -- is treated as GM interaction and pauses permanently (no auto-wake). The
    -- mode-gated branch further down sets the same flag but only for tells /
    -- mode 12; it missed a real GM /say on 2026-07-27 because the interaction
    -- block's system-broadcast filter ('^%a[%w]*%s:%s') rejects a line starting
    -- with '[' . Acting here is mode-independent by construction, so no channel
    -- can slip through. A player typing the literal "[GM]" will false-trigger;
    -- that trade is accepted deliberately.
    do
        local clean_gm = strip_codes(text)
        if clean_gm:find('[GM]', 1, true) and clean_gm ~= state.last_gm_line then
            state.last_gm_line = clean_gm
            state.gm_log(clean_gm)
            note('[GM] message received -> copied to GM log')
            if auto_fish[1] and not state.gm_tell_pause then
                state.gm_tell_pause = true
                note('[detector] GM contact (any channel) -> hard AFK (no auto-wake)')
                state.pause_now('GM contact', true)
            end
        end
    end

    -- Fishing skill-up capture. Horizon emits exactly:
    --   "<Player>'s fishing skill rises 0.X points."
    -- Match that form directly and pull the gain. Logged to file + chat with a
    -- running session tally so AFK skill progress is in the log, not just on
    -- screen (the data that back-solves real grind time).
    do
        local clean = strip_codes(text)
        local gain = clean:match("[Ff]ishing skill rises (%d+%.%d+) points")
        if gain then
            local g = tonumber(gain) or 0.1
            stats.skillups  = stats.skillups + 1
            stats.skillgain = stats.skillgain + g
            note(string.format('SKILLUP fishing +%.1f  (session: %d ups, +%.1f total)',
                g, stats.skillups, stats.skillgain))
        end
    end

    -- /tell capture: log EVERY tell, incoming AND outgoing. Incoming match the
    -- "<sender>> message" format; outgoing start with ">>name : ...". Both are
    -- logged. The "Stop on tells" burst counter only counts INCOMING tells
    -- (people noticing you), so outgoing don't trip the pause.
    local outgoing_tell = (text:match('^>>') ~= nil)
    -- Exclude outgoing explicitly. Matching on the text pattern alone was
    -- enough (">>Name : x" fails ^[^>]+>>), but the `e.mode == 3` arm had no
    -- such guard, so our OWN tells could feed the burst counter the comment
    -- below says they must not. Same class of bug as trusting mode 12 for GM.
    local incoming_tell = (not outgoing_tell)
        and (e.mode == 3 or text:match('^[^>]+>>') ~= nil)
    if incoming_tell or outgoing_tell then
        tell_log('tell', strip_codes(text))
    end
    if incoming_tell then
        stats.tells = stats.tells + 1
        if S.tell_watch[1] then
            local now = os.time()
            tellp.times[#tellp.times + 1] = now
            local kept = {}
            for _, t in ipairs(tellp.times) do
                if (now - t) <= TUNE.TELL_WINDOW then kept[#kept + 1] = t end
            end
            tellp.times = kept
            if #tellp.times >= TUNE.TELL_LIMIT and auto_fish[1] then
                local nc = os.clock()
                if tellp.regime_start > 0 and (nc - tellp.regime_start) < TUNE.TELL_PAUSE then
                    -- A second burst within the 15-min window -> people are
                    -- clearly noticing. Hard stop, but let any fight in
                    -- progress finish first (executed from the tick).
                    tellp.hard_stop = true
                    note('tells again within 15min -> shutting down after this fish')
                else
                    -- First burst -> pause 15 min (auto-fish stays on, so the
                    -- current fish finishes; only the next cast is held).
                    tellp.regime_start = nc
                    tellp.pause_until  = nc + TUNE.TELL_PAUSE
                    tellp.times = {}   -- restart the count for the next burst
                    note(string.format('2 tells -> pausing %d min (current fish finishes)',
                        math.floor(TUNE.TELL_PAUSE / 60)))
                    state.pause_now('tell burst')
                end
            end
        end
    end

    -- Chat logging: capture all relevant channels to the tell log. Tells (in/out)
    -- are handled above. GM lines are copied to the GM log by tell_log. Each
    -- channel gets its own tag for easy filtering.
    do
        local is_tell = (e.mode == 3 or text:match('^[^>]+>>') ~= nil or text:match('^>>') ~= nil)
        if not is_tell then
            local clean = strip_codes(text)
            local is_gm = clean:find('[GM]', 1, true) ~= nil
            if not is_gm then   -- GM lines already logged by the mode-independent GM catch above
                if     e.mode == 0  then tell_log('say',      clean)
                elseif e.mode == 1  then tell_log('shout',    clean)
                elseif e.mode == 8  then tell_log('emote',    clean)
                elseif e.mode == 12 then tell_log('gmprompt', clean)
                elseif e.mode == 26 then tell_log('yell',     clean)
                end
            end
        end
    end

    -- Interaction pause: any incoming chat on a probe-relevant channel (say,
    -- shout, emote, yell, gmprompt) or a /tell that ISN'T our own output
    -- triggers a fishing hold. This catches hidden GMs (who can't be seen in
    -- the entity list) testing whether we react like a bot.
    --
    --   say(0) / shout(1) / emote(8) / gmprompt(12) / yell(26) -> 90s pause
    --   /tell with [GM] tag  -> PERMANENT pause (hard AFK, no auto-wake)
    --   /tell from anyone    -> 90s pause (they're reaching out specifically)
    --
    -- Skip our OWN lines (name-prefix match). The rapid-tell burst counter
    -- (TUNE.TELL_LIMIT/TUNE.TELL_WINDOW) is separate and handles its own stop logic.
    do
        local clean = strip_codes(text)
        local probe_mode = (e.mode == 0 or e.mode == 1 or e.mode == 8
                         or e.mode == 12 or e.mode == 26)
        local is_incoming_tell = (e.mode == 3 or text:match('^[^>]+>>') ~= nil)
                            and text:match('^>>') == nil   -- exclude outgoing
        if (probe_mode or is_incoming_tell) and auto_fish[1] then
            -- Grace period: ignore the first 5s after START so the login/zone
            -- chat backlog (dozens of old shouts dumped at once) doesn't
            -- trigger pauses or crash via note() spam.
            if state.run_started_at and (os.clock() - state.run_started_at) < 5.0 then
                -- backlog window, skip
            else
            -- Exclude our own lines: our say/emote/shout start with our name.
            local mine = false
            if current_player_name ~= '' then
                local low = clean:lower()
                local me  = current_player_name:lower()
                if low:sub(1, #me) == me then mine = true end
            end
            -- Filter system broadcasts on say/shout/yell channels. Real player
            -- lines are prefixed "Name : text" (name, space, colon, space).
            -- System messages (Regional influence / conquest tally, Ballista,
            -- Besieged, Campaign, airship arrivals, etc.) don't. Only real
            -- player interaction should trigger the pause.
            --
            -- Emotes (mode 8) always come from a player and use a different
            -- format ("Name <verbs> ..."), so we don't filter those.
            -- Tells (mode 3) always come from a player, no filter.
            -- GMPROMPT (mode 12) is always a GM, no filter.
            local is_system_broadcast = false
            if e.mode == 0 or e.mode == 1 or e.mode == 26 then
                is_system_broadcast = not clean:match('^%a[%w]*%s:%s')
            end
            if not mine and not is_system_broadcast then
                -- GM contact = permanent hard AFK (no auto-wake).
                --
                -- REQUIRES the literal "[GM]" tag. The mode number alone is NOT
                -- trusted: e.mode here is the CLIENT chat-log mode (the value
                -- CTkMsgWinData::AddString was called with), not the LSB packet
                -- chat-type enum. They are different spaces -- proof is that our
                -- own print() output comes back as mode 1 ("shout"), and system
                -- lines land on mode 0 ("say"). Mode 12 is therefore not
                -- reliably GMPROMPT, and a plain player /tell can arrive on it.
                -- Gating on mode 12 alone turned "Unholyknight>> logging?" into
                -- a permanent GM hard-AFK. Tag or nothing.
                --
                -- Real GM contact is still covered: Horizon GMs carry the [GM]
                -- prefix, and a VISIBLE GM is hard-stopped independently by the
                -- render-flag 0x1000 entity check in scan_entities.
                local has_gm_tag = clean:find('[GM]', 1, true) ~= nil
                if has_gm_tag and (is_incoming_tell or e.mode == 12) then
                    if not state.gm_tell_pause then
                        state.gm_tell_pause = true
                        note(string.format('[detector] GM contact (mode %s) -> hard AFK (no auto-wake): %s',
                            tostring(e.mode), clean))
                        state.pause_now('GM contact', true)
                    end
                else
                    -- Everything else: 90s hold from last probe (refreshes).
                    -- Only log the FIRST trigger (edge), not every message in a
                    -- backlog or repeated shouts — prevents note() spam/crash.
                    local was_paused = state.interaction_pause_until
                        and os.clock() < state.interaction_pause_until
                    state.interaction_pause_until = os.clock() + 90.0
                    if not was_paused then
                        local tag = 'say'
                        if     e.mode == 1  then tag = 'shout'
                        elseif e.mode == 8  then tag = 'emote'
                        elseif e.mode == 12 then tag = 'mode12'
                        elseif e.mode == 26 then tag = 'yell'
                        elseif is_incoming_tell then tag = 'tell' end
                        note('[detector] interaction (' .. tag .. ') -> pausing fishing')
                        state.pause_now('interaction (' .. tag .. ')')
                    end
                end
            end
            end  -- grace period if/else
        end
    end

    if text:find('cast your line', 1, true) or text:find('You cast', 1, true) then
        clear_bite_latch()
    end

    local kind = classify_bite(text)    if kind then
        state.bite.text = text
        state.bite.time = os.time()
        if kind == 'monster' then
            state.bite.kind, state.bite.fish_size = 'monster', nil
        elseif kind == 'item' then
            state.bite.kind, state.bite.fish_size = 'item', nil
        elseif kind == 'fish_large' then
            state.bite.kind, state.bite.fish_size = 'fish', 'large'
        elseif kind == 'fish_small' then
            state.bite.kind, state.bite.fish_size = 'fish', 'small'
        end
        local q_inline = classify_quality(text)
        if q_inline then state.bite.quality = q_inline end
        fail_streak     = 0
        reject_streak   = 0
        retry_attempts  = 0
        retry_resume_at = 0
        -- Now that we know fish-vs-item (step 1), resolve the name from the
        -- CORRECT list. The 0x115 may have arrived before this chat line, in
        -- which case it left the name unresolved to avoid mixing items+fish
        -- (the "Arrowwood or Gold Carp" bug). Resolve/refresh it here.
        if state.packet_0x115.captured then
            fight_fish_name, fight_fish_ambig = resolve_fish_name(
                state.packet_0x115.depletion_x20, state.bite.kind, state.bite.fish_size)
        end
        -- NOTE: fight_start_clock is anchored on the 0x115 packet arrival, not
        -- here -- the chat hook lags the packet and would drift the timing.
        -- Prefer the resolved name (fish or item) over the bare bite kind, and
        -- show ambiguous candidates when the key ties (e.g. "Black Eel or
        -- Crayfish"); fall back to kind/size if unresolved.
        local bite_label
        if fight_fish_ambig and #fight_fish_ambig > 1 then
            bite_label = table.concat(fight_fish_ambig, ' or ')
        elseif fight_fish_name then
            bite_label = fight_fish_name
        else
            bite_label = state.bite.kind ..
                (state.bite.fish_size and ('/' .. state.bite.fish_size) or '')
        end
        dnote('bite: ' .. bite_label)
    end

    if state.bite.kind ~= nil then
        local q = classify_quality(text)
        if q and q ~= state.bite.quality then state.bite.quality = q end
    end

    local end_tag = classify_end(text)
    if end_tag then
        -- A deliberate RELEASE and a genuine catch FAILURE both produce the
        -- game's "You lost your catch" line. Distinguish them: if we armed a
        -- release (relw.at set), this lost_catch is OUR doing -> tag 'released'.
        if end_tag == 'lost_catch' and relw.at > 0 then
            end_tag = 'released'
            relw.at = 0.0   -- consume so the next genuine loss reads correctly
            dnote('result: released (deliberate)')
        end
        state.last_result.kind   = end_tag
        -- Keep the resolved name so the status line-2 can show WHAT was released
        -- / lost during the brief result window (cleared on the next cast).
        state.last_result.name   = fight_fish_name and titlecase(fight_fish_name) or nil
        state.last_result.text   = text
        state.last_result.time   = os.time()
        state.last_result.source = 'chat'
        clear_bite_latch()

        -- These errors EXPLAIN why a /fish didn't register, so they must NOT
        -- count toward the "casts not registering" stuck-cast guard (that guard
        -- is only for SILENT failures -- broken keybind, etc.). Clearing it lets
        -- the no_bait / no_rod / reject retry logic below own the situation
        -- (e.g. out of bait -> TUNE.FAIL_LIMIT -> retry -> promote bait 2).
        if end_tag == 'no_bait' or end_tag == 'no_rod' or end_tag == 'command_rejected' then
            cast_pending = false
            cast_fail    = 0
        end

        if NO_ROOM_TAGS[end_tag] and S.stop_full[1] and auto_fish[1] then
            state.stop_now('inventory full')
            -- Shutdown on full: after stopping, wait 15s then issue /shutdown.
            if S.shutdown_full[1] then
                note('inventory full -> /shutdown in 15s')
                ashita.tasks.once(15.0, function()
                    AshitaCore:GetChatManager():QueueCommand(1, '/shutdown')
                end)
            end
        end

        -- Rod snapped. If another copy of the configured rod is in inventory,
        -- equip it and carry on; otherwise stop NOW with a clear reason (not the
        -- slow no_rod retry spin that just sits at Idle). Distinct from startup
        -- "no rod found" and from "out of bait".
        if end_tag == 'rod_broke' and auto_fish[1] then
            local cfg_rod = S.rod_name[1]
            if cfg_rod ~= '' and item_total_count(cfg_rod) > 0 then
                note('rod broke -> equipping spare ' .. cfg_rod)
                equip_gear('rod', cfg_rod)
            else
                state.stop_now('rod broken - no more rods')
            end
        end

        -- "You cannot fish here" -> always an instant stop. No toggle.
        if end_tag == 'wrong_pos' and auto_fish[1] then
            state.stop_now('cannot fish here')
        end

        -- "Command rejected" is the transient zoning / mid-warp / server-lag
        -- recast error. It gets its own, more forgiving streak (TUNE.REJECT_LIMIT)
        -- so a few lag spikes over a long session don't halt us; only a solid
        -- run of them triggers the long retry. Any non-reject event resets it.
        if end_tag == 'command_rejected' then
            reject_streak = reject_streak + 1
            if reject_streak >= TUNE.REJECT_LIMIT and auto_fish[1] then
                reject_streak = 0
                schedule_retry('repeated command_rejected (lag)')
            end
        elseif end_tag == 'no_bait' then
            reject_streak = 0
            if item_total_count(current_bait()) <= 0 then
                -- INVENTORY confirms we hold zero of this bait -> genuinely out,
                -- swap to the lure (or stop). This is the ONLY thing that
                -- triggers a swap -- never the error or a failed equip alone.
                fail_streak = 0
                promote_or_stop('out of ' .. current_bait())
            else
                -- Bait IS in inventory -> the no_bait is lag / a dropped equip.
                -- Re-equip and let the proven retry + 90s cooldown ride it out.
                equip_gear('bait', current_bait())
                fail_streak = fail_streak + 1
                if fail_streak >= TUNE.FAIL_LIMIT and auto_fish[1] then
                    fail_streak = 0
                    schedule_retry('no_bait (lag?)')
                end
            end
        elseif end_tag == 'no_rod' then
            reject_streak = 0
            -- If there's genuinely no rod to equip, stop NOW with a clear reason
            -- rather than spinning the retry ladder at Idle.
            if S.rod_name[1] == '' or item_total_count(S.rod_name[1]) <= 0 then
                if auto_fish[1] then state.stop_now('no rod found') end
            else
                equip_gear('rod', S.rod_name[1])
                fail_streak = fail_streak + 1
                if fail_streak >= TUNE.FAIL_LIMIT and auto_fish[1] then
                    fail_streak = 0
                    schedule_retry('no_rod')
                end
            end
        else
            fail_streak   = 0
            reject_streak = 0
        end
    end

    -- Catch line carries the fish/item name. "caught X! But cannot carry..."
    -- matches the catch pattern but never enters inventory: keep the no_room
    -- result, just record the name.
    -- Keen angler's sense: the server just told us the name. Take it verbatim.
    -- Runs whether or not the hook line was seen, because the sense line can be
    -- the only thing that identifies the catch.
    do
        -- The keen line carries the fish name as a TALKNUMWORK insert, and the
        -- client wraps that insert in 2-byte format codes: "...the pull of a
        -- <1E 02>Tavnazian Goby<1E 01>!". Matching raw text captured those codes
        -- into the name, which drew as "??tavnazian Goby??" in the panel (imgui
        -- can't map the bytes) and, worse, made every clean_name() compare miss
        -- -- so fish_entry() fell through to the Unknown row and every crit
        -- fought the 10-12s fallback instead of the real 4.5-5s Goby range.
        -- Strip first, match second, same as extract_catch_name already does.
        local kn = state.keen_sense_name(strip_codes(text):lower())
        if kn and kn ~= '' then
            fight_fish_name   = clean_name(kn)
            fight_fish_ambig  = nil
            state.resolve_why = nil
            -- The sense line only fires on the FISH path in LSB, so if the hook
            -- line has not been classified yet, fix the kind. Size stays as the
            -- hook line left it (nil is fine -- we already have the name).
            if state.bite.kind ~= 'fish' and state.bite.kind ~= 'item'
               and state.bite.kind ~= 'monster' then
                state.bite.kind = 'fish'
            end
            dnote('keen sense -> ' .. titlecase(fight_fish_name))
        end
    end

    local catch_name = extract_catch_name(text, state.player.name)
    if catch_name then catch_name = titlecase(catch_name) end
    if catch_name then
        local was_no_room = NO_ROOM_TAGS[end_tag or '']
        if was_no_room then
            state.last_result.name = catch_name
        else
            state.last_result.kind   = 'caught'
            state.last_result.name   = catch_name
            state.last_result.text   = text
            state.last_result.time   = os.time()
            state.last_result.source = 'chat'
            if fight_start_clock > 0 then
                -- Measure to when WE sent the catch (the fight the bot actually
                -- performed), not the server's caught-chat (which lags by the
                -- confirmation latency). Manual catches have no send -> use now.
                local end_t = (catch_sent_clock > fight_start_clock) and catch_sent_clock or os.clock()
                local total = end_t - fight_start_clock
                dnote(string.format('Caught %s, key %d, %.1f + %.1f = %.1fs (base + extend = total)',
                    catch_name, fight_fish_id,
                    last_fight_base, last_fight_extend, total))
                -- Resolver accuracy check: predicted (from key+rod) vs actual.
                -- Chat-only under Debug; not written to the log to keep it clean.
                if S.debug[1] then
                    print(string.format('\31\200[bfh]\30\01 [dbg] predict=%s actual=%s%s%s',
                        fish_display(), catch_name,
                        (fight_fish_name and clean_name(fight_fish_name) ~= clean_name(catch_name))
                            and '  <<< MISMATCH' or '',
                        -- '?' means the resolver bailed, not that it guessed
                        -- wrong. Say where it bailed.
                        (not fight_fish_name and state.resolve_why)
                            and ('  [' .. state.resolve_why .. ']') or ''))
                end
                fight_start_clock = 0
            else
                dnote('caught: ' .. catch_name)
            end
            clear_bite_latch()

            -- Auto-drop matching catch. text_in runs on its own coroutine,
            -- so the sleep lets the inventory update arrive before we look.
            if S.auto_drop[1] and S.drop_name[1] ~= ''
               and clean_name(catch_name) == clean_name(S.drop_name[1]) then
                coroutine.sleep(1.0)
                local dok, info = drop_item_by_name(S.drop_name[1])
                if dok then
                    note(string.format('auto-dropped: %s x%d (slot %d)',
                        info.name, info.count, info.slot))
                else
                    note(string.format('auto-drop failed: %s (%s)',
                        S.drop_name[1], tostring(info)))
                end
            end
        end
    end
end)

-- Packet 0x115: capture fishing minigame initial state.
ashita.events.register('packet_in', 'bfh_pkt_in', function(e)
    -- Post-catch capture window (Debug only): log every incoming packet for
    -- ~2s after we send the catch, so we have the server's real resolution
    -- packets (status/animation/catch-result) to replay for Recovery.
    if status_capture_until > 0 and os.clock() < status_capture_until and not e.injected then
        status_dump(e.id, e.data)
    elseif status_capture_until > 0 and os.clock() >= status_capture_until then
        status_capture_until = 0
    end
    -- Keep the latest catch-resolution packets for the Recovery button.
    -- These are the ones that end the fishing stance; replaying them client-
    -- side un-sticks a client that missed the originals. Real packets only.
    if not e.injected then
        -- Live packet sequence (offset 0x02-0x03) for rebuilding a valid 0x037.
        if e.size >= 4 then
            last_in_seq_lo = struct.unpack('B', e.data, 0x02 + 1)
            last_in_seq_hi = struct.unpack('B', e.data, 0x03 + 1)
        end
        if e.id == 0x037 then
            last_0x037_bytes = e.data
            if e.size >= 0x44 then
                last_0x037_ts = e.data:sub(0x40 + 1, 0x43 + 1)
            end
        elseif e.id == 0x01E then last_0x01E_bytes = e.data end
    end
    if e.injected then return end
    if e.id ~= 0x115 then return end
    if e.size < 0x18 then return end

    state.packet_0x115.stamina           = struct.unpack('H', e.data, 0x04 + 1)
    state.packet_0x115.arrow_duration    = struct.unpack('H', e.data, 0x06 + 1)
    state.packet_0x115.regen_modifier    = struct.unpack('H', e.data, 0x08 + 1)
    state.packet_0x115.arrow_frequency   = struct.unpack('H', e.data, 0x0A + 1)

    local dep_x20                        = struct.unpack('H', e.data, 0x0C + 1)
    state.packet_0x115.depletion_x20     = dep_x20
    state.packet_0x115.stamina_depletion = math.floor(dep_x20 / 20)

    state.packet_0x115.unknown_0e        = struct.unpack('H', e.data, 0x0E + 1)
    state.packet_0x115.catch_delay       = struct.unpack('H', e.data, 0x10 + 1)
    state.packet_0x115.flags             = struct.unpack('H', e.data, 0x12 + 1)
    state.packet_0x115.size_bit          = state.packet_0x115.flags % 2
    state.packet_0x115.gold_arrow_chance = struct.unpack('I', e.data, 0x14 + 1)

    state.packet_0x115.captured          = true
    fight_fish_id = state.packet_0x115.stamina_depletion  -- legacy key snapshot
    -- Resolve the real fish NAME from the key + equipped rod (rod-independent).
    -- If the bite kind (fish/item) isn't known yet, this returns nil and we
    -- re-resolve when the bite chat classifies it (see the bite handler).
    fight_fish_name, fight_fish_ambig = resolve_fish_name(
                state.packet_0x115.depletion_x20, state.bite.kind, state.bite.fish_size)
    state.packet_0x115.time              = os.time()
    -- Anchor the fight clock HERE -- the 0x115 packet is the real event that
    -- begins the minigame. (The bite chat hook lagged behind this by the
    -- chat-render latency, which is what made the measured total drift from
    -- base+extend.) End anchor is catch_sent_clock (our 0x110 send), so the
    -- measured span is packet-to-packet and lines up with base+extend.
    fight_start_clock = os.clock()
    catch_sent_clock  = 0
    -- Diagnostic: dump every parsed 0x115 field plus the live rod fa, so the
    -- key/stamina formula can be reverse-engineered from real catches. One
    -- line per bite when Debug is on.
    if S.debug[1] then
        local p = state.packet_0x115
        local fa = select(1, current_rod_attack())
        dnote(string.format(
            '0x115: stam=%d dur=%d regen=%d freq=%d dep_x20=%d (/20=%d) unk0e=%d cdelay=%d flags=%d gold=%d | fa=%d area=%s',
            p.stamina or 0, p.arrow_duration or 0, p.regen_modifier or 0,
            p.arrow_frequency or 0, p.depletion_x20 or 0, p.stamina_depletion or 0,
            p.unknown_0e or 0, p.catch_delay or 0, p.flags or 0,
            p.gold_arrow_chance or 0, fa, current_area()))
    end
    -- Legendary calibration: lgd_bonus is unverified for every rod (no legendary
    -- catches yet). When a LEGENDARY fish is hooked, back-solve the bonus the
    -- equipped rod would need for the observed dep_x20 to match, and log it.
    -- The first legendary catch on any rod thus reveals that rod's true bonus.
    if fight_fish_name and DB.fish_legend[clean_name(fight_fish_name)] then
        local fa2, rn2, ok2 = current_rod_attack()
        local d = DB.fish_diff[clean_name(fight_fish_name)]
        local obs = state.packet_0x115.depletion_x20 or 0
        if ok2 and d and obs > 0 then
            -- find the integer bonus where arrow_dmg(d, fa2, bonus) == obs
            local found = nil
            for b = 0, 60 do
                if state.arrow_dmg(d, fa2, b) == obs then found = b; break end
            end
            local cur = (state.rod_lgd and state.rod_lgd[rn2]) or 0
            note(string.format('[LGD CAL] %s (diff %d) on "%s": dep=%d -> lgd_bonus=%s (table has %d)',
                fight_fish_name, d, rn2, obs,
                found and tostring(found) or '??', cur))
        end
    end
end)

-- 0x110 outbound: capture player-ID + inner-header bytes from real packets
-- so the inject builders always have current-cycle bytes. Capture only.
ashita.events.register('packet_out', 'bfh_pkt_out', function(e)
    if e.injected then return end
    if e.id ~= 0x110 then return end
    if e.size ~= 20 then return end
    last_cast_player_id_bytes = e.data:sub(4 + 1, 7 + 1)
    last_inner_header_bytes   = e.data:sub(12 + 1, 13 + 1)
end)

-- 0x00A (enter zone) / 0x00B (leave to char select) -- in-world signal.
-- A disconnect at char select would otherwise have auto-fish spamming
-- /fish into "command at this time" rejections; halt immediately instead.
ashita.events.register('packet_in', 'bfh_loginstate', function(e)
    if e.injected then return end
    if e.id == 0x00A then
        logged_in = true
    elseif e.id == 0x00B then
        if logged_in and auto_fish[1] then
            state.stop_now('disconnected')
        end
        logged_in = false
        state.sell_ready = false   -- any pending sale prompt is gone on zone
    -- 0x03D (SHOP_SELL): the server's price reply when an item is selected to
    -- sell in an open vendor menu. It carries the price AND the inventory slot
    -- (PropertyItemIndex) of the fish being quoted. We latch both; the "Sell
    -- Fish" button reads that slot's full stack and sells it.
    elseif e.id == 0x03D then
        if e.size >= 9 then
            state.sell_price = struct.unpack('I', e.data, 0x04 + 1)
            state.sell_slot  = struct.unpack('B', e.data, 0x08 + 1)
            state.sell_ready = true
            state.sell_done_until = nil   -- a new quote replaces the "Sale complete" banner
        end
    end
end)

----------------------------------------------------------------------------------------------------
-- Command: bare /bfh toggles the panel (only command in the addon)
----------------------------------------------------------------------------------------------------

ashita.events.register('command', 'bfh_command', function(e)
    local cmd = e.command or ''
    local first = cmd:match('^%s*(%S+)')
    if first == nil or first:lower() ~= '/bfh' then return end
    e.blocked = true
    local sub = (cmd:match('^%s*%S+%s+(%S+)') or ''):lower()

    -- helpers that mirror the START/STOP button behaviour exactly
    local function do_start()
        if not auto_fish[1] then
            auto_fish[1] = true
            begin_run()
            save_cfg()
            note('fishing STARTED')
        else
            note('already fishing')
        end
    end
    local function do_stop()
        if auto_fish[1] then
            auto_fish[1] = false
            stop_reason = nil
            move_base   = nil
            save_cfg()
            note('fishing STOPPED')
        else
            note('already stopped')
        end
    end

    if sub == 'start' or sub == 'on' then
        do_start()
    elseif sub == 'stop' or sub == 'off' then
        do_stop()
    elseif sub == 'toggle' then
        if auto_fish[1] then do_stop() else do_start() end
    elseif sub == 'recovery' or sub == 'recover' or sub == 'fix' then
        do_recovery()
    elseif sub == 'put' then
        -- /bfh put <location> <item name...>
        local loc = cmd:match('^%s*%S+%s+%S+%s+(%S+)')
        local item = cmd:match('^%s*%S+%s+%S+%s+%S+%s+(.+)')
        if loc == nil or item == nil then
            note('[put] usage: /bfh put <satchel|sack|case|storage|locker|safe> <item name>')
        else
            item = item:gsub('^"',''):gsub('"$','')   -- strip optional quotes
            put_item(loc, item)
        end
    else
        -- bare /bfh (or anything else): show/hide the panel
        ui_visible[1] = not ui_visible[1]
        note(ui_visible[1] and 'panel shown' or 'panel closed -> unloading')
    end
end)

ashita.events.register('load', 'bfh_load', function()
    load_data_tables()
    if DB.data_tables_ready then
        local fa, rn, matched = current_rod_attack()
        local area = current_area()
        local naf = (DB.area_fish[area] and #DB.area_fish[area]) or 0
        note(string.format('data tables loaded (%d fish, %d rods). rod=%s fishAttack=%d',
            (function() local n=0; for _ in pairs(DB.fish_diff) do n=n+1 end; return n end)(),
            (function() local n=0; for _ in pairs(DB.rod_attack) do n=n+1 end; return n end)(),
            rn, fa))
        if not matched then
            note(string.format('[!] equipped rod "%s" not in rod_tables - resolution OFF until a known rod is equipped.', rn))
        end
        note(string.format('area=%s (%d fish here) - resolution is zone-locked', area ~= '' and area or '?', naf))
    else
        note('name resolution OFF (missing /data_tables files) - falling back to key IDs')
    end
    note('loaded.  /bfh toggles the panel.  /bfh start | stop | toggle controls fishing.')

    -- Auto-update: kick a check 5s after load (lets login/zone settle). The
    -- result is handled by state.upd_poll(), which is already running every
    -- frame -- no extra timer loop. auto_fish is never persisted, so a fresh
    -- load is always STOPPED and the apply gate is satisfied.
    if S.auto_update[1] then
        ashita.tasks.once(5.0, function()
            state.upd.auto_apply = true
            state.upd_check()
        end)
    end
end)

ashita.events.register('unload', 'bfh_unload', function()
    -- Stop the engine first so no queued tick fires another /fish during teardown.
    auto_fish[1] = false
    -- If we're unloaded mid-cast (line out / fighting a bite), cancel the
    -- fishing action so the client isn't left with a stuck line and the next
    -- manual /fish works cleanly. (The addon DOES issue commands -- /fish casts,
    -- equip packets, etc. -- so there is real in-flight state to clean up.)
    local st = state.player and state.player.status
    if st == 56 or st == 57 then
        send_fishing_cancel()
    end
    save_cfg()   -- persist final config (also covers the window-X unload path)
end)