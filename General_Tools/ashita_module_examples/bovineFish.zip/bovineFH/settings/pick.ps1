Add-Type -AssemblyName System.Windows.Forms
Set-Location -LiteralPath $PSScriptRoot
$d = New-Object System.Windows.Forms.OpenFileDialog
$d.Filter = 'Fish tables (*.txt)|*.txt|All files (*.*)|*.*'
$d.Title = 'Select pool timing table'
$d.InitialDirectory = (Resolve-Path (Join-Path $PSScriptRoot '..\pool_timings')).Path
$out = Join-Path $PSScriptRoot 'pick.result'
if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
  Set-Content -Path $out -Value $d.FileName
} else { Set-Content -Path $out -Value '' }
