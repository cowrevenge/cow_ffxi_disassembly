--[[---------------------------------------------------------------------------
movement.lua

Purpose
    Movement controller only.

Design
    - NO QueueCommand ownership here in the final architecture sense.
    - Commands are routed through /mncmd so main.lua owns the real execution.
    - NO extra debug chatter here.
    - Only actual client commands should be echoed by main.lua.

Responsibilities
    - windowerinput loading
    - W forward movement
    - A LOS tap
    - full movement release
    - Test W helper
---------------------------------------------------------------------------]]--

local movement = {}

local state = {
    windowerinput_loaded = false,
    windowerinput_last_try = 0.0,
    w_down = false,
    a_down = false,
    s_down = false,
    d_down = false,
    test_w_until = 0.0,
    walk_until = 0.0,
}

local function now_sec()
    return os.clock()
end

---------------------------------------------------------------------
-- COMMAND ROUTING
---------------------------------------------------------------------

local function cmd(text)
    text = tostring(text or '')
    if text == '' then
        return false
    end

    AshitaCore:GetChatManager():QueueCommand(1, '/mncmd ' .. text)
    return true
end

---------------------------------------------------------------------
-- WINDOWERINPUT
---------------------------------------------------------------------

function movement.ensure_windowerinput()
    if state.windowerinput_loaded then
        return true
    end

    local now = now_sec()
    if (now - (state.windowerinput_last_try or 0.0)) < 5.0 then
        return false
    end

    state.windowerinput_last_try = now

    if cmd('/plugin load windowerinput') then
        state.windowerinput_loaded = true
        return true
    end

    return false
end

---------------------------------------------------------------------
-- KEY SENDER
---------------------------------------------------------------------

local function send_key(key, is_down)
    if not movement.ensure_windowerinput() then
        return false
    end

    return cmd(string.format('/sendkey %s %s', tostring(key), is_down and 'down' or 'up'))
end

---------------------------------------------------------------------
-- W KEY
---------------------------------------------------------------------

function movement.key_w_down()
    if state.w_down then
        return true
    end

    if send_key('W', true) then
        state.w_down = true
        return true
    end

    return false
end

function movement.key_w_up()
    if not state.w_down then
        return true
    end

    if send_key('W', false) then
        state.w_down = false
        return true
    end

    return false
end

---------------------------------------------------------------------
-- A KEY
---------------------------------------------------------------------

function movement.key_a_down()
    if state.a_down then
        return true
    end

    if send_key('A', true) then
        state.a_down = true
        return true
    end

    return false
end

function movement.key_a_up()
    if not state.a_down then
        return true
    end

    if send_key('A', false) then
        state.a_down = false
        return true
    end

    return false
end

---------------------------------------------------------------------
-- S KEY
---------------------------------------------------------------------

function movement.key_s_down()
    if state.s_down then return true end
    if send_key('S', true) then
        state.s_down = true
        return true
    end
    return false
end

function movement.key_s_up()
    if not state.s_down then return true end
    if send_key('S', false) then
        state.s_down = false
        return true
    end
    return false
end

---------------------------------------------------------------------
-- D KEY
---------------------------------------------------------------------

function movement.key_d_down()
    if state.d_down then return true end
    if send_key('D', true) then
        state.d_down = true
        return true
    end
    return false
end

function movement.key_d_up()
    if not state.d_down then return true end
    if send_key('D', false) then
        state.d_down = false
        return true
    end
    return false
end

---------------------------------------------------------------------
-- MOVEMENT API
---------------------------------------------------------------------

function movement.walk_forward()
    return movement.key_w_down()
end

function movement.stop()
    return movement.key_w_up()
end

function movement.tap_left_for_los()
    if not movement.key_a_down() then
        return false
    end

    ashita.tasks.once(0.15, function()
        movement.key_a_up()
    end)

    return true
end

---------------------------------------------------------------------
-- FORCE RELEASE
---------------------------------------------------------------------

function movement.force_release()
    movement.key_w_up()
    movement.key_a_up()
    movement.key_s_up()
    movement.key_d_up()
    state.test_w_until = 0.0
    return true
end

---------------------------------------------------------------------
-- TIMED WALK
---------------------------------------------------------------------

function movement.walk_timed(duration_sec)
    duration_sec = math.max(0.1, tonumber(duration_sec or 0.5) or 0.5)

    -- If already doing a timed walk that ends later, let it run
    local now = now_sec()
    if state.walk_until and now < state.walk_until then
        return true
    end

    state.walk_until = now + duration_sec

    if not movement.key_w_down() then
        state.walk_until = 0.0
        return false
    end

    ashita.tasks.once(duration_sec, function()
        movement.key_w_up()
        state.walk_until = 0.0
    end)

    return true
end

function movement.walk_timed_active()
    return state.walk_until ~= nil and now_sec() < state.walk_until
end

---------------------------------------------------------------------
-- TEST W
---------------------------------------------------------------------

function movement.start_test_w()
    local now = now_sec()

    state.test_w_until = now + 1.0

    if not movement.key_w_down() then
        state.test_w_until = 0.0
        return false
    end

    ashita.tasks.once(1.0, function()
        movement.key_w_up()
        state.test_w_until = 0.0
    end)

    return true
end

function movement.test_w_remaining()
    local now = now_sec()
    local remaining = (state.test_w_until or 0.0) - now
    if remaining < 0 then remaining = 0 end
    return remaining
end

function movement.test_w_active()
    return movement.test_w_remaining() > 0
end

---------------------------------------------------------------------
-- DEBUG STATE
---------------------------------------------------------------------

function movement.debug_state()
    return {
        windowerinput_loaded = state.windowerinput_loaded == true,
        w_down = state.w_down == true,
        a_down = state.a_down == true,
        s_down = state.s_down == true,
        d_down = state.d_down == true,
        test_w_until = tonumber(state.test_w_until or 0.0) or 0.0,
    }
end

return movement