--[[---------------------------------------------------------------------------
main_magic_helper.lua

Purpose
  Own shared magic-related runtime helpers for MeleeNostrum.

Owns
  - player MP %
  - spell lock state ensure / start / clear / timeout
  - spell name extraction from /ma command text
  - once-per-mob combat debuff tracking
  - ctx spell helpers for atk ladder usage
  - debuff pending / confirm / resist / wear-off handling

Notes
  - This file does not write to client directly.
  - general.lua still owns the main runtime flow and dispatch pipe.
---------------------------------------------------------------------------]]--

local MainMagicHelper = {}

local function n(v)
    return tonumber(v) or 0
end

local function now_sec()
    return os.clock()
end

local function normalize_name(name)
    name = tostring(name or ''):lower()
    name = name:gsub('_', ' ')
    name = name:gsub('%s+', ' ')
    name = name:gsub('^%s+', '')
    name = name:gsub('%s+$', '')
    return name
end

-- Base cast bar duration (no Fast Cast) in seconds, lowercased
-- spell name key. Used by spell_lock_start to size the cast
-- timeout (cast_time + ANIMATION_END_SEC + SLACK) instead of the
-- previous flat 3.0s, which was too short for Refresh / Stoneskin /
-- Reraise (the timeout would fire while the cast was still actually
-- running -> spell_lock_clear -> bot queues next /ma -> UTC because
-- the server slot is still locked). Unknown spells fall through to
-- DEFAULT_CAST_TIME -- conservative enough to not undersize any
-- normally-cast spell. Add entries as new spells are used.
local SPELL_CAST_TIME = {
    ['utsusemi: ichi']    = 2.0,
    ['utsusemi: ni']      = 1.5,
    ['utsusemi: san']     = 1.0,
    ['cure']              = 2.0,
    ['cure ii']           = 2.25,
    ['cure iii']          = 2.5,
    ['cure iv']           = 2.5,
    ['cure v']            = 2.5,
    ['curaga']            = 4.5,
    ['curaga ii']         = 5.0,
    ['banish']            = 3.0,
    ['banish ii']         = 4.5,
    ['dia']               = 1.0,
    ['dia ii']            = 1.5,
    ['protect']           = 2.0,
    ['protect ii']        = 2.5,
    ['shell']             = 2.0,
    ['shell ii']          = 2.5,
    ['protect iii']       = 1.5,
    ['protect iv']        = 1.75,
    ['protect v']         = 2.0,
    ['shell iii']         = 1.5,
    ['shell iv']          = 1.75,
    ['shell v']           = 2.0,
    ['stoneskin']         = 7.0,
    ['blink']             = 6.0,
    ['reraise']           = 8.0,
    ['refresh']           = 5.0,
    ['haste']             = 3.0,
    ['regen']             = 4.0,
    ['regen ii']          = 4.5,
    ['phalanx']           = 4.0,
    ['paralyze']          = 3.0,
    ['slow']              = 2.0,
    ['silence']           = 3.0,
    ['bio']               = 1.0,
    ['bio ii']            = 2.0,
    ['drain']             = 5.0,
    ['aspir']             = 5.5,
    ['poisona']           = 1.0,
    ['paralyna']          = 1.0,
    ['silena']            = 1.0,
    ['blindna']           = 1.0,
    ['stona']             = 1.0,
    ['viruna']            = 1.0,
    ['erase']             = 4.0,
    ['dispel']            = 3.0,
    ['enfire']            = 3.0,
    ['enblizzard']        = 3.0,
    ['enaero']            = 3.0,
    ['enstone']           = 3.0,
    ['enwater']           = 3.0,
    ['enthunder']         = 3.0,
    ['stone']             = 0.5,
    ['poison']            = 1.0,
    ['blind']             = 2.0,
}
local DEFAULT_CAST_TIME  = 4.0

-- Post-bar finish phase on the server side. The chat-line
-- "X casts Y" doesn't arrive until this phase ends; the cast
-- timeout must cover the full bar + finish + slack window so
-- it doesn't fire mid-cast. Mirrors nomount's ANIMATION_END_SEC.
local ANIMATION_END_SEC  = 5.0
local CAST_TIMEOUT_SLACK = 0.5
-- Post-confirm animation tail. When "X casts Y" arrives or the completion
-- action packet lands, the cast bar is gone but the character is still in the
-- finish animation and the game will drop commands sent during it. Keep the
-- lock (spell_lock_until) held this long past confirm so nothing tries to
-- fire into the animation tail. is_casting still clears immediately since
-- the cast bar is no longer showing.
local POST_CAST_ANIMATION_HOLD_SEC = 1.0
-- Extra grace beyond the sized completion estimate before the SAFETY
-- fallback force-clears a lock whose completion was never confirmed.
-- Always sized-relative (sized + this), never a flat lockout.
local CAST_TIMEOUT_FALLBACK_EXTRA = 3.0

function MainMagicHelper.lookup_cast_time(spell_name)
    if type(spell_name) ~= 'string' or spell_name == '' then
        return DEFAULT_CAST_TIME
    end
    return SPELL_CAST_TIME[normalize_name(spell_name)] or DEFAULT_CAST_TIME
end

local function make_pending(md)
    return {
        id = nil,
        spell_name = nil,
        target_server_id = n(md and md.target_server_id),
        target_index = n(md and md.target_index),
        sent_at = 0.0,
    }
end

local function clear_pending_for_current_target(state)
    MainMagicHelper.ensure_mob_debuff_state(state)
    local md = state.combat.mob_debuffs
    md.pending = make_pending(md)
end

local function pending_matches_current_target(md)
    if not md or not md.pending then return false end
    return
        n(md.pending.target_server_id) == n(md.target_server_id) and
        n(md.pending.target_index) == n(md.target_index)
end

local function pending_active(md)
    if not md or not md.pending then return false end
    if md.pending.id == nil then return false end
    if not pending_matches_current_target(md) then return false end
    return true
end

function MainMagicHelper.player_mp_percent()
    local mm = AshitaCore:GetMemoryManager()
    if not mm then return nil end

    local party = mm:GetParty()
    if not party then return nil end

    if type(party.GetMemberMPPercent) == 'function' then
        local ok, v = pcall(function()
            return party:GetMemberMPPercent(0)
        end)

        if ok and v ~= nil then
            local pct = tonumber(v)
            if pct ~= nil then
                return pct
            end
        end
    end

    local mp = nil
    local mpMax = nil

    if type(party.GetMemberMP) == 'function' then
        local ok, v = pcall(function()
            return party:GetMemberMP(0)
        end)
        if ok and v ~= nil then
            mp = tonumber(v)
        end
    end

    if type(party.GetMemberMPMax) == 'function' then
        local ok, v = pcall(function()
            return party:GetMemberMPMax(0)
        end)
        if ok and v ~= nil then
            mpMax = tonumber(v)
        end
    end

    if mp ~= nil and mpMax ~= nil and mpMax > 0 then
        return (mp / mpMax) * 100
    end

    return nil
end

function MainMagicHelper.player_mp_raw()
    local mm = AshitaCore:GetMemoryManager()
    if not mm then return nil end

    local party = mm:GetParty()
    if not party then return nil end

    if type(party.GetMemberMP) == 'function' then
        local ok, v = pcall(function()
            return party:GetMemberMP(0)
        end)
        if ok and v ~= nil then
            return tonumber(v)
        end
    end

    return nil
end

function MainMagicHelper.ensure_spell_state(state)
    state.combat = state.combat or {}

    if state.combat.spell_locked == nil then
        state.combat.spell_locked = false
    end

    if state.combat.active_started_spell == nil then
        state.combat.active_started_spell = nil
    end

    if state.combat.spell_started_at == nil then
        state.combat.spell_started_at = 0.0
    end

    if state.combat.last_confirmed_spell == nil then
        state.combat.last_confirmed_spell = nil
    end

    if state.combat.last_confirmed_spell_at == nil then
        state.combat.last_confirmed_spell_at = 0.0
    end

    if state.combat.last_interrupt_at == nil then
        state.combat.last_interrupt_at = 0.0
    end

    if state.combat.is_casting == nil then
        state.combat.is_casting = false
    end

    if state.combat.current_spell == nil then
        state.combat.current_spell = nil
    end

    if state.combat.cast_timeout_at == nil then
        state.combat.cast_timeout_at = 0.0
    end

    if state.combat.spell_lock_until == nil then
        state.combat.spell_lock_until = 0.0
    end

    -- Diagnostic state for the cast-stall warnings emitted by
    -- refresh_spell_timeout. last_cast_acked_* records the most recent
    -- "starts casting" we observed and survives spell_lock_clear. The
    -- _warned_* fields are per-event one-shots: each holds the
    -- timestamp of the dispatch/ack that was already warned about, so
    -- the next dispatch/ack (whose timestamp is newer) re-arms the
    -- warning. Same shape as the existing _recorded_confirm_at gate.
    if state.combat.last_cast_acked_at == nil then
        state.combat.last_cast_acked_at = 0.0
    end

    if state.combat.last_cast_acked_name == nil then
        state.combat.last_cast_acked_name = nil
    end

    if state.combat._warned_not_started_at == nil then
        state.combat._warned_not_started_at = 0.0
    end

    if state.combat._warned_not_confirmed_at == nil then
        state.combat._warned_not_confirmed_at = 0.0
    end
end

function MainMagicHelper.extract_spell_name_from_command(command_text)
    command_text = tostring(command_text or '')

    local spell_name = command_text:match('^%s*/ma%s+"([^"]+)"')
    if spell_name and spell_name ~= '' then
        return spell_name
    end

    spell_name = command_text:match("^%s*/ma%s+'([^']+)'")
    if spell_name and spell_name ~= '' then
        return spell_name
    end

    return nil
end

function MainMagicHelper.spell_lock_start(state, spell_name, timing)
    MainMagicHelper.ensure_spell_state(state)

    -- Per-cast timeout, computed from what we're actually casting:
    -- cast_time + animation + 0.5 buffer. No flat lockouts. The safety
    -- fallback is this sized value + 3s -- it only matters if completion
    -- is never confirmed (interrupt / lost packet).
    local cast_time = MainMagicHelper.lookup_cast_time(spell_name)
    local timeout_sec = cast_time + ANIMATION_END_SEC + CAST_TIMEOUT_SLACK

    state.combat.spell_locked = true
    state.combat.active_started_spell = spell_name
    state.combat.spell_started_at = now_sec()

    state.combat.is_casting = true
    state.combat.current_spell = spell_name
    -- Stored for packet_parser's action-packet completion path so it
    -- can apply the same cast-bar floor (elapsed >= cast_time) that
    -- nomount's try_action_completion uses to reject magic-start
    -- packets and other actions arriving before the bar could fill.
    state.combat.cast_time_sec = cast_time
    state.combat.cast_timeout_at = state.combat.spell_started_at + timeout_sec
    state.combat.cast_fallback_at = state.combat.cast_timeout_at + CAST_TIMEOUT_FALLBACK_EXTRA
    state.combat.spell_lock_until = state.combat.cast_timeout_at

    -- Diagnostic timestamps. last_cast_acked_at marks the moment the
    -- game accepted the cast ("starts casting" line landed and
    -- spell_lock_start was called). Unlike spell_started_at, this is
    -- NOT zeroed by spell_lock_clear, so the not-confirmed-after-20s
    -- diagnostic in refresh_spell_timeout can still see it after the
    -- safety fallback has cleared the lock. Cleared implicitly by
    -- being overwritten on the next cast's lock_start; the
    -- not-confirmed diagnostic gates itself on last_confirmed_spell_at
    -- being newer than this, so a successful confirm naturally
    -- suppresses the warning without us touching this field here.
    state.combat.last_cast_acked_at   = state.combat.spell_started_at
    state.combat.last_cast_acked_name = spell_name

    -- Diagnostic: record the send-time so cast_log can stamp elapsed
    -- on the confirmation. Best-effort; silent if module missing.
    local ok, CastLog = pcall(require, 'cast_log')
    if ok and CastLog and type(CastLog.pending) == 'function' then
        CastLog.pending(spell_name, state.combat.spell_started_at)
    end
end

function MainMagicHelper.spell_lock_clear(state)
    MainMagicHelper.ensure_spell_state(state)

    state.combat.spell_locked = false
    state.combat.active_started_spell = nil
    state.combat.spell_started_at = 0.0

    state.combat.is_casting = false
    state.combat.current_spell = nil
    state.combat.cast_time_sec = nil
    state.combat.cast_timeout_at = 0.0
    state.combat.spell_lock_until = 0.0
end

function MainMagicHelper.spell_confirm(state, spell_name)
    MainMagicHelper.ensure_spell_state(state)

    MainMagicHelper.spell_lock_clear(state)

    -- Post-confirm animation tail: hold CASTS (not JAs/WS -- those are
    -- instant and fire fine in this window) for a beat so a follow-up spell
    -- isn't dropped by the finish animation. Own field, NOT spell_lock_until:
    -- putting it there blocked the whole dispatch (JA chains included) for
    -- 1s after every cast, which gutted the Jump->Jump->Berserk cascades.
    state.combat.post_cast_hold_until = now_sec() + POST_CAST_ANIMATION_HOLD_SEC

    state.combat.last_confirmed_spell = spell_name
    state.combat.last_confirmed_spell_at = now_sec()
end

function MainMagicHelper.spell_interrupt(state)
    MainMagicHelper.ensure_spell_state(state)

    MainMagicHelper.spell_lock_clear(state)
    -- Interrupt recovery: halt ALL casting for 3 seconds. This is NOT a
    -- per-spell cooldown -- the interrupted spell is deliberately left
    -- untouched (cooldowns module is not called, spell_confirm is not
    -- called, no completion is recorded). The 3s window covers the
    -- server's brief post-interrupt state where retrying inside it
    -- reliably produces a UTC, which would then trip the legitimate UTC
    -- backoff at line 668 of text_parser.lua and lock things up further.
    --
    -- We reuse spell_lock_until -- the same field used by the cast lock
    -- itself and by the UTC backoff -- so the existing OR in general.lua's
    -- real_locked check (state.combat.spell_lock_until > now_t) honors
    -- this for free. spell_lock_clear() just zeroed it; we re-set it
    -- here. Other state (spell_locked=false, is_casting=false) stays put
    -- so the bot knows we are NOT mid-cast, only in the post-interrupt
    -- hold.
    state.combat.spell_lock_until = now_sec() + 3.0

    state.combat.last_interrupt_at = now_sec()

    -- Clear the "cast was acked (starts casting seen)" watermark so the
    -- 20s never-confirmed diagnostic in refresh_spell_timeout doesn't
    -- false-positive later. An interrupted cast is genuinely never
    -- confirmed, but that's expected -- not a lost-confirm to warn about.
    state.combat.last_cast_acked_at = 0.0
    state.combat.last_cast_acked_name = nil

    local attempted_id = state.combat.last_attempted_action_id
    if attempted_id ~= nil then
        MainMagicHelper.mob_debuff_resisted(state, attempted_id)
    end
end

function MainMagicHelper.refresh_spell_timeout(state, timing, current_time, cooldowns)
    MainMagicHelper.ensure_spell_state(state)

    local tnow = tonumber(current_time or 0.0) or now_sec()

    -- Forced CD brake. When a timeout fires (i.e. spell_confirm never
    -- ran for this cast), write a flat 25s cooldown on the spell's id
    -- slot to prevent the ladder from machine-gunning retries against
    -- a lost-confirm case (interrupt missed, lost packet, weird server
    -- state). 25s is deliberately NOT the spell's real recast -- if
    -- we're hitting this branch we don't know whether the /ma actually
    -- landed on the server, so a fixed safety window protects against
    -- the worst case where the cast went through silently. On normal
    -- completion, spell_confirm in text_parser writes the real recast
    -- via cooldown_id_map before the timeout could fire, so the brake
    -- only ever applies to the broken path.
    --
    -- Gated on last_attempted_action_kind == 'spell' so JA / WS / item
    -- / ranged timeouts (which set their own CDs at dispatch via do_*)
    -- aren't affected.
    local FORCED_CD_BRAKE_SEC = 25.0
    local function apply_brake()
        if not cooldowns or type(cooldowns.set) ~= 'function' then return end
        if state.combat.last_attempted_action_kind ~= 'spell' then return end
        local id = state.combat.last_attempted_action_id
        if id == nil then return end
        cooldowns.set(id, FORCED_CD_BRAKE_SEC)
    end

    -- Diagnostic 1: dispatched-but-never-started (10s, debug-only, red).
    -- The bot sent /ma but no "starts casting" line ever arrived. Cause
    -- is almost always a silent server rejection: UTC under the recast
    -- threshold, not enough MP, out of range, silenced, dead target, or
    -- a Lua/game state desync. The cast won't proceed and the bot has
    -- no other signal that it failed -- only this elapsed-since-attempt
    -- check catches it.
    --
    -- Gates:
    --   * last_attempted_action_kind == 'spell' (filters out JA / WS /
    --     item / ranged attempts which don't have a casting bar)
    --   * last_cast_acked_at < last_attempted_action_at (the most recent
    --     attempt was never acknowledged by a "starts casting" event)
    --   * _warned_not_started_at < last_attempted_action_at (one-shot:
    --     this attempt has not already been warned about)
    -- The next dispatch's newer last_attempted_action_at re-arms the
    -- check naturally.
    if state.combat.last_attempted_action_kind == 'spell' then
        local attempted_at = tonumber(state.combat.last_attempted_action_at or 0.0) or 0.0
        local acked_at     = tonumber(state.combat.last_cast_acked_at or 0.0) or 0.0
        local warned_at    = tonumber(state.combat._warned_not_started_at or 0.0) or 0.0

        if attempted_at > 0.0
           and acked_at < attempted_at
           and warned_at < attempted_at
           and (tnow - attempted_at) >= 10.0 then
            state.combat._warned_not_started_at = attempted_at
            if state.ui and state.ui.debug_enabled == true and AshitaCore then
                local cm = AshitaCore:GetChatManager()
                if cm and type(cm.QueueCommand) == 'function' then
                    local sp = tostring(state.combat.last_attempted_action_name or '?')
                    -- \31\68 = red in Ashita's /echo color palette. If
                    -- the byte renders the wrong color on a given chat
                    -- config, swap the second byte (0x44 = 68) for the
                    -- desired palette index.
                    cm:QueueCommand(1, '/echo ' .. string.char(0x1F, 68)
                        .. '[CAST] ' .. sp
                        .. ' dispatched but not started after 10 seconds')
                end
            end
        end
    end

    -- Diagnostic 2: started-but-never-confirmed (20s, always emitted).
    -- The "starts casting" was observed (spell_lock_start ran, so
    -- last_cast_acked_at > 0) but neither the action-packet completion
    -- (packet_parser) nor the "X casts Y" chat-line (text_parser)
    -- produced a confirmation in 20s. This is a genuine lost-confirm
    -- event -- the safety fallback below has already cleared the lock
    -- by this point, but the diagnostic field survives so we can still
    -- report it. Always echoed (not debug-gated) because a missing
    -- confirm means cooldown bookkeeping was skipped for a cast the
    -- game actually ran.
    --
    -- Gates:
    --   * acked_at > 0 (a cast was actually started)
    --   * last_confirmed_spell_at < acked_at (no spell_confirm landed
    --     for this cast -- using last_confirmed_spell_at, not
    --     last_confirmed_action_at, so a JA confirm mid-cast doesn't
    --     spuriously satisfy this)
    --   * _warned_not_confirmed_at < acked_at (one-shot per cast)
    do
        local acked_at  = tonumber(state.combat.last_cast_acked_at or 0.0) or 0.0
        local conf_at   = tonumber(state.combat.last_confirmed_spell_at or 0.0) or 0.0
        local warned_at = tonumber(state.combat._warned_not_confirmed_at or 0.0) or 0.0

        if acked_at > 0.0
           and conf_at < acked_at
           and warned_at < acked_at
           and (tnow - acked_at) >= 20.0 then
            state.combat._warned_not_confirmed_at = acked_at
            if AshitaCore then
                local cm = AshitaCore:GetChatManager()
                if cm and type(cm.QueueCommand) == 'function' then
                    local sp = tostring(state.combat.last_cast_acked_name or '?')
                    cm:QueueCommand(1,
                        '/echo [CAST] ' .. sp
                        .. ' cast but not confirmed after 20 seconds')
                end
            end
        end
    end

    -- All clears are per-cast and computed from what we cast. No flat
    -- lockouts. spell_lock_start stores:
    --   cast_timeout_at  = start + cast_time + animation + 0.5  (expected done)
    --   cast_fallback_at = cast_timeout_at + 3.0                (safety only)
    -- Normal completion clears the lock far earlier via spell_confirm; these
    -- only fire if the confirmation is missed (interrupt / lost packet).

    if state.combat.spell_locked == true then
        local started_at  = tonumber(state.combat.spell_started_at or 0.0) or 0.0
        local fallback_at = tonumber(state.combat.cast_fallback_at or 0.0) or 0.0
        if started_at > 0.0 and fallback_at > 0.0 and tnow >= fallback_at then
            apply_brake()
            MainMagicHelper.spell_lock_clear(state)
            return
        end
    end

    if state.combat.is_casting == true then
        local timeout_at = tonumber(state.combat.cast_timeout_at or 0.0) or 0.0
        if timeout_at > 0.0 and tnow >= timeout_at then
            apply_brake()
            MainMagicHelper.spell_lock_clear(state)
            return
        end
    end

    local legacy_lock_until = tonumber(state.combat.spell_lock_until or 0.0) or 0.0
    if legacy_lock_until > 0.0 and tnow >= legacy_lock_until then
        state.combat.spell_lock_until = 0.0
        if state.combat.is_casting ~= true and state.combat.spell_locked == true then
            MainMagicHelper.spell_lock_clear(state)
        end
    end

    MainMagicHelper.ensure_mob_debuff_state(state)
    do
        local md = state.combat.mob_debuffs
        if pending_active(md) then
            local sent_at = tonumber(md.pending.sent_at or 0.0) or 0.0
            if sent_at > 0.0 and (tnow - sent_at) > 12.0 then
                clear_pending_for_current_target(state)
            end
        end
    end
end

function MainMagicHelper.ensure_mob_debuff_state(state)
    state.combat = state.combat or {}
    state.combat.mob_debuffs = state.combat.mob_debuffs or {
        target_server_id = 0,
        target_index = 0,
        first_atk_seen = false,
        pending = {
            id = nil,
            spell_name = nil,
            target_server_id = 0,
            target_index = 0,
            sent_at = 0.0,
        },
    }

    state.combat.mob_debuffs.pending = state.combat.mob_debuffs.pending or {
        id = nil,
        spell_name = nil,
        target_server_id = 0,
        target_index = 0,
        sent_at = 0.0,
    }
end

function MainMagicHelper.reset_mob_debuff_state(state, sid, idx)
    MainMagicHelper.ensure_mob_debuff_state(state)

    local md = state.combat.mob_debuffs
    md.target_server_id = tonumber(sid or 0) or 0
    md.target_index = tonumber(idx or 0) or 0
    md.first_atk_seen = false
    md.pending = make_pending(md)
end

function MainMagicHelper.current_target_identity(get_entity, target_manager)
    if type(target_manager) ~= 'function' then
        return 0, 0
    end

    local targets = target_manager()
    if not targets or type(targets.GetTargetIndex) ~= 'function' then
        return 0, 0
    end

    local idx = tonumber(targets:GetTargetIndex(0) or 0) or 0
    if idx == 0 then
        return 0, 0
    end

    local ent = nil
    if type(get_entity) == 'function' then
        ent = get_entity(idx)
    end

    if not ent then
        return 0, idx
    end

    local sid =
        tonumber(
            ent.ServerId or
            ent.ServerID or
            ent.Id or
            ent.ID or
            ent.EntityId or
            ent.EntityID or
            0
        ) or 0

    return sid, idx
end

function MainMagicHelper.refresh_mob_debuff_state(state, get_entity, target_manager)
    MainMagicHelper.ensure_mob_debuff_state(state)

    local sid, idx = MainMagicHelper.current_target_identity(get_entity, target_manager)
    local target_hp = tonumber(state.live and state.live.player_target_hp or 0) or 0

    if sid == 0 or idx == 0 or target_hp <= 0 then
        MainMagicHelper.reset_mob_debuff_state(state, sid, idx)
        return
    end

    local md = state.combat.mob_debuffs
    if md.target_server_id ~= sid or md.target_index ~= idx then
        MainMagicHelper.reset_mob_debuff_state(state, sid, idx)
        return
    end

    if pending_active(md) then
        local sent_at = tonumber(md.pending.sent_at or 0.0) or 0.0
        if sent_at > 0.0 and (now_sec() - sent_at) > 12.0 then
            clear_pending_for_current_target(state)
        end
    end
end

function MainMagicHelper.mark_first_atk_on_target(state)
    MainMagicHelper.ensure_mob_debuff_state(state)

    local md = state.combat.mob_debuffs
    if n(md.target_server_id) == 0 and n(md.target_index) == 0 then
        return
    end

    md.first_atk_seen = true
end

function MainMagicHelper.mob_debuff_mark_sent(state, id, spell_name)
    MainMagicHelper.ensure_mob_debuff_state(state)

    local key = tostring(id or spell_name or ''):upper()
    if key == '' then return end

    local md = state.combat.mob_debuffs
    md.pending = {
        id = key,
        spell_name = tostring(spell_name or ''),
        target_server_id = n(md.target_server_id),
        target_index = n(md.target_index),
        sent_at = now_sec(),
    }
end

function MainMagicHelper.mob_debuff_confirm(state, id_or_spell_name)
    MainMagicHelper.ensure_mob_debuff_state(state)
    local md = state.combat.mob_debuffs
    local key = tostring(id_or_spell_name or ''):upper()
    if key == '' then
        if pending_active(md) then
            clear_pending_for_current_target(state)
        end
        return
    end

    -- Cast confirmed -> clear the in-flight pending gate. DebuffHandler is
    -- the truth source for whether the debuff is on the mob, so nothing
    -- else to track here.
    if md.pending and md.pending.id == key then
        clear_pending_for_current_target(state)
    end
end

function MainMagicHelper.mob_debuff_resisted(state, id_or_spell_name)
    MainMagicHelper.ensure_mob_debuff_state(state)
    local md = state.combat.mob_debuffs
    local key = tostring(id_or_spell_name or ''):upper()
    if key == '' then
        if pending_active(md) then
            clear_pending_for_current_target(state)
        end
        return
    end
    -- Resist: clear pending so the bot retries on the next cycle.
    if md.pending and md.pending.id == key then
        clear_pending_for_current_target(state)
    end
end

function MainMagicHelper.mob_debuff_wore_off(state, id_or_spell_name)
    MainMagicHelper.ensure_mob_debuff_state(state)
    local md = state.combat.mob_debuffs
    local key = tostring(id_or_spell_name or ''):upper()
    if key == '' then return end

    -- Wear-off chat line: clear any matching in-flight pending.
    if md.pending and md.pending.id == key then
        clear_pending_for_current_target(state)
    end
end

function MainMagicHelper.attach_ctx(ctx, state, dispatch, general_actions, cooldowns, normalize_action_name_for_map, timing)
    ctx.do_spell = function(spell_name, target, id)
        if ctx.target_dead then return false end

        local spell = tostring(spell_name or '')
        if spell == '' then return false end

        -- Skip while a ranged shot is in flight -- the game will drop the cast.
        if ctx.ranged_busy then
            local ok, cm = pcall(function() return AshitaCore:GetChatManager() end)
            if ok and cm then
                pcall(function()
                    cm:QueueCommand(1, string.format(
                        '/echo [bovinebattle] blocked: SPELL:%s (ranged shot in progress)',
                        tostring(id or spell)))
                end)
            end
            return false
        end

        if general_actions.cast(spell, target or '<t>', dispatch, 1.0) then
            -- NOTE: cooldowns.set is intentionally NOT called at /ma
            -- send time. The per-spell CD is set ONLY when the cast
            -- actually confirms -- text_parser.lua's spell_confirm
            -- writes state.cooldown_id_map[attempted_id] via the
            -- 'log' (chat-line) or 'action' (packet) completion
            -- paths, both of which are success-only. Silently rejected
            -- casts (UTC, recast still up, OOM, silence, out of range,
            -- dead target) emit no "starts casting" line and no
            -- action packet, so they correctly leave the CD untouched
            -- and the next ladder pass can immediately retry.
            --
            -- The in-flight gate is held by spell_locked / is_casting
            -- / spell_lock_until (all set in spell_lock_start below)
            -- plus the short dispatch_guard armed inside the dispatch
            -- pipe, so removing the send-time CD write does not open
            -- a re-fire window before "starts casting" arrives.
            MainMagicHelper.spell_lock_start(state, spell, timing)
            MainMagicHelper.mob_debuff_mark_sent(state, id, spell)

            state.combat.last_attempted_action_id = id or spell
            state.combat.last_attempted_action_name = normalize_action_name_for_map(spell)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'spell'

            return true
        end

        return false
    end

    -- Self-target spell cast that bypasses the dead-target guard. Used by
    -- the Full-Buff sequence, which runs while disengaged with no mob
    -- target -- in that state ctx.target_dead is true (no valid target),
    -- which would block ctx.do_spell entirely. <me> casts don't care about
    -- the mob target, so this variant skips that check. Everything else
    -- (lock arming, cooldown-on-confirm, last_attempted bookkeeping) is
    -- identical to do_spell. Target is forced to '<me>'.
    ctx.do_self_spell = function(spell_name, id)
        local spell = tostring(spell_name or '')
        if spell == '' then return false end

        if general_actions.cast(spell, '<me>', dispatch, 1.0) then
            MainMagicHelper.spell_lock_start(state, spell, timing)
            MainMagicHelper.mob_debuff_mark_sent(state, id, spell)

            state.combat.last_attempted_action_id = id or spell
            state.combat.last_attempted_action_name = normalize_action_name_for_map(spell)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'spell'

            return true
        end

        return false
    end
end

return MainMagicHelper