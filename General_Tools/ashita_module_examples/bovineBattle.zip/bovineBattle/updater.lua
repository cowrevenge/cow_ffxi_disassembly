--[[---------------------------------------------------------------------------
updater.lua

GitHub auto-updater for a MULTI-FILE addon.

bovinefh's updater replaces exactly one file. bovinebattle is ~18 lua files
plus libs/ and gdifonts/, so this one walks the whole repo tree instead:

  1. GET /repos/<repo>/git/trees/<branch>?recursive=1
     -> every path in the repo with its git blob SHA-1.
  2. For each path, compute the SAME hash for the local copy
     (sha1("blob " .. len .. "\0" .. bytes)) and compare.
  3. Download ONLY the paths whose hashes differ, into update/staged/.
  4. Apply = syntax-check every staged .lua, back the originals up, copy the
     staged tree over the addon dir, reload.

Transport is the same trick bovinefh uses: write a tiny .ps1, launch it
DETACHED, poll for a result file from d3d_present. Nothing ever blocks the
render thread, so a slow or dead network cannot hitch the game. No sockets,
no LuaSocket, no extra dependencies.

Never touches: settings/, update/, gitvar.dat, .git*, README, LICENSE.
Never deletes anything. A file removed from the repo stays on disk.

LINE ENDINGS MATTER. The comparison is on bytes, so if git normalizes CRLF to
LF on commit while your working copy stays CRLF, every file reads as changed
on the first check. That is technically correct and self-healing (the first
apply rewrites everything to the repo's bytes and it is stable after), but if
you want the CRLF the files ship with, commit a .gitattributes containing
`* -text` so git stores them verbatim.

TOKEN: leave empty for a public repo. For a private repo use a fine-grained
PAT scoped to this one repo with Contents: Read and nothing else. Put it in
<addon>/gitvar.dat (one line, just the token) and add that to .gitignore.
It is handed to the child process through an environment variable, so it is
never written to disk and never appears in a process list.
---------------------------------------------------------------------------]]--

local imgui = require('imgui')

local M = {}

-- Filled in by M.setup(). Kept in one table so the host addon holds a single
-- reference and nothing here needs a global.
M.opts = {
    name    = 'bovinebattle',
    version = '0.0',
    path    = '',
    repo    = 'cowrevenge/bovinebattle',
    branch  = 'main',
    token   = '',            -- prefer gitvar.dat; see header
    is_busy = nil,           -- function() -> bool, reason   (refuse to apply)
    note    = nil,           -- function(msg)                (chat/log line)
}

-- Live state the panel reads. Never holds the token.
M.st = {
    status    = 'idle',      -- idle | checking | uptodate | available | error | applying
    message   = '',
    pending   = false,
    ready     = false,
    started   = 0.0,
    changes   = {},          -- { {kind='MOD'|'NEW', path=..., sha=...}, ... }
    auto_apply= false,
    last_check= 0,
}

--------------------------------------------------------------------------------
-- PATHS
--------------------------------------------------------------------------------

local P = {}

local function rebuild_paths()
    local root = M.opts.path or ''
    P.root   = root
    P.dir    = root .. 'update/'
    P.ps     = P.dir .. 'update.ps1'
    P.result = P.dir .. 'update.result'
    P.stage  = P.dir .. 'staged/'
    P.backup = P.dir .. 'backup/'
end

-- Windows mkdir -p. Ashita's Lua has no filesystem library, so this is the
-- same os.execute idiom the file pickers already use. 2>nul swallows the
-- "already exists" noise.
rebuild_paths()

local function mkdirp(dir)
    if dir == nil or dir == '' then return end
    os.execute('mkdir "' .. tostring(dir):gsub('/', '\\') .. '" 2>nul')
end

local function parent_of(p)
    return (tostring(p):match('^(.*)[/\\][^/\\]*$'))
end

local function read_all(path, mode)
    local f = io.open(path, mode or 'rb')
    if not f then return nil end
    local d = f:read('*a')
    f:close()
    return d
end

local function write_all(path, data)
    local f = io.open(path, 'wb')
    if not f then return false end
    f:write(data)
    f:close()
    return true
end

local function note(msg)
    if type(M.opts.note) == 'function' then M.opts.note(msg) end
end

--------------------------------------------------------------------------------
-- TOKEN
--------------------------------------------------------------------------------

local token_cache = nil

-- gitvar.dat in the addon root, then settings/, then the inline opts.token.
-- First line only, all whitespace stripped: a trailing CR from a Windows
-- editor inside a header value fails auth with a confusing 401.
local function token_read()
    for _, path in ipairs({ P.root .. 'gitvar.dat',
                            P.root .. 'settings/gitvar.dat' }) do
        local f = io.open(path, 'r')
        if f then
            local t = f:read('*l') or ''
            f:close()
            t = t:gsub('%s', '')
            if t ~= '' then return t end
        end
    end
    return (tostring(M.opts.token or ''):gsub('%s', ''))
end

-- Cached so the panel can call it every frame without hitting the disk every
-- frame. The sidecar is only re-read on a reload, which is also when you would
-- have just edited it.
function M.token()
    if token_cache == nil then token_cache = token_read() end
    return token_cache
end

--------------------------------------------------------------------------------
-- CHECK (detached powershell, non-blocking)
--------------------------------------------------------------------------------

-- Build the .ps1. Everything our side supplies goes in as a SINGLE-QUOTED
-- PowerShell literal, so no path or repo name can be reinterpreted as code.
-- URLs are built by concatenation rather than interpolation, because "$branch?"
-- would end the variable name in a way that depends on the PS version.
local function write_script()
    local q = function(s) return "'" .. tostring(s):gsub("'", "''") .. "'" end
    local L = {}
    local function w(s) L[#L + 1] = s end

    w("$ErrorActionPreference = 'Stop'")
    w("$root  = " .. q(P.root))
    w("$stage = " .. q(P.stage))
    w("$res   = " .. q(P.result))
    w("$repo  = " .. q(M.opts.repo))
    w("$brch  = " .. q(M.opts.branch))
    w("$ua    = " .. q(M.opts.name))
    w("$sent  = 'auth=MISSING'")
    -- GIT blob SHA-1, not a plain file hash: sha1("blob <len>\0" + bytes).
    -- Same value the trees API returns, so the two are directly comparable.
    w("function Get-BlobSha([string]$p) {")
    w("  if (-not (Test-Path -LiteralPath $p)) { return '-' }")
    w("  $b = [IO.File]::ReadAllBytes($p)")
    w("  $hd = [Text.Encoding]::ASCII.GetBytes('blob ' + $b.Length + [char]0)")
    w("  $a = New-Object byte[] ($hd.Length + $b.Length)")
    w("  [Array]::Copy($hd,0,$a,0,$hd.Length)")
    w("  [Array]::Copy($b,0,$a,$hd.Length,$b.Length)")
    w("  $sh = [Security.Cryptography.SHA1]::Create()")
    w("  return ((($sh.ComputeHash($a)) | ForEach-Object { $_.ToString('x2') }) -join '')")
    w("}")
    w("try {")
    w("  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12")
    w("  $tok = $env:BB_GH_TOK")
    w("  $hj = @{ 'User-Agent' = $ua; 'Accept' = 'application/vnd.github+json' }")
    w("  $hr = @{ 'User-Agent' = $ua; 'Accept' = 'application/vnd.github.raw' }")
    -- A 404 on a private repo looks identical whether the token never went out
    -- or went out without the right scope, so record which case this was.
    w("  if ($tok) { $hj['Authorization'] = 'Bearer ' + $tok; $hr['Authorization'] = 'Bearer ' + $tok; $sent = 'auth=sent' }")
    w("  $turl = 'https://api.github.com/repos/' + $repo + '/git/trees/' + $brch + '?recursive=1'")
    w("  $tree = Invoke-RestMethod -Uri $turl -Headers $hj -UseBasicParsing")
    -- The trees API truncates past ~100k entries. Not a risk for an addon, but
    -- silently syncing half a repo would be much worse than refusing.
    w("  if ($tree.truncated) { throw 'repo tree truncated - too many files' }")
    w("  if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }")
    w("  New-Item -ItemType Directory -Path $stage -Force | Out-Null")
    -- Never sync user config, our own working dir, or repo furniture.
    w("  $skipdir  = @('settings/','update/','.github/','.vscode/','docs/')")
    w("  $skipfile = @('gitvar.dat','.gitignore','.gitattributes','readme.md','license','license.txt')")
    w("  $lines = New-Object System.Collections.ArrayList")
    w("  foreach ($n in $tree.tree) {")
    w("    if ($n.type -ne 'blob') { continue }")
    w("    $p  = $n.path")
    w("    $pl = $p.ToLower()")
    w("    $bad = $false")
    w("    foreach ($s in $skipdir)  { if ($pl.StartsWith($s)) { $bad = $true } }")
    w("    foreach ($s in $skipfile) { if ($pl -eq $s)         { $bad = $true } }")
    w("    if ($bad) { continue }")
    w("    $lsha = Get-BlobSha ($root + $p)")
    w("    if ($lsha -eq $n.sha) { continue }")
    w("    $dest = $stage + $p")
    w("    New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null")
    w("    $furl = 'https://api.github.com/repos/' + $repo + '/contents/' + $p + '?ref=' + $brch")
    w("    Invoke-WebRequest -Uri $furl -Headers $hr -OutFile $dest -UseBasicParsing")
    w("    if ($lsha -eq '-') { $k = 'NEW' } else { $k = 'MOD' }")
    w("    [void]$lines.Add($k + ' ' + $p + ' ' + $n.sha)")
    w("  }")
    w("  Set-Content -Path $res -Value (@('OK ' + $lines.Count) + $lines)")
    w("} catch {")
    w("  Set-Content -Path $res -Value ('ERR [' + $sent + '] ' + $_.Exception.Message)")
    w("} finally {")
    -- Belt and braces: the script deletes itself even though it never held
    -- the token in the first place.
    w("  Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue")
    w("}")

    local f = io.open(P.ps, 'w')
    if not f then return false end
    f:write(table.concat(L, '\n'))
    f:close()
    return true
end

-- Kick off a check. Returns immediately; M.poll() picks up the result.
function M.check(auto)
    local u = M.st
    if u.pending then return end
    rebuild_paths()
    mkdirp(P.dir)
    os.remove(P.result)
    os.remove(P.ps)          -- never reuse a stale script

    if not write_script() then
        u.status, u.message = 'error', 'could not write update script'
        return
    end

    -- `set` then `start` in ONE cmd invocation so the launched powershell
    -- inherits the variable. The token is not on the command line either, so
    -- it never shows up in a process list.
    local launch = 'start "" /b powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File "'
        .. P.ps .. '"'
    local tok = M.token()
    if tok ~= '' then
        launch = 'set "BB_GH_TOK=' .. tok .. '" && ' .. launch
    end
    os.execute(launch)

    u.pending    = true
    u.ready      = false
    u.changes    = {}
    u.started    = os.clock()
    u.status     = 'checking'
    u.auto_apply = (auto == true)
    u.message    = 'checking ' .. M.opts.repo .. '@' .. M.opts.branch .. ' ...'
end

-- Polled every frame from d3d_present. CHECK ONLY: never writes to the addon.
-- 90s timeout (not bovinefh's 30s) because this can pull a dozen files.
function M.poll()
    local u = M.st
    if not u.pending then return end

    if (os.clock() - u.started) > 90.0 then
        u.pending = false
        u.status, u.message = 'error', 'timed out after 90s'
        return
    end

    local raw = read_all(P.result, 'r')
    if raw == nil then return end
    os.remove(P.result)
    u.pending    = false
    u.last_check = os.time()

    local auto = u.auto_apply
    u.auto_apply = false

    local lines = {}
    for line in tostring(raw):gmatch('[^\r\n]+') do lines[#lines + 1] = line end
    local head = lines[1] or ''

    local err = head:match('^ERR%s*(.*)$')
    if err then
        -- GitHub hides private repos it will not show you rather than 403ing,
        -- so a 404 is nearly always a token problem. Say WHICH one.
        if err:find('404') then
            if err:find('auth=MISSING', 1, true) then
                err = err .. '  -> token never reached the request'
            elseif M.token() == '' then
                err = err .. '  (private repo? no gitvar.dat found)'
            else
                err = err .. '  -> token sent but cannot see the repo (scope?)'
            end
        end
        u.status, u.message = 'error', err
        if auto then note('[update] check failed: ' .. err) end
        return
    end

    local n = tonumber(head:match('^OK%s+(%d+)'))
    if n == nil then
        u.status, u.message = 'error', 'unreadable result: ' .. head:sub(1, 80)
        return
    end

    u.changes = {}
    for i = 2, #lines do
        local kind, path, sha = lines[i]:match('^(%u+)%s+(%S+)%s+(%S+)$')
        if kind and path then
            u.changes[#u.changes + 1] = { kind = kind, path = path, sha = sha }
        end
    end

    if #u.changes == 0 then
        u.ready   = false
        u.status  = 'uptodate'
        u.message = string.format('Up to date (v%s, %d files match)', M.opts.version, n)
        if auto then note('[update] ' .. u.message) end
        return
    end

    u.ready   = true
    u.status  = 'available'
    u.message = string.format('%d file(s) changed - ready to apply', #u.changes)
    if auto then
        note('[update] ' .. u.message)
        M.apply()
    end
end

--------------------------------------------------------------------------------
-- APPLY
--------------------------------------------------------------------------------

-- Every staged .lua must COMPILE before anything is copied. This is the real
-- safety net: a truncated download, an HTML error page, or a genuinely broken
-- commit all fail here, and the addon on disk is never touched. Cheap, too --
-- loadstring parses, it does not run the chunk.
local function verify_staged()
    for _, c in ipairs(M.st.changes) do
        local src = read_all(P.stage .. c.path)
        if src == nil or #src == 0 then
            return false, 'staged file missing or empty: ' .. c.path
        end
        if c.path:lower():sub(-4) == '.lua' then
            local chunk, cerr = loadstring(src, '@' .. c.path)
            if chunk == nil then
                return false, 'syntax error in ' .. c.path .. ': ' .. tostring(cerr)
            end
        end
    end
    return true
end

function M.apply()
    local u = M.st
    if not u.ready then return end

    -- Reloading mid-fight would drop the ladder session and could strand a
    -- held movement key. The host decides what "busy" means.
    if type(M.opts.is_busy) == 'function' then
        local busy, why = M.opts.is_busy()
        if busy then
            u.status  = 'error'
            u.message = why or 'busy - cannot apply right now'
            return
        end
    end

    local ok, verr = verify_staged()
    if not ok then
        u.status, u.message = 'error', verr
        return
    end

    -- Timestamped backup of everything about to be replaced, so a bad push is
    -- one folder copy away from being undone.
    local stamp = os.date('%Y%m%d-%H%M%S')
    local bdir  = P.backup .. stamp .. '/'
    mkdirp(bdir)

    local applied, failed = 0, nil
    for _, c in ipairs(M.st.changes) do
        local target = P.root .. c.path
        local staged = P.stage .. c.path

        local cur = read_all(target)
        if cur ~= nil then
            mkdirp(parent_of(bdir .. c.path))
            write_all(bdir .. c.path, cur)
        end

        local data = read_all(staged)
        if data == nil then
            failed = 'could not read staged ' .. c.path
            break
        end
        mkdirp(parent_of(target))
        if not write_all(target, data) then
            failed = 'could not write ' .. c.path
            break
        end
        applied = applied + 1
    end

    if failed then
        -- Partial write. Say so loudly and point at the backup: the addon may
        -- be in a mixed state and a reload could fail.
        u.status  = 'error'
        u.message = failed .. '  (applied ' .. applied .. ', backup in update/backup/' .. stamp .. ')'
        note('[update] ' .. u.message)
        return
    end

    u.ready   = false
    u.status  = 'applying'
    u.message = string.format('Applied %d file(s), reloading...', applied)
    note('[update] ' .. u.message .. '  (backup: update/backup/' .. stamp .. ')')
    -- Reload on the next command tick so this frame finishes cleanly first.
    AshitaCore:GetChatManager():QueueCommand(1, '/addon reload ' .. M.opts.name)
end

--------------------------------------------------------------------------------
-- SETUP
--------------------------------------------------------------------------------

function M.setup(o)
    o = o or {}
    for k, v in pairs(o) do M.opts[k] = v end
    token_cache = nil
    rebuild_paths()
    return M
end

--------------------------------------------------------------------------------
-- UI
--------------------------------------------------------------------------------

local function help_marker(text)
    imgui.SameLine()
    imgui.TextDisabled('(?)')
    if imgui.IsItemHovered() then
        imgui.SetTooltip(text)
    end
end

-- Renders its own CollapsingHeader. `auto_on` / `set_auto` let the host keep
-- the auto-update flag in its own settings table without this module knowing
-- anything about Ashita's settings library.
function M.render(auto_on, set_auto)
    if not imgui.CollapsingHeader('Updates##bb_updates') then return end

    local u = M.st

    if u.pending then
        imgui.TextDisabled('checking...')
    elseif imgui.Button('Check Updates##bb_upd_check', { 130, 0 }) then
        M.check(false)
    end

    -- Apply only exists once a check actually found something, so the two
    -- buttons can never contradict each other.
    if u.ready then
        imgui.SameLine()
        if imgui.Button('Update Now##bb_upd_apply', { 120, 0 }) then
            M.apply()
        end
    end

    if u.message ~= '' then
        local col = { 0.70, 0.70, 0.70, 1.0 }
        if     u.status == 'uptodate'  then col = { 0.50, 0.90, 0.50, 1.0 }
        elseif u.status == 'available' then col = { 1.00, 0.80, 0.30, 1.0 }
        elseif u.status == 'error'     then col = { 1.00, 0.40, 0.40, 1.0 }
        elseif u.status == 'applying'  then col = { 0.60, 0.80, 1.00, 1.0 } end
        imgui.TextColored(col, u.message)
    end

    -- The changed-file list is the whole point of a multi-file updater: you
    -- can see it is about to touch general.lua and not, say, your atk_list.
    if u.ready and #u.changes > 0 then
        for _, c in ipairs(u.changes) do
            local tag = (c.kind == 'NEW') and '+ ' or '~ '
            local col = (c.kind == 'NEW') and { 0.55, 0.85, 0.95, 1.0 }
                                          or { 0.85, 0.85, 0.60, 1.0 }
            imgui.TextColored(col, tag .. c.path)
        end
    end

    if u.ready and type(M.opts.is_busy) == 'function' then
        local busy, why = M.opts.is_busy()
        if busy then
            imgui.TextColored({ 1.0, 0.60, 0.30, 1.0 }, why or 'busy')
        end
    end

    if set_auto ~= nil then
        local v = { auto_on and true or false }
        if imgui.Checkbox('Auto-update on load##bb_upd_auto', v) then
            set_auto(v[1])
        end
        help_marker('On load, check GitHub and apply any changed files automatically, then reload. Only applies while PAUSED. Every replaced file is backed up to update/backup/<timestamp>/ first.')
    end

    imgui.TextDisabled(string.format('local v%s  |  %s@%s',
        M.opts.version, M.opts.repo, M.opts.branch))
    if M.token() == '' then
        imgui.TextDisabled('no gitvar.dat (public repo mode)')
    else
        imgui.TextDisabled('token loaded from gitvar.dat')
    end
end

return M
