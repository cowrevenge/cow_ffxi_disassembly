--[[---------------------------------------------------------------------------
text_parser.lua

Purpose
  Own all text parsing for Bovine Battle.

Owns
  - attack round detection
  - defence round detection
  - spell start / spell finish / spell interrupt
  - ninja tools out
  - ranged no weapon
  - cannot see target
  - cannot attack target suppression
  - last seen text line debug state
  - action confirmation tracking for cooldown follow-up
  - magic resist / wears-off tracking for debuff retry state

State ownership
  - state.debug.last_log_line
  - state.combat.last_confirmed_action_name
  - state.combat.last_confirmed_action_at

Expected args to on_text_in(...)
  - event
  - state
  - current_time

Notes
  - Player name / pattern cache is owned by main.lua.
  - This file consumes:
      state.cached_player_name
      state.cached_player_pat
  - Ninja tools out does NOT apply a general cast lock.
    It clears the active cast state only.
---------------------------------------------------------------------------]]--

require('common')
require('helpers')

-- Worm-family mob names, generated from LSB. Only used by the "cannot attack
-- that target" branch. pcall-wrapped so a missing or broken worm_list costs
-- the worm-specific pause and nothing else -- text parsing is on the hot path
-- for every line the client prints and must not be able to fail at load.
local WormList = nil
do
    local ok, mod = pcall(require, 'worm_list')
    if ok and type(mod) == 'table' and type(mod.is_worm) == 'function' then
        WormList = mod
    end
end

-- How long to hold off the engage retry when a WORM says we cannot attack it.
-- It is burrowed; it comes back up on its own. The generic case stays at 1.0s.
local WORM_CANNOT_ATTACK_SEC = 2.0

-- Ceiling on the worm grace. A burrowed worm surfaces within a couple of
-- seconds, so a THIRD refusal for the same mob is not burrowing -- it is a
-- corpse, a despawn, or a worm that is never coming back. Past this the mob
-- gets dropped like any other bad target.
local CANNOT_ATTACK_MAX_TRIES   = 3

-- LOS strikes before we give up on a mob. ONE.
--
-- It was two, on the theory that a single refusal might be the character
-- still rotating. In practice two never accumulated: a refused /ra never
-- resolves, so the refire gate waits out its 10s stale ceiling before trying
-- again -- and the strike window was also 10s, so strike 1 had always just
-- expired when strike 2 arrived. The counter could not reach 2 by
-- construction, and the 18s stale-lock watchdog ended up doing the work
-- instead. Two refusals ten seconds apart, then eighteen seconds of standing
-- still, for a mob we already knew about at the first message.
--
-- One strike, because this message is deterministic LOS on HorizonXI and we
-- are standing still: the geometry that refused the first shot is the same
-- geometry ten seconds later. Drops in ~2s instead of 18, and saves the
-- second wasted arrow.
--
-- Cost of being wrong is one mob parked for 30s, and the entry expires on
-- its own. Raise this back to 2 with a window well over 10s if a refusal
-- ever turns out to be transient.
local LOS_MAX_TRIES             = 1
-- Streak window. Comfortably wider than the 10s refire ceiling so a counter
-- with a threshold above 1 can actually accumulate -- see LOS_MAX_TRIES for
-- how a 10s window silently made a 2-strike rule unreachable.
local CANNOT_ATTACK_WINDOW_SEC  = 30.0

local TextParser = {}

local function now_sec()
    return os.clock()
end

local function general_lua()
    return package.loaded['general']
end

local function main_magic_helper()
    return package.loaded['main_magic_helper'] or require('main_magic_helper')
end

local function hb_shadows_helper()
    return package.loaded['hb_shadows_helper']
end

local function hb_shadows_helper()
    return package.loaded['hb_shadows_helper']
end

local function memory_manager()
    return AshitaCore:GetMemoryManager()
end

local function party_manager()
    local m = memory_manager()
    return m and m:GetParty() or nil
end

local function get_entity(index)
    local ok, entity = pcall(GetEntity, index)
    return ok and entity or nil
end

local function player_status()
    local ok, entity = pcall(GetPlayerEntity)
    if ok and entity then
        local st = entity.Status or entity.status or entity.CurrentStatus
        if st ~= nil then
            return tonumber(st)
        end
    end

    local party = party_manager()
    if party then
        local ok_status, value = pcall(function()
            if type(party.GetMemberStatus) == 'function' then
                return party:GetMemberStatus(0)
            end
            if type(party.GetMemberCurrentStatus) == 'function' then
                return party:GetMemberCurrentStatus(0)
            end
            return nil
        end)
        if ok_status and value ~= nil then
            return tonumber(value)
        end
    end

    local party2 = party_manager()
    if not party2 then return nil end

    local player_server_id = tonumber(party2:GetMemberServerId(0) or 0) or 0
    if player_server_id == 0 then return nil end

    for i = 0, 2047 do
        local entity2 = get_entity(i)
        if entity2 then
            local sid =
                entity2.ServerId or
                entity2.ServerID or
                entity2.Id or
                entity2.ID or
                entity2.EntityId or
                entity2.EntityID

            if tonumber(sid or 0) == player_server_id then
                local st2 = entity2.Status or entity2.status or entity2.CurrentStatus
                if st2 ~= nil then
                    return tonumber(st2)
                end
            end
        end
    end

    return nil
end

local function get_event_text(event)
    local keys = { 'message', 'text', 'modified', 'original', 'data', 'line' }

    for _, key in ipairs(keys) do
        local ok, value = pcall(function() return event[key] end)
        if ok and type(value) == 'string' and #value > 0 then
            return value
        end
    end

    return nil
end

local function sanitize_log_text(text)
    text = tostring(text or '')
    text = text:gsub('\r', ' ')
    text = text:gsub('\n', ' ')
    -- Normalize non-ASCII apostrophe-like bytes to ASCII apostrophe BEFORE
    -- the printable-only strip below. The FFXI log can emit "X's casting
    -- is interrupted." with the apostrophe as:
    --   * UTF-8 right single quote ’  (E2 80 99) -- most common on modern clients
    --   * UTF-8 left single quote  ‘  (E2 80 98)
    --   * CP1252 right single quote   (0x92)
    --   * legacy single-byte         (0xA4)
    -- All four of those byte sequences fall into the 0x80-0xFF range and
    -- would be wiped to NOTHING by the strip below, turning "Cowrevenge's"
    -- into "Cowrevenges" and breaking exact-match checks like
    -- is_player_cast_interrupted_exact -- which silently killed our
    -- interrupt detection and left cast watchdogs / cooldowns wedged.
    -- Substitute these to ASCII apostrophe up front so they survive.
    text = text:gsub('\xE2\x80\x99', "'")
    text = text:gsub('\xE2\x80\x98', "'")
    text = text:gsub('\x92',         "'")
    text = text:gsub('\xA4',         "'")
    -- Strip control / non-printable bytes (auto-translate markers,
    -- color codes, stray nulls) the game injects into log lines,
    -- which render as garbage like 'enthunder.?1'. Printable only.
    text = text:gsub('[%z\1-\31\127-\255]', '')
    -- Legacy literal subs kept as a safety net for any apostrophe
    -- variant that happens to survive as printable ASCII bytes.
    text = text:gsub('’', "'")
    text = text:gsub('`', "'")
    text = text:gsub('%s+', ' ')
    text = text:gsub('^%s+', '')
    text = text:gsub('%s+$', '')
    return text
end

local function normalize_action_name(name)
    if type(name) ~= 'string' then return nil end

    local s = sanitize_log_text(name):lower()
    s = s:gsub('%s+on%s+.+$', '')
    s = s:gsub(',%s+but%s+.+$', '')
    s = s:gsub('%s+but%s+.+$', '')
    s = s:gsub(',%s+and%s+.+$', '')
    s = s:gsub('%s+and%s+.+$', '')
    s = s:gsub('%.%s*$', '')
    s = s:gsub('^%s+', '')
    s = s:gsub('%s+$', '')

    return (#s > 0) and s or nil
end

local function line_is_you_or_player(state, lower_text)
    if lower_text:find('you ', 1, true) == 1 then
        return true
    end

    if state.cached_player_pat then
        if lower_text:match('^' .. state.cached_player_pat .. '%s+') then return true end
        if lower_text:match('^' .. state.cached_player_pat .. "'s%s+") then return true end
    end

    return false
end

local function is_player_attack_line(state, text)
    if type(text) ~= 'string' then return false end
    if not state.cached_player_pat then return false end

    local sl = sanitize_log_text(text):lower()

    if sl:match('^' .. state.cached_player_pat .. '%s+hits%s+') then return true end
    if sl:match('^' .. state.cached_player_pat .. '%s+misses%s+') then return true end
    if sl:match('^' .. state.cached_player_pat .. '%s+critically%s+hits%s+') then return true end
    if sl:match('^' .. state.cached_player_pat .. '%s+scores%s+a%s+critical%s+hit') then return true end
    if sl:match('^' .. state.cached_player_pat .. '%s+attacks%s+') then return true end

    return false
end

local function is_enemy_attack_you_line(state, text)
    if type(text) ~= 'string' then return false end

    local sl = sanitize_log_text(text):lower()

    -- HorizonXI combat-log style: "<name> takes N points of damage."
    -- Must be checked BEFORE the line_is_you_or_player bouncer below,
    -- because the line starts with the player's name (grammatical subject)
    -- even though the player is the semantic victim.
    if state.cached_player_pat then
        if sl:match('^' .. state.cached_player_pat .. '%s+takes%s+%d+%s+point') then return true end
    end

    if line_is_you_or_player(state, sl) then return false end

    -- VERB AGREEMENT: FFXI conjugates the attack verb to the MOB's name,
    -- which is the grammatical subject here. A plural-named mob emits
    -- "The Funnel Bats miss Cowrevenge" / "... hit Cowrevenge for 12",
    -- NOT "misses" / "hits". Matching only the singular form meant every
    -- plural-named mob (Funnel Bats, Ravenous Crawlers, Goblin Smithies,
    -- ...) was completely invisible to defence-round detection -- shadows
    -- never got recast, Time Since Last Defence just climbed forever.
    -- `hits?` matches hit/hits; `misse?s?` matches miss/misses.
    -- (The player-as-subject patterns above stay singular-only: the
    -- player's own name is never plural.)
    if sl:match('^.+%s+misse?s?%s+you%f[%W]') then return true end
    if sl:match('^.+%s+hits?%s+you%s+for%s+%d+') then return true end
    if sl:match('^.+%s+critically%s+hits?%s+you%s+for%s+%d+') then return true end
    if sl:match("^%d+%s+of%s+your%s+shadows%s+absorbs%s+the%s+damage%s+and%s+disappears%.?$") then return true end

    if state.cached_player_pat then
        if sl:match('^.+%s+misse?s?%s+' .. state.cached_player_pat .. '%f[%W]') then return true end
        if sl:match('^.+%s+hits?%s+' .. state.cached_player_pat .. '%s+for%s+%d+') then return true end
        if sl:match('^.+%s+critically%s+hits?%s+' .. state.cached_player_pat .. '%s+for%s+%d+') then return true end
        if sl:match("^[1234]%s+of%s+" .. state.cached_player_pat .. "'s%s+shadows%s+absorbs") then return true end
    end

    return false
end

local function parse_player_starts_casting_name(state, text)
    if type(text) ~= 'string' then return nil end

    local sl = sanitize_log_text(text):lower()
    local spell = nil

    if state.cached_player_pat then
        spell = sl:match('^' .. state.cached_player_pat .. '%s+starts%s+casting%s+([^.]+)')
    end
    if not spell then
        spell = sl:match('^you%s+start%s+casting%s+([^.]+)')
    end

    return normalize_action_name(spell)
end

local function parse_player_casts_name(state, text)
    if type(text) ~= 'string' then return nil end

    local sl = sanitize_log_text(text):lower()
    local spell = nil

    -- Capture stops at the first period -- the "X casts Y." line ends the
    -- spell name there. A greedy (.+) ran past it and swallowed any
    -- following sentence in the same buffer (e.g. "...refresh. cowrevenge
    -- gains the effect of refresh. 1"), producing a garbage name. [^.] keeps
    -- it to just the spell.
    if state.cached_player_pat then
        spell = sl:match('^' .. state.cached_player_pat .. '%s+casts%s+([^.]+)')
    end
    if not spell then
        spell = sl:match('^you%s+cast%s+([^.]+)')
    end
    if not spell then return nil end

    return normalize_action_name(spell)
end

local function is_player_cast_interrupted_exact(state, text)
    if type(text) ~= 'string' then return false end

    local sl = sanitize_log_text(text):lower()

    if sl == 'your casting is interrupted.' or sl == 'your casting is interrupted' then
        return true
    end

    if state.cached_player_pat then
        if sl == (state.cached_player_pat .. "'s casting is interrupted.") then return true end
        if sl == (state.cached_player_pat .. "'s casting is interrupted") then return true end
    end

    if state.cached_player_name then
        local lower_name = sanitize_log_text(state.cached_player_name):lower()
        if sl == (lower_name .. "'s casting is interrupted.") then return true end
        if sl == (lower_name .. "'s casting is interrupted") then return true end
    end

    return false
end

local function is_lacks_ninja_tools(state, text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return line_is_you_or_player(state, sl) and sl:find('lacks the ninja tools to cast', 1, true) ~= nil
end

local function is_unable_cast_spells_time(text)
    return type(text) == 'string'
       and sanitize_log_text(text):lower():find('unable to cast spells at this time', 1, true) ~= nil
end

local function is_no_ranged_weapon_line(state, text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return line_is_you_or_player(state, sl) and sl:find('do not have an appropriate ranged weapon equipped', 1, true) ~= nil
end

local function is_ranged_interrupted_line(state, text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return line_is_you_or_player(state, sl) and sl:find('ranged attack', 1, true) ~= nil
        and sl:find('interrupt', 1, true) ~= nil
end

-- "Unable to use weapon skill." -- the server rejected our /ws outright. No
-- name in the line, so there's nothing to match against the attempted WS;
-- the line is self-addressed (it only ever appears for our own failed WS)
-- and needs no line_is_you_or_player check.
local function is_unable_ws_line(text)
    return type(text) == 'string'
       and sanitize_log_text(text):lower():find('unable to use weapon skill', 1, true) ~= nil
end

-- Server refusals when the target is beyond a command's range. FFXI uses a
-- couple of variants depending on the command:
--   "That target is too far away."     -- /attack out of melee reach
--   "That target is out of range."     -- /ra beyond /ra range
--   "Target is out of range."          -- occasional variant
-- All three collapse to "we need to close distance and try again."
local function is_too_far_line(text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    if sl:find('too far away',  1, true) ~= nil then return true end
    if sl:find('out of range',  1, true) ~= nil then return true end
    return false
end

-- Line-of-sight failure. FFXI emits TWO different strings for this and we
-- need both:
--   "Unable to see <target>."        -- action/spell attempt
--   "You cannot see the <target>."   -- ranged attempt (this is the one a
--                                       Sleep Bolt at an off-target mob
--                                       through a wall produces)
-- Only the first was matched, so an LoS-blocked ranged shot set no flag at
-- all and any "give up on that mob" logic could never fire.
-- "<player> cannot perform that action." On HorizonXI this is line of sight,
-- confirmed in play. The server will not say why, and no amount of retrying
-- from the same spot changes the geometry.
local function is_cannot_perform_action_line(state, text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return line_is_you_or_player(state, sl)
        and sl:find('cannot perform that action', 1, true) ~= nil
end

local function is_unable_to_see_line(text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    if sl:match('^unable to see%s+.+$') ~= nil then return true end
    if sl:match('^you cannot see%s+.+$') ~= nil then return true end
    return false
end

local function is_cannot_attack_target_line(text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return sl == 'you cannot attack that target.' or sl == 'you cannot attack that target'
end

-- Pet/wyvern name lookup. Reads our own entity's PetTargetIndex,
-- then the entity at that index. Returns nil if no pet or name
-- unavailable. Called per chat-line; cheap. Don't cache -- pet is
-- (un)called dynamically and re-summons get fresh names.
local function get_my_wyvern_name()
    local me = get_entity(0)
    if not me then return nil end
    local pet_idx = tonumber(me.PetTargetIndex or 0) or 0
    if pet_idx == 0 then return nil end
    local pet = get_entity(pet_idx)
    if not pet then return nil end
    local name = pet.Name
    if type(name) ~= 'string' or name == '' then return nil end
    return name
end

-- Wyvern HB chat-line. Format on FFXI / HorizonXI:
--   "<Wyvern_Name> readies Healing Breath."        (cast prep)
--   "<Wyvern_Name> readies Healing Breath II/III/IV."
--   "<Wyvern_Name> uses Healing Breath."           (actual fire)
--   "<Wyvern_Name> uses Healing Breath II/III/IV."
-- Match BOTH verbs. "readies" arrives before "uses" -- catching it
-- clears the safety timeout sooner so the bot can chain the next
-- trigger as the wyvern is winding up rather than after it lands.
-- We MUST match our own wyvern's name -- other DRGs' wyverns will
-- produce the same chat-line pattern and would false-trigger
-- HB-ready on our side.
local function is_my_wyvern_hb_line(text)
    if type(text) ~= 'string' then return false end
    local name = get_my_wyvern_name()
    if not name then return false end

    local sl = sanitize_log_text(text):lower()
    local name_pat = name:lower():gsub('([^%w%s])', '%%%1')
    return sl:match('^' .. name_pat .. '%s+readies%s+healing%s+breath') ~= nil
        or sl:match('^' .. name_pat .. '%s+uses%s+healing%s+breath')    ~= nil
end

local function is_spell_resisted_line(text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return sl:match('^.+%s+resists%s+the%s+spell%.?$') ~= nil
end

local function parse_effect_wears_off_name(text)
    if type(text) ~= 'string' then return nil end
    local sl = sanitize_log_text(text):lower()

    local effect = sl:match("^.+%'s%s+(.+)%s+effect%s+wears%s+off%.?$")
    if not effect then return nil end

    return normalize_action_name(effect)
end

local function suppress_engage_retry(state, current_time, sec)
    state.idle_rest_engage = state.idle_rest_engage or {}
    local cur = tonumber(state.idle_rest_engage.engage_retry_until or 0.0) or 0.0
    local nextt = (tonumber(current_time or 0.0) or 0.0) + (tonumber(sec or 1.0) or 1.0)
    if nextt > cur then
        state.idle_rest_engage.engage_retry_until = nextt
    end
end

local function parse_player_uses_action_name(state, text)
    if type(text) ~= 'string' then return nil end

    local sl = sanitize_log_text(text):lower()
    local action = nil

    if state.cached_player_pat then
        action = sl:match('^' .. state.cached_player_pat .. '%s+uses%s+(.+)$')
    end
    if not action then
        action = sl:match('^you%s+use%s+(.+)$')
    end
    if not action then
        return nil
    end

    return normalize_action_name(action)
end

local function is_unable_to_use_job_ability(text)
    if type(text) ~= 'string' then return false end
    local sl = sanitize_log_text(text):lower()
    return sl:find('unable to use job ability', 1, true) ~= nil
end

local function parse_time_left_seconds(text)
    if type(text) ~= 'string' then return nil end
    local sl = sanitize_log_text(text):lower()

    local h, m, s = sl:match('time%s+left:%s*%((%d+):(%d+):(%d+)%)')
    if not h then return nil end

    h = tonumber(h or 0) or 0
    m = tonumber(m or 0) or 0
    s = tonumber(s or 0) or 0

    return (h * 3600) + (m * 60) + s
end

local function clear_attempted_debuff_for_retry(state)
    local MM = main_magic_helper()
    local attempted_id = state.combat.last_attempted_action_id
    local attempted_name = state.combat.last_attempted_action_name

    MM.mob_debuff_resisted(state, attempted_id or attempted_name)
    MM.mob_debuff_wore_off(state, attempted_id or attempted_name)
end

local function spell_name_is_hb_trigger(spell_name)
    if type(spell_name) ~= 'string' or #spell_name == 0 then return false end
    local list = rawget(_G, 'Hb_list')
    if type(list) ~= 'table' then return false end
    local want = spell_name:lower()
    for i = 1, #list do
        local ent = list[i]
        if type(ent) == 'table' and type(ent.name) == 'string'
           and ent.name:lower() == want then
            return true
        end
    end
    return false
end

local function spell_lock_start(state, spell_name)
    -- Arm the HB safety timeout ONLY when the spell that started
    -- casting is actually one of the wyvern HB trigger spells. Arming
    -- it for every spell (e.g. a manual or laddered Cure) would block
    -- auto-HB for the full safety window after unrelated casts.
    if spell_name_is_hb_trigger(spell_name) then
        local HbS = hb_shadows_helper()
        if HbS and type(HbS.notify_hb_cast) == 'function' then
            HbS.notify_hb_cast(state)
        end
    end

    local G = general_lua()
    if G and G.runtime and type(G.runtime.spell_lock_start) == 'function' then
        G.runtime.spell_lock_start(state, spell_name)
        return
    end

    state.combat.spell_locked = true
    state.combat.active_started_spell = spell_name
    state.combat.spell_started_at = now_sec()
    state.combat.is_casting = true
    state.combat.current_spell = spell_name
    state.combat.cast_timeout_at = now_sec() + 4.0
    state.combat.spell_lock_until = now_sec() + 4.0
end

local function spell_lock_clear(state)
    local G = general_lua()
    if G and G.runtime and type(G.runtime.spell_lock_clear) == 'function' then
        G.runtime.spell_lock_clear(state)
        return
    end

    state.combat.spell_locked = false
    state.combat.active_started_spell = nil
    state.combat.spell_started_at = 0.0
    state.combat.is_casting = false
    state.combat.current_spell = nil
    state.combat.cast_timeout_at = 0.0
    state.combat.spell_lock_until = 0.0
end

local function spell_confirm(state, spell_name, current_time)
    local G = general_lua()
    if G and G.runtime and type(G.runtime.spell_confirm) == 'function' then
        G.runtime.spell_confirm(state, spell_name)
    else
        spell_lock_clear(state)
    end

    state.combat.last_confirmed_action_name = spell_name
    state.combat.last_confirmed_action_at = current_time

    local attempted_id = state.combat.last_attempted_action_id
    local attempted_kind = state.combat.last_attempted_action_kind
    local attempted_at = tonumber(state.combat.last_attempted_action_at or 0.0) or 0.0

    if attempted_kind == 'spell' and attempted_id and (current_time - attempted_at) <= 8.0 then
        if state.cooldown_id_map and state.cooldown_id_map[attempted_id] ~= nil then
            local cd = tonumber(state.cooldown_id_map[attempted_id] or 0) or 0
            local G2 = general_lua()
            if cd > 0 and G2 and G2.cooldowns and G2.cooldowns.set then
                G2.cooldowns.set(attempted_id, cd)
            end
        end
    end

    -- Do NOT call notify_hb_cast here. The HB safety timeout is armed
    -- once, at cast-start, by spell_lock_start (driven by the game's
    -- "starts casting" line). Re-arming it on confirm would slam a
    -- fresh 12s window down right when the trigger has just landed,
    -- which would then clobber the 1.5s real recast that
    -- notify_hb_actually_fired sets when the wyvern's HB is detected --
    -- i.e. it would make every HB chain wait the full safety timeout
    -- instead of the wyvern's actual recast. That was a primary cause
    -- of "HB feels sluggish / not chaining like before".
end

-- External entry point. Exposed so packet_parser's action-packet
-- completion path can drive the same confirm bookkeeping (cooldown
-- set, HB notify, last_confirmed_*) without duplicating logic.
-- Same gate the local spell_confirm uses, just callable from outside
-- the on_text_in handler.
--
-- method:
--   nil / 'log'    - chat-line "X casts Y" arrived. spell_lock_until
--                    is left at whatever spell_confirm sets (0 via
--                    spell_lock_clear) because chat-line arrives
--                    AFTER the server's post-bar finish window has
--                    already released the slot. Safe to clear.
--   'action'       - action-packet finish arrived early, typically
--                    ~0.5s past bar fill. The server slot is STILL
--                    LOCKED through the post-bar finish phase (~3-5s
--                    on HorizonXI). If we let spell_lock_clear zero
--                    spell_lock_until, the cascade will queue the
--                    next /ma into the still-locked slot and eat a
--                    UTC. So we capture the existing spell_lock_until
--                    (set by spell_lock_start to cover the full
--                    cast_time + ANIMATION_END_SEC + slack window)
--                    and restore it after the clear. is_casting
--                    still goes false -- the cast is logically done,
--                    just slot-busy for a few more seconds.
function TextParser.confirm_player_spell(state, spell_name, current_time, method)
    state.combat = state.combat or {}

    local preserved_lock = nil
    if method == 'action' then
        preserved_lock = tonumber(state.combat.spell_lock_until or 0) or 0
        if preserved_lock <= 0 then preserved_lock = nil end
    end

    spell_confirm(state, spell_name, current_time or now_sec())

    if preserved_lock ~= nil then
        local current_lock = tonumber(state.combat.spell_lock_until or 0) or 0
        if preserved_lock > current_lock then
            state.combat.spell_lock_until = preserved_lock
        end
    end

    -- Diagnostic: stamp elapsed + completion method to casttimes.txt.
    local ok, CastLog = pcall(require, 'cast_log')
    if ok and CastLog and type(CastLog.confirmed) == 'function' then
        CastLog.confirmed(spell_name, current_time or now_sec(), method or 'log')
    end
end

local function spell_interrupt(state, reason)
    -- Clear the HB safety lock silently. If the interrupted spell was
    -- an HB trigger, notify_hb_cast had already armed the safety
    -- timeout at "starts casting" -- leaving it armed would fire a
    -- false "HB not detected" error a few seconds later for a cast
    -- that was actually interrupted by damage / silence / stun / etc.
    -- No-op if safety wasn't armed (regular non-HB-trigger interrupt).
    local HbS = hb_shadows_helper()
    local interrupted_spell = state.combat and state.combat.current_spell
    if HbS and type(HbS.notify_hb_cast_interrupted) == 'function' then
        HbS.notify_hb_cast_interrupted(state)
    end

    -- Diagnostic: stamp failure to casttimes.txt before clearing
    -- state. Best-effort; silent if module missing.
    if type(interrupted_spell) == 'string' and #interrupted_spell > 0 then
        local ok, CastLog = pcall(require, 'cast_log')
        if ok and CastLog and type(CastLog.failed) == 'function' then
            CastLog.failed(interrupted_spell, now_sec(), reason or 'interrupted')
        end
    end

    local G = general_lua()
    if G and G.runtime and type(G.runtime.spell_interrupt) == 'function' then
        G.runtime.spell_interrupt(state)
        return
    end

    spell_lock_clear(state)
end

function TextParser.on_text_in(args)
    local event = args.event
    local state = args.state
    local current_time = args.current_time or now_sec()

    state.combat = state.combat or {}
    state.flags = state.flags or {}
    state.last_action_ts = state.last_action_ts or {}
    state.debug = state.debug or {}

    state.combat.awaiting_job_ability_timeleft = state.combat.awaiting_job_ability_timeleft or nil

    local text = get_event_text(event)
    if not text then return end

    local clean_text = sanitize_log_text(text)

    do
        local G = general_lua()
        if G and G.runtime and type(G.runtime.finish_zoning) == 'function' then
            if clean_text:find('===', 1, true) ~= nil then
                G.runtime.finish_zoning(state, current_time)
            end
        end
    end

    state.debug.last_log_line = clean_text

    if is_no_ranged_weapon_line(state, clean_text) then
        state.flags.player_ranged_no_weapon = true
        local G = general_lua()
        if G and G.runtime and type(G.runtime.mark_tool_missing) == 'function' then
            G.runtime.mark_tool_missing(state, 'Ranged Weapon')
        end
    end

    -- Sneak Attack use (text fallback for the packet detection). Stamp the 60s
    -- CD when we see "<you> uses Sneak Attack".
    do
        local sl = sanitize_log_text(clean_text):lower()
        if line_is_you_or_player(state, sl)
           and sl:find('uses', 1, true) ~= nil
           and sl:find('sneak attack', 1, true) ~= nil then
            local G = general_lua()
            if G and G.cooldowns and type(G.cooldowns.set) == 'function' then
                G.cooldowns.set('SNEAK_ATTACK', 60.0)
            end
        end
    end

    -- RA-skill: an interrupted ranged shot produces no action packet, so the
    -- packet-based resolve stamp never fires. Catch the interrupt chat-line
    -- here so the loop can refire.
    if is_ranged_interrupted_line(state, clean_text) then
        state.combat.ranged_resolved_at = current_time
    end

    -- Rejected weapon skill. ctx.do_ws treats a successful DISPATCH as a
    -- successful WS: it stamps last_attempted_action_kind='ws' (which arms
    -- the 2.5s ws_post_block_sec window), sets the WS cooldown, and
    -- drain_dispatch nils ws_slot on the way past. Nothing was watching for
    -- the refusal, so one rejected WS cost a full round even though the TP
    -- was never spent. Roll the bookkeeping back.
    --
    -- The cause is almost always the ranged recovery tail, so re-stamp
    -- ranged_resolved_at from NOW. That re-arms the existing post-resolve
    -- gate (ranged_ws_locked) for another full tail measured from the
    -- refusal, which is exactly "wait it out, then retry" with no new state.
    -- ranged_cd_set is already true by this point so the RANGED cooldown is
    -- not re-armed. If the refusal was actually a TP desync instead, holding
    -- for one more tail costs nothing.
    if is_unable_ws_line(clean_text) then
        if state.combat.last_attempted_action_kind == 'ws' then
            state.combat.last_attempted_action_kind = nil
            state.combat.last_attempted_action_at   = 0.0
        end
        local G = general_lua()
        if G and G.cooldowns and type(G.cooldowns.set) == 'function' then
            G.cooldowns.set('WS', 0.0)
        end

        -- Pair the refusal with the ra_delta measured when the /ws went out
        -- (see the wsra block in general.lua). Only trust the stash if the
        -- attempt is recent -- a refusal with no fresh FIRE behind it gets
        -- logged as stale rather than reusing an old number and lying about
        -- where the floor is. Debug-gated inside wsra_log.
        if G and G.utils and type(G.utils.wsra_log) == 'function' then
            local at    = tonumber(state.combat.wsra_last_at or 0) or 0
            local fresh = (at > 0) and ((current_time - at) <= 5.0)
            local d     = nil
            if fresh then d = tonumber(state.combat.wsra_last_delta) end
            local fmt = (type(G.utils.wsra_fmt) == 'function')
                and G.utils.wsra_fmt
                or function(v) return (v and string.format('%6.2f', v)) or ' --.--' end
            G.utils.wsra_log(state, string.format(
                'REJECT  ra_delta=%s  ra=%-8s ws=%-22s server refused',
                fmt(d),
                (fresh and tostring(state.combat.wsra_last_state or '?') or 'stale'),
                (fresh and tostring(state.combat.wsra_last_ws or '?') or '?')))
        end

        if (tonumber(state.combat.ranged_fired_at or 0) or 0) > 0 then
            state.combat.ranged_resolved_at = current_time
        end
    end

    if is_cannot_attack_target_line(clean_text) then
        -- WORMS BURROW.
        --
        -- "You cannot attack that target." from a worm does not mean the
        -- target is bad. It means the thing is underground for a moment and
        -- the client still shows it as targetable, so the engage retry comes
        -- straight back round and gets the same answer -- that is the wall of
        -- identical yellow lines.
        --
        -- The generic 1s is tuned for a genuinely wrong target, where coming
        -- back quickly is right. A submerged worm needs longer than that, so
        -- give it 2s and let it surface.
        --
        -- Everything else keeps the 1s. This deliberately does not raise the
        -- floor for all targets: a real bad-target case wants the fast retry.
        local sid = tonumber(state.live and state.live.player_target_server_id or 0) or 0

        -- REPEAT COUNTER, per target, rolling window. This is what stops the
        -- worm grace from being a permanent exemption. Reset when the sid
        -- changes or the window lapses, so a worm that legitimately burrows
        -- once every fight never accumulates.
        local c = state.combat
        if (tonumber(c.ca_streak_sid or 0) or 0) ~= sid
            or (current_time - (tonumber(c.ca_streak_at or 0) or 0)) > CANNOT_ATTACK_WINDOW_SEC
        then
            c.ca_streak_sid = sid
            c.ca_streak_at  = current_time
            c.ca_streak_n   = 0
        end
        c.ca_streak_n = (tonumber(c.ca_streak_n or 0) or 0) + 1

        -- WORMS BURROW -- BUT ONLY LIVE ONES.
        --
        -- The grace exists because a submerged worm comes back up on its own,
        -- so dropping it would be throwing away a perfectly good mob. Two
        -- ways that stops being true, and MISSING BOTH is what left the bot
        -- hammering a Stone Eater corpse:
        --
        --   1. The worm is DEAD. We just killed it, the client still has it
        --      targeted, and it is never going to be attackable again. HP of
        --      0 (or unreadable) is not something to wait out.
        --   2. It has refused CANNOT_ATTACK_MAX_TRIES times. Burrowing lasts
        --      seconds; a third refusal in the window means something else is
        --      wrong and waiting is not going to fix it.
        local thp = tonumber(state.live and state.live.player_target_hp)
        local target_alive = (thp ~= nil and thp > 0)

        local is_worm = (WormList ~= nil)
            and WormList.is_worm(state.live and state.live.player_target_name)

        local worm_grace = is_worm
            and target_alive
            and (c.ca_streak_n < CANNOT_ATTACK_MAX_TRIES)

        suppress_engage_retry(state, current_time,
            worm_grace and WORM_CANNOT_ATTACK_SEC or 1.0)

        -- GIVE UP ON IT.
        --
        -- Everything that is not a live worm inside its grace lands here: a
        -- corpse, a pet, a wrong entity type, an out-of-instance mob, or a
        -- worm that has had its chances. Retrying any of those forever is the
        -- wall of yellow text.
        --
        -- Raise a flag with the sid rather than acting here. This file runs
        -- inside the text event and has no business sending 0x058 packets or
        -- reasoning about the blacklist -- tick_auto_target owns targeting,
        -- and it consumes this on the next tick. Same shape as the
        -- target_too_far flag above.
        if not worm_grace then
            state.flags = state.flags or {}
            state.flags.cannot_attack_target = true
            state.flags.cannot_attack_sid    = sid
            -- Streak is spent: the drop is happening, so the next refusal
            -- (different mob, or this one after the blacklist lapses) starts
            -- from a clean count.
            c.ca_streak_sid = 0
            c.ca_streak_at  = 0.0
            c.ca_streak_n   = 0
        end
    end

    -- LINE OF SIGHT. Blacklist the mob and move on.
    --
    -- Without this the only thing that noticed a failed pull was the 15s
    -- stale-lock watchdog in tick_auto_target, so every LOS mob cost a full
    -- 15 seconds of standing still before the bot even started looking
    -- elsewhere. We know the pull is dead the moment this line arrives.
    --
    -- Reuses the cannot_attack flag deliberately: the consumer's response is
    -- exactly what we want here too (blacklist 30s, break the lock, repick),
    -- and a second flag doing the identical thing is a second thing to keep
    -- in sync. Its own strike counter though -- the thresholds differ.
    if is_cannot_perform_action_line(state, clean_text) then
        local sid = tonumber(state.live and state.live.player_target_server_id or 0) or 0
        local c = state.combat

        if (tonumber(c.los_streak_sid or 0) or 0) ~= sid
            or (current_time - (tonumber(c.los_streak_at or 0) or 0)) > CANNOT_ATTACK_WINDOW_SEC
        then
            c.los_streak_sid = sid
            c.los_streak_at  = current_time
            c.los_streak_n   = 0
        end
        c.los_streak_n = (tonumber(c.los_streak_n or 0) or 0) + 1

        if sid ~= 0 and c.los_streak_n >= LOS_MAX_TRIES then
            state.flags = state.flags or {}
            state.flags.cannot_attack_target = true
            state.flags.cannot_attack_sid    = sid
            c.los_streak_sid = 0
            c.los_streak_at  = 0.0
            c.los_streak_n   = 0
        end
    end

    if is_unable_cast_spells_time(clean_text) then
        spell_interrupt(state, 'utc')

        -- UTC backoff escalation (ban-risk guard). Previously a flat
        -- 1.0s extra lockout regardless of how often UTC was firing.
        -- That fails the case where something keeps failing (silenced,
        -- amnesia'd, server slot wedged, cooldown desync) -- the bot
        -- would retry every ~1s indefinitely, pinging the server with
        -- /ma until the underlying state cleared. Escalating backoff
        -- on repeat UTCs caps the spam rate.
        --
        -- Window: rolling 30s. Per-spell granularity skipped because
        -- the actual MN UTC scenarios (silence/amnesia, server slot
        -- busy after a long cast, full cooldown system desync) all
        -- fail every spell -- global is the right shape here.
        state.combat.utc_tracking = state.combat.utc_tracking or { events = {} }
        local events = state.combat.utc_tracking.events
        table.insert(events, current_time)
        local window_start = current_time - 30.0
        while events[1] ~= nil and events[1] < window_start do
            table.remove(events, 1)
        end

        local backoff = 1.0
        if #events >= 5 then
            backoff = 15.0
        elseif #events >= 3 then
            backoff = 5.0
        end

        local new_lock = current_time + backoff
        local existing = tonumber(state.combat.spell_lock_until or 0) or 0
        if new_lock > existing then
            state.combat.spell_lock_until = new_lock
        end

        clear_attempted_debuff_for_retry(state)
    end

    if is_lacks_ninja_tools(state, clean_text) then
        state.flags.player_utsu_tools_out = true
        local G = general_lua()
        if G and G.runtime and type(G.runtime.mark_tool_missing) == 'function' then
            G.runtime.mark_tool_missing(state, 'Shihei')
        end
        spell_interrupt(state, 'no_tools')
        clear_attempted_debuff_for_retry(state)
    end

    -- Wyvern HB chat-line. Source-of-truth detection of our wyvern
    -- actually firing Healing Breath. Fires the HB-ready gate release
    -- in hb_shadows_helper, replacing the safety timeout that
    -- notify_hb_cast set at trigger-spell send time. The packet path
    -- in packet_parser also fires this for known HB IDs (faster by
    -- ~0.5s), but this chat-line path is the fallback that catches
    -- HBs whose IDs aren't in WYVERN_HB_IDS yet. Both calling the
    -- same notify is fine -- the gate set is idempotent.
    if is_my_wyvern_hb_line(clean_text) then
        local HbS = hb_shadows_helper()
        if HbS and type(HbS.notify_hb_actually_fired) == 'function' then
            HbS.notify_hb_actually_fired(state, 'log')
        end
    end

    local start_cast_name = parse_player_starts_casting_name(state, clean_text)
    if start_cast_name ~= nil then
        -- This is the authoritative point at which a cast is known to
        -- have been ACCEPTED by the game, and it is where the spell
        -- lock + HB safety timeout get armed (spell_lock_start ->
        -- notify_hb_cast).
        --
        -- The `is_casting ~= true` guard: regular spell casts
        -- (ctx.do_spell: cure/dia/enspells/etc.) still set is_casting
        -- at their own /ma dispatch with an accurate spell_started_at,
        -- so for those this handler must stay a no-op -- otherwise it
        -- would reset spell_started_at to chat-line arrival time
        -- (~0.5-1.0s late) and throw off per-spell timeout sizing and
        -- the action-packet completion gate's elapsed check.
        --
        -- HB casts (ctx.do_hb) deliberately do NOT pre-set is_casting,
        -- so for HB this branch DOES fire and is the sole arming point
        -- -- which is exactly what we want: HB state only commits to
        -- casts the game actually accepted. Manual /ma the user types
        -- while the bot tracks nothing (is_casting==false) also locks
        -- the bot out here for the cast duration.
        if state.combat.is_casting ~= true then
            spell_lock_start(state, start_cast_name)
        end
    end

    if is_player_cast_interrupted_exact(state, clean_text) then
        spell_interrupt(state, 'interrupted')
        clear_attempted_debuff_for_retry(state)
    end

    local casts_name = parse_player_casts_name(state, clean_text)
    if casts_name ~= nil then
        -- Chat-line gate. With the action-packet completion path in
        -- packet_parser.lua, the "X casts Y" line for cast A typically
        -- arrives 3-5s after we've already processed A's action packet
        -- (which set is_casting=false). If we ran spell_confirm here
        -- unconditionally, it would:
        --   1. Clobber any in-flight cast B's lock (spell_lock_clear)
        --   2. Double-set the cooldown for A
        --   3. Notify HB a second time about A
        -- All three are wrong. So skip spell_confirm if:
        --   (a) we're not currently casting -- the action path already
        --       handled this cast and nothing new is in flight; OR
        --   (b) we ARE casting but elapsed on the CURRENT cast is
        --       below its cast_time -- the chat-line must be for a
        --       prior cast (a new cast just started; the chat-line
        --       can't yet be for it because the bar hasn't filled).
        -- mob_debuff_confirm still runs unconditionally below: the
        -- chat-line is genuine (just late), the debuff did land, and
        -- the debuff bookkeeping is target-stamped independently.
        -- The "X casts Y" line is the game reporting a cast COMPLETED.
        -- This gate exists only to reject a stale line for a PRIOR cast
        -- bleeding into a newly-started one (the action-packet path
        -- usually confirms first, then the chat-line arrives 3-5s later).
        --
        -- Two ways the line is genuinely ours:
        --   * it names the spell we have in flight (active_started_spell),
        --     in which case it's our completion regardless of elapsed; OR
        --   * enough of the cast bar has elapsed that the line can't be
        --     for a cast that started after ours.
        --
        -- The elapsed floor is a FRACTION of cast_time, not the full
        -- value. Haste / fast-cast / Refresh-style fast buffs complete
        -- well before the table's base cast time, and the table holds
        -- BASE times -- so gating at 100% rejected legitimate completions
        -- (a manual Refresh fired its "casts" line at ~2.2s against a 5.0
        -- table value, tripped can_confirm=false, and then spuriously
        -- logged "not confirmed after 20s"). 40% clears haste/fast-cast
        -- while still rejecting a line for a brand-new cast whose bar
        -- physically can't have filled yet.
        local can_confirm = (state.combat.is_casting == true)
        if can_confirm then
            local started_name = normalize_action_name(state.combat.active_started_spell)
            local names_match  = (started_name ~= nil and started_name == casts_name)

            if not names_match then
                local started_at = tonumber(state.combat.spell_started_at or 0) or 0
                local cast_time  = tonumber(state.combat.cast_time_sec or 4.0) or 4.0
                local elapsed    = (current_time or now_sec()) - started_at
                if elapsed < (cast_time * 0.40) then
                    can_confirm = false
                end
            end
        end

        if can_confirm then
            -- Route through the public entry point so cast_log gets
            -- via='log' on chat-line completions alongside via='action'
            -- on packet completions. Behavior is identical to the
            -- local spell_confirm call for method != 'action'.
            TextParser.confirm_player_spell(state, casts_name, current_time, 'log')
        end

        local MM = main_magic_helper()
        MM.mob_debuff_confirm(state, casts_name)

        -- Unconditional last-cast recording. The 'X casts Y' line is a
        -- genuine completed self-cast (bot, manual, or menu), so record
        -- Protect/Shell/Utsusemi here regardless of the can_confirm gate
        -- above (which only guards lock/cooldown bookkeeping). This is what
        -- makes menu/manual casts show up in the debug panel and feed the
        -- Pro/Shell upgrade gate.
        do
            local G = general_lua()
            if G and G.runtime and type(G.runtime.record_cast) == 'function' then
                G.runtime.record_cast(state, casts_name)
            end
        end
    end

    if is_spell_resisted_line(clean_text) then
        local attempted_kind = state.combat.last_attempted_action_kind
        local attempted_at = tonumber(state.combat.last_attempted_action_at or 0.0) or 0.0

        if attempted_kind == 'spell' and (current_time - attempted_at) <= 8.0 then
            clear_attempted_debuff_for_retry(state)
        end
    end

    do
        local wore_off_name = parse_effect_wears_off_name(clean_text)
        if wore_off_name ~= nil then
            local MM = main_magic_helper()
            MM.mob_debuff_wore_off(state, wore_off_name)
        end
    end

    local used_action_name = parse_player_uses_action_name(state, clean_text)
    if used_action_name ~= nil then
        state.combat.last_confirmed_action_name = used_action_name
        state.combat.last_confirmed_action_at = current_time

        if state.cooldown_action_name_map then
            local map_entry = state.cooldown_action_name_map[used_action_name]
            if map_entry and map_entry.id then
                local cd = tonumber(map_entry.cooldown_sec or 0) or 0
                local G = general_lua()
                if cd > 0 and G and G.cooldowns and G.cooldowns.set then
                    G.cooldowns.set(map_entry.id, cd)
                end
            end
        end
    end

    if is_unable_to_use_job_ability(clean_text) then
        local attempted_id = state.combat.last_attempted_action_id
        local attempted_at = tonumber(state.combat.last_attempted_action_at or 0.0) or 0.0

        if attempted_id and (current_time - attempted_at) <= 3.0 then
            state.combat.awaiting_job_ability_timeleft = attempted_id
        else
            state.combat.awaiting_job_ability_timeleft = nil
        end
    end

    do
        local remaining_sec = parse_time_left_seconds(clean_text)
        local pending_id = state.combat.awaiting_job_ability_timeleft

        if remaining_sec ~= nil and pending_id ~= nil and state.cooldown_id_map and state.cooldown_id_map[pending_id] ~= nil then
            local max_cd = tonumber(state.cooldown_id_map[pending_id] or remaining_sec) or remaining_sec
            local G = general_lua()
            if G and G.cooldowns and G.cooldowns.sync_remaining then
                G.cooldowns.sync_remaining(pending_id, remaining_sec, max_cd)
            end
            state.combat.awaiting_job_ability_timeleft = nil
        end
    end

    local engaged_now = tonumber(player_status() or 0) == 1

    -- Burst suppression: within atk_burst_window_sec of the last atk line,
    -- treat subsequent lines as the same round (Double/Triple Attack, Haste
    -- tight rounds, etc.). Don't bump the timestamp or the round seq or the
    -- display resets on every sub-hit. Same for def.
    local burst = 0.35
    do
        local G = general_lua()
        if G and G.timing and G.timing.atk_burst_window_sec then
            burst = tonumber(G.timing.atk_burst_window_sec) or 0.35
        end
    end

    if engaged_now and is_player_attack_line(state, clean_text) then
        local last = tonumber(state.combat.last_attack_ts or 0) or 0
        if (current_time - last) >= burst then
            state.combat.last_attack_ts = current_time
            state.combat.atk_round_seq = (state.combat.atk_round_seq or 0) + 1
        end
    end

    if engaged_now and is_enemy_attack_you_line(state, clean_text) then
        local last = tonumber(state.combat.last_defence_ts or 0) or 0
        if (current_time - last) >= burst then
            state.combat.last_defence_ts = current_time
            state.combat.def_round_seq = (state.combat.def_round_seq or 0) + 1
        end
    end

    if is_unable_to_see_line(clean_text) then
        state.flags.player_cannot_see_target = true

        if state.ui and state.ui.debug_enabled == true then
            AshitaCore:GetChatManager():QueueCommand(1, '/echo [MN] unable to see detected')
        end
    end

    -- "Target is out of range" / "too far away" -- pull needs to re-chase.
    -- Consumed and cleared by tick_auto_pull: it re-arms the current
    -- target and lets the chase-to-range block kick back in.
    if is_too_far_line(clean_text) then
        state.flags.target_too_far = true

        -- Engaged out-of-range watchdog counter. Every "out of range" /
        -- "too far away" line that arrives WHILE we're engaged means our
        -- auto-swing timer just fired at a mob we can't reach -- either
        -- it teleported, was killed by someone else and our target
        -- flipped elsewhere, or LoS/pathing is broken. Consumed by the
        -- watchdog tick in idle_rest_engage: 3 hits -> disengage +
        -- blacklist + self-target so auto-target picks a fresh mob.
        if engaged_now then
            state.combat.oor_swing_count =
                (tonumber(state.combat.oor_swing_count or 0) or 0) + 1
        end

        if state.ui and state.ui.debug_enabled == true then
            AshitaCore:GetChatManager():QueueCommand(1, '/echo [MN] target too far detected')
        end
    end
end

return TextParser