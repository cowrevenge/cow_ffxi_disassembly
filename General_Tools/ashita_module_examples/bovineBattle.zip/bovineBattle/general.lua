--[[---------------------------------------------------------------------------
general.lua

Purpose
  Core shared gameplay systems for Bovine Battle.

Owns
  - minimal player / target reads needed by runtime
  - pet presence / pet hp via player entity pet target index
  - effective job / level info
  - cooldown tracking
  - runtime ladder context builder
  - runtime live-state refresh
  - runtime dispatch / gate handling
  - runtime ladder session ticking
  - command event handling for debug / show / hide
  - zoning pause flow:
      * detect status=nil
      * pause 5 seconds
      * then wait for === log text
  - ladder step timing:
      * JA / WS / Ranged use fixed post-send hold
      * spells use tiny post-send hold, then wait on cast state / spell lock

Delegates
  - packet parsing      => packet_parser.lua
  - text parsing        => text_parser.lua
  - shadows / HB logic  => hb_shadows_helper.lua
  - magic helpers       => main_magic_helper.lua

Command ownership
  - general.lua does NOT write to client directly
  - main.lua owns the real send_cmd pipe
---------------------------------------------------------------------------]]--

require('common')
require('helpers')

local HbShadows    = require('hb_shadows_helper')
local TextParser   = require('text_parser')
local PacketParser = require('packet_parser')
local MainMagic    = require('main_magic_helper')
local bit          = require('bit')
local WeaponDB     = require('weapon_db')

-- Bloody Bolt (HP drain) hysteresis band, in HP%.
-- Engage at the configured threshold, release only once HP has climbed
-- this far above it. Without a band the mode chatters on/off at the
-- boundary because each drain tick lifts HP back over the line.
local HP_DRAIN_HYSTERESIS = 5



local GeneralLua = {
    _state_ref = nil,

    jobs = {
        WAR = 1,
        WHM = 3,
        BLM = 4,
        RDM = 5,
        PLD = 7,
        BRD = 10,
        NIN = 13,
        DRG = 14,
        BLU = 16,
    },

    status = {
        IDLE    = 0,
        ENGAGED = 1,
        DEAD1   = 2,
        DEAD2   = 3,
        RESTING = 33,
    },

    timing = {
        ws_post_block_sec              = 2.5,
        utsu_retry_sec                 = 0.5,

        -- action_step_hold_sec: per-tick wait after a JA / non-spell fires
        -- before the ladder is allowed to step again. Was 1.2s; +0.5s
        -- gives more spacing between consecutive JAs so dispatches don't
        -- land inside the game's ~1s JA-anti-spam window and get
        -- silently dropped ("humping" symptom).
        -- Kept as the legacy fallback only; the JA / def_JA / RA drain
        -- paths in drain_dispatch now consult instant_chain_gates below.
        action_step_hold_sec           = 1.7,

        -- instant_chain_gates: cascading wait between consecutive instant
        -- actions (JAs, items, ranged) drained out of ja_queue /
        -- def_ja_queue / ra_slot. gates[N] is the wait set AFTER the Nth
        -- back-to-back instant fires, before the (N+1)th may dispatch.
        -- Past #gates clamps to the last entry. Designed for openers
        -- like DRG "High Jump -> Jump -> Berserk -> Warcry -> WS" --
        -- the first interval is conservative (server warmup), later
        -- intervals tighten as the chain proves clean. Chain resets on
        -- WS / spell / disengage so the next combat opens at gates[1].
        --
        -- NOTE on humping: gates[2..] dip below the 1.0s JA anti-spam
        -- floor that drove action_step_hold_sec up to 1.7. If JAs start
        -- silently dropping mid-chain again, bump the inner gates up
        -- (e.g. {1.0, 0.8, 0.6, 0.5, 0.4}). The dispatch-level gate is
        -- aligned to the same cascade value at fire-time, so this
        -- single table controls both pacing layers.
        instant_chain_gates            = { 1.0, 0.4, 0.3, 0.3, 0.3 },

        -- After this many seconds of NO instant activity (ja_next_at
        -- elapsed AND both JA queues empty), reset the chain so the
        -- next instant starts fresh at gates[1]. Without this, a long
        -- lull between fires would let a "stale" chain count ride a
        -- shrunk gate when activity resumes.
        chain_idle_decay_sec           = 3.0,

        spell_post_hold_sec            = 0.5,
        atk_burst_window_sec           = 3.0,
        -- atk/def session timeouts: bumped from 4.0/3.0 -> 5.0/5.0 so a
        -- chain of 2 actions has room to land before the session ends.
        -- The hard case is a 2-spell def chain (e.g. Stoneskin 3s cast +
        -- 0.5s post-hold + Blink 1.5s cast); the cast portions pause the
        -- timeout (gated on spells_locked_soft), but the 0.5s post-hold
        -- bridges still count against it. At 3.0s the old def timeout
        -- fired exactly as Stoneskin finished, killing the second cast.
        -- 5.0s leaves comfortable headroom for the bridge + second cast.
        atk_session_timeout_sec        = 5.0,
        def_session_timeout_sec        = 5.0,

        zoning_wait_before_finish_sec  = 5.0,
    },

    cooldowns = {
        abilities = {},
    },

    utils   = {},
    actions = {},
    runtime = {},
    events  = {},
}

-- safe_send: route commands through the addon's send_cmd safety filter
-- (registered by bovinebattle at load). Defined UP HERE so it's visible when
-- the ladder table below closes over it. Falls back to a direct QueueCommand
-- if the filter isn't ready yet (boot-order glitch).
local function safe_send(cmd)
    local sc = GeneralLua.send_cmd
    if type(sc) == 'function' then
        return sc(cmd)
    end
    local ok, cm = pcall(function() return AshitaCore:GetChatManager() end)
    if ok and cm then
        pcall(function() cm:QueueCommand(1, cmd) end)
        return true
    end
    return false
end

GeneralLua.ladder = {

    {
        id='WS',
        kind='ws',
        priority=6500,
        gate_time=1.0,
        ui={
            { kind='checkbox', label='Auto Weaponskill', cfgkey='auto.ws', default=false },
            { kind='radio3',
              labelA='10%##ws', valA=10,
              labelB='25%##ws', valB=25,
              labelC='Any##ws', valC=0,
              cfgkey='ws_hp_mode',
              default=25
            },
            { kind='ws_name', cfgkey='ws_name', default='Double Thrust' },
            -- SC Open/Close controls live in bovinebattle's hand-built shell
            -- panel (render section with 'Auto WS'), NOT here -- this ui
            -- table isn't what the shell renders. cfg keys: auto.ws_sc_open, auto.ws_sc_close,
            -- ws_sc_partner.
        },
        eligible=function(ctx)
            if ctx.target_dead then return false end
            if not ctx.cfgget('auto.ws') then return false end
            -- Hold WS (Thief section) replaces Auto WS: when on, the WS
            -- fires from the TA+WS state machine in idle_rest_engage and
            -- this entry stays out of the way.
            if ctx.cfgget('thief.hold_ws') then return false end
            if ctx.engaged01 ~= 1 then return false end
            if ctx.spells_locked then return false end
            if ctx.ws_blocked then return false end
            -- /ra grants TP the instant it resolves, but the character is
            -- still in the ranged recovery animation and a WS attempt gets
            -- swallowed. ranged_busy stays true for RANGED_POST_RESOLVE_SEC
            -- past the resolve stamp -- gate on it so WS waits for the tail.
            --
            -- ranged_ws_busy is the same idea with the longer WS-only tail
            -- (RANGED_POST_RESOLVE_WS_SEC). The 1.0s grace was measured too
            -- short: the /ws went out ~0.5s inside the lock, ate an "Unable
            -- to use weapon skill.", and the failed attempt still armed the
            -- 2.5s ws_post_block so the round was gone.
            if ctx.ranged_busy or ctx.ranged_ws_busy then return false end
            if not (ctx.dist and ctx.dist <= 4) then return false end
            if (ctx.tp or 0) < 1000 then return false end
            -- SC Open/Close: when a role is enabled with a partner named,
            -- hold the WS until the partner can chain with us. See the
            -- ctx.sc_gate_active / sc_ws_allowed computation in build_ctx.
            if ctx.sc_gate_active and ctx.sc_ws_allowed ~= true then
                return false
            end
            return ctx.ws_hp_ok
        end,
        act=function(ctx)
            return ctx.do_ws()
        end,
    },

    {
        id='RANGED',
        kind='ra',
        priority=9800,
        gate_time=1.0,
        ui={
            { kind='ranged_control', label='Auto Ranged on Attack', cfgkey='auto.ranged', default=false },
        },
        eligible=function(ctx)
            if not ctx.cfgget('auto.ranged') then return false end
            if ctx.engaged01 ~= 1 then return false end
            if ctx.target_dead then return false end
            -- Same rule as the standoff loop: a mob auto-target has
            -- blacklisted is one we are done with, and that has to mean
            -- every shooter, not just the picker.
            if ctx.target_blacklisted == true then return false end
            if ctx.ranged_no_weapon then return false end
            -- Not a /ra job right now: no bow/xbow/gun equipped. A stat
            -- stick in the ammo slot is not a reason to shoot.
            if not ctx.ranged_weapon_ok then return false end
            -- WS steals the round when TP is up. Don't burn an atk event on
            -- /ra + a bolt swap the same tick the WS is going out.
            if ctx.cfgget('auto.ws') and (ctx.tp or 0) >= 1000 and ctx.ws_hp_ok then
                return false
            end
            if ctx.spells_locked then return false end
            local plan = ctx.ranged_plan()
            if plan == 'hold' or plan == 'none' then return false end
            return true
        end,
        act=function(ctx)
            local plan = ctx.ranged_plan()

            -- SLEEP OTHER: identical to any other bolt round -- swap ammo,
            -- then shoot. The ONLY difference is the shot goes at the other
            -- mob's server id instead of <t>. /ra can only ever hit <t>, so
            -- the shot itself is an action packet (Shoot 0x10) which names
            -- its target; nothing else about the round changes.
            if plan == 'sleep' then
                -- Same shape as every other bolt round: equip, then shoot.
                -- Only difference is the shot names the other mob's server
                -- id instead of <t>, because /ra can only ever hit <t>.
                local want = tostring(ctx.sleep_ammo_name or '')
                local ssid, _si, sname = ctx.sleep_other_target()
                if not ssid or want == '' then return end
                if not ctx.sleep_ammo_equipped then
                    safe_send('/equip ammo "' .. want .. '"')
                end
                safe_send(('/echo [MN] [sleep-other] %s -> %s sid %d'):format(
                    want, tostring(sname or '?'), ssid))
                -- No blacklist. If the shot fails LOS the game says
                -- "You cannot see the X", text_parser raises
                -- player_cannot_see_target, and the existing LOS handler in
                -- idle_rest_engage taps A to break the geometry -- same as
                -- every other system. We just try again next round.
                GeneralLua.utils.ranged_shot(ssid)
                -- NOTE: `state` and `now_sec` are NOT visible in this
                -- closure -- the ladder table is built above where they're
                -- declared as locals, so they resolved to nil globals and
                -- this line threw inside the pcall that wraps act(). The
                -- shot went out but ranged_fired_at was never stamped, so
                -- ranged_in_progress() was permanently false. GeneralLua is
                -- an upvalue here (declared before the ladder), and now_sec
                -- is just os.clock().
                local st = GeneralLua._state_ref
                if st and st.combat then
                    st.combat.ranged_fired_at = os.clock()
                end
                return
            end

            local bolt = nil
            if     plan == 'blood' and not ctx.blood_bolt_equipped then bolt = 'Bloody Bolt'
            elseif plan == 'acid'  and not ctx.acid_bolt_equipped  then bolt = 'Acid Bolt'
            elseif plan == 'blind' and not ctx.blind_bolt_equipped then bolt = 'Blind Bolt'
            end
            if bolt then
                safe_send('/equip ammo "' .. bolt .. '"')
            end
            safe_send('/ra <t>')
            -- Same nil-global fix as the sleep branch above. This is the
            -- line that broke ranged_busy for every ordinary shot: it threw
            -- inside act()'s pcall, so ranged_fired_at stayed 0 and the
            -- /ra was never tracked as in flight.
            local st = GeneralLua._state_ref
            if st and st.combat then
                st.combat.ranged_fired_at = os.clock()
                st.combat.ranged_cd_set = false
            end
            return true
        end,
    },

}

local function n(v)
    return tonumber(v) or 0
end

local function set_state_ref(state)
    if state ~= nil then
        GeneralLua._state_ref = state
    end
end

local function get_state_ref()
    return GeneralLua._state_ref
end

local function now_sec()
    return os.clock()
end




-- Dispatch guard: a short, unconditional, no-confirmation-needed lock
-- armed the instant ANY action /command is sent to the game. It exists
-- purely to stop the Lua from machine-gunning multiple casts/actions
-- in the ~0.5s window between sending a /ma and the game emitting the
-- "<player> starts casting" line that arms the REAL spell lock.
--
-- This is deliberately separate from state.combat.spell_locked:
--   * dispatch guard  -> set at send time, expires on a fixed timer,
--                        never waits for confirmation. Self-clears.
--   * spell_locked    -> armed only when the cast is DETECTED
--                        ("starts casting"), held for the real cast
--                        duration, cleared by confirm/interrupt/timeout.
-- ctx.spells_locked / spells_locked_soft are the OR of both, so every
-- existing gate that already checks them honors the guard for free.
local DISPATCH_GUARD_SEC = 1.0

local function arm_dispatch_guard(state)
    state.combat = state.combat or {}
    state.combat.dispatch_guard_until = now_sec() + DISPATCH_GUARD_SEC
end

local function dispatch_guard_active(state)
    local c = state.combat
    if not c then return false end
    return now_sec() < (tonumber(c.dispatch_guard_until or 0) or 0)
end

-- Always-on "action attempted but blocked" reporter. Something tried to fire
-- and a gate rejected it -- that means somewhere upstream we missed a gate and
-- the action is being wasted (bolt swap, /ra, spell). Echoed regardless of
-- debug so it's visible. Throttled per (action_key, reason) so a re-tried
-- event doesn't spam every tick.
local BLOCK_ECHO_MIN_GAP_SEC = 1.5
local function report_blocked_action(state, action_key, reason)
    state.combat = state.combat or {}
    state.combat.block_echo_at = state.combat.block_echo_at or {}
    local key = tostring(action_key or '?') .. '|' .. tostring(reason or '?')
    local now = now_sec()
    local prev = tonumber(state.combat.block_echo_at[key] or 0) or 0
    if (now - prev) < BLOCK_ECHO_MIN_GAP_SEC then return end
    state.combat.block_echo_at[key] = now
    safe_send(string.format(
        '/echo [bovinebattle] blocked: %s (%s)', action_key, reason))
end

-- Ranged state. A /ra puts us "in progress" until the shot resolves (the
-- packet/text parsers stamp ranged_resolved_at on hit/miss/interrupt). While
-- in progress nothing else fires (like the cast lock). On a hit/miss the /ra
-- itself goes on a short CD so it can't be chained. NOT a timer for the lock.
-- Fallback recast, used only when weapon_db cannot answer (unknown launcher
-- id, nothing equipped). Everything with a real bow/xbow/gun goes through
-- ranged_recast_sec below instead.
local RANGED_CD_SEC    = 3.5    -- /ra recast after it resolves
local RANGED_STALE_SEC = 6.0    -- give up waiting on a resolve after this

-- Server-side free phase added on top of the weapon delay before the shot
-- can go again. range_state.cpp reads it from settings as
-- main.RANGED_ATTACK_FREE_PHASE_DELAY and the shipped default is 500ms.
local RANGED_FREE_PHASE_SEC = 0.5

-- Standoff ladder pacing. See the STANDOFF REFILL block in runtime.tick.
--
-- Reach: LSB's real melee range is CBattleEntity::GetMeleeRange, which is
-- modelHitboxSize + 2.0 + the target's hitbox, so it moves with mob size and
-- there is no single right number here. 4.0 matches the ctx.dist <= 4 the WS
-- entry already uses. Erring SMALL is the safe direction: too small only
-- costs a redundant refill (the burst window and every entry's own cooldown
-- absorb it), while too large would put us back to standing idle at 6y
-- thinking we were in melee.
local RANGED_STANDOFF_MELEE_REACH = 4.0

-- How often to synthesise an atk event while standing off. Does not need to
-- match any weapon: it only decides how often the ladder is RE-EVALUATED,
-- and everything in it still owns its own cooldown, gate_time and ja chain
-- pacing. 2s is responsive without churning the pool.
local RANGED_STANDOFF_REFILL_SEC = 2.0

-- Real /ra recast for the CURRENTLY EQUIPPED launcher, in seconds.
--
-- The flat 3.5s this replaces was a guess, and it is wrong in both
-- directions: a Power Crossbow (delay 288) actually comes back at 288/120 +
-- 0.5 = 2.9s, so we were leaving half a second on the floor every shot,
-- while anything slow was firing early and eating "You must wait longer to
-- perform that action".
--
-- weapon_db.ranged_delay_sec mirrors CBattleEntity::GetRangedWeaponDelay:
-- the launcher owns the cadence, ammo delay is TP-only, and ammo takes over
-- entirely when the launcher does no damage (throwing). See the weapon_db
-- header for the full derivation.
--
-- NOT modelled: Snapshot, Rapid Shot and Velocity Shot all cut this down
-- multiplicatively. That makes us slightly SLOW on a geared ranged job,
-- which is the safe direction to be wrong in -- firing early is a wasted
-- round and a server refusal, firing late is a fraction of a second.
local function ranged_recast_sec(state)
    local live = state and state.live
    if not live then return RANGED_CD_SEC end

    local rid = tonumber(live.ranged_weapon_id or 0) or 0
    local aid = tonumber(live.equipped_ammo_id or 0) or 0
    if rid == 0 then rid = nil end
    if aid == 0 then aid = nil end

    local ok, secs = pcall(WeaponDB.ranged_delay_sec, rid, aid)
    if not ok then return RANGED_CD_SEC end

    secs = tonumber(secs)
    if secs == nil or secs <= 0 then return RANGED_CD_SEC end

    return secs + RANGED_FREE_PHASE_SEC
end
local RANGED_POST_RESOLVE_SEC = 1.0  -- keep "in progress" this long after the
                                     -- shot resolves; the character is still in
                                     -- ranged animation and the game will drop
                                     -- a spell/cast attempted before it clears

-- WS needs a LONGER tail than a cast does. ranged_resolved_at is stamped by
-- packet_parser off the type-2 action packet, which is the damage line -- but
-- the client's ranged recovery keeps running past it. A /ws issued at
-- resolve + RANGED_POST_RESOLVE_SEC still lands inside the lock and the server
-- answers "Unable to use weapon skill.", which (before the text_parser
-- rollback) burned the 2.5s ws_post_block window and cost the whole round.
--
-- Tune THIS one, not RANGED_POST_RESOLVE_SEC. Casts/shadows are fine at 1.0
-- and raising the shared value would delay every Utsusemi for no reason.
-- Starting point is 1.0 + 0.6; if rejects still show up, walk it to 1.8.
local RANGED_POST_RESOLVE_WS_SEC = 1.6

local function ranged_in_progress(state)
    local c = state.combat
    if not c then return false end
    local fired = tonumber(c.ranged_fired_at or 0) or 0
    if fired <= 0 then return false end
    local resolved = tonumber(c.ranged_resolved_at or 0) or 0
    if resolved >= fired then
        -- Shot resolved. Hold "in progress" for a short beat -- Utsusemi cast
        -- the instant the resolve stamp lands gets eaten by the tail of the
        -- ranged animation.
        return (now_sec() - resolved) < RANGED_POST_RESOLVE_SEC
    end
    return (now_sec() - fired) < RANGED_STALE_SEC     -- still in flight
end

-- EXPORTED. idle_rest_engage needs this same answer for chase_step (do not
-- walk while an arrow is in the air) and it must be the SAME answer, not a
-- second implementation that happens to agree today. RANGED_POST_RESOLVE_SEC
-- and RANGED_STALE_SEC are tuning knobs; a copy of this logic in another file
-- would keep its own copy of those numbers and silently disagree the first
-- time either is changed.
--
-- Safe to export here: GeneralLua.runtime is created at the top of the file,
-- well above this, and callers only ever reach it at tick time.
--
-- Callers must NOT use ctx.ranged_busy for this. ctx is snapshotted at the
-- start of runtime.tick, so a shot fired during that same tick is invisible
-- in ctx until the next frame -- which is exactly the frame that matters.
-- This function reads state.combat live.
GeneralLua.runtime.ranged_in_progress = ranged_in_progress

-- Same shape as ranged_in_progress but with the longer WS tail. Only the WS
-- path consults this; everything else stays on the 1.0s grace. In-flight
-- behaviour is identical (a shot that never resolved is stale-capped), the
-- only difference is how long we hold AFTER the resolve stamp.
local function ranged_ws_locked(state)
    local c = state.combat
    if not c then return false end
    local fired = tonumber(c.ranged_fired_at or 0) or 0
    if fired <= 0 then return false end
    local resolved = tonumber(c.ranged_resolved_at or 0) or 0
    if resolved >= fired then
        return (now_sec() - resolved) < RANGED_POST_RESOLVE_WS_SEC
    end
    return (now_sec() - fired) < RANGED_STALE_SEC     -- still in flight
end

--------------------------------------------------------------------------
-- WS / RANGED-RECOVERY INSTRUMENTATION  ->  <addon>/logs/wsra.txt
--
-- RANGED_POST_RESOLVE_WS_SEC above is a starting guess. This turns it into
-- a measurement. Debug-only (state.ui.debug_enabled, /bb debug), so it
-- costs nothing when it's off.
--
-- Two record kinds, written in order as they happen:
--   FIRE    -- a /ws was dispatched. ra_delta is seconds since the last
--              ranged resolve stamp at the moment we sent it.
--   REJECT  -- the server answered "Unable to use weapon skill." The
--              ra_delta on this line is the one carried over from the FIRE
--              it belongs to, so a failure and its measured tail sit
--              together on one line.
--
-- HOW TO READ IT: grep REJECT. The SMALLEST ra_delta that ever appears on
-- a REJECT line is the real floor. Put RANGED_POST_RESOLVE_WS_SEC above it
-- with a little headroom. A FIRE line with no REJECT under it is a shot
-- that worked, so the FIRE deltas show what is already safe.
--
-- ra= column says which clock the delta came off:
--   resolved -- normal case, measured from the type-2 resolve packet
--   inflight -- shot never resolved, measured from fire; the stale ceiling
--               is carrying us and the tail math is not what we think
--   noshot   -- no ranged shot in play at all, this was a pure melee WS
--               (ra_delta is --.-- and the line is just a control sample)
--
-- Opened and closed per line on purpose. WS attempts are a few per minute,
-- so the cost is irrelevant, and it means the file is fully flushed and
-- readable in another window while the game is still running.
--------------------------------------------------------------------------
local WSRA_LOG_REL      = 'logs/wsra.txt'
local wsra_log_disabled = false   -- latched after one failed open, no spam
local wsra_header_done  = false

local function wsra_log_base()
    -- `addon` is the Ashita v4 global the main script uses for package.path
    -- (bovinebattle.lua line ~35), so it is reachable from a required module
    -- too. rawget so a boot-order glitch is a nil, not a crash. addon.path
    -- already carries its trailing separator.
    local a = rawget(_G, 'addon')
    if type(a) == 'table' and type(a.path) == 'string' then return a.path end
    return ''
end

local function wsra_open(path)
    local ok, fh = pcall(io.open, path, 'a')
    if ok and fh then return fh end
    return nil
end

-- Seconds between the last ranged event and now, plus which clock it came
-- off. nil delta means there was no shot in play.
local function wsra_delta(state)
    local c = (state and state.combat) or {}
    local fired = tonumber(c.ranged_fired_at or 0) or 0
    if fired <= 0 then return nil, 'noshot' end
    local resolved = tonumber(c.ranged_resolved_at or 0) or 0
    if resolved >= fired then
        return (now_sec() - resolved), 'resolved'
    end
    return (now_sec() - fired), 'inflight'
end

-- Format a delta for the fixed-width column. nil renders as blanks so the
-- columns still line up when you eyeball the file.
local function wsra_fmt(d)
    d = tonumber(d)
    if d == nil then return ' --.--' end
    return string.format('%6.2f', d)
end

GeneralLua.utils.wsra_fmt = wsra_fmt

function GeneralLua.utils.wsra_log(state, line)
    if not (state and state.ui and state.ui.debug_enabled == true) then return end
    if wsra_log_disabled then return end

    local base = wsra_log_base()
    local path = base .. WSRA_LOG_REL
    local fh   = wsra_open(path)

    if not fh then
        -- logs/ probably does not exist yet. Ashita v4 ships a filesystem
        -- helper but the exact name moves between builds, so probe for
        -- whatever is actually there instead of hard-calling a name that
        -- might be nil. If none of them exist we fall through and latch.
        local ash = rawget(_G, 'ashita')
        local fs  = (type(ash) == 'table') and ash.fs or nil
        if type(fs) == 'table' then
            for _, fn in ipairs({ 'create_directory', 'create_dir', 'createdir' }) do
                if type(fs[fn]) == 'function' then
                    pcall(fs[fn], base .. 'logs')
                    break
                end
            end
        end
        fh = wsra_open(path)
    end

    if not fh then
        wsra_log_disabled = true
        safe_send(('/echo [bovinebattle] wsra log OFF: cannot open %s -- create the logs folder')
            :format(path))
        return
    end

    pcall(function()
        if not wsra_header_done then
            wsra_header_done = true
            fh:write(('\n===== session %s  (RANGED_POST_RESOLVE_WS_SEC=%.2f) =====\n')
                :format(os.date('%Y-%m-%d %H:%M:%S'), RANGED_POST_RESOLVE_WS_SEC))
        end
        fh:write(os.date('%H:%M:%S') .. '  ' .. tostring(line) .. '\n')
    end)
    pcall(function() fh:close() end)
end

local function memory_manager()
    return AshitaCore:GetMemoryManager()
end

local function party_manager()
    local m = memory_manager()
    return m and m:GetParty() or nil
end

local function target_manager()
    local m = memory_manager()
    return m and m:GetTarget() or nil
end

local function entity_manager()
    local m = memory_manager()
    return m and m:GetEntity() or nil
end

local function config_get_from_state(state, path)
    if not state then return nil end

    local current = state.config_ref or state.config or state.config_view
    if type(current) ~= 'table' then return nil end

    for segment in tostring(path):gmatch('[^%.]+') do
        if type(current) ~= 'table' then return nil end
        current = current[segment]
    end

    return current
end

local function normalize_action_name_for_map(name)
    name = tostring(name or ''):lower()
    name = name:gsub('_', ' ')
    name = name:gsub('%s+', ' ')
    name = name:gsub('^%s+', '')
    name = name:gsub('%s+$', '')
    return name
end

local function ensure_cooldown_maps(state, atk_list, def_list, general_list)
    state.cooldown_id_map = state.cooldown_id_map or {}
    state.cooldown_action_name_map = state.cooldown_action_name_map or {}

    if state.cooldown_maps_built == true then
        return
    end

    local function add_list(list)
        for i = 1, #list do
            local entry = list[i]
            if entry and entry.id and entry.cooldown_sec ~= nil then
                local cd = tonumber(entry.cooldown_sec or 0) or 0
                state.cooldown_id_map[entry.id] = cd

                local action_name = normalize_action_name_for_map(entry.confirm_name or entry.id)
                state.cooldown_action_name_map[action_name] = {
                    id = entry.id,
                    cooldown_sec = cd,
                }
            end
        end
    end

    add_list(atk_list or {})
    add_list(def_list or {})
    add_list(general_list or {})

    state.cooldown_maps_built = true
end

local function array_contains(list, value)
    if type(list) ~= 'table' then return false end
    for i = 1, #list do
        if tonumber(list[i] or 0) == tonumber(value or 0) then
            return true
        end
    end
    return false
end

local SPELL_MP_COST = {
    ['cure']        = 8,
    ['cure ii']     = 24,
    ['cure iii']    = 46,
    ['cure iv']     = 88,
    ['protect']     = 9,
    ['protect ii']  = 28,
    ['protect iii'] = 46,
    ['protect iv']  = 65,
    ['shell']       = 18,
    ['shell ii']    = 37,
    ['shell iii']   = 56,
    ['shell iv']    = 75,
    ['stone']       = 4,
    -- HorizonXI wiki values, sourced from horizonffxi.wiki spell pages.
    -- Tick costs here MUST match the wiki -- retail/era values diverge
    -- (Refresh, Bio, Slow, Paralyze all changed on Horizon).
    ['dia']         = 7,
    ['dia ii']      = 30,
    ['bio']         = 15,
    ['bio ii']      = 36,
    ['paralyze']    = 6,
    ['slow']        = 15,
    ['blind']       = 5,
    ['poison']      = 5,
}

local BUFF_IDS = {
    -- All Protect tiers share status ID 40; all Shell tiers share ID 41.
    -- The tier is carried in the effect's power (server-side only) and is
    -- NOT readable from the client buff list, so tier tracking is done via
    -- last-cast recording in spell_confirm (see ps_record_cast_tier).
    PROTECT = { 40 },
    SHELL   = { 41 },
}

local TARGET_DEBUFF_NAMES = {
    -- Debuffs (value=1 in bufftable.statusEffects)
    [2]   = 'sleep',
    [3]   = 'poison',
    [4]   = 'paralyze',
    [5]   = 'blind',
    [6]   = 'silence',
    [7]   = 'petrify',
    [8]   = 'disease',
    [9]   = 'curse',
    [10]  = 'stun',
    [11]  = 'bind',
    [12]  = 'weight',
    [13]  = 'slow',
    [14]  = 'charm',
    [16]  = 'amnesia',
    [18]  = 'gradual petrify',
    [19]  = 'sleep II',
    [21]  = 'addle',
    [28]  = 'terror',
    [29]  = 'mute',
    [31]  = 'plague',
    [128] = 'burn',
    [129] = 'frost',
    [130] = 'choke',
    [131] = 'rasp',
    [132] = 'shock',
    [133] = 'drown',
    [134] = 'dia',
    [135] = 'bio',
    [136] = 'str down',
    [137] = 'dex down',
    [138] = 'vit down',
    [139] = 'agi down',
    [140] = 'int down',
    [141] = 'mnd down',
    [142] = 'chr down',
    [144] = 'max hp down',
    [145] = 'max mp down',
    [146] = 'acc down',
    [147] = 'atk down',
    [148] = 'eva down',
    [149] = 'def down',
    [156] = 'flash',
    [168] = 'inhibit tp',
    [186] = 'helix',
    [192] = 'requiem',
    [193] = 'lullaby',
    [194] = 'elegy',
    [195] = 'paeon',       -- Army's Paeon buff (status id 195)
    -- Buffs (value=0 in bufftable.statusEffects)
    [33]  = 'haste',
    [34]  = 'blaze spikes',
    [35]  = 'ice spikes',
    [36]  = 'blink',
    [37]  = 'stoneskin',
    [38]  = 'shock spikes',
    [39]  = 'aquaveil',
    [40]  = 'protect',
    [41]  = 'shell',
    [42]  = 'regen',
    [43]  = 'refresh',
    [56]  = 'berserk',
    [57]  = 'defender',
    [58]  = 'aggressor',
    [68]  = 'warcry',
    [94]  = 'enfire',
    [95]  = 'enblizzard',
    [96]  = 'enaero',
    [97]  = 'enstone',
    [98]  = 'enthunder',
    [99]  = 'enwater',
    [100] = 'barfire',
    [101] = 'barblizzard',
    [102] = 'baraero',
    [103] = 'barstone',
    [104] = 'barthunder',
    [105] = 'barwater',
    [113] = 'reraise',
    [116] = 'phalanx',
    [249] = 'dedication',
    [251] = 'food',
    [253] = 'signet',
    [445] = 'shadows',
}

-- Spell-id (atk_list entry id, uppercase) -> packet-side debuff name as it
-- appears in TARGET_DEBUFF_NAMES. This is the bridge between "what spell did
-- ctx.mob_debuff_ready ask about" and "what string DebuffHandler stores".
-- KEEP THIS IN SYNC with every debuff spell the bot can actually cast (see
-- atk_list.lua). A missing entry means the wrapper below silently falls
-- through to the legacy "we cast it" tracking, which is the bug enemylist
-- doesn't have -- enemylist asks DebuffHandler directly for everything.
local SPELL_DEBUFF_PACKET_NAME = {
    DIA       = 'dia',
    BIO       = 'bio',
    PARALYZE  = 'paralyze',
    SLOW      = 'slow',
    BLIND     = 'blind',
    POISON    = 'poison',     -- atk_list.lua entry id='POISON' was unmapped
}

-- NOTE: We can't use Entity.Buffs alone here - that's the broadcast/party-visible
-- list, which omits private stance buffs like Hasso/Seigan. Defer to the same
-- multi-source scan the debug panel uses (IPlayer:GetBuffs + IParty:GetMemberBuff
-- + Entity.Buffs) so private buffs are seen.
local collect_player_buff_ids  -- forward declaration; defined below
local function player_buff_active(buff_ids)
    local list = collect_player_buff_ids()
    for i = 1, #list do
        if array_contains(buff_ids, list[i]) then
            return true
        end
    end
    return false
end

-- Collect every player buff ID we can find from every available source.
-- Some sources are 0-indexed, some are 1-indexed; some return uint16 with -1
-- for empty slots (which shows up as 65535 after coercion). Be permissive.
-- IMPORTANT: Ashita's IPlayer:GetBuffs() returns a userdata-with-metamethods,
-- not a real Lua table, so do NOT type-check it - just index and iterate.
-- Returns a sorted list of unique buff IDs that look real.
function collect_player_buff_ids()
    local seen = {}

    local function add(v)
        local n = tonumber(v)
        if n == nil then return end
        n = math.floor(n + 0.5)
        if n <= 0 then return end                     -- 0 = empty slot
        if n == 255 then return end                   -- 255 = empty slot (legacy)
        if n == 65535 or n == -1 then return end      -- 0xFFFF = empty (uint16)
        if n > 1023 then return end                   -- buff IDs cap at 10 bits in FFXI
        seen[n] = true
    end

    -- Try indexed reads on whatever-it-is. Wrap each access in pcall so a
    -- userdata that doesn't support a particular operation just fails silently
    -- rather than aborting the whole collection.
    local function scan_indexed(obj, idx_lo, idx_hi)
        if obj == nil then return end
        for i = idx_lo, idx_hi do
            local ok, v = pcall(function() return obj[i] end)
            if ok then add(v) end
        end
        -- If it's a real Lua table, also try pairs() in case of sparse keys.
        if type(obj) == 'table' then
            for k, v in pairs(obj) do
                if type(k) == 'number' then add(v) end
            end
        end
    end

    local mm = AshitaCore and AshitaCore:GetMemoryManager()

    -- Source 1: IPlayer:GetBuffs()  - canonical local source, includes private buffs
    do
        local pm = mm and mm:GetPlayer()
        if pm and type(pm.GetBuffs) == 'function' then
            local ok, buffs = pcall(function() return pm:GetBuffs() end)
            if ok and buffs ~= nil then
                scan_indexed(buffs, 0, 63)
            end
        end
        -- Source 1b: per-slot accessor on some Ashita builds
        if pm and type(pm.GetBuff) == 'function' then
            for i = 0, 31 do
                local ok, v = pcall(function() return pm:GetBuff(i) end)
                if ok then add(v) end
            end
        end
    end

    -- Source 2: IParty:GetMemberBuff(0, i)  - known-working in hb_shadows_helper
    do
        local party = mm and mm:GetParty()
        if party and type(party.GetMemberBuff) == 'function' then
            for i = 0, 31 do
                local ok, v = pcall(function() return party:GetMemberBuff(0, i) end)
                if ok then add(v) end
            end
        end
    end

    -- Source 3: Entity.Buffs  - broadcast/party-visible only, last-ditch backup
    do
        local player = GeneralLua.utils.get_player_entity and GeneralLua.utils.get_player_entity()
        if player ~= nil then
            scan_indexed(player.Buffs or player.buffs, 0, 63)
        end
    end

    local out = {}
    for id in pairs(seen) do out[#out + 1] = id end
    table.sort(out)
    return out
end

local function player_has_buff_id(want_id, cached_list)
    want_id = tonumber(want_id)
    if not want_id then return false end
    local list = cached_list or collect_player_buff_ids()
    for i = 1, #list do
        if list[i] == want_id then return true end
    end
    return false
end

local function player_hp_percent()
    local party = party_manager()
    if not party or type(party.GetMemberHPPercent) ~= 'function' then return nil end

    local ok, value = pcall(function()
        return party:GetMemberHPPercent(0)
    end)

    if ok and value ~= nil then
        return tonumber(value)
    end

    return nil
end

local function player_mp_percent()
    return MainMagic.player_mp_percent()
end

local function player_mp_raw()
    return MainMagic.player_mp_raw()
end

-- Protect/Shell share one status ID per family, so the buff list can't tell
-- tier apart. We track the last tier WE cast and allow a recast (overwrite)
-- when our best castable tier outranks it. Roman numeral -> rank.
local PS_TIER_RANK = {
    ['protect']     = 1, ['protect ii']  = 2, ['protect iii'] = 3, ['protect iv'] = 4, ['protect v'] = 5,
    ['shell']       = 1, ['shell ii']    = 2, ['shell iii']   = 3, ['shell iv']   = 4, ['shell v']   = 5,
}
local function ps_tier_rank(spell_name)
    if type(spell_name) ~= 'string' then return 0 end
    return PS_TIER_RANK[spell_name:lower()] or 0
end

-- Record what we just cast. For Protect/Shell this drives the upgrade gate
-- (tier rank) AND a readable display name for the debug panel. For Utsusemi
-- we record the last shadow spell (Ni / Ichi) for the Ninja debug readout.
-- Fires for ANY confirmed self-cast -- bot-issued or manually typed -- since
-- it's driven by spell_confirm off the action-packet / chat-line completion.
local function ps_record_cast_tier(state, spell_name)
    if type(spell_name) ~= 'string' then return end
    state.combat = state.combat or {}
    local lname = spell_name:lower()

    local PS_TIER_ROMAN = { [1] = '', [2] = ' II', [3] = ' III', [4] = ' IV', [5] = ' V' }
    local rank = PS_TIER_RANK[lname]
    if rank then
        if lname:find('protect', 1, true) then
            state.combat.last_protect_tier = rank
            state.combat.last_protect_name = 'Protect' .. (PS_TIER_ROMAN[rank] or '')
        elseif lname:find('shell', 1, true) then
            state.combat.last_shell_tier = rank
            state.combat.last_shell_name = 'Shell' .. (PS_TIER_ROMAN[rank] or '')
        end
        return
    end

    -- Utsusemi: Ni / Ichi (and San if it ever applies). Record the tier word
    -- for the Ninja debug panel.
    if lname:find('utsusemi', 1, true) then
        if lname:find('ni', 1, true) then
            state.combat.last_shadow_name = 'Ni'
        elseif lname:find('ichi', 1, true) then
            state.combat.last_shadow_name = 'Ichi'
        elseif lname:find('san', 1, true) then
            state.combat.last_shadow_name = 'San'
        else
            state.combat.last_shadow_name = spell_name
        end
    end
end

local function get_best_spell_for_job(job_info, spell_line)
    if not job_info then return nil end

    local mainJob = n(job_info.mainJob)
    local subJob  = n(job_info.subJob)
    local mainLv  = n(job_info.mainLv)
    local subLv   = n(job_info.subLv)

    local WHM = GeneralLua.jobs.WHM
    local RDM = GeneralLua.jobs.RDM
    local PLD = GeneralLua.jobs.PLD

    local function can_main(job, lv)
        return mainJob == job and mainLv >= lv
    end

    local function can_sub(job, lv)
        return subJob == job and subLv >= lv
    end

    if spell_line == 'CURE' then
        if can_main(WHM, 41) or can_main(RDM, 48) or can_main(PLD, 55) then return 'Cure IV' end
        if can_sub(WHM, 21) or can_sub(RDM, 26) then return 'Cure III' end

        if can_main(WHM, 21) or can_main(RDM, 26) or can_main(PLD, 30) then return 'Cure III' end
        if can_sub(WHM, 11) or can_sub(RDM, 14) then return 'Cure II' end

        if can_main(WHM, 11) or can_main(RDM, 14) or can_main(PLD, 17) then return 'Cure II' end
        if can_sub(WHM, 1) or can_sub(RDM, 3) then return 'Cure' end

        if can_main(WHM, 1) or can_main(RDM, 3) or can_main(PLD, 5) then return 'Cure' end
        return nil
    end

    if spell_line == 'PROTECT' then
        if can_main(WHM, 63) or can_main(RDM, 63) then return 'Protect IV' end
        if can_main(WHM, 47) or can_main(RDM, 47) or can_main(PLD, 50) then return 'Protect III' end
        if can_sub(WHM, 27) or can_sub(RDM, 27) then return 'Protect II' end

        if can_main(WHM, 27) or can_main(RDM, 27) or can_main(PLD, 30) then return 'Protect II' end
        if can_sub(WHM, 4) or can_sub(RDM, 7) then return 'Protect' end

        if can_main(WHM, 4) or can_main(RDM, 7) or can_main(PLD, 10) then return 'Protect' end
        return nil
    end

    if spell_line == 'SHELL' then
        if can_main(WHM, 68) or can_main(RDM, 68) then return 'Shell IV' end
        if can_main(WHM, 57) or can_main(RDM, 57) or can_main(PLD, 60) then return 'Shell III' end
        if can_sub(WHM, 37) or can_sub(RDM, 37) then return 'Shell II' end

        if can_main(WHM, 37) or can_main(RDM, 37) or can_main(PLD, 40) then return 'Shell II' end
        if can_sub(WHM, 17) or can_sub(RDM, 17) then return 'Shell' end

        if can_main(WHM, 17) or can_main(RDM, 17) or can_main(PLD, 20) then return 'Shell' end
        return nil
    end

    return nil
end

local function get_target_server_id()
    local target = GeneralLua.utils.current_target()
    if not target then return 0 end

    return tonumber(
        target.ServerId or
        target.ServerID or
        target.Id or
        target.ID or
        target.EntityId or
        target.EntityID or
        0
    ) or 0
end

local function is_party_member_sid(sid)
    local party = AshitaCore:GetMemoryManager():GetParty()
    if not party then return false end
    for i = 0, 17 do
        if (tonumber(party:GetMemberIsActive(i) or 0) or 0) == 1 then
            if (tonumber(party:GetMemberServerId(i) or 0) or 0) == sid then
                return true
            end
        end
    end
    return false
end

local function get_packet_target_debuff_ids(state, sid)
    sid = tonumber(sid or 0) or 0
    if sid == 0 then return T{} end

    -- Mob debuffs: use DebuffHandler ONLY if not a party member
    -- (mobs that debuff players also end up in debuffHandler.enemies).
    -- DebuffHandler.GetActiveDebuffs returns a REUSABLE module-level table
    -- (ids, times) that is cleared/refilled on the next call, so we copy
    -- the ids into a stable table immediately -- same pattern enemylist.lua
    -- uses. Returning the reusable table directly would alias whatever the
    -- next GetActiveDebuffs call (any target) overwrites it with.
    local dh = rawget(_G, 'DebuffHandler')
    if dh and type(dh.GetActiveDebuffs) == 'function' and not is_party_member_sid(sid) then
        local active = dh.GetActiveDebuffs(sid)
        if active ~= nil and #active > 0 then
            local out = T{}
            for i = 1, #active do
                out[i] = active[i]
            end
            return out
        end
    end

    -- Self: use GetPlayer():GetBuffs() via player manager -- always live
    do
        local mm = AshitaCore:GetMemoryManager()
        local pm_self = mm and mm:GetParty()
        if pm_self and type(pm_self.GetMemberServerId) == 'function' then
            local self_sid = tonumber(pm_self:GetMemberServerId(0) or 0) or 0
            if self_sid == sid then
                local player_mgr = mm:GetPlayer()
                if player_mgr and type(player_mgr.GetBuffs) == 'function' then
                    local buffs = player_mgr:GetBuffs()
                    if buffs then
                        local out = T{}
                        for i = 1, #buffs do
                            local id = tonumber(buffs[i] or -1) or -1
                            if id >= 0 and id ~= 255 then
                                table.insert(out, id)
                            end
                        end
                        if #out > 0 then return out end
                    end
                end
            end
        end
    end

    -- Party members: StatusHandler reads from memory (populated by 0x076 packets)
    local sh = rawget(_G, 'StatusHandler')
    if sh and type(sh.get_member_status) == 'function' then
        local buffs = sh.get_member_status(sid)
        if buffs then
            local out = T{}
            for i = 1, #buffs do
                local id = tonumber(buffs[i] or -1) or -1
                if id >= 0 and id ~= 255 then
                    table.insert(out, id)
                end
            end
            if #out > 0 then return out end
        end
    end

    return T{}
end

-- Every status that means "this mob is already asleep".
--
-- Checking the NAME 'sleep' only matches id 2 -- a mob put down by Sleep II
-- or a Bard's Lullaby reads as wide awake, so we burn a bolt re-sleeping
-- something that is already out. Match the whole family by id instead.
--   2   sleep       (Sleep, Sleepga, Sleep Bolt/Arrow)
--   19  sleep II    (Sleep II, Sleepga II)
--   193 lullaby     (Foe Lullaby / Horde Lullaby)
local SLEEP_DEBUFF_IDS = { [2] = true, [19] = true, [193] = true }

-- True if `sid` has ANY sleep-family status on it.
local function sid_is_asleep(state, sid)
    sid = tonumber(sid or 0) or 0
    if sid == 0 then return false end
    local ids = get_packet_target_debuff_ids(state, sid)
    for i = 1, #ids do
        if SLEEP_DEBUFF_IDS[tonumber(ids[i] or 0) or 0] then return true end
    end
    return false
end

local function get_packet_target_debuff_names(state, sid)
    local ids = get_packet_target_debuff_ids(state, sid)
    local out = T{}

    for i = 1, #ids do
        local id = tonumber(ids[i] or 0) or 0
        out[#out + 1] = TARGET_DEBUFF_NAMES[id] or ('id:' .. tostring(id))
    end

    return out
end

local function get_packet_target_debuff_updated_at(state, sid)
    if not state or not state.mob_status or not state.mob_status.by_server_id then
        return 0.0
    end

    local row = state.mob_status.by_server_id[tonumber(sid or 0) or 0]
    if not row then return 0.0 end

    return tonumber(row.updated_at or 0.0) or 0.0
end

local function target_has_packet_debuff_name(state, sid, wanted)
    wanted = normalize_action_name_for_map(wanted or '')
    if wanted == '' then return false end

    local names = get_packet_target_debuff_names(state, sid)
    for i = 1, #names do
        if normalize_action_name_for_map(names[i]) == wanted then
            return true
        end
    end

    return false
end

local function entity_distance(ent)
    if not ent then return nil end
    local d = tonumber(ent.Distance)
    if not d or d < 0 then return nil end
    return math.sqrt(d)
end

local function entity_hp_percent_sane(ent)
    if not ent then return nil end

    local hp = tonumber(ent.HPPercent)
    if hp and hp >= 0 and hp <= 100 then
        return hp
    end

    hp = tonumber(ent.HPP)
    if hp and hp >= 0 and hp <= 100 then
        return hp
    end

    return nil
end

local function entity_position(ent)
    if not ent then return nil, nil, nil end

    -- Ashita v4: position is under Movement.LocalPosition
    local lp = ent.Movement and ent.Movement.LocalPosition
    local x = tonumber((lp and lp.X) or ent.X or ent.x)
    local y = tonumber((lp and lp.Y) or ent.Y or ent.y)
    local z = tonumber((lp and lp.Z) or ent.Z or ent.z)

    if x == nil or y == nil or z == nil then
        return nil, nil, nil
    end

    return x, y, z
end

-- Facing direction (yaw) in radians. Ashita v4 builds vary in what field
-- exposes it: some put it on LocalPosition alongside X/Y/Z, others expose
-- Movement.Heading directly, older builds have entity.Heading. Try each.
-- ffxi_pos_tool reads the raw offset 0x0E4 -- one of the below is the
-- same struct member.
local function entity_heading(ent)
    if not ent then return nil end
    local lp = ent.Movement and ent.Movement.LocalPosition
    local h =
        (lp and (lp.H or lp.R or lp.Heading))
        or (ent.Movement and (ent.Movement.Heading or ent.Movement.H))
        or ent.Heading
        or ent.H
    return tonumber(h)
end

-- Read a mob's claim owner (server id of whoever claimed it), 0 = unclaimed.
--
-- ClaimStatus MUST come first. Ashita v4 exposes the field as ClaimStatus;
-- ClaimId/ClaimOwnerId/ClaimServerId do not exist on the entity, so the
-- previous list returned 0 for every mob -- meaning every claim check fed
-- by this (ctx.target_claim_id, ctx.target_claim_free_or_party, and the
-- bot's free/party filters) treated every mob in the zone as unclaimed.
-- Order copied from bovinemage, which reads claims correctly in production.
local function entity_claim_id(ent)
    if not ent then return 0 end
    return tonumber(
        ent.ClaimStatus or
        ent.ClaimId or
        ent.claim_status or
        ent.claim_id or
        ent.ClaimID or
        ent.ClaimOwnerId or
        ent.ClaimOwnerID or
        ent.ClaimServerId or
        ent.ClaimServerID or
        0
    ) or 0
end

local function entity_index(ent)
    if not ent then return 0 end
    return tonumber(
        ent.TargetIndex or
        ent.Index or
        ent.index or
        0
    ) or 0
end

local function entity_server_id(ent)
    if not ent then return 0 end
    return tonumber(
        ent.ServerId or
        ent.ServerID or
        ent.Id or
        ent.ID or
        ent.EntityId or
        ent.EntityID or
        0
    ) or 0
end

local function is_valid_mob(index)
    local entities = entity_manager()
    if not entities then return false end
    if type(entities.GetRenderFlags0) ~= 'function' then return false end

    local ok, flags = pcall(entities.GetRenderFlags0, entities, index)
    if not ok or type(flags) ~= 'number' then return false end

    if bit.band(flags, 0x200) ~= 0x200 then return false end
    if bit.band(flags, 0x4000) ~= 0 then return false end

    return true
end

local function compute_under_attack(state)
    state.all_claimed_targets = state.all_claimed_targets or T{}

    local cnt = 0
    local nearest = nil
    local nearest_idx = 0
    local nearest_sid = 0

    for idx, v in pairs(state.all_claimed_targets) do
        local ent = GeneralLua.utils.get_entity(idx)
        local hp = entity_hp_percent_sane(ent)

        if v ~= nil and ent ~= nil and is_valid_mob(idx) and hp ~= nil and hp > 0 and ent.Name ~= nil then
            cnt = cnt + 1

            local d = entity_distance(ent)
            if d and (nearest == nil or d < nearest) then
                nearest = d
                nearest_idx = tonumber(idx or 0) or 0
                nearest_sid = tonumber(ent.ServerId or 0) or 0
            end
        else
            -- A claimed target just dropped out. If the entity exists but is
            -- at 0 HP, that's a kill - stamp a "no attack" cooldown so we
            -- don't /attack <bt> the corpse during its lingering aggro window.
            -- (The other prune cases - missing entity, wrong type, gone - are
            -- also safe to treat as kills for this purpose.)
            if v ~= nil then
                state.combat = state.combat or {}
                state.combat.last_kill_at = now_sec()
            end
            state.all_claimed_targets[idx] = nil
        end
    end

    return cnt, nearest, nearest_idx, nearest_sid
end

local function get_party_member_ids()
    local out = T{}
    local party = party_manager()
    if not party then return out end

    for i = 0, 17 do
        local active = tonumber(party:GetMemberIsActive(i) or 0) or 0
        if active == 1 then
            local sid = tonumber(party:GetMemberServerId(i) or 0) or 0
            if sid > 0 then
                out[#out + 1] = sid
            end
        end
    end

    return out
end

local function claim_is_party_or_free(claim_id)
    claim_id = tonumber(claim_id or 0) or 0
    if claim_id == 0 then return true end
    return array_contains(get_party_member_ids(), claim_id)
end

---------------------------------------------------------------------
-- COOLDOWNS
---------------------------------------------------------------------

function GeneralLua.cooldowns.is_ready(id)
    local ready_at = GeneralLua.cooldowns.abilities[id]
    local safety = 0.40
    return ready_at == nil or now_sec() >= (ready_at + safety)
end

function GeneralLua.cooldowns.set(id, sec)
    if id == nil then return end
    sec = tonumber(sec or 0) or 0
    GeneralLua.cooldowns.abilities[id] = now_sec() + math.max(0, sec)
end

function GeneralLua.cooldowns.sync_remaining(id, remaining_sec, max_sec)
    if id == nil then return end

    remaining_sec = tonumber(remaining_sec or 0) or 0
    max_sec = tonumber(max_sec or remaining_sec) or remaining_sec

    if remaining_sec < 0 then remaining_sec = 0 end
    if max_sec < 0 then max_sec = 0 end
    if remaining_sec > max_sec then
        remaining_sec = max_sec
    end

    GeneralLua.cooldowns.abilities[id] = now_sec() + remaining_sec
end

---------------------------------------------------------------------
-- SPELL LOCK / CONFIRM
---------------------------------------------------------------------

function GeneralLua.runtime.spell_lock_start(state, spell_name)
    MainMagic.spell_lock_start(state, spell_name, GeneralLua.timing)
end

function GeneralLua.runtime.spell_lock_clear(state)
    MainMagic.spell_lock_clear(state)
end

function GeneralLua.runtime.spell_confirm(state, spell_name)
    MainMagic.spell_confirm(state, spell_name)
    ps_record_cast_tier(state, spell_name)
end

-- Lock-free recorder for the unconditional chat-line path. Records the
-- last Protect/Shell/Utsusemi we cast (for upgrade gating + debug) WITHOUT
-- touching spell locks, cooldowns, or HB notifies. Safe to call on every
-- 'X casts Y' line regardless of bot casting state or paused state.
function GeneralLua.runtime.record_cast(state, spell_name)
    ps_record_cast_tier(state, spell_name)
end

function GeneralLua.runtime.spell_interrupt(state)
    MainMagic.spell_interrupt(state)
end

function GeneralLua.runtime.refresh_spell_timeout(state, current_time)
    MainMagic.refresh_spell_timeout(state, GeneralLua.timing, current_time, GeneralLua.cooldowns)
end

---------------------------------------------------------------------
-- UTILS
---------------------------------------------------------------------

function GeneralLua.utils.get_entity(index)
    local ok, entity = pcall(GetEntity, index)
    return ok and entity or nil
end

function GeneralLua.utils.get_player_entity()
    local ok, player = pcall(GetPlayerEntity)
    if ok and player ~= nil then
        return player
    end
    return nil
end

function GeneralLua.utils.player_status()
    local player = GeneralLua.utils.get_player_entity()
    if player == nil then return nil end
    return tonumber(player.Status or player.status or player.CurrentStatus)
end

function GeneralLua.utils.player_pet_entity()
    local player = GeneralLua.utils.get_player_entity()
    if player == nil then return nil end

    local pet_index = tonumber(player.PetTargetIndex or 0) or 0
    if pet_index == 0 then return nil end

    return GeneralLua.utils.get_entity(pet_index)
end

function GeneralLua.utils.player_pet_hp()
    local pet = GeneralLua.utils.player_pet_entity()
    if pet == nil then return nil end
    return tonumber(pet.HPPercent)
end

-- BST Sic/Ready charges. Returns 0..3.
-- bsthud's reference values for HorizonXI: Sic recast id = 102, charge cycle
-- = 135s (45s per charge), in 60-tick units. Translation:
--   charges_held = floor((3 * cb_seconds - remaining_seconds) / cb_seconds)
-- Falls back to 0 if recast slot can't be located.
local SIC_RECAST_ID = 102
local SIC_CHARGE_BASE_SEC = 45
local RECAST_TICKS_PER_SEC = 60

function GeneralLua.utils.player_pet_ready_charges()
    local mm = AshitaCore and AshitaCore:GetMemoryManager()
    local rm = mm and mm:GetRecast()
    if rm == nil then return 0 end

    -- Find slot for Sic.
    local slot
    for i = 0, 30 do
        local ok, id = pcall(function() return rm:GetAbilityTimerId(i) end)
        if ok and id == SIC_RECAST_ID then
            slot = i
            break
        end
    end
    if slot == nil then return 3 end   -- not in recast table = full charges

    local ok, ticks = pcall(function() return rm:GetAbilityTimer(slot) end)
    if not ok or ticks == nil then return 3 end
    local remaining = (tonumber(ticks) or 0) / RECAST_TICKS_PER_SEC
    if remaining <= 0 then return 3 end

    local cb = SIC_CHARGE_BASE_SEC
    local total = cb * 3
    local charges = math.floor((total - remaining) / cb)
    if charges < 0 then charges = 0 end
    if charges > 3 then charges = 3 end
    return charges
end

function GeneralLua.utils.player_mp_percent()
    return player_mp_percent()
end

function GeneralLua.utils.player_tp()
    local party = party_manager()
    if not party or type(party.GetMemberTP) ~= 'function' then return 0 end

    local ok, value = pcall(function()
        return party:GetMemberTP(0)
    end)

    return ok and n(value) or 0
end

function GeneralLua.utils.current_target()
    local targets = target_manager()
    if not targets or type(targets.GetTargetIndex) ~= 'function' then return nil end

    local index = targets:GetTargetIndex(0)
    if not index or index == 0 then return nil end

    return GeneralLua.utils.get_entity(index)
end

-- Force the client's hard target to a given entity INDEX by injecting an
-- incoming 0x058 packet (the method the Windower "SetTarget" addon by
-- Arcon uses). This is NOT a memory write to the target struct -- poking
-- that struct only flashes the target animation and does not actually
-- retarget. 0x058 feeds the client the server-style "you are now
-- targeting X" event, so the client's own code sets the target properly
-- (cursor, lock, UI, everything). No memory writes, no crash.
--
-- 0x058 incoming layout (byte array, 1-indexed for AddIncomingPacket):
--   [1]   = 0x58 (id)
--   [5..8]   = Player       (u32 self server id)
--   [9..12]  = Target       (u32 target server id)
--   [13..14] = Player Index (u16 self entity index)
--
-- Returns true on inject, false (with no side effects) if ids can't be
-- resolved. Safe to call from anywhere, including inside a d3d_present
-- render frame (packet injection does not race the render thread).
function GeneralLua.utils.set_target(target_index)
    target_index = tonumber(target_index or 0) or 0
    if target_index == 0 then return false end

    -- self server id
    local self_id = 0
    local player = GeneralLua.utils.get_player_entity()
    if player then self_id = tonumber(player.ServerId) or 0 end

    -- self entity index (party member 0)
    local self_idx = 0
    local mm = AshitaCore:GetMemoryManager()
    local party = mm and mm:GetParty()
    if party and type(party.GetMemberTargetIndex) == 'function' then
        local ok, i = pcall(function() return party:GetMemberTargetIndex(0) end)
        self_idx = (ok and tonumber(i)) or 0
    end

    -- target server id
    local tgt_id = 0
    local tent = GeneralLua.utils.get_entity(target_index)
    if tent then tgt_id = tonumber(tent.ServerId) or 0 end

    if self_id == 0 or tgt_id == 0 then return false end

    -- build the 0x058 packet
    local d = {}
    for i = 1, 0x18 do d[i] = 0 end
    d[1] = 0x58
    d[5]  = bit.band(self_id, 0xFF)
    d[6]  = bit.band(bit.rshift(self_id, 8), 0xFF)
    d[7]  = bit.band(bit.rshift(self_id, 16), 0xFF)
    d[8]  = bit.band(bit.rshift(self_id, 24), 0xFF)
    d[9]  = bit.band(tgt_id, 0xFF)
    d[10] = bit.band(bit.rshift(tgt_id, 8), 0xFF)
    d[11] = bit.band(bit.rshift(tgt_id, 16), 0xFF)
    d[12] = bit.band(bit.rshift(tgt_id, 24), 0xFF)
    d[13] = bit.band(self_idx, 0xFF)
    d[14] = bit.band(bit.rshift(self_idx, 8), 0xFF)

    local ok = pcall(function()
        AshitaCore:GetPacketManager():AddIncomingPacket(0x058, d)
    end)
    return ok == true
end

-- Convenience: force target by an entity's SERVER ID (claim id / mob id)
-- instead of index. Resolves the index from the entity table, then calls
-- set_target. Useful when a bot tracks targets by server id.
-- Fire the equipped ranged weapon at a mob by SERVER ID, via an outgoing
-- 0x01A action packet with ActionID = Shoot (0x10).
--
-- This is what makes "Sleep Other" possible at all. /ra only ever shoots
-- <t>, so putting a bolt into an add meant dropping your target and losing
-- the mob you were actually fighting. The action packet names its target in
-- the payload, so the shot goes wherever we say and the cursor never moves.
--
-- Packet layout is LSB's own GP_CLI_COMMAND_ACTION (src/map/packets/c2s/
-- 0x01a_action.h) -- see GeneralLua.utils.set_target for the full field map.
-- Shoot takes no param.
--
-- NOTE: this fires whatever ammo is currently EQUIPPED. Swap first.
function GeneralLua.utils.ranged_shot(server_id)
    server_id = tonumber(server_id or 0) or 0
    if server_id == 0 then return false end

    -- resolve index from sid
    local idx = 0
    for i = 1, 2303 do
        local e = GeneralLua.utils.get_entity(i)
        if e and (tonumber(e.ServerId) or 0) == server_id then idx = i; break end
    end
    if idx == 0 then
        AshitaCore:GetChatManager():QueueCommand(1,
            ('/echo [MN] [ranged_shot] sid %d not in entity table'):format(server_id))
        return false
    end

    local d = {}
    for i = 1, 28 do d[i] = 0 end
    -- [1..4] header: AddOutgoingPacket fills id/size/sync.
    d[5]  = bit.band(server_id, 0xFF)
    d[6]  = bit.band(bit.rshift(server_id, 8), 0xFF)
    d[7]  = bit.band(bit.rshift(server_id, 16), 0xFF)
    d[8]  = bit.band(bit.rshift(server_id, 24), 0xFF)
    d[9]  = bit.band(idx, 0xFF)
    d[10] = bit.band(bit.rshift(idx, 8), 0xFF)
    d[11] = 0x10   -- ActionID = Shoot
    d[12] = 0x00

    local ok, err = pcall(function()
        AshitaCore:GetPacketManager():AddOutgoingPacket(0x01A, d)
    end)
    if not ok then
        AshitaCore:GetChatManager():QueueCommand(1,
            '/echo [MN] [ranged_shot] AddOutgoingPacket threw: ' .. tostring(err))
    end
    return ok == true
end

-- SWITCH TARGET, the real one. Outgoing 0x01A with ActionID = ChangeTarget
-- (0x0F) -- the same action the in-game menu's "Switch Target" entry sends,
-- straight out of GP_CLI_COMMAND_ACTION_ACTIONID in LSB.
--
-- WHY THIS IS BETTER THAN INJECTING 0x058 OURSELVES:
-- an injected 0x058 lies to the client and tells it nothing the server
-- knows about. This asks the SERVER to change our battle target; LSB runs
-- PChar->PAI->ChangeTarget(...) and CCharEntity::OnChangeTarget then pushes
-- a genuine 0x058 back at us -- and RelinquishClaim on the old mob along
-- with it. Server and client end up agreeing, which the injected version
-- never guarantees.
--
-- HARD LIMIT: ENGAGED ONLY. The packet validator in 0x01a_action.cpp gates
-- this action with .isEngaged(), so sending it while disengaged is simply
-- dropped. It is not a general-purpose retarget -- it is 'I am fighting, I
-- want to fight that one instead'. Callers must keep the 0x058 path for the
-- idle case.
--
-- Same 28-byte layout as ranged_shot above; only the ActionID differs.
function GeneralLua.utils.switch_target(server_id)
    server_id = tonumber(server_id or 0) or 0
    if server_id == 0 then return false end

    local idx = 0
    for i = 1, 2303 do
        local e = GeneralLua.utils.get_entity(i)
        if e and (tonumber(e.ServerId) or 0) == server_id then idx = i; break end
    end
    if idx == 0 then return false end

    local d = {}
    for i = 1, 28 do d[i] = 0 end
    d[5]  = bit.band(server_id, 0xFF)
    d[6]  = bit.band(bit.rshift(server_id, 8), 0xFF)
    d[7]  = bit.band(bit.rshift(server_id, 16), 0xFF)
    d[8]  = bit.band(bit.rshift(server_id, 24), 0xFF)
    d[9]  = bit.band(idx, 0xFF)
    d[10] = bit.band(bit.rshift(idx, 8), 0xFF)
    d[11] = 0x0F   -- ActionID = ChangeTarget
    d[12] = 0x00

    local ok = pcall(function()
        AshitaCore:GetPacketManager():AddOutgoingPacket(0x01A, d)
    end)
    return ok == true
end

function GeneralLua.utils.set_target_by_server_id(server_id)
    server_id = tonumber(server_id or 0) or 0
    if server_id == 0 then return false end
    for i = 1, 2303 do
        local e = GeneralLua.utils.get_entity(i)
        if e and (tonumber(e.ServerId) or 0) == server_id then
            return GeneralLua.utils.set_target(i)
        end
    end
    return false
end

function GeneralLua.utils.target_distance()
    local target = GeneralLua.utils.current_target()
    return (target and target.Distance) and math.sqrt(target.Distance) or nil
end

function GeneralLua.utils.current_target_hp()
    local target = GeneralLua.utils.current_target()
    return target and tonumber(target.HPPercent) or nil
end

function GeneralLua.utils.current_target_claim_id()
    local target = GeneralLua.utils.current_target()
    return entity_claim_id(target)
end

function GeneralLua.utils.current_target_valid()
    local target = GeneralLua.utils.current_target()
    if not target then return false end

    local idx = entity_index(target)
    if idx == 0 then return false end
    if not is_valid_mob(idx) then return false end

    local hp = entity_hp_percent_sane(target)
    return hp ~= nil and hp > 0
end

function GeneralLua.utils.is_player_casting()
    local state = get_state_ref()
    if not state or not state.combat then return false end

    if state.combat.spell_locked == true then
        return true
    end

    return state.combat.is_casting == true
end

function GeneralLua.utils.get_effective_job_info()
    local party = party_manager()
    if not party then return nil end

    return {
        mainJob = n(party:GetMemberMainJob(0)),
        subJob  = n(party:GetMemberSubJob(0)),
        mainLv  = n(party:GetMemberMainJobLevel(0)),
        subLv   = n(party:GetMemberSubJobLevel(0)),
    }
end

function GeneralLua.utils.req_ok(req, job_info)
    if not req then
        return true
    end

    if not job_info then
        return false
    end

    local main_job = tonumber(job_info.mainJob or 0) or 0
    local sub_job  = tonumber(job_info.subJob or 0) or 0
    local main_lv  = tonumber(job_info.mainLv or 0) or 0
    local sub_lv   = tonumber(job_info.subLv or 0) or 0

    local function match_one(side_job, side_lv, need)
        if not need then return false end
        local need_job = tonumber(need.job or 0) or 0
        local need_lv  = tonumber(need.lv or 0) or 0
        return side_job == need_job and side_lv >= need_lv
    end

    local function match_list(side_job, side_lv, list)
        if type(list) ~= 'table' or #list == 0 then
            return false
        end
        for i = 1, #list do
            if match_one(side_job, side_lv, list[i]) then
                return true
            end
        end
        return false
    end

    local has_new_main = (type(req.main) == 'table' and #req.main > 0)
    local has_new_sub  = (type(req.sub) == 'table' and #req.sub > 0)

    if has_new_main or has_new_sub then
        local main_ok = false
        local sub_ok  = false

        if has_new_main then
            main_ok = match_list(main_job, main_lv, req.main)
        end

        if has_new_sub then
            sub_ok = match_list(sub_job, sub_lv, req.sub)
        end

        if req.any == true then
            return main_ok or sub_ok
        end

        if has_new_main and not main_ok then return false end
        if has_new_sub and not sub_ok then return false end
        return true
    end

    if req.mainJob and main_job ~= tonumber(req.mainJob) then
        return false
    end
    if req.mainLv and main_lv < tonumber(req.mainLv) then
        return false
    end
    if req.subJob and sub_job ~= tonumber(req.subJob) then
        return false
    end
    if req.subLv and sub_lv < tonumber(req.subLv) then
        return false
    end

    return true
end

function GeneralLua.utils.player_position()
    return entity_position(GeneralLua.utils.get_player_entity())
end

function GeneralLua.utils.entity_position(ent)
    return entity_position(ent)
end

function GeneralLua.utils.entity_heading(ent)
    return entity_heading(ent)
end

-- Sleep Other facing math. Puts the player on the opposite side of the
-- locked target (<t>, the pivot) from the sleep-other mob, so a bolt fired
-- past <t> can reach the other mob without the LOS blocker being wrong
-- geometry. Assumes lock-on is active: A/D strafe around <t> at fixed
-- radius. Ground plane is X/Y (X = east, Y = north per bovinescan's
-- empirical convention); Z is height, ignored.
--
-- Sign convention: which key (A/D) maps to which orbit direction is a
-- game-side convention. If the bot strafes the WRONG way (away from the
-- desired position), flip SLEEP_STRAFE_INVERT.
--
-- Returns nil when any position is unreadable or degenerate. Otherwise a
-- table { delta_rad, hold_sec, key } where key is 'a' | 'd' | 'none'.
-- key='none' = we're already within tolerance, fire directly.
-- Sleep Other facing. We want the sleep mob to sit on the far side of the
-- pivot (our locked target) from us -- i.e., pivot on the line between us
-- and sleep. Equivalently: the direction FROM PLAYER TO PIVOT should equal
-- the direction FROM PLAYER TO SLEEP. Both computed with the same atan2,
-- so the reference frame cancels out -- no heading involved.
--
-- (The earlier heading-based version mixed a raw FFXI heading with a math
-- atan2 result. FFXI's heading zero direction and rotation direction are
-- not necessarily "0 = east, CCW" like atan2 assumes, so the delta was
-- systematically off by a rotation/reflection and the strafe wandered
-- instead of converging. SSD's rear_facing_plan works because it compares
-- TWO raw headings -- same frame regardless of what that frame is.)
--
-- Returns nil when either position is unreadable. Otherwise:
--   { delta_rad, key }  key = 'a' | 'd' | 'none'
-- 'none' = within SLEEP_STRAFE_TOL_RAD, fire directly.
local SLEEP_STRAFE_INVERT   = false
local SLEEP_STRAFE_TOL_RAD  = math.rad(10)   -- ~10 degrees, per spec

local function normalize_angle_pi(a)
    while a >   math.pi do a = a - 2 * math.pi end
    while a <= -math.pi do a = a + 2 * math.pi end
    return a
end

-- Behind-the-mob detection. When we're behind the mob (locked on it), our
-- heading and the mob's heading point in the SAME direction: the mob's
-- front is away from us, our facing points at the mob, both "look forward"
-- the same way. Delta = mob_heading - player_heading; |delta| < tolerance
-- means we're behind. Otherwise strafe A/D to close the gap.
--
-- Returns nil if either heading isn't readable. Otherwise:
--   { delta_rad, key }  key = 'a' | 'd' | 'none'
local REAR_STRAFE_INVERT = false
local REAR_TOL_RAD       = math.rad(10)

function GeneralLua.utils.rear_facing_plan(mob_idx)
    mob_idx = tonumber(mob_idx or 0) or 0
    if mob_idx == 0 then return nil end

    local ply = GeneralLua.utils.get_player_entity()
    local ph  = entity_heading(ply)
    if ph == nil then return nil end

    local mob = GeneralLua.utils.get_entity(mob_idx)
    if not mob then return nil end
    local mh = entity_heading(mob)
    if mh == nil then return nil end

    local delta = normalize_angle_pi(mh - ph)
    if math.abs(delta) < REAR_TOL_RAD then
        return { delta_rad = delta, key = 'none' }
    end

    -- Same sign convention as sleep_facing_plan. Flip REAR_STRAFE_INVERT
    -- if we orbit the wrong way.
    local key
    if delta > 0 then
        key = REAR_STRAFE_INVERT and 'd' or 'a'
    else
        key = REAR_STRAFE_INVERT and 'a' or 'd'
    end
    return { delta_rad = delta, key = key }
end

function GeneralLua.utils.sleep_facing_plan(pivot_idx, sleep_idx)
    pivot_idx = tonumber(pivot_idx or 0) or 0
    sleep_idx = tonumber(sleep_idx or 0) or 0
    if pivot_idx == 0 or sleep_idx == 0 then return nil end

    local px, py = GeneralLua.utils.player_position()
    if px == nil or py == nil then return nil end

    local pivot = GeneralLua.utils.get_entity(pivot_idx)
    if not pivot then return nil end
    local cx, cy = entity_position(pivot)
    if cx == nil then return nil end

    local sleep = GeneralLua.utils.get_entity(sleep_idx)
    if not sleep then return nil end
    local sx, sy = entity_position(sleep)
    if sx == nil then return nil end

    -- Two directions from the player, both via atan2 -- same reference
    -- frame guaranteed. When they match, the pivot is between us and the
    -- sleep mob on a straight line (with pivot in front).
    local dcx, dcy = cx - px, cy - py
    local dsx, dsy = sx - px, sy - py
    if (dcx*dcx + dcy*dcy) < 0.01 then return nil end   -- on the pivot
    if (dsx*dsx + dsy*dsy) < 0.01 then return nil end   -- on the sleep mob

    local angle_to_pivot = math.atan2(dcy, dcx)
    local angle_to_sleep = math.atan2(dsy, dsx)
    local delta = normalize_angle_pi(angle_to_sleep - angle_to_pivot)

    if math.abs(delta) < SLEEP_STRAFE_TOL_RAD then
        return { delta_rad = delta, key = 'none' }
    end

    -- delta > 0 = sleep is CCW of pivot from player's view. To bring the
    -- pivot back onto the line to sleep, orbit CW around pivot ("right"
    -- relative to locked target = D). If it strafes the wrong way in
    -- practice, flip SLEEP_STRAFE_INVERT.
    local key
    if delta > 0 then
        key = SLEEP_STRAFE_INVERT and 'a' or 'd'
    else
        key = SLEEP_STRAFE_INVERT and 'd' or 'a'
    end
    return { delta_rad = delta, key = key }
end

function GeneralLua.utils.entity_distance(ent)
    return entity_distance(ent)
end

function GeneralLua.utils.entity_claim_id(ent)
    return entity_claim_id(ent)
end

function GeneralLua.utils.entity_server_id(ent)
    return entity_server_id(ent)
end

function GeneralLua.utils.entity_index(ent)
    return entity_index(ent)
end

function GeneralLua.utils.is_valid_mob(index)
    return is_valid_mob(index)
end

function GeneralLua.utils.entity_hp_percent_sane(ent)
    return entity_hp_percent_sane(ent)
end

function GeneralLua.utils.claim_is_party_or_free(claim_id)
    return claim_is_party_or_free(claim_id)
end

function GeneralLua.utils.get_party_member_ids()
    return get_party_member_ids()
end

---------------------------------------------------------------------
-- ACTIONS
---------------------------------------------------------------------

function GeneralLua.actions.ja(name, target, dispatch)
    return dispatch('/ja "' .. tostring(name) .. '" ' .. tostring(target), 1.0)
end

function GeneralLua.actions.pet(name, target, dispatch)
    return dispatch('/pet "' .. tostring(name) .. '" ' .. tostring(target), 1.0)
end

function GeneralLua.actions.ws(name, target, dispatch)
    return dispatch('/ws "' .. tostring(name) .. '" ' .. tostring(target), 1.0)
end

function GeneralLua.actions.cast(spell, target, dispatch, gate_time)
    spell = tostring(spell or '')
    target = tostring(target or '<t>')
    if spell == '' then
        return false
    end

    local cmd = '/ma "' .. spell .. '" ' .. target
    return dispatch(cmd, gate_time or 1.0)
end

function GeneralLua.actions.ranged(dispatch)
    return dispatch('/ra <t>', 1.0)
end

function GeneralLua.actions.item(name, target, dispatch)
    name = tostring(name or '')
    target = tostring(target or '<me>')
    if name == '' then
        return false
    end
    return dispatch('/item "' .. name .. '" ' .. target, 1.0)
end

---------------------------------------------------------------------
-- RUNTIME
---------------------------------------------------------------------

local function zoning_state(state)
    state.zoning = state.zoning or {
        active = false,
        waiting_for_finish_text = false,
        pause_until = 0.0,
        started_at = 0.0,
    }
    return state.zoning
end

function GeneralLua.runtime.enter_zoning(state, current_time)
    local z = zoning_state(state)
    local tnow = tonumber(current_time or 0.0) or now_sec()

    if z.active == true then
        return
    end

    z.active = true
    z.waiting_for_finish_text = false
    z.pause_until = tnow + GeneralLua.timing.zoning_wait_before_finish_sec
    z.started_at = tnow
end

function GeneralLua.runtime.finish_zoning(state, current_time)
    local z = zoning_state(state)
    if z.active ~= true then return end

    local tnow = tonumber(current_time or 0.0) or now_sec()

    if z.waiting_for_finish_text ~= true then
        return
    end

    if tnow < n(z.pause_until) then
        return
    end

    z.active = false
    z.waiting_for_finish_text = false
    z.pause_until = 0.0
    z.started_at = 0.0
end

function GeneralLua.runtime.zoning_paused(state, current_time)
    local z = zoning_state(state)
    local tnow = tonumber(current_time or 0.0) or now_sec()

    if z.active ~= true then
        return false
    end

    if z.waiting_for_finish_text ~= true then
        if tnow < n(z.pause_until) then
            return true
        end

        z.waiting_for_finish_text = true
        return true
    end

    return true
end

local function runtime_is_gated(state, current_time)
    state.combat = state.combat or {}
    return current_time < n(state.combat.gate_until)
end

-- Returns ok, reason. The REASON is the point: 'false' collapses four very
-- different outcomes into one word, and a caller logging plain FAIL next to a
-- shot that visibly landed sends you hunting a bug that is not there. The
-- common one by far is 'gated' -- another action already went out this
-- window and this one was correctly suppressed, which is the system working.
--
-- Extra return values are ignored by existing callers, so this stays
-- backwards compatible with every `if dispatch(...) then` in the tree.
function GeneralLua.dispatch(state, command_text, gate_time, send_cmd)
    if type(command_text) ~= 'string' or command_text == '' then
        return false, 'empty command'
    end

    if type(send_cmd) ~= 'function' then
        return false, 'no sender'
    end

    state.combat = state.combat or {}

    local current_time = now_sec()
    if runtime_is_gated(state, current_time) then
        local until_t = tonumber(state.combat.gate_until or 0) or 0
        return false, ('gated %.2fs'):format(math.max(0, until_t - current_time))
    end

    local sent = (send_cmd(command_text) == true)
    if not sent then
        return false, 'sender refused (blocked command?)'
    end

    state.combat.gate_until = math.max(
        n(state.combat.gate_until),
        current_time + math.max(0, n(gate_time))
    )

    return true, 'sent'
end

function GeneralLua.runtime.refresh_live_state(state)
    set_state_ref(state)

    state.live = state.live or {}
    state.combat = state.combat or {}
    state.flags = state.flags or {}

    -- Sleep Other LoS attribution. Must run EVERY tick, not just when a
    -- ranged round comes up: the "You cannot see the X." line arrives a
    -- moment after the shot, and if nothing is watching for it the mob
    -- never gets blacklisted and we shoot the same wall forever.
    state.debug = state.debug or {}
    state.all_claimed_targets = state.all_claimed_targets or T{}
    state.last_action_ts = state.last_action_ts or {}

    MainMagic.ensure_spell_state(state)

    -- Completion-driven last-cast recording. MainMagic.spell_confirm stamps
    -- last_confirmed_spell + last_confirmed_spell_at when a cast COMPLETES
    -- (packet 'action' path or the chat-line 'X casts Y', both success-only;
    -- interrupted casts never reach spell_confirm). We watch the timestamp
    -- and record on change, so Protect/Shell/Utsusemi tracking fires for
    -- bot, manual, AND menu casts -- on completion, never on cast start.
    do
        local at = tonumber(state.combat.last_confirmed_spell_at or 0) or 0
        local prev = tonumber(state.combat._recorded_confirm_at or 0) or 0
        if at > 0 and at ~= prev then
            state.combat._recorded_confirm_at = at
            ps_record_cast_tier(state, state.combat.last_confirmed_spell)
        end
    end

    if not state.cached_player_name or not state.cached_player_pat then
        local ok, player = pcall(GetPlayerEntity)
        if ok and player and type(player.Name) == 'string' and #player.Name > 0 then
            state.cached_player_name = player.Name
            state.cached_player_pat = player.Name:lower():gsub('([^%w])', '%%%1')
        end
    end

    local current_time = now_sec()

    if state.combat.spell_locked ~= true and state.combat.is_casting == true then
        state.combat.spell_locked = true
        if n(state.combat.spell_started_at) <= 0 then
            state.combat.spell_started_at = current_time
        end
    end

    if state.combat.is_casting ~= true and n(state.combat.spell_lock_until) > current_time then
        state.combat.spell_locked = true
        if n(state.combat.spell_started_at) <= 0 then
            state.combat.spell_started_at = current_time
        end
    end

    GeneralLua.runtime.refresh_spell_timeout(state, current_time)

    local pet_hp = GeneralLua.utils.player_pet_hp()
    local mobs_attacking, nearest_hate_distance, nearest_hate_idx, nearest_hate_sid = compute_under_attack(state)

    local player_status = GeneralLua.utils.player_status()
    if player_status == nil then
        GeneralLua.runtime.enter_zoning(state, current_time)
    else
        -- Player entity is back. If we were holding a zoning lock, clear it
        -- unconditionally - waiting for "finish text" deadlocks the bot when
        -- the gate was triggered by logout (no zone-finish text ever arrives).
        local z = state.zoning
        if z and z.active == true then
            z.active = false
            z.waiting_for_finish_text = false
            z.pause_until = 0.0
            z.started_at = 0.0
        end
    end

    local target_ent = GeneralLua.utils.current_target()
    local target_sid = get_target_server_id()
    local packet_target_debuff_ids = get_packet_target_debuff_ids(state, target_sid)
    local packet_target_debuff_updated_at = get_packet_target_debuff_updated_at(state, target_sid)
    local packet_target_debuff_names = get_packet_target_debuff_names(state, target_sid)

    local px, py, pz = GeneralLua.utils.player_position()
    local tx, ty, tz = entity_position(target_ent)

    -- Stash previous tick's target HP so we can detect "HP was positive, now nil/0".
    -- Use a stable history per server_id so swapping targets doesn't false-positive.
    state.live.player_target_hp_prev      = state.live.player_target_hp
    state.live.player_target_sid_prev     = state.live.player_target_server_id

    state.live.player_status              = player_status
    state.live.player_hp                  = player_hp_percent()
    state.live.player_mp                  = player_mp_percent()
    state.live.player_mp_raw              = player_mp_raw()
    state.live.player_tp                  = GeneralLua.utils.player_tp()
    state.live.player_target_distance     = GeneralLua.utils.target_distance()
    state.live.player_target_hp           = GeneralLua.utils.current_target_hp()
    state.live.player_target_server_id    = target_sid
    state.live.player_target_claim_id     = entity_claim_id(target_ent)
    state.live.player_target_index        = entity_index(target_ent)
    -- Target NAME as well as index. text_parser has no entity handle of its
    -- own and needs the name to tell a burrowing worm from a genuinely
    -- unattackable target -- see the worm branch on the "cannot attack" line.
    state.live.player_target_name         = (target_ent and target_ent.Name) or nil
    state.live.player_target_valid        = GeneralLua.utils.current_target_valid()
    state.live.target_debuff_updated_at   = packet_target_debuff_updated_at
    state.live.target_debuff_ids          = packet_target_debuff_ids
    state.live.target_debuff_names        = packet_target_debuff_names
    state.live.player_shadow_count        = HbShadows.shadow_count(state)
    HbShadows.tick_shadow_cancel(state)
    state.live.player_pet_hp              = pet_hp
    state.live.player_pet_present         = (pet_hp ~= nil and pet_hp > 0)
    state.live.player_pet_ready_charges   = state.live.player_pet_present
                                            and GeneralLua.utils.player_pet_ready_charges()
                                            or 0
    if not state.live.player_pet_present then
        -- No pet -> drop any stale pet target so PET_FIGHT (and similar) can re-fire on next pet.
        state.live.player_pet_target_server_id = nil
    end
    state.live.is_player_casting          = (state.combat.spell_locked == true) or (state.combat.is_casting == true)
    state.live.mobs_attacking             = mobs_attacking
    state.live.nearest_hate_distance      = nearest_hate_distance
    state.live.nearest_hate_index         = nearest_hate_idx
    state.live.nearest_hate_server_id     = nearest_hate_sid
    state.live.player_x                   = px
    state.live.player_y                   = py
    state.live.player_z                   = pz
    state.live.target_x                   = tx
    state.live.target_y                   = ty
    state.live.target_z                   = tz

    -- Live diagnostic for "why isn't Call Beast firing?". This mirrors the
    -- atk_list eligibility logic so the debug panel shows status every tick,
    -- not just at swing-edges.
    do
        local cfg_callbeast = config_get_from_state(state, 'auto.callbeast')
        local engaged = (state.live.player_status == GeneralLua.status.ENGAGED)
        local pet_present = (state.live.player_pet_present == true)
        local ready = GeneralLua.cooldowns.is_ready('CALL_BEAST')
        local left_at = GeneralLua.cooldowns.abilities['CALL_BEAST']
        local left = (left_at == nil) and 0 or math.max(0, left_at - now_sec())

        local reason
        if not cfg_callbeast then
            reason = 'toggle off'
        elseif not engaged then
            reason = 'not engaged'
        elseif pet_present then
            reason = 'pet already out'
        elseif not ready then
            reason = string.format('on cooldown (%ds left)', math.floor(left + 0.5))
        else
            reason = 'ready'
        end
        state.live.callbeast_reason = reason
        state.live.callbeast_recast_left = left
    end

    MainMagic.refresh_mob_debuff_state(
        state,
        GeneralLua.utils.get_entity,
        target_manager
    )
end

function GeneralLua.runtime.build_ctx(state, dispatch)
    set_state_ref(state)

    state.live = state.live or {}
    state.combat = state.combat or {}
    state.flags = state.flags or {}
    state.last_action_ts = state.last_action_ts or {}

    MainMagic.ensure_spell_state(state)

    local target_hp = state.live.player_target_hp
    -- target_dead is true if any of these signal death:
    --   1. HP is readable as 0
    --   2. HP went from positive -> nil/0 on the SAME server_id (HP-drop transition)
    --   3. Target became invalid AND we have no distance reading
    -- (The HP-drop case catches the most common scenario: game clears your
    -- target instantly on death, so target_hp goes nil while target_sid may
    -- still be the same for a frame.)
    local target_valid = (state.live.player_target_valid == true)
    local hp_prev = state.live.player_target_hp_prev
    local sid_prev = state.live.player_target_sid_prev
    local sid_now = tonumber(state.live.player_target_server_id or 0) or 0
    local hp_dropped = (sid_prev ~= nil and sid_prev == sid_now and sid_now ~= 0
                        and (tonumber(hp_prev or 0) or 0) > 0
                        and (target_hp == nil or (tonumber(target_hp) or 0) <= 0))
    local target_dead = (target_hp ~= nil and target_hp <= 0)
                        or hp_dropped
                        or (not target_valid and state.live.player_target_distance == nil)
    local player_hp = tonumber(state.live.player_hp or 0) or 0
    local player_mp = tonumber(state.live.player_mp or 0) or 0
    local target_sid = tonumber(state.live.player_target_server_id or 0) or 0
    local target_claim_id = tonumber(state.live.player_target_claim_id or 0) or 0
    local target_debuff_updated_at = tonumber(state.live.target_debuff_updated_at or 0.0) or 0.0

    local ctx = {
        job_info                  = GeneralLua.utils.get_effective_job_info(),
        tp                        = state.live.player_tp or 0,
        dist                      = state.live.player_target_distance,
        target_distance           = state.live.player_target_distance,
        target_hp                 = target_hp,
        target_dead               = target_dead,
        target_valid              = target_valid,
        target_claim_id           = target_claim_id,
        target_claim_free_or_party= claim_is_party_or_free(target_claim_id),
        player_hp                 = state.live.player_hp,
        player_mp                 = state.live.player_mp,
        target_server_id          = target_sid,
        target_debuff_updated_at  = target_debuff_updated_at,
        target_debuff_ids         = state.live.target_debuff_ids or T{},
        target_debuff_names       = state.live.target_debuff_names or T{},
        engaged01                 = (state.live.player_status == GeneralLua.status.ENGAGED) and 1 or 0,
        resting01                 = (state.live.player_status == GeneralLua.status.RESTING) and 1 or 0,
        pet_present               = (state.live.player_pet_present == true),
        pet_hp                    = tonumber(state.live.player_pet_hp or 0) or 0,
        pet_target_server_id      = tonumber(state.live.player_pet_target_server_id or 0) or 0,
        pet_engaged               = (tonumber(state.live.player_pet_target_server_id or 0) or 0) ~= 0,
        pet_ready_charges         = tonumber(state.live.player_pet_ready_charges or 0) or 0,
        hp_emerg                  = (player_hp > 0 and player_hp < 10),
        ranged_no_weapon          = (state.flags.player_ranged_no_weapon == true),
        acid_bolt_equipped        = (state.live.acid_bolt_equipped == true),
        acid_bolt_available       = (state.live.acid_bolt_available == true),
        blood_bolt_equipped       = (state.live.blood_bolt_equipped == true),
        blood_bolt_available      = (state.live.blood_bolt_available == true),
        blind_bolt_equipped       = (state.live.blind_bolt_equipped == true),
        blind_bolt_available      = (state.live.blind_bolt_available == true),
        sleep_ammo_name           = tostring(state.live.sleep_ammo_name or ''),
        sleep_ammo_equipped       = (state.live.sleep_ammo_equipped == true),
        sleep_ammo_available      = (state.live.sleep_ammo_available == true),

        player_x                  = state.live.player_x,
        player_y                  = state.live.player_y,
        player_z                  = state.live.player_z,
        target_x                  = state.live.target_x,
        target_y                  = state.live.target_y,
        target_z                  = state.live.target_z,
    }

    -- spells_locked is the OR of the REAL cast lock (armed on
    -- detection, held for the cast duration) and the short dispatch
    -- guard (armed at send time, self-expiring). Every gate that reads
    -- ctx.spells_locked / spells_locked_soft is thus blocked during BOTH
    -- the post-send gap (so we don't double-fire before "starts casting"
    -- arrives) and the confirmed cast itself.
    -- A cast in progress (ours OR a manually/menu-cast spell the text
    -- parser detected via 'starts casting') must block both ladders so we
    -- never stack a def/atk cast on top of an active cast. We check three
    -- independent signals rather than relying on the spell_locked
    -- reconciliation having already run this frame:
    --   * spell_locked   -- the reconciled real lock
    --   * is_casting     -- set the instant 'starts casting' is parsed
    --   * spell_lock_until in the future -- covers the sized cast window
    local now_t = now_sec()
    local real_locked = (state.combat.spell_locked == true)
        or (state.combat.is_casting == true)
        or (n(state.combat.spell_lock_until) > now_t)
    local guard_active = dispatch_guard_active(state)
    ctx.spells_locked = real_locked or guard_active
    ctx.spells_locked_soft = ctx.spells_locked
    -- ws_blocked covers two things: the generic per-dispatch gate, AND the
    -- post-weaponskill animation/lockout window. The WS recovery is longer
    -- than the 1.0s dispatch gate, so casting (e.g. Stone) right after a WS
    -- hit the server lockout. Block for ws_post_block_sec after a WS.
    local ws_last_kind = state.combat.last_attempted_action_kind
    local ws_last_at   = tonumber(state.combat.last_attempted_action_at or 0) or 0
    local ws_block_dur = tonumber(GeneralLua.timing.ws_post_block_sec or 2.5) or 2.5
    local in_ws_post   = (ws_last_kind == 'ws') and ((now_t - ws_last_at) < ws_block_dur)
    ctx.ws_blocked = runtime_is_gated(state, now_sec()) or in_ws_post

    ctx.cfgget = function(path)
        return config_get_from_state(state, path)
    end

    ctx.is_ready = function(id)
        return GeneralLua.cooldowns.is_ready(id)
    end

    -- Provoke per-mob tracking. "Claim mode" (high HP threshold) wants to voke
    -- exactly once per mob; we remember the SID of the last successful voke and
    -- gate the eligibility on that. Sustain modes (50%/25%) don't need this
    -- because the HP threshold itself stops the loop, but harmless to expose.
    do
        local voke_last_sid = tonumber(state.live.voke_last_sid or 0) or 0
        ctx.voke_already_done_on_target =
            (target_sid > 0) and (voke_last_sid > 0) and (voke_last_sid == target_sid)
    end

    ctx.mark_target_voked = function(sid)
        local s = tonumber(sid or 0) or 0
        if s > 0 then
            state.live.voke_last_sid = s
        end
    end

    ctx.target_has_debuff = function(name)
        return target_has_packet_debuff_name(state, target_sid, name)
    end

    -- Any DoT / periodic-damage debuff on the target breaks sleep on the next
    -- tick, so there's no point sleeping a mob that already has one. Reads the
    -- same live id list the target panel shows. Ids: poison 3, elemental DoTs
    -- 128-133, dia 134, bio 135, helix 186.
    ctx.target_has_waking_dot = function()
        local ids = state.live and state.live.target_debuff_ids
        if type(ids) ~= 'table' then return false end
        for i = 1, #ids do
            local id = tonumber(ids[i] or -1) or -1
            if id == 3 or id == 134 or id == 135 or id == 186
               or (id >= 128 and id <= 133) then
                return true
            end
        end
        return false
    end

    -- True when a shadow spell (Ni or Ichi) is actually ready to cast right
    -- now. If both are on cooldown this is false, so there's no reason to
    -- spend a sleep bolt.
    ctx.shadow_recast_ready = function()
        return HbShadows.shadow_command(state, 0) ~= nil
    end

    ctx.buff_active = function(name)
        if not name then return false end
        local lname = name:lower()
        -- Use the multi-source buff scan so private buffs (Warcry, Berserk,
        -- Hasso, Seigan, Third Eye...) are seen. Entity.Buffs alone is the
        -- broadcast list and misses these.
        local ids = collect_player_buff_ids()
        for i = 1, #ids do
            local bname = TARGET_DEBUFF_NAMES[ids[i]]
            if bname and bname:lower() == lname then return true end
        end
        return false
    end

    ctx.mob_claim_is_party_or_free = function(ent_or_claim)
        if type(ent_or_claim) == 'table' then
            return claim_is_party_or_free(entity_claim_id(ent_or_claim))
        end
        return claim_is_party_or_free(ent_or_claim)
    end

    ctx.current_target_valid = function()
        return state.live.player_target_valid == true
    end

    MainMagic.attach_ctx(
        ctx,
        state,
        dispatch,
        GeneralLua.actions,
        GeneralLua.cooldowns,
        normalize_action_name_for_map,
        GeneralLua.timing
    )

    do
        -- Mob-debuff readiness. DebuffHandler is the live source of truth
        -- for whether the debuff is on the mob right now (reads action
        -- packets; the complex handler tracks spell AND weapon-skill
        -- debuffs). The in-flight pending check below stops a double-cast
        -- in the 1-2s window between /ma send and the apply packet landing.
        -- Every debuff spell the ladder can fire must be present in
        -- SPELL_DEBUFF_PACKET_NAME or it returns ready=true unconditionally
        -- (which is wrong; add the entry).
        ctx.mob_debuff_ready = function(id)
            local key = tostring(id or ''):upper()
            local packet_name = SPELL_DEBUFF_PACKET_NAME[key]

            -- If the mob currently shows the debuff, not ready -- full stop.
            if packet_name and ctx.target_has_debuff
               and ctx.target_has_debuff(packet_name) then
                return false
            end

            -- Debuff is absent. The only remaining reason to hold is an
            -- in-flight cast we haven't seen resolve yet.
            local md = state.combat and state.combat.mob_debuffs
            if md == nil then return false end
            if md.first_atk_seen ~= true then return false end
            if n(md.target_server_id) == 0 and n(md.target_index) == 0 then
                return false
            end
            if md.pending and md.pending.id == key then
                local sent_at = tonumber(md.pending.sent_at or 0.0) or 0.0
                -- A pending cast newer than 12s is still "in flight";
                -- older than that is stale and ignored (the action packet
                -- was lost / the cast failed silently).
                if sent_at > 0.0 and (now_sec() - sent_at) <= 12.0 then
                    return false
                end
            end
            return true
        end
    end

    do
        local ws_hp = n(config_get_from_state(state, 'ws_hp'))
        ctx.ws_hp_ok = not (ws_hp > 0 and target_hp ~= nil) or n(target_hp) >= ws_hp
    end

    -- SC partner coordination. Two independent roles:
    --   OPEN  (auto.ws_sc_open):  allowed when partner holds 1000+ TP --
    --                             we fire first, they close on us.
    --   CLOSE (auto.ws_sc_close): allowed within 5s of the partner's WS
    --                             (party_ws_at stamped by packet_parser
    --                             from the type-3 action packet).
    -- ctx.sc_gate_active tells the WS entry whether to gate at all;
    -- ctx.sc_ws_allowed is the verdict. Empty partner name -> not gated
    -- (a half-configured toggle shouldn't silently kill all WS).
    do
        local open_on  = config_get_from_state(state, 'auto.ws_sc_open')  == true
        local close_on = config_get_from_state(state, 'auto.ws_sc_close') == true
        local partner  = tostring(config_get_from_state(state, 'ws_sc_partner') or ''):lower()

        ctx.sc_gate_active = (open_on or close_on) and partner ~= ''
        ctx.sc_ws_allowed = false

        if ctx.sc_gate_active then
            -- OPEN: partner TP via party memory (slots 1-5).
            if open_on then
                local party = party_manager()
                if party and type(party.GetMemberName) == 'function' then
                    for i = 1, 5 do
                        local nm = tostring(party:GetMemberName(i) or ''):lower()
                        if nm ~= '' and nm == partner then
                            local ok, tp = pcall(function()
                                return tonumber(party:GetMemberTP(i) or 0) or 0
                            end)
                            if ok and tp >= 1000 then
                                ctx.sc_ws_allowed = true
                            end
                            break
                        end
                    end
                end
            end
            -- CLOSE: partner WS'd -- but the skillchain window doesn't open
            -- until ~3s after their WS, so firing instantly breaks the
            -- chain. Allowed window: 3.0s to 5.0s after their WS packet.
            if close_on and not ctx.sc_ws_allowed then
                local map = state.combat.party_ws_at
                local ws_at = map and tonumber(map[partner] or 0) or 0
                if ws_at > 0 then
                    local since = now_sec() - ws_at
                    if since >= 3.0 and since <= 5.0 then
                        ctx.sc_ws_allowed = true
                    end
                end
            end
        end
    end

    do
        local jump_hp = n(config_get_from_state(state, 'jump_hp'))
        ctx.jump_hp_ok = not (jump_hp > 0 and target_hp ~= nil) or n(target_hp) >= jump_hp
    end

    do
        local hb_hp = n(config_get_from_state(state, 'hb_hp'))
        ctx.hb_hp_ok = (hb_hp > 0 and player_hp > 0 and player_hp <= hb_hp) or false
    end

    do
        local cure_hp = n(config_get_from_state(state, 'cure_hp'))
        ctx.cure_hp_ok = (cure_hp > 0 and player_hp > 0 and player_hp <= cure_hp) or false
    end

    -- Lowest HP% across all active party members (used for HB_PARTY / party cure)
    do
        local party = party_manager()
        local min_hp = nil
        local hb_party_hp    = n(config_get_from_state(state, 'hb_party_hp'))
        local HB_RANGE_YALMS = 10.0
        local low_hp_in_range_count = 0

        if party and type(party.GetMemberHPPercent) == 'function' then
            -- Scan all 18 alliance slots so we don't miss own-party members
            -- that happen to be assigned to higher slot indices in some cases.
            -- Then explicitly exclude alliance parties: HB only heals your own
            -- party (alliance number 0). If GetMemberAllianceNumber isn't
            -- exposed in this Ashita build, fall back to the strict 0-5 range.
            local has_alliance_fn = type(party.GetMemberAllianceNumber) == 'function'
            for i = 0, 17 do
                local active = tonumber(party:GetMemberIsActive(i) or 0) or 0
                if active == 1 then
                    -- Own-party gate: alliance 0, or fallback to slots 0-5.
                    local own_party = false
                    if has_alliance_fn then
                        local ok, an = pcall(function() return party:GetMemberAllianceNumber(i) end)
                        an = ok and tonumber(an) or nil
                        own_party = (an == 0)
                    else
                        own_party = (i <= 5)
                    end

                    if own_party then
                        local ok, v = pcall(function() return party:GetMemberHPPercent(i) end)
                        local hp = ok and tonumber(v) or nil
                        if hp ~= nil and hp > 0 then
                            if min_hp == nil or hp < min_hp then
                                min_hp = hp
                            end

                            -- Range check: only count low-HP members within HB range
                            if hb_party_hp > 0 and hp < hb_party_hp then
                                local in_range = false
                                if i == 0 then
                                    -- Self is always in range of own wyvern
                                    in_range = true
                                elseif type(party.GetMemberTargetIndex) == 'function' then
                                    local ok2, tidx = pcall(function()
                                        return party:GetMemberTargetIndex(i)
                                    end)
                                    tidx = ok2 and tonumber(tidx) or nil
                                    if tidx and tidx > 0 then
                                        local ent = GeneralLua.utils.get_entity(tidx)
                                        local dist = ent and entity_distance(ent)
                                        in_range = dist ~= nil and dist <= HB_RANGE_YALMS
                                    end
                                end
                                if in_range then
                                    low_hp_in_range_count = low_hp_in_range_count + 1
                                end
                            end
                        end
                    end
                end
            end
        end
        ctx.party_hp_min = min_hp

        ctx.hb_party_hp_ok = (hb_party_hp > 0 and min_hp ~= nil and min_hp > 0 and min_hp < hb_party_hp)
            and (low_hp_in_range_count > 0)
    end

    local player_dead =
        state.live.player_status == GeneralLua.status.DEAD1 or
        state.live.player_status == GeneralLua.status.DEAD2

    ctx.player_dead = player_dead

    -- Status effects that block magic casting. Any of these means a
    -- /ma will be silently rejected by the game, so HB must not even
    -- attempt (an attempt would otherwise sit waiting on the lock /
    -- retry gate for no reason).
    --   2  sleep        7  petrify     14 charm        28 terror
    --   6  silence      10 stun        19 sleep II
    -- (amnesia/16 blocks abilities not magic; mute/29 blocks songs)
    local player_incapacitated = player_buff_active({ 2, 6, 7, 10, 14, 19, 28 })

    -- MP floor. state.live.player_mp is a PERCENT (set from
    -- player_mp_percent() at refresh). 0 means no MP for any trigger
    -- spell regardless of which one hb_command would pick.
    local player_mp_pct = tonumber(state.live.player_mp or 0) or 0
    local player_has_mp = player_mp_pct > 0

    -- Post-weaponskill lockout. The WS animation runs ~1.5-2.5s and
    -- the game rejects magic during it. last_attempted_action_at is
    -- overwritten by the next action of any kind, so this naturally
    -- clears the instant anything else (melee swing record, JA, the
    -- next confirmed spell) posts -- it only blocks the immediate
    -- post-WS window, it does not linger into sustained combat.
    local last_kind = state.combat.last_attempted_action_kind
    local last_at   = tonumber(state.combat.last_attempted_action_at or 0) or 0
    local in_post_ws = (last_kind == 'ws') and ((now_sec() - last_at) < 2.5)

    ctx.hb_ready =
        (not player_dead) and
        (not player_incapacitated) and
        player_has_mp and
        (not in_post_ws) and
        (not ctx.target_dead) and
        (ctx.pet_present == true) and
        HbShadows.hb_ready(state, rawget(_G, 'Hb_list')) == true

    -- Party HB doesn't need a live target - just needs the wyvern and spell ready
    ctx.hb_ready_notarget =
        (not player_dead) and
        (not player_incapacitated) and
        player_has_mp and
        (not in_post_ws) and
        (ctx.pet_present == true) and
        HbShadows.hb_ready(state, rawget(_G, 'Hb_list')) == true

    ctx.shadows_can_attempt = function(mode, _ignore_gate)
        local max_shadows_before_recast = 1

        if ctx.target_dead then
            return false
        end

        if mode == 'pre_attack' or mode == 'idle' or mode == 'idle_post_stand' then
            max_shadows_before_recast = 0
        elseif mode == 'atk' or mode == 'def' then
            max_shadows_before_recast = 1
        end

        return HbShadows.shadows_ready(state, max_shadows_before_recast) == true
    end

    -- Current utsusemi shadow count (0-4). Sourced from state.live which
    -- HbShadows.shadow_count populated this frame in refresh_live_state.
    -- Exposed on ctx so list-side eligibility checks can defer to shadows
    -- (e.g. Blink skips when shadows are up or about to be cast).
    ctx.shadow_count = tonumber(state.live.player_shadow_count or 0) or 0

    -- Ranged gating exposed to list eligibility / the SSD button.
    ctx.ranged_busy = ranged_in_progress(state)
    -- Longer post-shot tail, WS only. Implies ranged_busy (wider window), so
    -- anything already gating on ranged_busy needs no change. The ladder
    -- table is built ABOVE where ranged_ws_locked is declared, so eligible()
    -- must read this ctx field and never call the local directly -- same
    -- upvalue trap that silently broke ranged_fired_at in the sleep branch.
    ctx.ranged_ws_busy = ranged_ws_locked(state)
    -- True only when a real bow/xbow/gun is equipped. Throwing isn't in
    -- weapon_db, so a stat stick (Hedgehog Bomb, Tiphia Sting) parked for
    -- its stats leaves this false -- that job isn't shooting, and /ra would
    -- otherwise throw the stick away one round at a time.
    ctx.ranged_weapon_ok = (state.live and state.live.ranged_weapon_ok) == true
    -- Set by idle_rest_engage from its auto-target blacklist. See the stamp
    -- site there for why it has to travel through state.live.
    ctx.target_blacklisted = (state.live and state.live.target_blacklisted) == true
    ctx.ra_ready    = GeneralLua.cooldowns.is_ready('RANGED')

    ctx.best_cure_spell    = get_best_spell_for_job(ctx.job_info, 'CURE')
    ctx.best_protect_spell = get_best_spell_for_job(ctx.job_info, 'PROTECT')
    ctx.best_shell_spell   = get_best_spell_for_job(ctx.job_info, 'SHELL')

    ctx.can_use_cure    = (ctx.best_cure_spell ~= nil)
    ctx.can_use_protect = (ctx.best_protect_spell ~= nil)
    ctx.can_use_shell   = (ctx.best_shell_spell ~= nil)

    -- Header button visibility capabilities.
    do
        local J = GeneralLua.jobs or {}
        local ji = ctx.job_info or {}
        local mj = tonumber(ji.mainJob or 0) or 0
        local sj = tonumber(ji.subJob or 0) or 0
        -- Full-Buff button: only meaningful for a job that casts the buff
        -- suite (WHM or RDM, main or sub).
        ctx.cap_full_buff = (mj == J.WHM or mj == J.RDM or sj == J.WHM or sj == J.RDM)
        -- Cast Shadows fallback: NIN main/sub at Lv12 (Utsusemi: Ichi).
        ctx.cap_shadows = ((mj == J.NIN and (tonumber(ji.mainLv or 0) or 0) >= 12)
                        or (sj == J.NIN and (tonumber(ji.subLv or 0) or 0) >= 12))
        -- Sleep/Sneak/Disengage button: THF main/sub Lv15 (Sneak Attack).
        local THF = J.THF or 6
        ctx.can_sneak_attack = ((mj == THF and (tonumber(ji.mainLv or 0) or 0) >= 15)
                             or (sj == THF and (tonumber(ji.subLv or 0) or 0) >= 15))
    end

    -- Sneak Attack readiness. Tracked from actual use (packet in packet_parser,
    -- text fallback in text_parser) as a 60s CD -- the game-recast read was
    -- unreliable. is_ready is true when the tracked CD has elapsed.
    ctx.sneak_attack_ready = function()
        return GeneralLua.cooldowns.is_ready('SNEAK_ATTACK')
    end
    ctx.trick_attack_ready = function()
        return GeneralLua.cooldowns.is_ready('TRICK_ATTACK')
    end

    -- Which enspell / spike the menu has selected -- i.e. which
    -- auto.en* / auto.*_spikes toggle is on. Full-Buff casts this one and
    -- overwrites whatever's active. Defaults when nothing is selected:
    -- Enthunder / Shock Spikes.
    ctx.chosen_enspell = function()
        local map = {
            { 'auto.enfire',     'Enfire'     },
            { 'auto.enblizzard', 'Enblizzard' },
            { 'auto.enaero',     'Enaero'     },
            { 'auto.enstone',    'Enstone'    },
            { 'auto.enwater',    'Enwater'    },
            { 'auto.enthunder',  'Enthunder'  },
        }
        for _, e in ipairs(map) do
            if ctx.cfgget(e[1]) == true then return e[2] end
        end
        return 'Enthunder'
    end
    ctx.chosen_spike = function()
        local map = {
            { 'auto.blaze_spikes', 'Blaze Spikes' },
            { 'auto.ice_spikes',   'Ice Spikes'   },
            { 'auto.shock_spikes', 'Shock Spikes' },
        }
        for _, e in ipairs(map) do
            if ctx.cfgget(e[1]) == true then return e[2] end
        end
        return 'Shock Spikes'
    end

    -- Find the tank in the party by name. Returns entity index and live
    -- position + heading (ground plane X,Y; heading via entity_heading).
    -- nil if unset / no match / entity table lacks their record right now.
    -- Case-insensitive whole-name match, same pattern as the SC partner
    -- lookup below.
    ctx.tank_entity = function()
        local nm = tostring(ctx.cfgget('thief.tank_name') or ''):lower()
        if nm == '' then return nil end
        local party = party_manager()
        if not party or type(party.GetMemberName) ~= 'function' then return nil end
        for i = 0, 17 do
            local mnm = tostring(party:GetMemberName(i) or ''):lower()
            if mnm ~= '' and mnm == nm then
                local idx = 0
                if type(party.GetMemberTargetIndex) == 'function' then
                    local ok, v = pcall(function() return party:GetMemberTargetIndex(i) end)
                    if ok then idx = tonumber(v or 0) or 0 end
                end
                if idx == 0 then return nil end
                local ent = GeneralLua.utils.get_entity(idx)
                if not ent then return nil end
                local tx, ty = entity_position(ent)
                local th     = entity_heading(ent)
                if tx == nil or th == nil then return nil end
                return { index = idx, x = tx, y = ty, heading = th, entity = ent }
            end
        end
        return nil
    end

    -- Thief movement lane. state.combat.thief_action is a single slot:
    -- only ONE thief action runs at a time (priority per spec: Sleep
    -- Other > Trick Attack > Sneak Attack; whichever started first
    -- finishes first). start_* stages the kind; tick_thief_action in
    -- idle_rest_engage progresses it and clears the slot when done.
    ctx.thief_movement_active = function()
        if state.combat.thief_action ~= nil then return true end
        if state.combat.sleep_facing_active_lane == true then return true end
        return false
    end

    ctx.start_sneak_only = function()
        if state.combat.thief_action ~= nil then return false end
        local tsid = tonumber(state.live.player_target_server_id or 0) or 0
        local tidx = tonumber(state.live.player_target_index or 0) or 0
        if tsid == 0 or tidx == 0 then return false end
        state.combat.thief_action = {
            kind       = 'sneak_only',
            phase      = 'align',
            started_at = now_sec(),
            target_sid = tsid,
            target_idx = tidx,
            fire_key   = 'none',
        }
        return true
    end

    ctx.start_trick_attack = function(with_ws)
        if state.combat.thief_action ~= nil then return false end
        local tsid = tonumber(state.live.player_target_server_id or 0) or 0
        local tidx = tonumber(state.live.player_target_index or 0) or 0
        if tsid == 0 or tidx == 0 then return false end
        local tank = ctx.tank_entity()
        if not tank then return false end
        state.combat.thief_action = {
            kind       = 'trick_attack',
            phase      = 'align_heading',
            started_at = now_sec(),
            target_sid = tsid,
            target_idx = tidx,
            tank_idx   = tank.index,
            with_ws    = (with_ws == true),
            fire_key   = 'none',
        }
        return true
    end

    -- Raw buff presence (any tier shares one status ID).
    ctx.self_protect_active = player_buff_active(BUFF_IDS.PROTECT)
    ctx.self_shell_active   = player_buff_active(BUFF_IDS.SHELL)

    -- Pro/Shell cast gate: dead simple -- read the buff. If the Protect/Shell
    -- buff is present, do NOT cast. If it's gone, cast. No tier tracking, no
    -- upgrade comparison: the old tier-aware gate recast whenever last_tier
    -- was 0 (unrecorded / post-reload / flaky completion), which spammed the
    -- spell and burned MP for no reason. Presence is the only signal we need.
    ctx.protect_should_cast = (ctx.best_protect_spell ~= nil) and (not ctx.self_protect_active)
    ctx.shell_should_cast   = (ctx.best_shell_spell ~= nil)   and (not ctx.self_shell_active)
    ctx.self_poison_active  = player_buff_active({ 3 })
    ctx.self_stoneskin_active = player_buff_active({ 37 })
    ctx.self_blink_active     = player_buff_active({ 36 })
    ctx.self_phalanx_active   = player_buff_active({ 116 })
    ctx.self_haste_active     = player_buff_active({ 33 })
    ctx.self_refresh_active   = player_buff_active({ 43 })
    ctx.self_thirdeye_active  = player_buff_active({ 67 })
    ctx.self_hasso_active     = player_buff_active({ 353 })
    ctx.self_seigan_active    = player_buff_active({ 354 })

    -- Collect ALL player buff IDs once per refresh from every available source.
    -- Use the list both for has_food and to render in the debug panel.
    ctx.player_buff_ids = collect_player_buff_ids()
    ctx.has_food        = player_has_buff_id(251, ctx.player_buff_ids)

    ctx.has_spell_mp = function(spell_name)
        local key = normalize_action_name_for_map(spell_name)
        local cost = SPELL_MP_COST[key]
        if cost == nil then return true end
        -- SPELL_MP_COST holds RAW MP costs (Cure=8, Cure IV=88, etc.),
        -- so compare against RAW current MP -- NOT state.live.player_mp,
        -- which is a 0-100 percentage. The old percent-vs-raw compare
        -- silently blocked expensive spells until MP% exceeded the cost
        -- number (Cure IV needed >88% MP to ever fire). If raw MP can't
        -- be read, fail open (return true) and let the game reject if
        -- genuinely short.
        local raw = state.live.player_mp_raw
        if raw == nil then return true end
        return (tonumber(raw) or 0) >= cost
    end

    ctx.do_ja = function(name, target, id)
        if ctx.target_dead then return false end
        local key = 'JA:' .. tostring(id or name or '?')
        if ctx.spells_locked then
            report_blocked_action(state, key, 'spells locked (casting)')
            return false
        end
        if ranged_in_progress(state) then
            report_blocked_action(state, key, 'ranged shot in progress')
            return false
        end

        if GeneralLua.actions.ja(name, target, dispatch) then
            local cd = 1.0
            if state.cooldown_id_map and state.cooldown_id_map[id] ~= nil then
                cd = tonumber(state.cooldown_id_map[id] or 1.0) or 1.0
            end

            GeneralLua.cooldowns.set(id, cd)

            state.combat.last_attempted_action_id = id
            state.combat.last_attempted_action_name = normalize_action_name_for_map(name)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'ability'

            return true
        end
        return false
    end

    ctx.do_pet = function(name, target, id)
        -- If we're targeting a mob (<t>/<bt>), bail when the mob is dead/gone.
        -- <me>-targeted pet commands (none currently used, but defensive) skip the gate.
        local tgt = tostring(target or '')
        local mob_targeted = (tgt == '<t>' or tgt == '<bt>' or tgt == 't' or tgt == 'bt')
        if mob_targeted and ctx.target_dead then return false end

        if GeneralLua.actions.pet(name, target, dispatch) then
            local cd = 1.0
            if state.cooldown_id_map and state.cooldown_id_map[id] ~= nil then
                cd = tonumber(state.cooldown_id_map[id] or 1.0) or 1.0
            end

            GeneralLua.cooldowns.set(id, cd)

            state.combat.last_attempted_action_id = id
            state.combat.last_attempted_action_name = normalize_action_name_for_map(name)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'ability'

            return true
        end
        return false
    end

    ctx.do_item = function(name, target, id)
        if not name or name == '' then return false end
        if GeneralLua.actions.item(name, target or '<me>', dispatch) then
            local cd = 1.0
            if state.cooldown_id_map and state.cooldown_id_map[id] ~= nil then
                cd = tonumber(state.cooldown_id_map[id] or 1.0) or 1.0
            end

            GeneralLua.cooldowns.set(id, cd)

            state.combat.last_attempted_action_id = id
            state.combat.last_attempted_action_name = normalize_action_name_for_map(name)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'item'

            return true
        end
        return false
    end

    ctx.do_ws = function()
        if ctx.target_dead then return false end
        -- Same guard do_ja / do_ra already carry, with the longer WS tail.
        -- do_ws was the only action helper without one, which is how the
        -- THF TA+WS phase (idle_rest_engage) could fire straight into a
        -- ranged recovery. That caller ignores the return value, so it holds
        -- on ctx.ranged_ws_busy itself before it ever reaches here -- this is
        -- the backstop for any future caller that forgets.
        if ranged_ws_locked(state) then
            report_blocked_action(state, 'WS', 'ranged recovery (post-shot)')
            return false
        end

        local ws_name = config_get_from_state(state, 'ws_name') or 'Double Thrust'

        -- Dagger-only overrides. Guarded on equipped skill so a non-dagger
        -- user with these toggled on doesn't fire a WS the weapon can't use.
        -- MP wins over Haste if both trigger.
        local mw_skill = state.live and state.live.main_weapon_skill
        if mw_skill == 'Dagger' then
            local mp_pct = tonumber(state.live and state.live.player_mp or 100) or 100
            local mp_override    = config_get_from_state(state, 'auto.ws_mp_override') == true
            local haste_override = config_get_from_state(state, 'auto.ws_haste_override') == true

            if mp_override and mp_pct < 50 then
                ws_name = 'Energy Steal'
            elseif haste_override and ctx.self_haste_active ~= true then
                ws_name = 'Energy Drain'
            end
        end

        if GeneralLua.actions.ws(ws_name, '<t>', dispatch) then
            -- Instrument the ATTEMPT, not the outcome. The stash is what
            -- text_parser's refusal handler reads to write the matching
            -- REJECT line, so a failure carries the tail it failed at.
            do
                local d, dstate = wsra_delta(state)
                state.combat.wsra_last_delta = d
                state.combat.wsra_last_state = dstate
                state.combat.wsra_last_ws    = ws_name
                state.combat.wsra_last_at    = now_sec()
                GeneralLua.utils.wsra_log(state, string.format(
                    'FIRE    ra_delta=%s  ra=%-8s ws=%-22s tp=%-5d dist=%s',
                    wsra_fmt(d),
                    tostring(dstate),
                    tostring(ws_name),
                    math.floor(tonumber(ctx.tp) or 0),
                    (ctx.dist and string.format('%.1f', ctx.dist) or '--')))
            end

            local cd = 1.0
            if state.cooldown_id_map and state.cooldown_id_map['WS'] ~= nil then
                cd = tonumber(state.cooldown_id_map['WS'] or 1.0) or 1.0
            end

            GeneralLua.cooldowns.set('WS', cd)

            state.combat.last_attempted_action_id = 'WS'
            state.combat.last_attempted_action_name = normalize_action_name_for_map(ws_name)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'ws'

            return true
        end
        return false
    end

    ctx.equip_ammo = function(name)
        local nm = tostring(name or '')
        if nm == '' then return false end
        -- Gates: never swap ammo when the last event's block would drop the
        -- follow-up /ra on the floor. `ranged_no_weapon` handled by do_ra so
        -- we don't spam a swap that will never fire. `spells_locked` covers
        -- an active cast; `ranged_in_progress` covers /ra in flight. Also
        -- don't swap to something already equipped.
        if state.flags.player_ranged_no_weapon then
            report_blocked_action(state, 'EQUIP:' .. nm, 'no ranged weapon')
            return false
        end
        if ctx.spells_locked then
            report_blocked_action(state, 'EQUIP:' .. nm, 'spells locked (casting)')
            return false
        end
        if ranged_in_progress(state) then
            report_blocked_action(state, 'EQUIP:' .. nm, 'ranged shot in progress')
            return false
        end
        if not GeneralLua.cooldowns.is_ready('RANGED') then
            report_blocked_action(state, 'EQUIP:' .. nm, '/ra on cooldown')
            return false
        end
        -- Already equipped? No-op (this is a common case).
        local cur = tostring(state.live and state.live.equipped_ammo_name or '')
        if cur:lower() == nm:lower() then
            return true
        end
        return dispatch('/equip ammo "' .. nm .. '"', 1.0)
    end

    -- Emergency sleep: if the sleep ammo isn't loaded, /equip it. Either way,
    -- /ra now. Same round, no timer, no pending. Shadows are cast once the
    -- shot resolves (see the reconcile pass).
    ctx.sleep_shot = function(name)
        local nm = tostring(name or '')
        if nm == '' then return false end
        if ctx.target_dead then return false end
        if not ctx.sleep_ammo_equipped then
            safe_send('/equip ammo "' .. nm .. '"')
        end
        safe_send('/ra <t>')
        state.combat.ranged_fired_at = now_sec()
        state.combat.ranged_cd_set = false
        state.combat.pending_ra_kind = 'sleep'

        -- Sleep-shadows fast path. The normal path waits for the sleep
        -- shot's action packet to resolve (ranged_resolved_at) before
        -- kicking off shadows, which can leave a gap long enough for the
        -- next auto-attack swing to wake the mob before Utsusemi lands.
        -- Instead, watch for the sleep debuff to appear on the mob (that's
        -- the ground truth), wait a short beat, and trigger shadows the
        -- same way every other shadow cast goes out (do_shadows -> dispatch).
        state.combat.sleep_shot_at         = now_sec()
        state.combat.sleep_shot_sid        = tonumber(target_sid or 0) or 0
        state.combat.sleep_shadows_fired   = false
        state.combat.sleep_debuff_seen_at  = 0.0
        return true
    end

    -- Auto Sleep/Sneak (THF): the SLEEP_SNEAK atk_list entry calls this
    -- after its eligibility gates pass. Fires sleep ammo at <t> and hands
    -- straight to the SSD pipeline at 'wait' -- SSD will confirm sleep
    -- landed within 5s, then disengage / walk rear / SA / /attack, or
    -- ssd_fail_engage if the sleep resists (which just /attacks the
    -- target and unpauses so combat continues normally).
    ctx.do_auto_sleep_sneak = function()
        local nm = tostring(ctx.sleep_ammo_name or '')
        if nm == '' then return false end
        if ctx.target_dead then return false end
        if not ctx.sleep_ammo_equipped then
            safe_send('/equip ammo "' .. nm .. '"')
        end
        safe_send('/ra <t>')
        state.combat.ranged_fired_at = now_sec()
        state.combat.ranged_cd_set   = false
        GeneralLua.runtime.ssd_start_from_wait(state)
        return true
    end

    ctx.mark_tool_missing = function(name)
        GeneralLua.runtime.mark_tool_missing(state, name)
    end
    ctx.tool_missing = function(name)
        return state.flags and state.flags.missing_tools
            and state.flags.missing_tools[tostring(name or '')] == true
    end

    -- Single decision for what the ranged ladder should do this tick.
    -- Priority: HP Drain (Bloody Bolts) > Def Down (Acid Bolts) > Blind
    -- (Blind Bolts). Returns one of:
    --   'blood'  -- HP drain on and below threshold; use Bloody Bolts
    --   'acid'   -- def down mode, debuff absent; use Acid Bolts
    --   'blind'  -- blind mode, debuff absent (after def down); Blind Bolts
    --   'normal' -- plain ranged with whatever ammo is loaded
    --   'hold'   -- all enabled debuffs already on the mob; don't fire
    --   'none'   -- an enabled mode's debuff is missing but no usable bolts
    -- SLEEP OTHER
    --
    -- With 2+ mobs on the hate list and Bloody Bolts NOT currently
    -- triggered, put a Sleep Bolt into the NEAREST mob that is not our
    -- current target, so we fight them one at a time. Returns
    -- sid, index, name -- or nil when it should not fire.
    --
    -- Priority: Bloody Bolts owns the ranged slot whenever it is latched.
    -- It is the emergency heal; sleeping an add is never more urgent than
    -- not dying. state.combat.hp_drain_active is the latch (see ranged_plan)
    -- so this reads the SAME boolean the bolts do -- no second opinion.
    --
    -- LoS blacklist: a mob we could not see gets parked until the current
    -- target dies. Retrying a wall every round is pure ammo waste, and the
    -- geometry will not change while we stand here fighting.
    ctx.sleep_other_target = function()
        if ctx.cfgget('ranged.sleep_other') ~= true then return nil end
        if state.combat and state.combat.hp_drain_active == true then return nil end

        -- MUST be able to actually fire before claiming the round.
        --
        -- This gate is the whole ballgame. eligible() lets RANGED through
        -- whenever this returns a target, and act() then owns the round --
        -- so if we hand back a mob we cannot shoot, act() falls through to
        -- the normal path, that path is often 'hold'/'none', and the round
        -- dies. Result: /ra silently stops firing forever. Exactly what a
        -- character with no Sleep Bolts in inventory saw.
        --
        -- sleep_ammo_name is '' with no bow/crossbow; sleep_ammo_available
        -- is equipped-or-in-inventory. Both must be good or we do not exist.
        if tostring(ctx.sleep_ammo_name or '') == '' then return nil end
        if ctx.sleep_ammo_available ~= true then return nil end

        local cur_sid = tonumber(ctx.target_server_id or 0) or 0

        state.combat = state.combat or {}

        -- Prune expired blacklist entries (populated by tick_sleep_facing
        -- when the strafe times out on a mob whose heading we can't match).
        local bl = state.combat.sleep_other_blacklist
        if bl ~= nil then
            local now = now_sec()
            for k, exp in pairs(bl) do
                if (tonumber(exp or 0) or 0) <= now then bl[k] = nil end
            end
        end

        local best_sid, best_idx, best_name, best_d = 0, 0, nil, nil
        local cnt, n_asleep, n_blacklist = 0, 0, 0
        for idx, v in pairs(state.all_claimed_targets or {}) do
            local ent = GeneralLua.utils.get_entity(idx)
            local hp  = entity_hp_percent_sane(ent)
            if v ~= nil and ent ~= nil and is_valid_mob(idx) and hp ~= nil and hp > 0 then
                cnt = cnt + 1
                local sid = tonumber(ent.ServerId) or 0
                -- skip: our target, already-blacklisted, already asleep
                if sid ~= 0 and sid ~= cur_sid then
                    -- Tally exclusions so the debug line can say WHICH of
                    -- "no 2nd mob / all asleep / all blacklisted" it is --
                    -- three very different problems that used to share one
                    -- unhelpful message.
                    if bl and bl[sid] then
                        n_blacklist = n_blacklist + 1
                    elseif sid_is_asleep(state, sid) then
                        n_asleep = n_asleep + 1
                    else
                        local d = entity_distance(ent)
                        if d and (best_d == nil or d < best_d) then
                            best_d, best_sid, best_idx = d, sid, idx
                            best_name = tostring(ent.Name or '?')
                        end
                    end
                end
            end
        end

        -- Needs an actual second mob. One mob on the list is just the fight.
        state.combat.sleep_dbg = ('%d on hate, %d asleep, %d blacklisted'):format(
            cnt, n_asleep, n_blacklist)
        if cnt < 2 or best_sid == 0 then return nil end
        return best_sid, best_idx, best_name, best_d
    end



    ctx.ranged_plan = function()
        -- Priority 1: HP Drain. When enabled and the player is below the
        -- chosen HP%, fire Bloody Bolts to drain -- this beats everything.
        -- Falls through if Bloody Bolts aren't available.
        --
        -- HYSTERESIS: engage at `thresh`, but keep firing until HP has
        -- recovered to `thresh + HP_DRAIN_HYSTERESIS` before releasing.
        -- A bare `hp < thresh` test oscillates: each drain tick pushes HP
        -- back over the line, the mode drops, HP falls under again, and
        -- the bolts flicker on/off around the boundary (and the ammo
        -- swaps with them). The latch means one clean engage and one
        -- clean release per dip.
        --   thresh 75 -> engage below 75, hold until 80, then off.
        if ctx.cfgget('ranged.hp_drain') then
            local thresh = tonumber(ctx.cfgget('ranged.hp_drain_hp') or 0) or 0
            local hp = tonumber(ctx.player_hp or 100) or 100
            local release = thresh + HP_DRAIN_HYSTERESIS

            local active = (state.combat.hp_drain_active == true)
            if thresh > 0 and hp > 0 then
                if active then
                    -- Only let go once we're clear of the release point.
                    if hp >= release then active = false end
                else
                    if hp < thresh then active = true end
                end
            else
                active = false
            end
            state.combat.hp_drain_active = active

            if active and ctx.blood_bolt_available then
                return 'blood'
            end
        else
            -- Mode switched off: drop the latch so re-enabling starts clean.
            state.combat.hp_drain_active = false
        end

        -- Priority 2: Sleep Other. Two+ mobs on the hate list and Bloody
        -- Bolts did not take the round -> put the shot into the OTHER mob
        -- instead of <t>. Same /ra round, different target: that is the
        -- whole feature. Bloody wins above because it is the emergency
        -- heal; def down / blind lose below because a second mob beating
        -- on us matters more than a debuff on the one we are already on.
        if ctx.sleep_other_target and ctx.sleep_other_target() ~= nil then
            return 'sleep'
        end

        local thd = ctx.target_has_debuff
        local def_on = ctx.cfgget('ranged.def_down_only')
        local blind_on = ctx.cfgget('ranged.blind_bolt')
        local has_def = def_on and thd and thd('def down') or false
        local has_blind = blind_on and thd and thd('blind') or false

        -- Stop-at-10: when on, skip Acid / Blind if <t> is at 10% HP or
        -- below. Applied to Acid + Blind only -- Bloody drains (already
        -- handled above) and Sleep Other fires at an add, not <t>.
        -- target_hp is a percent (0-100) or nil when we can't read it;
        -- nil target_hp doesn't suppress (we don't know, so keep firing).
        local stop10 = ctx.cfgget('ranged.status_stop_at_10')
        local t_hp = tonumber(ctx.target_hp)
        local suppress_status = (stop10 == true)
                                and (t_hp ~= nil)
                                and (t_hp > 0)
                                and (t_hp <= 10)

        -- Priority 2: Def Down (Acid Bolts) -- applied before blind.
        if def_on and not has_def and ctx.acid_bolt_available and not suppress_status then
            return 'acid'
        end

        -- Priority 3: Blind (Blind Bolts). Normally waits its turn -- fires
        -- only after def down is applied or when def-down mode is off. BUT:
        -- if def-down mode is on and we're out of acid bolts, the def-down
        -- slot is stuck forever. Falling through to blind in that case
        -- keeps ranged productive instead of standing on a red x0.
        if blind_on and not has_blind and ctx.blind_bolt_available and not suppress_status then
            local def_out_of_bolts = def_on and (ctx.acid_bolt_available ~= true)
            if (not def_on) or has_def or def_out_of_bolts then
                return 'blind'
            end
        end

        -- Nothing actionable this tick.
        if def_on or blind_on then
            -- A debuff still wants applying but we couldn't act (no bolts,
            -- or stop_at_10 suppressed)? -> No Tools / hold. Blind counts
            -- as "reachable" when def-down isn't gating it -- meaning def
            -- is off, def-down is already up, or def-down is stuck with
            -- no acid bolts (same condition that lets blind fire above).
            local def_unmet = def_on and not has_def
            local blind_reachable = blind_on and not has_blind
                and ((not def_on) or has_def or (def_on and ctx.acid_bolt_available ~= true))
            if (def_unmet or blind_reachable) and not suppress_status then
                return 'none'
            end
            return 'hold'
        end

        return 'normal'
    end

    -- RA-skill refire gate. Returns true when it's time to fire the next
    -- skillup shot: immediately if we've never fired, otherwise once the
    -- previous shot has resolved (hit/miss/interrupt stamped into
    -- ranged_resolved_at) plus a short buffer. If a shot was fired but no
    -- resolve ever arrived (lost packet / odd interrupt), a stale ceiling
    -- lets it refire so the loop can't wedge.
    ctx.ra_skill_refire_ok = function()
        local c = state.combat or {}
        local fired = tonumber(c.ranged_fired_at or 0) or 0
        local resolved = tonumber(c.ranged_resolved_at or 0) or 0
        local now = now_sec()
        if fired <= 0 then
            return true
        end
        if fired > resolved then
            -- Shot in flight (not yet resolved). Only refire if it's gone
            -- stale -- normally we wait for the resolve stamp.
            return (now - fired) >= 10.0
        end
        -- Resolved: wait the weapon's own recast before the next shot. Was a
        -- flat 3.0s, which raced the 3.5s RANGED cooldown on one side and
        -- the real weapon delay on the other.
        return (now - resolved) >= ranged_recast_sec(state)
    end

    ctx.do_ra = function()
        if ctx.target_dead then return false end
        if state.flags.player_ranged_no_weapon then
            report_blocked_action(state, 'RA', 'no ranged weapon')
            return false
        end
        -- Don't chain: skip while a shot is in flight or /ra is on CD.
        if ctx.spells_locked then
            report_blocked_action(state, 'RA', 'spells locked (casting)')
            return false
        end
        if ranged_in_progress(state) then
            report_blocked_action(state, 'RA', 'ranged shot in progress')
            return false
        end
        if not GeneralLua.cooldowns.is_ready('RANGED') then
            report_blocked_action(state, 'RA', '/ra on cooldown')
            return false
        end

        if GeneralLua.actions.ranged(dispatch) then
            state.combat.last_attempted_action_id = 'RANGED'
            state.combat.last_attempted_action_name = 'ranged'
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'ranged'
            -- Mark the shot in flight. The resolve stamp (ranged_resolved_at)
            -- is set by packet_parser (hit/miss) and text_parser (interrupt);
            -- the tick reconcile puts /ra on its CD once it resolves.
            state.combat.ranged_fired_at = now_sec()
            state.combat.ranged_cd_set = false
            return true
        end
        return false
    end

    ctx.do_shadows = function(_ignore_gate, mode, opts)
        if ctx.target_dead then
            -- Reset any in-progress sleep sequence so it starts fresh next time.
            if state.combat and state.combat.shadow_sleep then
                state.combat.shadow_sleep.phase = 'idle'
            end
            return false
        end
        -- Skip while another action is blocking (a cast or /ra in flight);
        -- the game will silently reject and the recast round is wasted.
        if ctx.spells_locked then
            report_blocked_action(state, 'SHADOWS', 'spells locked (casting)')
            return false
        end
        -- Sleep-shadows fast path passes bypass_ranged_grace=true: the 1s
        -- post-resolve window exists to protect normal casts from the
        -- ranged animation tail, but the fresh sleep IS our cover and
        -- waiting risks the mob waking on the next melee swing.
        local bypass_grace = (type(opts) == 'table') and (opts.bypass_ranged_grace == true)
        if not bypass_grace and ranged_in_progress(state) then
            report_blocked_action(state, 'SHADOWS', 'ranged shot in progress')
            return false
        end
        -- W held = we're running (chase-to-range, tick_engaged_run's close-
        -- to-melee, whatever). An Utsusemi cast started here gets eaten,
        -- because we don't stop moving. Wait for the movement layer to
        -- release W before we spend the cast.
        if state.live and state.live.player_moving_w == true then
            report_blocked_action(state, 'SHADOWS', 'moving (W held)')
            return false
        end

        local max_shadows_before_recast = 1

        if mode == 'pre_attack' or mode == 'idle' or mode == 'idle_post_stand' then
            max_shadows_before_recast = 0
        elseif mode == 'atk' or mode == 'def' then
            max_shadows_before_recast = 1
        end

        local command = HbShadows.shadow_command(state, max_shadows_before_recast)
        if not command then return false end

        if dispatch(command, 0.5) then
            local spell_name = MainMagic.extract_spell_name_from_command(command) or 'utsusemi'

            -- Ichi-over-Ni cancel: Ichi has no effect if Ni-origin shadows
            -- remain. If we just dispatched Ichi while our last shadow cast
            -- was Ni and shadows are still up, arm a delayed cancel so the
            -- old Copy Image is cleared near the end of the Ichi cast and
            -- Ichi actually lands.
            do
                local sl = tostring(spell_name):lower()
                local last_shadow = tostring(state.combat.last_shadow_name or '')
                local shadows = tonumber(HbShadows.shadow_count(state) or 0) or 0
                if state.ui and state.ui.debug_enabled == true and AshitaCore then
                    local cm = AshitaCore:GetChatManager()
                    if cm and type(cm.QueueCommand) == 'function' then
                        cm:QueueCommand(1, string.format(
                            '/echo [SHADOW] dispatch spell=%s last_shadow=%s count=%d',
                            sl, last_shadow, shadows))
                    end
                end
                if sl:find('ichi', 1, true) and last_shadow == 'Ni' and shadows > 0 then
                    HbShadows.arm_shadow_cancel(state)
                end
            end

            -- Arm the short dispatch guard (folds into ctx.spells_locked
            -- next tick) so nothing else casts in the gap before the
            -- game confirms. The REAL spell lock is NOT armed here --
            -- dispatch() only means "/ma was sent", not that the game
            -- accepted it. Utsusemi gets silently rejected when on
            -- recast / tools missing, emitting no "starts casting" line;
            -- arming the real lock at dispatch in that case produced a
            -- phantom lock that nothing cleared except the 4s timeout.
            --
            -- The "<player> starts casting Utsusemi" handler in
            -- text_parser is the sole real-lock arming point (is_casting
            -- not pre-set here, so its is_casting~=true guard lets the
            -- shadow cast through). spell_name_is_hb_trigger is false for
            -- Utsusemi, so that handler arms the general lock WITHOUT
            -- touching the HB safety timeout.
            arm_dispatch_guard(state)

            state.combat.last_attempted_action_id = 'SHADOWS'
            state.combat.last_attempted_action_name = normalize_action_name_for_map(spell_name)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'spell'
            return true
        end
        return false
    end

    ctx.do_hb = function(_entry_id)
        if ctx.target_dead then
            return false
        end

        local command = HbShadows.hb_command(state, rawget(_G, 'Hb_list'))
        if not command then return false end

        if dispatch(command, 1.0) then
            local spell_name = MainMagic.extract_spell_name_from_command(command) or 'hb'

            -- Arm the short dispatch guard (folds into ctx.spells_locked
            -- next tick) so nothing else casts in the gap before the
            -- game confirms. Do NOT arm the real spell lock OR the HB
            -- safety timeout here -- dispatch() only means "/ma was
            -- sent", not that the game accepted it. The game silently
            -- rejects casts on recast / out of range / dead target /
            -- silenced and emits no "starts casting" line and no action
            -- packet for them.
            --
            -- The "<player> starts casting <spell>" handler in
            -- text_parser is the authoritative real-lock arming point;
            -- it fires spell_lock_start (which arms the HB safety
            -- timeout via notify_hb_cast) only when the game confirms
            -- the cast began, with an accurate spell_started_at. Because
            -- do_hb does not pre-set is_casting, that handler's
            -- is_casting~=true guard lets HB casts through.
            --
            -- Arming the HB safety at dispatch was the core HB bug: a
            -- chain of silently-rejected triggers each armed a 12s
            -- safety timeout that nothing cleared (wyvern never
            -- breathed -> notify_hb_actually_fired never ran), locking
            -- HB out ~12s at a time.
            arm_dispatch_guard(state)

            state.combat.last_attempted_action_id = _entry_id or 'HB'
            state.combat.last_attempted_action_name = normalize_action_name_for_map(spell_name)
            state.combat.last_attempted_action_at = now_sec()
            state.combat.last_attempted_action_kind = 'spell'
            return true
        end
        return false
    end

    return ctx
end

local function sort_by_priority(list)
    table.sort(list, function(a, b)
        return n(a.priority or 99999) < n(b.priority or 99999)
    end)
end

-- Ladder dispatch. Every tick we re-evaluate the WHOLE list from priority 1
-- downward and fire the first entry that is both eligible() and ready (via
-- ctx.is_ready or the entry's own readiness flag like ctx.hb_ready). The
-- previous implementation kept a per-session "where we stopped last tick"
-- index and walked down from there -- which meant a higher-priority entry
-- that became ready mid-session (e.g. SHADOWS dropping while we were past
-- it on the list) was skipped until the session expired. That cost lives
-- on NIN/sub-NIN setups where Utsusemi expiring is exactly the case we
-- need to re-cast IMMEDIATELY, not "after we finish the rest of the
-- ladder + a session reset."
--
-- Per-entry cooldowns and the readiness flags self-gate against the same
-- thing firing twice: SHADOWS has cooldown_sec=30, WS requires 1000 TP and
-- drops to 0 after casting, HB checks ctx.hb_ready (wyvern JA timer).
-- Re-evaluating from the top each tick is therefore safe -- the only thing
-- that changes is that priority is honored every tick, instead of "only
-- on the tick we entered the session."
local function ladder_step_top(list, ctx)
    for i = 1, #list do
        local entry = list[i]

        if entry and GeneralLua.utils.req_ok(entry.req, ctx.job_info) then
            local eligible_ok = true

            if type(entry.eligible) == 'function' then
                local ok, result = pcall(entry.eligible, ctx)
                eligible_ok = ok and result == true or false
            end

            if eligible_ok and type(entry.act) == 'function' then
                local ok, acted = pcall(entry.act, ctx, entry)
                if ok and acted then
                    return true, entry
                end
            end
        end
    end

    return false, nil
end

local function atk_detected(state)
    state.combat = state.combat or {}
    return n(state.combat.atk_round_seq) > n(state.combat.atk_round_seen)
end

local function def_detected(state)
    state.combat = state.combat or {}
    return n(state.combat.def_round_seq) > n(state.combat.def_round_seen)
end

local function consume_atk_all(state)
    state.combat = state.combat or {}
    state.combat.atk_round_seen = state.combat.atk_round_seq or 0
end

local function consume_def_all(state)
    state.combat = state.combat or {}
    state.combat.def_round_seen = state.combat.def_round_seq or 0
end

local function build_atk_runtime_list(atk_list, general_list)
    local merged = {}

    for i = 1, #atk_list do
        merged[#merged + 1] = atk_list[i]
    end

    for i = 1, #general_list do
        local entry = general_list[i]
        if entry and entry.priority ~= nil and type(entry.eligible) == 'function' and type(entry.act) == 'function' then
            merged[#merged + 1] = entry
        end
    end

    sort_by_priority(merged)
    return merged
end

---------------------------------------------------------------------
-- DISPATCH POOLS
--
-- Replaces the old per-side "session" model. The old design had two
-- parallel ladders (atk_list / def_list) each gated by their own
-- session_active flag with timeout windows; the runtime walked them
-- sequentially every tick. Two failure modes drove the rewrite:
--   (1) def's session was tiny -- if def became eligible mid-cast,
--       the session would time out before the cast cleared and def
--       got starved.
--   (2) cross-ladder priority didn't exist. A prio-9500 atk spell
--       never competed against a prio-6000 def spell; they lived in
--       parallel universes synced only by spells_locked.
--
-- New model: per-event refill into 4 weighted slots + a JA queue +
-- single HB/WS/RA slots. Events ONLY fill the queue; the dispatch
-- loop drains it as the cast lock allows. Spells queued in a slot
-- stay there until they dispatch or until the next event of the
-- same kind reshuffles them, so a def Cure that couldn't fire at
-- T=0 (because we were mid-atk-cast) still fires at T=cast_done
-- without needing another def round to re-trigger it.
--
-- Pools:
--   def     2-weight budget,  filled on def-round event, weight evict
--   atk     2-weight budget,  filled on atk-round event, weight evict
--   ja      unbounded queue,  filled on atk-round event (no cap/evict)
--   ws      single slot,      filled on atk-round event
--   ra      single slot,      filled on atk-round event
--   hb      single slot,      re-evaluated every tick (not event-driven)
--
-- Dispatch order on lock-clear (one action per tick):
--   HB -> JA(head) -> WS -> RA -> DEF[1] -> ATK[1] -> DEF[2] -> ATK[2]
--
-- Eligibility is re-checked at dispatch time. Stale entries are
-- dropped from the slot and the loop moves on.
---------------------------------------------------------------------

local DISPATCH_BUDGET = 2

---------------------------------------------------------------------
-- JA CASCADE CHAIN
--
-- Tracks consecutive instant actions (JAs, items, ranged) dispatched
-- by drain_dispatch so inter-action pacing can shrink as the chain
-- progresses. The Nth back-to-back instant arms gates[N] as the
-- wait before the (N+1)th can fire (see timing.instant_chain_gates).
--
-- Rationale: the game's JA anti-spam window accepts progressively
-- tighter spacing once it's seen a clean first /ja. A conservative
-- opening interval drops over the chain, letting a DRG opener like
--   High Jump -> Jump -> Berserk -> Warcry -> WS
-- complete in ~1.8s instead of ~5s+ on a flat anti-spam-safe gate.
--
-- State (on state.dispatch):
--   ja_chain_count : integer, count of consecutive instants fired
--   ja_chain_list  : table of entry ids fired, for diagnostics
--
-- Reset (cascade returns to gates[1] next fire):
--   * WS fires        -- cascade terminator
--   * any spell fires -- cast pipeline takes over
--   * disengage       -- clear_dispatch_state
--   * idle decay      -- timing.chain_idle_decay_sec with no activity
---------------------------------------------------------------------

local function next_ja_chain_gate(state)
    state.dispatch = state.dispatch or {}
    local next_chain = n(state.dispatch.ja_chain_count) + 1
    local gates = GeneralLua.timing.instant_chain_gates
    return gates[math.min(next_chain, #gates)], next_chain
end

local function commit_ja_chain(state, next_chain, entry)
    state.dispatch.ja_chain_count = next_chain
    state.dispatch.ja_chain_list = state.dispatch.ja_chain_list or {}
    state.dispatch.ja_chain_list[#state.dispatch.ja_chain_list + 1] =
        tostring((entry and entry.id) or '?')
end

local function reset_ja_chain(state)
    state.dispatch = state.dispatch or {}
    state.dispatch.ja_chain_count = 0
    state.dispatch.ja_chain_list = nil
end

-- Always-on error log (no debug gate). Format:
--   [MN-ERR] N-Chain failed: step N (Name) not started. Chain so far: [a, b, ...]
local function log_chain_failure(state, attempted_step, attempted_name)
    if not AshitaCore then return end
    local list = (state.dispatch and state.dispatch.ja_chain_list) or {}
    local list_str = (#list > 0) and ('[' .. table.concat(list, ', ') .. ']') or '[empty]'
    local line = string.format(
        '/echo [MN-ERR] %d-Chain failed: step %d (%s) not started. Chain so far: %s',
        attempted_step, attempted_step,
        tostring(attempted_name or '?'), list_str
    )
    local ok, cm = pcall(function() return AshitaCore:GetChatManager() end)
    if ok and cm then
        pcall(function() cm:QueueCommand(1, line) end)
    end
end

local function init_dispatch_state(state)
    state.dispatch = state.dispatch or {}
    state.dispatch.atk_pool = state.dispatch.atk_pool or {}
    state.dispatch.def_pool = state.dispatch.def_pool or {}
    state.dispatch.ja_queue = state.dispatch.ja_queue or {}
    state.dispatch.def_ja_queue = state.dispatch.def_ja_queue or {}
    state.dispatch.ws_slot  = state.dispatch.ws_slot  or nil
    state.dispatch.ra_slot  = state.dispatch.ra_slot  or nil
    state.dispatch.hb_slot  = state.dispatch.hb_slot  or nil
    state.dispatch.ja_next_at = state.dispatch.ja_next_at or 0.0
    -- Cascade chain state (see JA CASCADE CHAIN section above).
    state.dispatch.ja_chain_count = state.dispatch.ja_chain_count or 0
    -- Watchdog: time the def pool last made progress (became freshly
    -- populated, or last fired an entry). If it sits non-empty with no
    -- progress past DEF_POOL_STALE_SEC, it's cleared -- otherwise a
    -- wedged entry (eligible at scan but never dispatchable, or a
    -- borrowed atk spell stuck behind a lock that won't clear) would
    -- block atk forever via Part A.
    state.dispatch.def_progress_at = state.dispatch.def_progress_at or 0.0
end

local function clear_dispatch_state(state)
    state.dispatch = state.dispatch or {}
    state.dispatch.atk_pool = {}
    state.dispatch.def_pool = {}
    state.dispatch.ja_queue = {}
    state.dispatch.def_ja_queue = {}
    state.dispatch.ws_slot  = nil
    state.dispatch.ra_slot  = nil
    state.dispatch.hb_slot  = nil
    state.dispatch.ja_next_at = 0.0
    state.dispatch.ja_chain_count = 0
    state.dispatch.ja_chain_list = nil
    state.dispatch.def_progress_at = 0.0
end

local DEF_POOL_STALE_SEC = 10.0

local function entry_kind(entry)
    return (entry and entry.kind) or 'spell'
end

local function entry_weight(entry)
    return tonumber(entry and entry.weight or 1) or 1
end

-- Scan a list for entries of the requested kind that pass req_ok and
-- eligible(). Returns list sorted by priority desc. Eligibility is
-- evaluated fresh against the current ctx.
--
-- IMPORTANT: at scan time we temporarily clear the transient lock
-- states (spells_locked, spells_locked_soft, ws_blocked). The whole
-- point of the queue is to hold things that should fire when the
-- lock CLEARS. If a def event fires mid-cast and Cure's eligible()
-- returned false because of spells_locked_soft, def_pool would stay
-- empty and the Cure would never queue -- exactly the "lost def
-- trigger during atk cast" failure the queue is supposed to fix.
--
-- Per-slot dispatch in drain_dispatch re-runs eligible() with the
-- real lock state (drain_dispatch returns early if spells_locked is
-- true, and try_dispatch_entry calls eligible() again, so by the
-- time the queued entry actually fires, the lock has cleared and
-- the natural eligible() check passes). Cooldowns, HP/MP gates,
-- buff-present checks, distance checks all stay enforced at scan
-- time -- only the lock states are bypassed.
local function scan_eligible(list, ctx, kind_filter)
    local out = {}

    local saved_locked      = ctx.spells_locked
    local saved_locked_soft = ctx.spells_locked_soft
    local saved_ws_blocked  = ctx.ws_blocked
    ctx.spells_locked      = false
    ctx.spells_locked_soft = false
    ctx.ws_blocked         = false

    -- Deep lock bypass. Some eligibility paths don't read the ctx lock
    -- flags above -- they read the RAW cast-lock state off state.combat
    -- directly. The big one is Shadows: its eligible() -> shadows_can_
    -- attempt -> HbShadows.shadows_ready checks
    --     state.combat.is_casting, state.combat.spell_lock_until
    -- itself. So zeroing only the ctx flags wasn't enough -- during an
    -- in-flight atk cast, a def event would scan, Shadows would still
    -- read the raw lock as held, and it would NOT enter def_pool. By the
    -- time the cast cleared, that def event was consumed and no fresh one
    -- had arrived, so atk_pool kept refilling and firing while Shadows
    -- never got queued. THIS is why atk kept winning while the mob beat
    -- on us. Neutralize the raw lock state for the duration of the scan
    -- so "would this be eligible once the lock clears" is answered
    -- correctly; the dispatch-time recheck (and drain's own
    -- spells_locked early-return) still gate the ACTUAL fire on the real
    -- lock.
    local st = get_state_ref()
    local saved_is_casting, saved_lock_until, saved_spell_locked
    if st and st.combat then
        saved_is_casting   = st.combat.is_casting
        saved_lock_until   = st.combat.spell_lock_until
        saved_spell_locked = st.combat.spell_locked
        st.combat.is_casting     = false
        st.combat.spell_lock_until = 0.0
        st.combat.spell_locked   = false
    end

    for i = 1, #list do
        local entry = list[i]
        if entry and entry_kind(entry) == kind_filter
           and GeneralLua.utils.req_ok(entry.req, ctx.job_info) then
            local elig = false
            if type(entry.eligible) == 'function' then
                local ok, result = pcall(entry.eligible, ctx)
                elig = ok and result == true
            end
            if elig then
                out[#out + 1] = entry
            end
        end
    end

    if st and st.combat then
        st.combat.is_casting     = saved_is_casting
        st.combat.spell_lock_until = saved_lock_until
        st.combat.spell_locked   = saved_spell_locked
    end

    ctx.spells_locked      = saved_locked
    ctx.spells_locked_soft = saved_locked_soft
    ctx.ws_blocked         = saved_ws_blocked

    -- Sort ascending: codebase convention is LOWER number = HIGHER
    -- priority (see sort_by_priority and the def_list CURE entry's
    -- priority=5 comment -- "ABSOLUTE TOP of the def ladder").
    table.sort(out, function(a, b)
        return (a.priority or 99999) < (b.priority or 99999)
    end)
    return out
end

-- Greedy weight-bounded pack. Candidates must already be priority-sorted
-- (ascending = highest priority first). Walks the list taking entries
-- that fit the remaining budget; an entry too heavy to fit is SKIPPED
-- and the walk continues, so a lighter lower-priority entry can still
-- claim the leftover slot.
--
-- Worked example (budget=2):
--   [Stoneskin(w2), Dia(w1), Slow(w1)]  -> [Stoneskin]
--       Stoneskin fills both slots; nothing else fits.
--   [Dia(w1), Slow(w1), Haste(w1)]      -> [Dia, Slow]
--       two weight-1 spells in one round (the "2 cheap casts" case).
--   [Dia(w1), Stoneskin(w2), Slow(w1)]  -> [Dia, Slow]
--       Dia takes slot 1; Stoneskin (w2) can't fit the lone remaining
--       slot so it's skipped; Slow claims slot 2.
--
-- Round-to-round this gives the 1+1 / 2 / 1+1 alternation: a high-prio
-- weight-2 spell wins a round outright, and on the round it's gone (CD
-- or buff up) two weight-1 spells fill instead. The dispatch-time
-- eligible() recheck plus per-event refill keep the pool current.
local function pack_weighted(candidates, budget)
    local pool = {}
    local used = 0
    for i = 1, #candidates do
        local w = entry_weight(candidates[i])
        if used + w <= budget then
            pool[#pool + 1] = candidates[i]
            used = used + w
            if used >= budget then break end
        end
    end
    return pool
end

-- Same as pack_weighted but also returns the weight actually used, so
-- the caller can tell how much budget is left over. Used by def borrow.
local function pack_weighted_used(candidates, budget)
    local pool = {}
    local used = 0
    for i = 1, #candidates do
        local w = entry_weight(candidates[i])
        if used + w <= budget then
            pool[#pool + 1] = candidates[i]
            used = used + w
            if used >= budget then break end
        end
    end
    return pool, used
end

local function refill_atk_event(state, ctx, atk_runtime_list)
    -- Atk pool: spell-kind entries, weighted. REBUILT wholesale every atk
    -- event -- atk re-evaluates fresh on every swing (a spell that was
    -- queued but is now on cooldown / no longer wanted should drop, and
    -- the current best should take its place). This is intentional and
    -- different from def below.
    state.dispatch.atk_pool = pack_weighted(
        scan_eligible(atk_runtime_list, ctx, 'spell'), DISPATCH_BUDGET)
    -- JA queue: all eligible JAs (instant, no cap, no evict)
    state.dispatch.ja_queue = scan_eligible(atk_runtime_list, ctx, 'ja')
    -- WS slot
    state.dispatch.ws_slot = scan_eligible(atk_runtime_list, ctx, 'ws')[1]
    -- RA slot
    state.dispatch.ra_slot = scan_eligible(atk_runtime_list, ctx, 'ra')[1]
end

-- Def pool refill. Re-packs the full eligible def candidate set by
-- priority and weight every def event, then -- if there's leftover
-- budget that no eligible def entry can fill -- BORROWS one weight-1
-- atk spell to ride along in the def (safe, post-swing) window.
--
-- Base packing gives:
--   * PERSISTENCE: a still-eligible queued entry (e.g. Shadows queued on
--     a prior hit and not yet fired) is in the candidate list and gets
--     packed again by its priority, so it survives across events until
--     it fires or goes stale (shadows back up / on recast -> drops).
--   * EVICTION: packing is strict priority+weight, so a higher-priority
--     entry kicks a lower-priority one out of a full budget. Shadows
--     (prio 8888) beats Protect (prio 8890); when both are eligible and
--     the 2-weight budget is full, Shadows takes the slot, Protect waits.
--
-- BORROW (only when ALL of):
--   * at least ONE real def spell got packed (never borrow into an empty
--     def pool -- no def need means no def event timing to ride, so atk
--     runs normally on its own events instead)
--   * budget remains after packing def
--   * no eligible def entry can fill the remaining budget. A weight-2 def
--     spell that's eligible but can't fit the lone leftover slot counts
--     as "can't fill" (reading 1a) -- so we borrow rather than leave the
--     slot empty; the w2 def spell takes a slot on a later event.
-- Then take the highest-priority eligible WEIGHT-1 atk spell that fits
-- the remaining budget (one borrow max -- leftover is <=1 whenever a def
-- spell is queued, so only a w1 fits). The borrowed atk spell fires as
-- part of the def event, in the safe window, and drains from def_pool;
-- it is NOT subject to Part A's atk-dispatch block (it lives in def_pool
-- now, not atk_pool). Its own cooldown then suppresses a duplicate from
-- the real atk pool via the dispatch-time recheck.
local function refill_def_event(state, ctx, def_list, atk_runtime_list)
    -- Snapshot prior state for the fresh-populate watchdog stamp below,
    -- before we overwrite the spell pool and JA queue.
    local prev_def_pool = state.dispatch.def_pool
    local prev_def_ja   = state.dispatch.def_ja_queue

    local def_cands = scan_eligible(def_list, ctx, 'spell')   -- prio asc
    local pool, used = pack_weighted_used(def_cands, DISPATCH_BUDGET)

    -- Def JAs (Third Eye, Seigan, Super Jump, Call Wyvern -- kind='ja')
    -- get their own queue, mirroring the atk side. Without this they had
    -- NO dispatch path at all: refill_def_event only scanned kind='spell'
    -- so every def JA silently never fired. Instant, no weight budget,
    -- drained in the def window before the def spell pool.
    state.dispatch.def_ja_queue = scan_eligible(def_list, ctx, 'ja')

    local remaining = DISPATCH_BUDGET - used

    -- Borrow gate: must have packed >=1 real def spell, have leftover
    -- budget, and have no eligible def entry that could fill it.
    if #pool >= 1 and remaining > 0 then
        -- Can any not-yet-packed eligible def entry fit the remaining
        -- budget? If yes, do NOT borrow -- def work has the slot.
        local def_can_fill = false
        for i = 1, #def_cands do
            local e = def_cands[i]
            -- skip entries already in the pool
            local in_pool = false
            for j = 1, #pool do
                if pool[j] == e then in_pool = true; break end
            end
            if not in_pool and entry_weight(e) <= remaining then
                def_can_fill = true
                break
            end
        end

        if not def_can_fill then
            -- Borrow the top-priority eligible weight-1 atk spell that
            -- fits. atk_runtime_list scan is 'spell' kind only (JAs/WS/RA
            -- are not borrowable here).
            local atk_cands = scan_eligible(atk_runtime_list, ctx, 'spell')
            for i = 1, #atk_cands do
                local e = atk_cands[i]
                if entry_weight(e) == 1 and 1 <= remaining then
                    -- Mark as borrowed so it sorts to the END of the def
                    -- pool. The genuine def work is timing-critical (cast
                    -- in the post-swing gap to dodge interrupt); the
                    -- borrowed atk spell just rides spare capacity and
                    -- must fire AFTER the def spells, not interleaved by
                    -- its own (lower-number) priority. Without this, a
                    -- borrowed Dia (prio 8000) would sort ahead of Shadows
                    -- (prio 8888) and delay the timing-critical cast.
                    state.dispatch._borrowed_id = e.id
                    pool[#pool + 1] = e
                    break   -- one borrow max
                end
            end
        else
            state.dispatch._borrowed_id = nil
        end
    else
        state.dispatch._borrowed_id = nil
    end

    -- Keep priority order for the drain (tries [1] first), BUT force the
    -- borrowed atk entry (if any) to the end so def work fires first.
    local borrowed_id = state.dispatch._borrowed_id
    table.sort(pool, function(a, b)
        local a_borrowed = (borrowed_id ~= nil and a.id == borrowed_id)
        local b_borrowed = (borrowed_id ~= nil and b.id == borrowed_id)
        if a_borrowed ~= b_borrowed then
            return not a_borrowed   -- non-borrowed sorts first
        end
        return (a.priority or 99999) < (b.priority or 99999)
    end)

    -- Watchdog: stamp progress when def work transitions from empty to
    -- populated (a fresh def need just queued -- spell pool or JA queue).
    -- Re-populating an already-non-empty set does NOT reset the timer --
    -- otherwise a wedged entry that keeps getting re-packed every def
    -- event would refresh its own watchdog forever and never time out.
    -- Only a genuinely fresh queue (or a fire, stamped in the drain)
    -- counts as progress.
    local prev_pool_empty = (not prev_def_pool) or (#prev_def_pool == 0)
    local prev_ja_empty   = (not prev_def_ja) or (#prev_def_ja == 0)
    local was_empty = prev_pool_empty and prev_ja_empty
    local now_populated = (#pool > 0) or (#state.dispatch.def_ja_queue > 0)
    if was_empty and now_populated then
        state.dispatch.def_progress_at = now_sec()
    end

    state.dispatch.def_pool = pool
end
-- Looks across both atk_list and def_list (the user-mode flag in the
-- HB entry's eligible determines which side actually fires).
local function refresh_hb_slot(state, ctx, atk_runtime_list, def_list)
    local atk_cands = scan_eligible(atk_runtime_list, ctx, 'hb')
    local def_cands = scan_eligible(def_list, ctx, 'hb')
    state.dispatch.hb_slot = atk_cands[1] or def_cands[1]
end

-- At dispatch time we re-run eligible() one more time -- the pool
-- may have been built several ticks ago and conditions can shift
-- (target died, MP dropped under threshold, buff landed). Stale
-- entries drop quietly and the loop moves on.
local function try_dispatch_entry(ctx, entry)
    if not entry then return false, false end
    local elig = false
    if type(entry.eligible) == 'function' then
        local ok, result = pcall(entry.eligible, ctx)
        elig = ok and result == true
    end
    if not elig then return false, true end   -- not eligible, mark stale
    if type(entry.act) == 'function' then
        local ok, acted = pcall(entry.act, ctx, entry)
        if ok and acted == true then
            return true, false
        end
    end
    return false, true   -- act() returned false, treat as stale
end

local function compact(t)
    local out = {}
    for i = 1, #t do
        if t[i] ~= nil then out[#out + 1] = t[i] end
    end
    return out
end

-- Single-tick dispatch. Walks the priority order, fires the first
-- eligible thing, returns. Stale slots are dropped on the way past.
-- Returns true if something fired.
--
-- Pacing model:
--   * Spells space themselves via the cast lock (spells_locked).
--   * JAs / items / pet commands need explicit pacing because they
--     land instantly server-side and the game's ~1s JA anti-spam
--     window will silently drop a second one fired too soon. Only
--     the JA queue is paced; firing a spell right after a JA is
--     fine and we don't want the JA pacing blocking def/atk casts.
local function drain_dispatch(state, ctx)
    if ctx.spells_locked then return false end
    -- A ranged shot is in flight -- nothing else can act, so don't try.
    if ranged_in_progress(state) then return false end

    local tnow = now_sec()

    -- HB (locks like a spell once fired)
    if state.dispatch.hb_slot then
        local fired, stale = try_dispatch_entry(ctx, state.dispatch.hb_slot)
        if fired then
            reset_ja_chain(state)   -- spell breaks the instant cascade
            state.dispatch.hb_slot = nil
            return true
        end
        if stale then state.dispatch.hb_slot = nil end
    end

    -- Cascade idle-decay: if the chain is dirty but nothing's been
    -- firing for longer than chain_idle_decay_sec (queues empty AND
    -- ja_next_at well in the past), reset it so the next instant
    -- starts conservatively from gates[1] rather than riding a shrunk
    -- gate inherited from a chain that's effectively over.
    do
        local idle_decay = n(GeneralLua.timing.chain_idle_decay_sec)
        if idle_decay > 0
           and n(state.dispatch.ja_chain_count) > 0
           and #state.dispatch.ja_queue == 0
           and #state.dispatch.def_ja_queue == 0
           and tnow - n(state.dispatch.ja_next_at) >= idle_decay then
            reset_ja_chain(state)
        end
    end

    -- JA queue head -- paced by ja_next_at, where the wait is the
    -- cascade gate (see JA CASCADE CHAIN above), not the legacy
    -- action_step_hold_sec. Also overrides state.combat.gate_until
    -- with the same cascade gate -- actions.ja arms a +1.0s dispatch
    -- floor that would otherwise block the cascade's sub-1.0s steps.
    while state.dispatch.ja_queue[1] and tnow >= n(state.dispatch.ja_next_at) do
        local head = state.dispatch.ja_queue[1]
        local fired, stale = try_dispatch_entry(ctx, head)
        if fired then
            table.remove(state.dispatch.ja_queue, 1)
            local gate, next_chain = next_ja_chain_gate(state)
            commit_ja_chain(state, next_chain, head)
            state.dispatch.ja_next_at = tnow + gate
            state.combat.gate_until = tnow + gate
            return true
        end
        if stale then
            table.remove(state.dispatch.ja_queue, 1)
            -- Mid-chain failure: previous fires committed but THIS step
            -- went stale (eligibility recheck failed or act() returned
            -- false). Surface it as an error line so chains breaking
            -- silently in combat are visible. Bare openers (chain==0)
            -- don't log -- those are normal eligibility churn, not a
            -- broken cascade.
            local prev_chain = n(state.dispatch.ja_chain_count)
            if prev_chain > 0 then
                log_chain_failure(state, prev_chain + 1, (head and head.id) or '?')
            end
        else
            break
        end
    end

    -- WS (also gated by post-WS lockout / runtime_is_gated)
    if state.dispatch.ws_slot and not runtime_is_gated(state, tnow) then
        local fired, stale = try_dispatch_entry(ctx, state.dispatch.ws_slot)
        if fired then
            reset_ja_chain(state)   -- WS is the cascade terminator
            state.dispatch.ws_slot = nil
            return true
        end
        if stale then state.dispatch.ws_slot = nil end
    end

    -- RA -- instant like a JA; participates in the cascade so a ranged
    -- shot mid-combat paces correctly with surrounding instants.
    if state.dispatch.ra_slot then
        local head = state.dispatch.ra_slot
        local fired, stale = try_dispatch_entry(ctx, head)
        if fired then
            local gate, next_chain = next_ja_chain_gate(state)
            commit_ja_chain(state, next_chain, head)
            state.dispatch.ja_next_at = tnow + gate
            state.combat.gate_until = tnow + gate
            state.dispatch.ra_slot = nil
            return true
        end
        if stale then state.dispatch.ra_slot = nil end
    end

    -- DEF JA queue -- instant def abilities (Third Eye, Seigan, Super
    -- Jump, Call Wyvern). Fire in the def window ahead of the def spell
    -- pool. Shares the same cascade-paced ja_next_at + dispatch gate as
    -- the atk JA loop -- a JA is a JA regardless of which queue it came
    -- from.
    while state.dispatch.def_ja_queue[1] and tnow >= n(state.dispatch.ja_next_at) do
        local head = state.dispatch.def_ja_queue[1]
        local fired, stale = try_dispatch_entry(ctx, head)
        if fired then
            table.remove(state.dispatch.def_ja_queue, 1)
            local gate, next_chain = next_ja_chain_gate(state)
            commit_ja_chain(state, next_chain, head)
            state.dispatch.ja_next_at = tnow + gate
            state.combat.gate_until = tnow + gate
            state.dispatch.def_progress_at = tnow
            return true
        end
        if stale then
            table.remove(state.dispatch.def_ja_queue, 1)
            local prev_chain = n(state.dispatch.ja_chain_count)
            if prev_chain > 0 then
                log_chain_failure(state, prev_chain + 1, (head and head.id) or '?')
            end
        else
            break
        end
    end

    -- DEF then ATK, with Part A: while def_pool has ANYTHING queued, atk
    -- is blocked from firing. Def work owns the cast pipeline until it's
    -- fully drained. This protects def-cast timing -- a def spell (or a
    -- borrowed atk spell riding in the def window) fires in the safe
    -- post-swing gap, and atk doesn't get to start a long cast that would
    -- delay it or overrun the window.
    --
    -- Drain def in priority order; fire the first eligible one and return
    -- (one action per tick). Stale entries drop on the way past.
    local def = state.dispatch.def_pool
    -- Post-cast animation hold: casts wait it out (JAs/WS above already ran
    -- this tick). Skipping the loops leaves the pools intact -- no eviction --
    -- and the Part A gate below still blocks atk while def has work queued.
    local cast_hold = tnow < n(state.combat.post_cast_hold_until)
    if not cast_hold then
    for i = 1, #def do
        if def[i] then
            local fired, stale = try_dispatch_entry(ctx, def[i])
            if fired then
                reset_ja_chain(state)   -- spell breaks the instant cascade
                def[i] = nil
                state.dispatch.def_pool = compact(def)
                state.dispatch.def_progress_at = tnow   -- watchdog: a def
                                                        -- entry fired, pool
                                                        -- is making progress
                return true
            end
            -- Strict priority hold: if the TOP def entry can't fire this
            -- tick (transient stale -- spells_locked_soft, no target, etc.),
            -- do NOT skip to a lower-priority entry. Wait for it. Otherwise
            -- Cure (prio 5) transiently fails, drain moves to Phalanx
            -- (prio 8891.7), Phalanx casts, MP/lock is consumed, and Cure
            -- is delayed a full cast cycle -- exactly the "cast Phalanx
            -- instead of Cure" bug.
            --
            -- Also: def entries never drop as stale -- they persist across
            -- ticks until they fire or the next def event refills the pool.
            break
        end
    end
    state.dispatch.def_pool = compact(def)
    end   -- cast_hold guard (def spells)

    -- Part A gate: if def_pool OR the def JA queue still has queued
    -- entries (none were dispatchable THIS tick -- e.g. all waiting on
    -- the next def event's timing, or a JA held by the anti-spam pace),
    -- atk does NOT fire. Def work (spells and JAs) owns the pipeline
    -- until it's fully drained. Atk keeps its queued candidate ready but
    -- holds until def empties.
    if #state.dispatch.def_pool > 0 or #state.dispatch.def_ja_queue > 0 then
        return false
    end

    -- def_pool empty -> atk may fire. Drain atk in priority order.
    -- (Casts only -- held during the post-cast animation tail; entries stay
    -- queued rather than evicting.)
    if cast_hold then return false end
    local atk = state.dispatch.atk_pool
    for i = 1, #atk do
        if atk[i] and not runtime_is_gated(state, tnow) then
            local fired, stale = try_dispatch_entry(ctx, atk[i])
            if fired then
                reset_ja_chain(state)   -- spell breaks the instant cascade
                atk[i] = nil
                state.dispatch.atk_pool = compact(atk)
                return true
            end
            if stale then atk[i] = nil end
        end
    end
    state.dispatch.atk_pool = compact(atk)

    return false
end

---------------------------------------------------------------------
-- FULL-BUFF SEQUENCE
--
-- One-shot buff caster, armed by the Full-Buff button. Casts a fixed
-- list of self-buffs in order, one at a time, skipping any the player
-- can't cast (job/level) or already has up. Runs ONLY while disengaged
-- -- arming is refused mid-fight and an in-progress sequence aborts the
-- moment the player engages (the button is a pre-fight setup tool, not
-- a combat action).
--
-- Mechanics mirror the dispatch pools: one cast in flight, advance on
-- spell-lock-clear. Each step re-checks "can cast" and "already up" at
-- dispatch time so a buff that landed via some other source (party
-- member, food) is skipped on the way past.
--
-- Order: Protect, Shell, Stoneskin, Shadows-or-Blink, Phalanx,
--        Enthunder, Shock Spikes, Haste.
-- Shadows/Blink share one slot: Utsusemi if the job can cast it,
-- otherwise Blink (so a RDM/WHM with no NIN sub still gets damage
-- mitigation). The list is intentionally RDM/WHM-centric; jobs that
-- can't cast a given line just skip it.
---------------------------------------------------------------------

-- Each step: { name=<debug/skip label>, castable=fn(ctx)->bool,
--              already=fn(ctx)->bool, cast=fn(ctx)->bool }
-- castable: job/level can cast this at all
-- already:  buff already present (skip)
-- cast:     fire it (returns true if the cast was dispatched)
local function buildbuff_steps()
    local J = GeneralLua.jobs
    local function main_or_sub(ji, job, lv)
        ji = ji or {}
        return (n(ji.mainJob) == job and n(ji.mainLv) >= lv)
            or (n(ji.subJob)  == job and n(ji.subLv)  >= lv)
    end

    local function can_shadows(ctx)
        return main_or_sub(ctx.job_info, J.NIN, 12)
    end

    return {
        {
            name = 'Refresh',
            castable = function(ctx) return main_or_sub(ctx.job_info, J.RDM, 41) end,
            already  = function(ctx) return ctx.self_refresh_active == true end,
            cast     = function(ctx) return ctx.do_self_spell('Refresh', 'REFRESH') end,
        },
        {
            name = 'Protect',
            castable = function(ctx) return ctx.best_protect_spell ~= nil end,
            already  = function(ctx) return ctx.self_protect_active == true end,
            cast     = function(ctx) return ctx.do_self_spell(ctx.best_protect_spell, 'PROTECT') end,
        },
        {
            name = 'Shell',
            castable = function(ctx) return ctx.best_shell_spell ~= nil end,
            already  = function(ctx) return ctx.self_shell_active == true end,
            cast     = function(ctx) return ctx.do_self_spell(ctx.best_shell_spell, 'SHELL') end,
        },
        {
            name = 'Stoneskin',
            castable = function(ctx) return main_or_sub(ctx.job_info, J.WHM, 28) or main_or_sub(ctx.job_info, J.RDM, 34) end,
            already  = function(ctx) return ctx.self_stoneskin_active == true end,
            cast     = function(ctx) return ctx.do_self_spell('Stoneskin', 'STONESKIN') end,
        },
        {
            -- Shadows/Blink alternation. Utsusemi preferred; Blink only
            -- when the job can't cast Utsusemi (no NIN main/sub).
            name = 'Shadows/Blink',
            castable = function(ctx)
                if can_shadows(ctx) then return true end
                return main_or_sub(ctx.job_info, J.WHM, 19) or main_or_sub(ctx.job_info, J.RDM, 23)
            end,
            already = function(ctx)
                if can_shadows(ctx) then
                    -- Shadows up = any shadow images present.
                    return (ctx.shadow_count or 0) > 0
                end
                return ctx.self_blink_active == true
            end,
            cast = function(ctx)
                if can_shadows(ctx) then
                    -- do_shadows has a dead-target guard; while disengaged
                    -- with no target that's true, but Utsusemi is a <me>
                    -- cast and always valid. Clear the flag around the call
                    -- so shadows can fire during buffing.
                    local saved = ctx.target_dead
                    ctx.target_dead = false
                    local r = ctx.do_shadows(true, 'def')
                    ctx.target_dead = saved
                    return r
                end
                return ctx.do_self_spell('Blink', 'BLINK')
            end,
        },
        {
            name = 'Phalanx',
            castable = function(ctx) return main_or_sub(ctx.job_info, J.RDM, 33) end,
            already  = function(ctx) return ctx.self_phalanx_active == true end,
            cast     = function(ctx) return ctx.do_self_spell('Phalanx', 'PHALANX') end,
        },
        {
            name = 'Enspell',
            castable = function(ctx) return main_or_sub(ctx.job_info, J.RDM, 16) end,
            -- "Already" = the CHOSEN enspell (the one toggled on in the
            -- menu) is up. If a DIFFERENT enspell is active, this returns
            -- false so the step fires and overwrites it. If nothing is
            -- selected, Enthunder is the default target.
            already  = function(ctx)
                local want = ctx.chosen_enspell and ctx.chosen_enspell() or 'Enthunder'
                return ctx.buff_active and ctx.buff_active(want) == true
            end,
            cast     = function(ctx)
                local want = ctx.chosen_enspell and ctx.chosen_enspell() or 'Enthunder'
                return ctx.do_self_spell(want, want:upper())
            end,
        },
        {
            name = 'Spikes',
            castable = function(ctx) return main_or_sub(ctx.job_info, J.BLM, 30) or main_or_sub(ctx.job_info, J.RDM, 50) end,
            -- Same as enspell: "already" only counts the CHOSEN spike;
            -- a wrong spike gets overwritten. Default Shock Spikes.
            already  = function(ctx)
                local want = ctx.chosen_spike and ctx.chosen_spike() or 'Shock Spikes'
                return ctx.buff_active and ctx.buff_active(want) == true
            end,
            cast     = function(ctx)
                local want = ctx.chosen_spike and ctx.chosen_spike() or 'Shock Spikes'
                return ctx.do_self_spell(want, (want:gsub(' ', '_')):upper())
            end,
        },
        {
            name = 'Haste',
            castable = function(ctx) return main_or_sub(ctx.job_info, J.WHM, 40) or main_or_sub(ctx.job_info, J.RDM, 48) end,
            already  = function(ctx) return ctx.self_haste_active == true end,
            cast     = function(ctx) return ctx.do_self_spell('Haste', 'HASTE') end,
        },
    }
end

local BUILDBUFF_STEPS = nil

-- Arm the sequence. Refused while engaged. Returns true if armed.
function GeneralLua.runtime.buildbuff_start(state)
    state.combat = state.combat or {}
    state.live = state.live or {}
    if state.live.player_status == GeneralLua.status.ENGAGED then
        return false
    end
    state.combat.buildbuff_active = true
    state.combat.buildbuff_index  = 1
    return true
end

function GeneralLua.runtime.buildbuff_stop(state)
    state.combat = state.combat or {}
    state.combat.buildbuff_active = false
    state.combat.buildbuff_index  = nil
end

function GeneralLua.runtime.buildbuff_is_active(state)
    return state and state.combat and state.combat.buildbuff_active == true
end

-- RA-skill: a dedicated ranged-skillup mode armed by the RA Skill button.
-- Fires /ra at a single target on a resolve-paced cadence (see do_ra +
-- ra_skill_refire_ok) and self-stops on any of: that target dying or being
-- swapped away, out of ammo, no ranged weapon, or the Stop button. Locked to
-- the target that was selected when armed -- when that mob dies the session
-- ends (matching "stops if target dies"). Runs whether engaged or not.
function GeneralLua.runtime.ra_skill_start(state)
    state.combat = state.combat or {}
    state.live = state.live or {}
    local sid = tonumber(state.live.player_target_server_id or 0) or 0
    if sid == 0 then return false end          -- need a target to skill on
    state.combat.ra_skill_active = true
    state.combat.ra_skill_target_sid = sid
    state.combat.ranged_fired_at = 0.0         -- first shot fires immediately
    state.combat.ranged_resolved_at = 0.0
    return true
end

function GeneralLua.runtime.ra_skill_stop(state)
    state.combat = state.combat or {}
    state.combat.ra_skill_active = false
    state.combat.ra_skill_target_sid = nil
end

function GeneralLua.runtime.ra_skill_is_active(state)
    return state and state.combat and state.combat.ra_skill_active == true
end

function GeneralLua.runtime.ra_skill_step(state, ctx)
    if not (state.combat and state.combat.ra_skill_active) then return false end

    -- Stop conditions ---------------------------------------------------
    -- Out of ammo (bovinebattle stamps this from the live ammo slot).
    if (state.live and state.live.ranged_ammo_present) ~= true then
        GeneralLua.runtime.ra_skill_stop(state)
        return false
    end
    -- No ranged weapon equipped.
    if state.flags and state.flags.player_ranged_no_weapon == true then
        GeneralLua.runtime.ra_skill_stop(state)
        return false
    end
    -- Not a /ra job: no bow/xbow/gun equipped. Skilling up by throwing away
    -- the stat stick in your ammo slot is not a thing.
    if (state.live and state.live.ranged_weapon_ok) ~= true then
        GeneralLua.runtime.ra_skill_stop(state)
        return false
    end
    -- The target we armed on died, cleared, or got swapped away.
    local want_sid = tonumber(state.combat.ra_skill_target_sid or 0) or 0
    local cur_sid  = tonumber(ctx.target_server_id or 0) or 0
    if ctx.target_dead or cur_sid == 0 or cur_sid ~= want_sid then
        GeneralLua.runtime.ra_skill_stop(state)
        return false
    end

    -- Fire on the resolve-paced cadence --------------------------------
    if ctx.spells_locked then return false end
    if ranged_in_progress(state) then return false end
    if not ctx.ra_skill_refire_ok() then return false end
    return ctx.do_ra()
end

-- Max distance this mode will shoot from: the server's own cap, straight
-- from CBattleEntity::GetRangedAttackRange via weapon_db.
--
-- DO NOT confuse this with PULL_RANGE_YALMS[1] = 22 in idle_rest_engage,
-- and do not "correct" that one to 25. The 22 (stopping the chase at 21
-- after CHASE_STOP_MARGIN) is a deliberate drift buffer, not an out-of-date
-- guess at the cap: chase STOPS there and we stand still from then on, so a
-- mob that keeps walking has to be able to eat a few yalms without pushing
-- us out of range. Standing at 24 would work exactly once.
--
-- This gate is a different job. It is re-evaluated every cadence against the
-- live distance rather than picking a spot to stand, so it can sit on the
-- true cap. The residual risk is only outward drift during the shot's own
-- flight time, which costs one round and is re-checked on the next pass.
local RANGED_MODE_MAX_YALMS = WeaponDB.RANGED_ATTACK_RANGE or 25.0

-- Quiet window after the target dies or is lost. The /ra recast is a
-- SERVER timer that keeps running across the kill, and our own model of it
-- (cooldowns 'RANGED') is stamped at resolve, so a mob finished off by
-- melee leaves the model idle while the server is still counting. Fire
-- into that gap and the answer is "You must wait longer to perform that
-- action". This is also the messiest moment for movement: the corpse
-- clears, auto-target picks the next mob, and chase starts holding W.
local RANGED_MODE_POST_KILL_SEC = 2.0

-- Settle window on a freshly acquired target, on top of the quiet window
-- above. A new sid means auto-target just landed a 0x058 and auto-pull is
-- about to arm and very likely walk. Shooting on the first frame we see a
-- target buys an interrupted aim; waiting a beat costs nothing because the
-- refire cadence is 3s anyway.
local RANGED_MODE_TARGET_SETTLE_SEC = 1.5

-- Standoff ranged mode -- the top-row 'Ranged' checkbox (cfg
-- auto.rangedmode). Stand where we are and put /ra into the current target
-- on the shot's own resolve-paced cadence.
--
-- WHY THIS EXISTS SEPARATELY FROM THE RANGED LADDER ENTRY:
-- the ladder's RA slot is refilled by refill_atk_event, which only runs on
-- a melee atk round, and the whole dispatch path early-returns when
-- engaged01 ~= 1. So 'auto.ranged' can only ever shoot at melee cadence
-- while engaged. This loop runs ahead of that early-return, exactly like
-- ra_skill_step, so it fires engaged or not and paces on the shot itself.
--
-- DIFFERENCE FROM ra_skill_step: no sid lock. RA Skill arms on one mob and
-- self-stops when it dies (that is the point of a skillup session). This
-- follows whatever the current target is, so auto-target picking the next
-- mob just keeps the loop running.
--
-- Blocked conditions here only SKIP the shot, they never clear the mode --
-- the checkbox owns on/off. Running dry on ammo mid-camp should stop the
-- shooting, not silently untick the user's box.
--
-- Returns true only when a shot actually went out, so the caller can own
-- the tick on a fire and otherwise fall through to normal handling (cures,
-- shadows and the rest keep working while engaged).
function GeneralLua.runtime.ranged_mode_step(state, ctx)
    -- WHY IT IS NOT SHOOTING.
    --
    -- This function is now eight gates deep and every one of them looks
    -- identical from in-game: the character stands there. Rather than guess
    -- which one is holding, each records itself on the way out and
    -- bovinebattle's debug panel prints it live. Costs one string assignment
    -- on a path that runs a few times a second.
    state.live = state.live or {}
    local function blocked(reason)
        state.live.rangedmode_block = reason
        return false
    end
    state.combat = state.combat or {}
    state.live   = state.live or {}

    -- Out of ammo (bovinebattle stamps this from the live ammo slot).
    if (state.live and state.live.ranged_ammo_present) ~= true then return blocked('no ammo') end
    -- No ranged weapon equipped at all.
    if state.flags and state.flags.player_ranged_no_weapon == true then return blocked('no ranged weapon') end
    -- Not a /ra job right now: a stat stick parked in the ammo slot is not
    -- a bow. Same gate the RANGED ladder entry and ra_skill_step use.
    if (state.live and state.live.ranged_weapon_ok) ~= true then return blocked('launcher not a bow/xbow/gun') end
    -- Launcher and ammo disagree (arrows under a crossbow). The server
    -- answers this with "You do not have an appropriate ranged weapon
    -- equipped" and every other gate we have passes, so without this the
    -- loop fires into a guaranteed refusal every cadence. Explicit == false:
    -- nil means we could not tell, and that is not a reason to stop.
    if state.live and state.live.ranged_ammo_compatible == false then return blocked('ammo does not match launcher') end

    -- BLACKLISTED. auto-target has given up on this mob -- LOS, unreachable,
    -- refused every action -- and put it on a 30s cooldown. Shooting it anyway
    -- makes the blacklist a lie: the picker stops choosing it while this loop
    -- keeps feeding it ammo, which is what 'blacklisted, then shot it 4s
    -- later' looked like from the outside.
    if state.live and state.live.target_blacklisted == true then
        return blocked('target blacklisted')
    end

    -- NO HATE YET -- THE PULL OWNS THE OPENER.
    --
    -- This loop's job is to keep shooting a mob that is already ours. Getting
    -- hate in the first place is auto-pull's one job, and it does that shot
    -- properly: ammo swap off sleep bolts, align tap, settle, LOS retry.
    -- Firing here first skips all of it and races the pull into the dispatch
    -- gate, which is where 'FAIL (gated 0.55s)' came from.
    --
    -- Only holds off when auto-pull is actually going to do it. With Pull
    -- Off, nothing else will open, so this loop takes the shot itself rather
    -- than standing there waiting for a pull that is never coming.
    if state.live
        and state.live.have_hate_on_target ~= true
        and (ctx.cfgget('auto.pull') or 0) ~= 0
    then
        return blocked('no hate yet, pull opens')
    end

    local now = now_sec()
    local c = state.combat

    -- Need a live target. No sid lock -- whatever the cursor is on.
    --
    -- POST-KILL QUIET: no target, or the target is a corpse. Stamp the
    -- quiet window and drop the tracked sid so the next mob comes in fresh.
    -- Stamped every tick we sit in this state rather than once on the
    -- falling edge, so the window is measured from the LAST moment we had
    -- nothing to shoot at, not from the first.
    local cur_sid = tonumber(ctx.target_server_id or 0) or 0
    if cur_sid == 0 or ctx.target_dead then
        c.rangedmode_quiet_until = now + RANGED_MODE_POST_KILL_SEC
        c.rangedmode_sid    = 0
        c.rangedmode_sid_at = 0.0
        return blocked(ctx.target_dead and 'target dead' or 'no target')
    end

    -- NEW-TARGET SETTLE: first sight of a sid never shoots, it only starts
    -- the clock.
    if cur_sid ~= (tonumber(c.rangedmode_sid or 0) or 0) then
        c.rangedmode_sid    = cur_sid
        c.rangedmode_sid_at = now
        return blocked('new target settle')
    end
    if now < (tonumber(c.rangedmode_quiet_until or 0) or 0) then return blocked('post-kill quiet') end
    if (now - (tonumber(c.rangedmode_sid_at or 0) or 0)) < RANGED_MODE_TARGET_SETTLE_SEC then
        return blocked('new target settle')
    end

    -- MOVEMENT GATE. This is the one ra_skill_step does not need and this
    -- loop absolutely does. RA Skill is armed by hand on a mob you are
    -- already standing in front of, so nothing is ever holding W under it.
    -- This mode runs on a timer while auto-pull's chase_step may be walking
    -- us in, and a shot fired mid-walk gets "You move and interrupt your
    -- aim" -- the recast is spent and nothing comes out. Same flag and same
    -- reasoning as the do_shadows W gate: wait for the movement layer to
    -- release W, then shoot.
    -- movement_busy is the wider signal: W actually held, OR an auto-pull
    -- chase that is live and about to hold it, OR a stuck-wall strafe. Firing
    -- into any of those buys "You move and interrupt your aim". Checking only
    -- player_moving_w missed the frame where the chase had committed but the
    -- key had not gone down yet, which is precisely when the loop's own
    -- cadence liked to land. Kept as a fallback for the same reason it was
    -- used first: it is stamped even when idle_rest_engage has not run.
    if state.live and state.live.movement_busy == true then return blocked('moving (chase/strafe)') end
    if state.live and state.live.player_moving_w == true then return blocked('moving (W held)') end

    -- RANGE GATE. /ra caps around 25y and the server answers anything past
    -- it with "too far away" -- which still burns the attempt. The auto-
    -- target range now goes to 50y, so standing at camp with a mob picked
    -- at 40y is a completely normal state to be in and shooting from there
    -- is pure noise. Ceiling is RANGED_MODE_MAX_YALMS, the server's real 25y
    -- cap -- see the note there about why the chase's 22 is NOT this number.
    local dist = tonumber(ctx.target_distance or ctx.dist)
    if dist == nil then return blocked('no distance') end
    if dist > RANGED_MODE_MAX_YALMS then
        return blocked(string.format('out of range %.1f > %.1f', dist, RANGED_MODE_MAX_YALMS))
    end

    -- MELEE RANGE -- HAND IT BACK.
    --
    -- Ranged mode is three bands, not one:
    --
    --   > 25y            nothing fires; the pull's chase closes the gap
    --   4y .. 25y        shoot, and engage as well once the mob is in
    --                    /attack range so we are swinging the moment it
    --                    arrives
    --   <= 4y (here)     it is a melee fight now. Auto Battle owns it.
    --
    -- The mob walked into us, which is the outcome we were shooting toward.
    -- Carrying on with /ra at 2y is strictly worse than swinging: the shot
    -- has a longer cycle than a melee round, it burns ammo, and every shot
    -- costs the WS and JA windows the ladder wants. Standing down here is
    -- what 'hand the whole thing back to auto battle' means in code.
    --
    -- Not a blacklist and not a disarm: step back in the moment the mob is
    -- pushed out again, or the next one is picked at range.
    if dist <= RANGED_STANDOFF_MELEE_REACH then
        return blocked(string.format('melee range %.1f -- auto battle owns it', dist))
    end

    -- Cadence. Same three gates ra_skill_step uses: never shoot through a
    -- cast, never chain a shot that is still in flight, and wait out the
    -- post-resolve buffer.
    if ctx.spells_locked then return blocked('casting') end
    if ranged_in_progress(state) then return blocked('shot in flight') end
    if not ctx.ra_skill_refire_ok() then return blocked('waiting recast') end

    -- Cooldown checked HERE as well as inside do_ra. refire_ok clears at
    -- resolve + 3.0s but RANGED_CD_SEC is 3.5s, so for that half second
    -- do_ra would be called every tick only to bounce off its own cooldown
    -- and file a blocked-action report each time. Cheaper to not ask.
    if not GeneralLua.cooldowns.is_ready('RANGED') then return blocked('RANGED cooldown') end

    local fired = ctx.do_ra()
    state.live.rangedmode_block = fired and 'FIRED' or 'do_ra refused'
    return fired
end

-- Keypress injection via the windowerinput plugin (/sendkey), same approach
-- movement.lua uses for W. Loads the plugin on first use.
local ssd_windowerinput_loaded = false
local ssd_windowerinput_last_try = 0.0
local function ssd_ensure_windowerinput()
    if ssd_windowerinput_loaded then return true end
    local now = now_sec()
    if (now - ssd_windowerinput_last_try) < 5.0 then return false end
    ssd_windowerinput_last_try = now
    if safe_send('/plugin load windowerinput') then
        ssd_windowerinput_loaded = true
        return true
    end
    return false
end

-- Press then release a key (default: 'h'). Uses /sendkey <key> down + up.
local function ssd_press_key(key_name)
    key_name = tostring(key_name or 'h')
    if not ssd_ensure_windowerinput() then return end
    safe_send('/sendkey ' .. key_name .. ' down')
    safe_send('/sendkey ' .. key_name .. ' up')
end

-- Held-key variants for the walk-to-rear strafe. Down and Up as separate
-- events so we can hold A or D across ticks; ssd_press_key is atomic.
local function ssd_key_down(key_name)
    if not ssd_ensure_windowerinput() then return end
    safe_send('/sendkey ' .. tostring(key_name) .. ' down')
end
local function ssd_key_up(key_name)
    if not ssd_ensure_windowerinput() then return end
    safe_send('/sendkey ' .. tostring(key_name) .. ' up')
end

-- Read lock-on state -- ported directly from XIUI's libs/target.lua so
-- there's no guessing at API names. Two things I had wrong in earlier
-- attempts:
--   * GetIsLockedOn returns 1 or 0, NOT true/false. Comparing == true
--     never matched, so a locked target read as unlocked.
--   * The bitfield method is GetLockedOnFlags on the Target object, not
--     GetLockOnFlags on Player. Bit 0 (0x01) is the lock bit.
-- Returns true/false when readable, nil only if neither method exists.
local function ssd_read_locked()
    local locked = nil
    pcall(function()
        local mm = AshitaCore and AshitaCore:GetMemoryManager()
        if not mm then return end
        local tm = mm.GetTarget and mm:GetTarget()
        if not tm then return end

        -- Primary: GetIsLockedOn returns 1 if locked, 0 otherwise.
        if tm.GetIsLockedOn ~= nil then
            locked = (tm:GetIsLockedOn() == 1)
            return
        end

        -- Fallback: bit 0 of GetLockedOnFlags is the lock bit.
        if tm.GetLockedOnFlags ~= nil then
            local flags = tm:GetLockedOnFlags()
            locked = (bit.band(tonumber(flags) or 0, 0x01) == 0x01)
            return
        end
    end)
    return locked
end

-- Optional one-shot enumeration on the first SSD wait_idle entry, kept
-- for diagnostic use in case a future Ashita build renames things again.
local function ssd_probe_lock_api(state)
    local found = {}
    pcall(function()
        local mm = AshitaCore and AshitaCore:GetMemoryManager()
        if not mm then return end
        local tm = mm.GetTarget and mm:GetTarget()
        if not tm then return end
        if tm.GetIsLockedOn    ~= nil then found[#found + 1] = 'Target.GetIsLockedOn'    end
        if tm.GetLockedOnFlags ~= nil then found[#found + 1] = 'Target.GetLockedOnFlags' end
    end)
    if not (state and state.ui and state.ui.debug_enabled == true) then return end
    if #found == 0 then
        safe_send('/echo [bovinebattle] lock-check API: NONE FOUND on this build')
    else
        safe_send('/echo [bovinebattle] lock-check API: ' .. table.concat(found, ', '))
    end
end

-- Sleep/Sneak/Disengage: a manual one-shot. Fire a sleep bolt; ONLY if the
-- sleep lands, Sneak Attack + pause auto battle 10s + disengage + lock-on, so
-- the player can walk behind the sleeping mob and land the SA. Runs as a tick
-- pre-empt (owns the tick) while active.
function GeneralLua.runtime.ssd_start(state)
    state.combat = state.combat or {}
    state.live = state.live or {}
    if state.live.player_status ~= GeneralLua.status.ENGAGED then
        return false   -- must be engaged
    end
    local sid = tonumber(state.live.player_target_server_id or 0) or 0
    if sid == 0 then
        return false   -- nothing to sleep/SA
    end
    local idx = tonumber(state.live.player_target_index or 0) or 0
    -- Capture the target sid + idx up front. Later phases must read against
    -- THIS sid/idx, not ctx.target_*, because the cursor can slip off the
    -- mob during /attack off + H press and ctx would then read a different
    -- entity (or none), spuriously reporting "mob woke" or losing rear-walk.
    state.combat.ssd = {
        phase       = 'fire',
        fired_at    = 0.0,
        started_at  = now_sec(),
        target_sid  = sid,
        target_idx  = idx,
    }
    return true
end

-- Auto-Sleep-Sneak: same SSD pipeline as the manual button, but the atk
-- ladder just dispatched the sleep bolt via /ra <t>, so we skip the fire
-- phase and enter wait -- which watches for the sleep debuff to land and
-- either advances into disengage / walk-to-rear / SA / /attack, or aborts
-- via ssd_fail_engage if the bolt doesn't stick within 5s.
function GeneralLua.runtime.ssd_start_from_wait(state)
    state.combat = state.combat or {}
    state.live = state.live or {}
    if state.live.player_status ~= GeneralLua.status.ENGAGED then
        return false
    end
    local sid = tonumber(state.live.player_target_server_id or 0) or 0
    if sid == 0 then return false end
    local idx = tonumber(state.live.player_target_index or 0) or 0
    local now = now_sec()
    state.combat.ssd = {
        phase        = 'wait',
        fired_at     = now,             -- shot went out this tick
        started_at   = now,
        target_sid   = sid,
        target_idx   = idx,
        auto_started = true,            -- for future differentiation
    }
    return true
end

function GeneralLua.runtime.ssd_stop(state)
    if state.combat then state.combat.ssd = nil end
end

-- Failure path: SSD gave up (couldn't lock, wall blocked walk-to-rear, SA
-- never applied, whatever). Retarget the mob by captured server id (the
-- cursor may have slipped during disengage/H) and /attack -- better to
-- fight a sleeping mob than fight nothing.
local function ssd_fail_engage(state, reason)
    if reason and reason ~= '' then
        safe_send('/echo [bovinebattle] ' .. reason)
    end
    local ss = state.combat and state.combat.ssd
    if ss then
        local sid = tonumber(ss.target_sid or 0) or 0
        if sid ~= 0 and type(GeneralLua.utils.set_target_by_server_id) == 'function' then
            GeneralLua.utils.set_target_by_server_id(sid)
        end
    end
    safe_send('/attack <t>')
    GeneralLua.runtime.ssd_stop(state)
end

function GeneralLua.runtime.ssd_is_active(state)
    return state and state.combat and state.combat.ssd ~= nil
        and state.combat.ssd.phase ~= nil
end

function GeneralLua.runtime.ssd_step(state, ctx)
    local ss = state.combat and state.combat.ssd
    if not ss then return end
    local now = now_sec()

    -- Abort if the target is gone.
    if ctx.target_dead or (tonumber(ctx.target_server_id or 0) or 0) == 0 then
        GeneralLua.runtime.ssd_stop(state)
        return
    end

    if ss.phase == 'fire' then
        local ammo = tostring(ctx.sleep_ammo_name or '')
        if ammo == '' then GeneralLua.runtime.ssd_stop(state); return end
        if ctx.target_has_waking_dot() then GeneralLua.runtime.ssd_stop(state); return end
        if ctx.spells_locked or ranged_in_progress(state) then return end
        if not ctx.sleep_ammo_equipped then
            safe_send('/equip ammo "' .. ammo .. '"')
        end
        safe_send('/ra <t>')
        state.combat.ranged_fired_at = now_sec()
        state.combat.ranged_cd_set = false
        ss.fired_at = now
        ss.phase = 'wait'
        return
    end

    if ss.phase == 'wait' then
        -- Proceed ONLY if the sleep actually landed on the mob. Check the
        -- captured sid (not ctx) so a cursor slip doesn't fake a wake.
        local sleep_sid = tonumber(ss.target_sid or 0) or 0
        local sleep_up  = (sleep_sid ~= 0)
                          and target_has_packet_debuff_name(state, sleep_sid, 'sleep')
        if sleep_up then
            ss.phase = 'disengage'
        elseif (now - (ss.fired_at or 0)) >= 5.0 then
            safe_send('/echo [bovinebattle] sleep did not land, aborting')
            GeneralLua.runtime.ssd_stop(state)
        end
        return
    end

    -- Kick off the sequence: /attack off. The initial H press happens in
    -- wait_idle on the FIRST tick we're actually idle, not here -- pressing
    -- H while still engaged gets eaten by the game and burns a wasted retry
    -- cycle before the real one lands.
    if ss.phase == 'disengage' then
        safe_send('/attack off')
        ss.disengaged_at    = now
        ss.lockon_retries   = 0
        ss.h_sent           = false
        ss.phase            = 'wait_idle'
        return
    end

    -- Wait for the player to actually reach IDLE and for lock-on to register.
    -- If lock-on hasn't landed after 1s, retry H once and report the result.
    if ss.phase == 'wait_idle' then
        -- On first entry, enumerate every lock-related method the build
        -- actually exposes. Beats trying names one at a time and reporting
        -- "none" when there's a working alternative we didn't check.
        if not ss.lock_probe_reported then
            ss.lock_probe_reported = true
            ssd_probe_lock_api(state)
        end

        local st = tonumber(state.live and state.live.player_status or -1) or -1
        local is_idle = (st == GeneralLua.status.IDLE)

        -- Read via the multi-source helper. Returns nil only when NO API
        -- works -- the H-is-a-toggle rule below uses that to distinguish
        -- "unreadable" (don't press) from "unlocked" (do press).
        local locked = ssd_read_locked()

        -- Read sleep against the CAPTURED sid (not ctx). See ssd_start:
        -- disengage can make the cursor slip off the mob and ctx would
        -- then read a different entity, spuriously reporting "mob woke".
        local sleep_sid  = tonumber(ss.target_sid or 0) or 0
        local sleep_up   = (sleep_sid ~= 0)
                           and target_has_packet_debuff_name(state, sleep_sid, 'sleep')

        -- Throttled diagnostic. Every 2s while wait_idle is unresolved,
        -- echo the three flags gating progress so it's visible what's
        -- blocking. Prints at most 5 times before the phase gives up on
        -- its own timeouts.
        if (now - (ss.last_diag_at or 0.0)) >= 2.0 then
            ss.last_diag_at = now
            if state.ui and state.ui.debug_enabled == true then
                safe_send(('/echo [bovinebattle] SSD wait_idle: idle=%s locked=%s sleep=%s retries=%d'):format(
                    tostring(is_idle),
                    (locked == true and 'yes') or (locked == false and 'no') or 'unreadable',
                    tostring(sleep_up), tonumber(ss.lockon_retries or 0) or 0))
            end
        end

        -- H is a TOGGLE. Pressing it while ALREADY locked unlocks. Retry
        -- only when the read comes back explicitly false. If it comes back
        -- nil (no API), we CANNOT tell; falling through to the abort
        -- branch below is correct.
        --
        -- The first H press used to be a separate "instant" branch that
        -- skipped the cooldown gate. In practice attempt 1 never landed --
        -- fired too fast against the disengage tail -- and attempt 2 was
        -- the one that actually locked on. Merging both into the same
        -- 0.35s-cooldown branch means the FIRST press already has the
        -- settle time that used to only apply to the retry, and lock-on
        -- lands on attempt 1 instead of attempt 2.
        if is_idle and locked == false
           and (ss.lockon_retries or 0) < 5
           and (now - (ss.disengaged_at or 0)) >= 0.35 then
            ssd_press_key("h")            -- retry lock on
            ss.lockon_retries = (ss.lockon_retries or 0) + 1
            ss.disengaged_at = now
            return
        end

        -- Fully ready: idle + locked + mob still asleep -> walk to rear.
        -- The sneak phase used to fire straight from here, but Sneak Attack
        -- lands the DEX-scaled hit only when we're behind the mob, so an
        -- intermediate walk-to-rear step now sits in front of it.
        if is_idle and locked == true and sleep_up then
            local attempt = ss.lockon_retries or 0
            if state.ui and state.ui.debug_enabled == true then
                safe_send('/echo [bovinebattle] lock-on worked on attempt ' .. attempt)
            end
            ss.phase           = 'walk_rear'
            ss.rear_started_at = now
            ss.rear_key        = 'none'   -- currently held strafe key
            return
        end

        -- 5 retries done and still not locked -> abort. Same 0.35s gate
        -- keeps this in step with the retry branch above.
        if (ss.lockon_retries or 0) >= 5 and is_idle and locked == false
           and (now - (ss.disengaged_at or 0)) >= 0.35 then
            ssd_fail_engage(state, 'lock-on failed after 5 retries, /attack instead')
            return
        end

        -- Read returned nil (no lock API on this build) once we're idle.
        -- We cannot verify lock, and hitting H blind would flip whatever
        -- state the player is actually in. Abort with an explanation
        -- rather than gamble.
        if is_idle and locked == nil then
            ssd_fail_engage(state, 'lock-on state unreadable, /attack instead')
            return
        end

        -- Mob woke before we got everything lined up. Mob is awake, we're
        -- idle -- /attack to re-engage rather than stand paused.
        if not sleep_up then
            ssd_fail_engage(state, 'mob woke before SA, /attack instead')
        end
        return
    end

    -- WALK TO REAR. Locked on the sleeping mob, orbit it with A/D until
    -- our heading matches the mob's heading (within REAR_TOL_RAD). Then
    -- release keys and hand off to sneak. Bounded by REAR_WALK_TIMEOUT_SEC
    -- so a mob whose heading we can't match (rotating wildly, wandering
    -- because sleep resist, or unreadable heading field) can't hang SSD.
    if ss.phase == 'walk_rear' then
        local REAR_WALK_TIMEOUT_SEC = 5.0

        local function release_strafe()
            if ss.rear_key == 'a' then ssd_key_up('a')
            elseif ss.rear_key == 'd' then ssd_key_up('d') end
            ss.rear_key = 'none'
        end

        -- Timeout: 5s of strafing without reaching behind. Declare SSD
        -- failed rather than firing a front-facing SA that will get the
        -- weakest possible variant of the ability.
        if (now - (ss.rear_started_at or 0)) >= REAR_WALK_TIMEOUT_SEC then
            release_strafe()
            ssd_fail_engage(state, 'walk-to-rear timeout after 5s, /attack instead')
            return
        end

        -- Bail if the sleep wore off mid-walk. Cursor slip is possible
        -- during strafing, so check the captured sid, not ctx.
        local sleep_sid = tonumber(ss.target_sid or 0) or 0
        local sleep_up  = (sleep_sid ~= 0)
                          and target_has_packet_debuff_name(state, sleep_sid, 'sleep')
        if not sleep_up then
            release_strafe()
            ssd_fail_engage(state, 'mob woke during walk-to-rear, /attack instead')
            return
        end

        local plan = GeneralLua.utils.rear_facing_plan(tonumber(ss.target_idx or 0) or 0)
        if not plan then
            -- Heading unreadable on this build (or mob entity gone). Nothing
            -- to compare against -- just proceed to SA.
            release_strafe()
            if state.ui and state.ui.debug_enabled == true then
                safe_send('/echo [bovinebattle] rear heading unreadable, firing SA from here')
            end
            ss.phase = 'sneak'
            return
        end

        if plan.key == 'none' then
            -- Behind the mob within tolerance -- done.
            release_strafe()
            if state.ui and state.ui.debug_enabled == true then
                safe_send(('/echo [bovinebattle] behind mob (delta %+.1fdeg), firing SA'):format(
                    math.deg(plan.delta_rad)))
            end
            ss.phase = 'sneak'
            return
        end

        -- Still need to orbit. Swap keys if the direction changed (crossed
        -- the rear line and now need to strafe back).
        if plan.key ~= (ss.rear_key or 'none') then
            release_strafe()
            ssd_key_down(plan.key)
            ss.rear_key = plan.key
            -- New direction; seed a fresh stuck-anchor.
            ss.stuck_anchor_x  = tonumber(state.live and state.live.player_x)
            ss.stuck_anchor_y  = tonumber(state.live and state.live.player_y)
            ss.stuck_anchor_at = now
            ss.stuck_flipped   = ss.stuck_flipped or false
            return
        end

        -- STUCK-WALL DETECTION for rear-walk. Direction is already known
        -- (rear_facing_plan picked A or D based on heading), so on stuck
        -- we flip ONCE -- walk the long way around instead of humping the
        -- rock. Second stuck falls through to REAR_WALK_TIMEOUT_SEC above.
        do
            local STUCK_EPS = 0.5
            local STUCK_WIN = 1.0
            local px = tonumber(state.live and state.live.player_x)
            local py = tonumber(state.live and state.live.player_y)
            if px ~= nil and py ~= nil then
                if ss.stuck_anchor_x == nil then
                    ss.stuck_anchor_x  = px
                    ss.stuck_anchor_y  = py
                    ss.stuck_anchor_at = now
                    ss.stuck_flipped   = ss.stuck_flipped or false
                else
                    local dx = px - ss.stuck_anchor_x
                    local dy = py - ss.stuck_anchor_y
                    if math.sqrt(dx*dx + dy*dy) >= STUCK_EPS then
                        ss.stuck_anchor_x  = px
                        ss.stuck_anchor_y  = py
                        ss.stuck_anchor_at = now
                    elseif (now - (ss.stuck_anchor_at or now)) >= STUCK_WIN
                           and ss.stuck_flipped ~= true then
                        -- Flip direction once. Walk the long way.
                        local flipped
                        if ss.rear_key == 'a' then flipped = 'd'
                        elseif ss.rear_key == 'd' then flipped = 'a'
                        end
                        if flipped then
                            release_strafe()
                            ssd_key_down(flipped)
                            ss.rear_key       = flipped
                            ss.stuck_flipped  = true
                            ss.stuck_anchor_x = px
                            ss.stuck_anchor_y = py
                            ss.stuck_anchor_at = now
                            if state.ui and state.ui.debug_enabled == true then
                                safe_send(('/echo [bovinebattle] rear-walk stuck, flipping to %s'):format(flipped))
                            end
                        end
                    end
                end
            end
        end
        return
    end

    if ss.phase == 'sneak' then
        -- Fire Sneak Attack now that we're idle + locked on + mob asleep.
        -- do_ja's own gates (spells_locked, ranged_in_progress) still apply
        -- and this retries next tick if any of them block momentarily.
        if ctx.spells_locked or ranged_in_progress(state) then return end
        if not ctx.do_ja('Sneak Attack', '<me>', 'SNEAK_ATTACK') then
            return
        end
        GeneralLua.cooldowns.set('SNEAK_ATTACK', 60.0)   -- 1min CD on use
        -- Hand off to wait_sa: watch for the SA buff (id 65) to actually
        -- land, THEN /attack. Firing /attack straight after do_ja races
        -- the JA server-side and the swing goes out before SA applies,
        -- costing the whole damage bonus.
        ss.phase        = 'wait_sa'
        ss.sa_wait_since = now
        ss.sa_seen_at    = 0     -- 0 = not yet seen; set to `now` on detection
        return
    end

    if ss.phase == 'wait_sa' then
        -- Sneak Attack buff id = 65. Two-part wait:
        --   1. Watch for buff 65 to appear (server confirming SA landed)
        --   2. Once seen, hold for SA_ATTACK_DELAY_SEC before /attack
        -- The delay is empirical: firing /attack immediately worked for
        -- the first few SSD rounds but then stopped landing, most likely
        -- because /attack is a TOGGLE and racing it against the tail of
        -- SA's server-side processing sometimes reads as "disengage"
        -- instead of "engage". A 1s gap is well past that window.
        local SA_WAIT_TIMEOUT_SEC   = 3.0
        local SA_ATTACK_DELAY_SEC   = 1.0

        if ss.sa_seen_at == nil or ss.sa_seen_at == 0 then
            -- Phase 1: still watching for the buff.
            if player_buff_active({65}) then
                ss.sa_seen_at = now
                if state.ui and state.ui.debug_enabled == true then
                    safe_send('/echo [bovinebattle] SA buff detected, /attack in 1s')
                end
                return
            end
            if (now - (ss.sa_wait_since or 0)) >= SA_WAIT_TIMEOUT_SEC then
                ssd_fail_engage(state, 'SA buff never landed, /attack instead')
                return
            end
            return
        end

        -- Phase 2: buff was seen at ss.sa_seen_at. Fire /attack after the
        -- delay elapses.
        if (now - ss.sa_seen_at) >= SA_ATTACK_DELAY_SEC then
            safe_send('/attack <t>')
            if state.ui and state.ui.debug_enabled == true then
                safe_send('/echo [bovinebattle] /attack fired 1s post-SA')
            end
            GeneralLua.runtime.ssd_stop(state)
            return
        end
        return
    end
end

-- Missing-tool registry: state.flags.missing_tools[name] = true means an item
-- the bot needs (Shihei, Sleep Bolt, ...) wasn't available when it went to use
-- it. Sticky until reset from the UI. The echo ("no <name> found") is emitted
-- once by the central pass in bovinebattle; here we just set/clear the flag.
function GeneralLua.runtime.mark_tool_missing(state, name)
    if not state then return end
    state.flags = state.flags or {}
    state.flags.missing_tools = state.flags.missing_tools or {}
    local key = tostring(name or '')
    if key ~= '' then state.flags.missing_tools[key] = true end
end

function GeneralLua.runtime.clear_tool_missing(state, name)
    if not (state and state.flags) then return end
    local key = tostring(name or '')
    if state.flags.missing_tools then state.flags.missing_tools[key] = nil end
    if state.flags.missing_tools_echoed then state.flags.missing_tools_echoed[key] = nil end
end

-- Advance the sequence one step per call. Casts at most one buff; the
-- caller (tick) invokes this each frame while active and not casting.
-- Returns true if still active, false when the sequence is done.
local function buildbuff_step(state, ctx)
    if not (state.combat and state.combat.buildbuff_active) then return false end

    -- Abort on engage -- this is a pre-fight tool.
    if ctx.engaged01 == 1 then
        GeneralLua.runtime.buildbuff_stop(state)
        return false
    end

    -- Don't step while a cast is in flight; wait for the lock to clear.
    if ctx.spells_locked or ctx.spells_locked_soft then return true end

    BUILDBUFF_STEPS = BUILDBUFF_STEPS or buildbuff_steps()

    local idx = n(state.combat.buildbuff_index)
    if idx < 1 then idx = 1 end

    -- Walk from the current index, skipping steps that aren't castable
    -- or are already up, until we find one to cast or run off the end.
    while idx <= #BUILDBUFF_STEPS do
        local step = BUILDBUFF_STEPS[idx]
        local castable = false
        local already  = false

        local ok1, r1 = pcall(step.castable, ctx)
        castable = ok1 and r1 == true
        if castable then
            local ok2, r2 = pcall(step.already, ctx)
            already = ok2 and r2 == true
        end

        if castable and not already then
            -- MP gate: if we can't afford it, skip rather than stall the
            -- whole sequence waiting on MP that may never come.
            local mp_ok = true
            -- Resolve the spell name the step would cast for the MP check.
            -- do_spell paths gate MP themselves at cast; this is a soft
            -- pre-check so an unaffordable step doesn't fire-and-fail in a
            -- loop. We just attempt the cast; do_spell returns false if it
            -- couldn't dispatch, and we advance regardless.
            local okc, fired = pcall(step.cast, ctx)
            state.combat.buildbuff_index = idx + 1
            if okc and fired == true then
                return true   -- cast dispatched; wait for confirm next frame
            end
            -- cast didn't dispatch (MP/target/etc.) -- advance past it.
            idx = idx + 1
        else
            -- not castable or already up -- skip.
            idx = idx + 1
            state.combat.buildbuff_index = idx
        end
    end

    -- Ran off the end -- sequence complete.
    GeneralLua.runtime.buildbuff_stop(state)
    return false
end


function GeneralLua.runtime.tick(args)
    local state        = args.state
    local atk_list     = args.atk_list or {}
    local def_list     = args.def_list or {}
    local general_list = args.general_list or {}
    local dispatch     = args.dispatch

    set_state_ref(state)

    state.live = state.live or {}
    state.combat = state.combat or {}
    state.flags = state.flags or {}

    MainMagic.ensure_spell_state(state)
    ensure_cooldown_maps(state, atk_list, def_list, general_list)

    if state._lists_sorted ~= true then
        sort_by_priority(atk_list)
        sort_by_priority(def_list)
        state.atk_runtime_list = build_atk_runtime_list(atk_list, general_list)
        state._lists_sorted = true
    end

    local atk_runtime_list = state.atk_runtime_list or atk_list
    local ctx = GeneralLua.runtime.build_ctx(state, dispatch)

    if GeneralLua.runtime.zoning_paused(state, now_sec()) then
        clear_dispatch_state(state)
        return ctx
    end

    -- Sleep/Sneak/Disengage manual sequence. Owns the tick while active:
    -- returning here short-circuits the ladder + dispatch below, so nothing
    -- else can fire (auto attack, auto pull, def responses, etc.) until SSD
    -- finishes or ssd_fail_engage clears state.combat.ssd. This is the
    -- proper busy-lock -- earlier versions instead toggled auto.paused,
    -- which was a UI-visible hack and could get stranded on.
    if GeneralLua.runtime.ssd_is_active(state) then
        GeneralLua.runtime.ssd_step(state, ctx)
        return ctx
    end

    if ctx.cfgget and ctx.cfgget('auto.paused') == true then
        clear_dispatch_state(state)
        GeneralLua.runtime.buildbuff_stop(state)
        GeneralLua.runtime.ra_skill_stop(state)
        if state.combat and state.combat.shadow_sleep then
            state.combat.shadow_sleep.phase = 'idle'
        end
        return ctx
    end

    -- Full-Buff sequence runs while DISENGAGED (it's a pre-fight tool).
    -- Process it before the disengaged early-return below. While the
    -- sequence is active it owns the cast pipeline; combat dispatch is
    -- skipped (we're disengaged anyway, so atk/def pools are empty).
    -- buildbuff_step casts one buff per confirm and disarms when done
    -- or when the player engages.
    if GeneralLua.runtime.buildbuff_is_active(state) then
        buildbuff_step(state, ctx)
        -- Refresh ctx so the just-fired cast's lock is visible to the
        -- caller this frame (prevents the addon from also trying to act).
        return ctx
    end

    -- RA-skill loop. Runs before the disengaged early-return below so a
    -- pure ranged-skillup session (standing back, not meleeing) actually
    -- fires -- the combat dispatch path is gated on being engaged. While
    -- active it owns the tick like Full-Buff; ra_skill_step self-stops on
    -- target death, out of ammo, or no ranged weapon.
    if GeneralLua.runtime.ra_skill_is_active(state) then
        GeneralLua.runtime.ra_skill_step(state, ctx)
        return ctx
    end

    -- Standoff ranged ('Ranged' on the Auto Battle row). Must sit ABOVE the
    -- disengaged early-return below for the same reason the RA-skill loop
    -- does: standing back and shooting means we are frequently not engaged,
    -- and the dispatch path bails outright in that state.
    --
    -- Owns the tick ONLY on a shot. A miss here is usually just "not time
    -- yet" (post-resolve buffer, shot in flight), and swallowing the tick
    -- for that would starve cures, shadows and everything else in the
    -- ladder for the 3s between shots.
    if ctx.cfgget('auto.rangedmode') == true then
        if GeneralLua.runtime.ranged_mode_step(state, ctx) then
            return ctx
        end
    end

    -- Sleep/Sneak/Disengage handled above (before the pause check).

    if ctx.engaged01 ~= 1 then
        clear_dispatch_state(state)
        state.combat.atk_round_seen = state.combat.atk_round_seq or 0
        state.combat.def_round_seen = state.combat.def_round_seq or 0
        return ctx
    end

    init_dispatch_state(state)

    -- Atk round event -> refill atk pool, JA queue, WS slot, RA slot.
    -- Burst suppression skips refills that arrive within atk_burst_window
    -- of the last one so a 4-hit melee burst doesn't reshuffle the pool
    -- four times in 400ms (the old session model had the same guard, kept
    -- here verbatim semantics).
    -- STANDOFF REFILL.
    --
    -- refill_atk_event is the only thing that rebuilds atk_pool, ja_queue,
    -- ws_slot and ra_slot, and it rides atk_detected -- a melee swing. Stand
    -- off at 20y with Ranged on and there are no swings, so none of those
    -- ever refill and the whole ladder is frozen. That is the bot standing
    -- there doing nothing while the mob casts and walks in: not a decision,
    -- just an event that never arrived.
    --
    -- So while Ranged is on and the target is outside melee reach, synthesise
    -- the event on a timer. The ladder then evaluates on its own merits the
    -- way it does mid-melee.
    --
    -- Deliberately NOT gated on the target being alive or claimed -- the
    -- entries each check what they need. The only thing this decides is
    -- WHETHER TO LOOK.
    local standoff_refill = false
    if ctx.cfgget('auto.rangedmode') == true then
        local d = tonumber(ctx.dist or ctx.target_distance)
        if d ~= nil and d > RANGED_STANDOFF_MELEE_REACH then
            local tnow = now_sec()
            if tnow >= (tonumber(state.combat.standoff_refill_at or 0) or 0) then
                standoff_refill = true
                state.combat.standoff_refill_at = tnow + RANGED_STANDOFF_REFILL_SEC
                -- Count them so the debug panel can prove the filler is
                -- actually running. 'The ladder is frozen' and 'the ladder is
                -- running and has nothing to do' look the same on screen.
                state.live = state.live or {}
                state.live.standoff_refills = (tonumber(state.live.standoff_refills or 0) or 0) + 1
                state.live.standoff_refill_last = tnow
            end
        end
    end

    local atk_now = atk_detected(state)
    if atk_now then
        consume_atk_all(state)
    end

    if atk_now or standoff_refill then
        local tnow = now_sec()
        local suppress_until = n(state.combat.atk_burst_suppress_until)

        if tnow >= suppress_until then
            -- Only on a REAL swing. mark_first_atk_on_target is about having
            -- actually connected with this mob; stamping it off a synthetic
            -- event would tell MainMagic we opened when we have not.
            if atk_now then
                MainMagic.mark_first_atk_on_target(state)
            end
            refill_atk_event(state, ctx, atk_runtime_list)
            state.combat.atk_burst_suppress_until = tnow + GeneralLua.timing.atk_burst_window_sec
        end
    end

    -- Def round event -> refill def pool only. Burst-suppressed the same
    -- way atk is: a mob with Double/Triple Attack emits 2-3 "the X hits
    -- you" lines for one swing, each bumping def_round_seq. Without the
    -- guard, each line rebuilds def_pool from scratch -- and if a queued
    -- Cure's HP gate reads momentarily stale between the multi-hit lines,
    -- the pool churns. The guard collapses a multi-hit swing into a single
    -- refill, same as atk_burst_window does for fast melee.
    if def_detected(state) then
        consume_def_all(state)
        local tnow = now_sec()
        local def_suppress_until = n(state.combat.def_burst_suppress_until)

        if tnow >= def_suppress_until then
            refill_def_event(state, ctx, def_list, atk_runtime_list)
            -- Tight 0.35s burst window: only collapses within-swing multi-hit
            -- line spam (Double/Triple Attack, kick attacks). Every real
            -- follow-up hit triggers a fresh eligibility scan so CURE can
            -- enter the pool the moment HP crosses the threshold, without
            -- waiting out a 3s window during which atk work would keep
            -- firing.
            state.combat.def_burst_suppress_until = tnow + 0.35
        end
    end

    -- HB has its own slot that re-evaluates every tick. Independent of
    -- atk/def events because HB triggers from pet/player state (wyvern
    -- ready + HP threshold), not from rounds.
    refresh_hb_slot(state, ctx, atk_runtime_list, def_list)

    -- WS slot self-heals every tick (same treatment as HB). Two holes in
    -- the event-only model: (1) TP can cross 1000 from a source that is
    -- NOT one of our atk rounds -- getting hit, Meditate, a suppressed
    -- multi-hit inside the burst window -- and no atk event means no
    -- refill, so a ready WS sat parked for up to a full burst window.
    -- (2) one transient stale at dispatch time (mob HP gate flicker)
    -- evicted the slot until the next atk event. Refill-when-empty every
    -- tick closes both. Ordering is preserved: drain still runs the JA
    -- cascade first and runtime_is_gated paces the WS behind the chain
    -- gates, so buffs (Berserk/Warcry/Jump) still land before the WS.
    --
    -- NOTE: deliberately NO equivalent for CURE. Cure enters the pool on
    -- def events only, because right-after-a-swing IS the interrupt-safe
    -- cast window. A tick-based cure would fire into the mob's next swing
    -- and get interrupted.
    if state.dispatch.ws_slot == nil then
        state.dispatch.ws_slot = scan_eligible(atk_runtime_list, ctx, 'ws')[1]
    end

    -- Def pool stale watchdog. If def_pool has been sitting non-empty
    -- with no progress (no fire, no fresh queue) for DEF_POOL_STALE_SEC,
    -- clear it. Without this, an entry that's eligible at scan time but
    -- never actually dispatchable -- or a borrowed atk spell wedged
    -- behind a lock that won't clear -- would keep def_pool non-empty
    -- forever, and Part A would block atk indefinitely. 10s is long
    -- enough that it never trips in normal combat (def fires every swing
    -- cycle) but short enough to recover from a wedge.
    if (state.dispatch.def_pool and #state.dispatch.def_pool > 0)
       or (state.dispatch.def_ja_queue and #state.dispatch.def_ja_queue > 0) then
        local progress_at = n(state.dispatch.def_progress_at)
        if progress_at > 0 and (now_sec() - progress_at) >= DEF_POOL_STALE_SEC then
            state.dispatch.def_pool = {}
            state.dispatch.def_ja_queue = {}
            state.dispatch.def_progress_at = 0.0
            state.dispatch._borrowed_id = nil
        end
    end

    -- Ranged sequencer (runs every tick, before dispatch):
    --  1. when a shot resolves, put /ra on its 3s CD and, for a sleep, kick
    --     off the shadows recast;
    --  2. cast shadows once the /ra is fully done.
    do
        local c = state.combat
        local now = now_sec()

        -- 0. SLEEP-SHADOWS FAST PATH. Debuff-detection driven, races the
        -- old resolve-based path below. Watches for the sleep debuff to
        -- appear on the mob we just shot (that's ground truth: shot
        -- landed, mob is now sleeping) and triggers do_shadows the same
        -- way every other shadow cast goes out. Half-second grace after
        -- the debuff shows so the shot's own animation/lock clears.
        local shot_at = tonumber(c.sleep_shot_at or 0) or 0
        if shot_at > 0 and c.sleep_shadows_fired ~= true then
            local shot_sid = tonumber(c.sleep_shot_sid or 0) or 0
            local dh = rawget(_G, 'DebuffHandler')
            local has_sleep = false
            if shot_sid > 0 and dh and type(dh.GetActiveDebuffs) == 'function' then
                local ids = dh.GetActiveDebuffs(shot_sid)
                if type(ids) == 'table' then
                    for i = 1, #ids do
                        local id = tonumber(ids[i] or -1) or -1
                        -- 2 = Sleep, 19 = Sleep II, 193 = Lullaby
                        if id == 2 or id == 19 or id == 193 then
                            has_sleep = true
                            break
                        end
                    end
                end
            end

            if has_sleep and (tonumber(c.sleep_debuff_seen_at or 0) or 0) == 0 then
                c.sleep_debuff_seen_at = now
            end

            local seen_at = tonumber(c.sleep_debuff_seen_at or 0) or 0
            if seen_at > 0 and now >= (seen_at + 0.5) then
                local mode = tostring(ctx.cfgget('auto.shadows_mode') or 'atk')
                -- Bypass ranged_in_progress: the 1s post-resolve grace
                -- exists to protect NORMAL casts from the ranged
                -- animation tail eating them. For sleep-shadows we WANT
                -- to fire inside that window -- the fresh sleep is our
                -- cover, and waiting risks the mob waking on the next
                -- auto-attack swing before Utsusemi lands.
                if ctx.do_shadows(false, mode, { bypass_ranged_grace = true }) then
                    c.sleep_shadows_fired    = true
                    c.sleep_shadows_fired_at = now
                    c.sleep_cast_at          = 0.0    -- old path stand-down
                    c.pending_ra_kind        = nil
                    return ctx
                end
                -- do_shadows blocked (spells_locked, moving_w) -- next
                -- tick retries. 2s error window from seen_at: if we
                -- still haven't dispatched by then, log and stop trying
                -- (something's stuck).
                if now >= (seen_at + 2.5) then
                    report_blocked_action(state, 'SLEEP_SHADOWS',
                        'shadows cast not started in 2s')
                    c.sleep_shadows_fired    = true    -- stop retrying
                    c.sleep_shadows_fired_at = now
                end
            end

            -- Global timeout: shot missed / resisted (no sleep debuff ever
            -- appeared). Clear the cycle so we're not spinning forever.
            if seen_at == 0 and now >= (shot_at + 6.0) then
                c.sleep_shot_at        = 0.0
                c.sleep_shot_sid       = 0
                c.sleep_debuff_seen_at = 0.0
                c.sleep_shadows_fired  = false
            end
        end

        -- 1. Resolution -> weapon-derived CD (hit/miss/interrupt) + sleep
        --    follow-up. See ranged_recast_sec.
        local fired = tonumber(c.ranged_fired_at or 0) or 0
        local resolved = tonumber(c.ranged_resolved_at or 0) or 0
        if fired > 0 and resolved >= fired and c.ranged_cd_set ~= true then
            c.ranged_cd_set = true
            GeneralLua.cooldowns.set('RANGED', ranged_recast_sec(state))
            if c.pending_ra_kind == 'sleep' then
                c.pending_ra_kind = nil
                c.sleep_cast_at = now      -- cast shadows now that the shot is done
            end
        end

        -- 2. Cast shadows for a resolved emergency sleep.
        local sc = tonumber(c.sleep_cast_at or 0) or 0
        if sc > 0 and now >= sc and not ranged_in_progress(state) then
            if (tonumber(ctx.shadow_count or 0) or 0) > 0 then
                c.sleep_cast_at = 0.0
            elseif ctx.do_shadows(false, tostring(ctx.cfgget('auto.shadows_mode') or 'atk')) then
                c.sleep_cast_at = 0.0
                return ctx
            elseif now >= (sc + 5.0) then
                c.sleep_cast_at = 0.0
            end
        end
    end

    -- Single-tick dispatch. Walks the priority order and fires the
    -- first eligible thing. Cast lock and inter-action pacing are
    -- enforced inside drain_dispatch.
    drain_dispatch(state, ctx)

    return ctx
end

---------------------------------------------------------------------
-- EVENTS
---------------------------------------------------------------------

function GeneralLua.events.on_packet_in(args)
    set_state_ref(args.state)
    PacketParser.on_packet_in(args)
end

function GeneralLua.events.on_text_in(args)
    set_state_ref(args.state)
    TextParser.on_text_in(args)
end

function GeneralLua.events.on_command(args)
    local event = args.event
    local state = args.state

    set_state_ref(state)

    local command_args = event.command:args()
    if (#command_args == 0 or not command_args[1]:any('/bovinebattle', '/bb')) then return end
    event.blocked = true

    state.ui = state.ui or {}

    if (#command_args >= 2 and command_args[2]:any('debug')) then
        state.ui.debug_enabled = not state.ui.debug_enabled
        return
    end

    if (#command_args >= 2 and command_args[2]:any('show')) then
        state.ui.is_visible = true
        return
    end

    if (#command_args >= 2 and command_args[2]:any('hide')) then
        state.ui.is_visible = false
        return
    end
end

return GeneralLua