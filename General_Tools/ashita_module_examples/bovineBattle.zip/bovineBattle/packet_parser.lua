--[[---------------------------------------------------------------------------
packet_parser.lua

Purpose
  Own packet-side mob claim / hate tracking for MeleeNostrum.

Owns
  - action packet claim detection
  - mob update packet claim detection
  - claimed target table maintenance inputs
  - zone/reset clear for claimed targets
  - richer tracked-mob metadata for bot mode

Debuff tracking delegated to DebuffHandler (global set in meleenostrum.lua).
Player/party buff reads delegated to StatusHandler (global set in meleenostrum.lua).
---------------------------------------------------------------------------]]--

require('common')
require('helpers')

local bit = require('bit')

local PacketParser = {}

-- Wyvern Healing Breath mob-skill IDs. Used by the action-packet
-- HB detection block to distinguish HB from attack breaths (which
-- come through as the same category). Values below are best-effort
-- guesses for typical FFXI / HorizonXI numbering; the chat-line
-- fallback in text_parser catches HBs whose ID isn't in this table,
-- so if the bot is "working but slow" by ~0.5s per HB chain, the
-- correct IDs aren't in here -- read them off casttimes.txt
-- (wyvern mob_skill cat=N param=M rows that correlate with actual
-- HB chat-lines) and add them here.
local WYVERN_HB_IDS = {
    [562] = true,  -- Healing Breath
    [563] = true,  -- Healing Breath II
    [564] = true,  -- Healing Breath III
    [565] = true,  -- Healing Breath IV
}

local function now_sec()
    return os.clock()
end

local function memory_manager()
    return AshitaCore:GetMemoryManager()
end

local function party_manager()
    local m = memory_manager()
    return m and m:GetParty() or nil
end

local function entity_manager()
    local m = memory_manager()
    return m and m:GetEntity() or nil
end

local function n(v)
    return tonumber(v) or 0
end

local function ensure_mob_status_state(state)
    state.mob_status = state.mob_status or {}
    state.mob_status.by_server_id = state.mob_status.by_server_id or T{}
end

local function ensure_tracked_mobs_state(state)
    state.tracked_mobs = state.tracked_mobs or {}
    state.tracked_mobs.by_index = state.tracked_mobs.by_index or T{}
end

-- Cache of "this entity index is somebody's pet" rebuilt once per packet tick.
-- We scan all entity slots, collect each entity's PetTargetIndex, and any index
-- in this set is excluded from valid-mob detection. Catches: party member pets,
-- other players' BST charmed mobs, SMN avatars, PUP automatons, DRG wyverns.
local _pet_index_set = {}
local _pet_index_set_built_at = -1

local function refresh_pet_index_set()
    local set = {}
    -- Walk a generous range of entity slots. FFXI uses 0..2303 in practice but
    -- 0..1023 covers everything that isn't a far-away NPC.
    for i = 0, 1023 do
        local ok, ent = pcall(GetEntity, i)
        if ok and ent then
            local pti = tonumber(ent.PetTargetIndex or 0) or 0
            -- PetTargetIndex of 0 means "no pet". Anything else is a real index.
            if pti ~= 0 then
                set[pti] = true
            end
        end
    end
    _pet_index_set = set
end

local function is_pet_index(index)
    return _pet_index_set[index] == true
end

local function is_valid_mob(index)
    local entities = entity_manager()
    if not entities then return false end
    if type(entities.GetRenderFlags0) ~= 'function' then return false end

    local ok, flags = pcall(entities.GetRenderFlags0, entities, index)
    if not ok then return false end
    if type(flags) ~= 'number' then return false end

    if bit.band(flags, 0x200) ~= 0x200 then return false end
    if bit.band(flags, 0x4000) ~= 0 then return false end

    -- Reject pets/avatars/automatons - any entity that is somebody's PetTargetIndex.
    if is_pet_index(index) then return false end

    return true
end

local function get_party_member_ids()
    local ids = T{}
    local party = party_manager()
    if not party then return ids end

    for i = 0, 17 do
        if n(party:GetMemberIsActive(i)) == 1 then
            local sid = tonumber(party:GetMemberServerId(i) or 0) or 0
            if sid > 0 then
                table.insert(ids, sid)
            end
        end
    end

    return ids
end

local function get_entity(index)
    local ok, entity = pcall(GetEntity, index)
    return ok and entity or nil
end

local function pkt_u32(data, off0)
    -- Read little-endian u32 at zero-based offset off0.
    if type(data) ~= 'string' then return 0 end
    local i = off0 + 1
    if (i + 3) > #data then return 0 end
    local b1 = data:byte(i)
    local b2 = data:byte(i + 1)
    local b3 = data:byte(i + 2)
    local b4 = data:byte(i + 3)
    return b1 + (b2 * 256) + (b3 * 65536) + (b4 * 16777216)
end

local function get_player_server_id()
    local party = party_manager()
    if not party or type(party.GetMemberServerId) ~= 'function' then return 0 end
    local ok, sid = pcall(function() return party:GetMemberServerId(0) end)
    return (ok and tonumber(sid)) or 0
end

-- Resolve a spell ID to its name via the resource manager.
local function spell_name_by_id(spell_id)
    spell_id = tonumber(spell_id or 0) or 0
    if spell_id <= 0 then return nil end
    local rm = AshitaCore and AshitaCore.GetResourceManager
        and AshitaCore:GetResourceManager()
    if not rm or type(rm.GetSpellById) ~= 'function' then return nil end
    local ok, spell = pcall(function() return rm:GetSpellById(spell_id) end)
    if not ok or not spell then return nil end
    local ok2, nm = pcall(function() return spell.Name and spell.Name[1] end)
    if ok2 and type(nm) == 'string' and #nm > 0 then
        -- Strip control / non-printable bytes the resource may carry, which
        -- otherwise render as garbage (e.g. 'enthunder.?1').
        nm = nm:gsub('[%z\1-\31\127-\255]', '')
        nm = nm:gsub('^%s+', ''):gsub('%s+$', '')
        if #nm > 0 then return nm end
    end
    return nil
end

-- Log the last completed self-cast to general.lua's recorder. Driven purely
-- by the completion action packet -- no is_casting gate, no current_spell
-- dependency -- so it fires for bot, manual, AND menu casts, even paused.
-- general.lua's ps_record_cast_tier sorts it into the Pro / Shell / Shadows
-- box by name.
local function record_completed_self_cast(state, action_packet)
    if not action_packet or not action_packet.UserId then return end
    local self_sid = get_player_server_id()
    if self_sid <= 0 then return end
    if tonumber(action_packet.UserId) ~= self_sid then return end

    local cat = tonumber(action_packet.Type or action_packet.Category or action_packet.ActionType or 0) or 0
    -- Category 4 = magic (spell) finish. Some helpers builds expose 0.
    if cat ~= 4 and cat ~= 0 then return end

    -- Spell ID: prefer the per-target action Param, fall back to packet Param.
    local spell_id = 0
    if action_packet.Targets and action_packet.Targets[0]
        and action_packet.Targets[0].Actions and action_packet.Targets[0].Actions[0] then
        spell_id = tonumber(action_packet.Targets[0].Actions[0].Param or 0) or 0
    end
    if spell_id <= 0 then
        spell_id = tonumber(action_packet.Param or 0) or 0
    end

    local name = spell_name_by_id(spell_id)
    if not name then return end

    -- SELF filter: everything record_cast tracks (Protect/Shell tier,
    -- Utsusemi shadows) is a self-buff, so the spell must have landed on
    -- US, not a party member. Casting Protect III on someone else must NOT
    -- log to our Pro box or feed our upgrade gate. The target's server ID
    -- is in Targets[0].Id; require it to equal our own.
    local target_sid = 0
    if action_packet.Targets and action_packet.Targets[0] then
        target_sid = tonumber(action_packet.Targets[0].Id or 0) or 0
    end
    if target_sid ~= self_sid then return end

    local G = package.loaded['general']
    if G and G.runtime and type(G.runtime.record_cast) == 'function' then
        G.runtime.record_cast(state, name)
    end
end

-- Detect the player using Sneak Attack (job ability) and stamp a 60s CD -- the
-- game-recast read was unreliable, so we track it off the actual use. cat 6 =
-- job ability; resolve the ability id to a name via the resource manager so we
-- don't hardcode it.
-- Party-member WS finishes. Stamps state.combat.party_ws_at[<name_lc>] with
-- the fire time whenever a party member (slots 1-5, not self) lands a WS
-- (type-3 action packet). Consumed by the SC Open/Close gate in general.lua
-- (ctx.sc_ws_allowed) to time our closing WS inside the chain window.
local function record_party_ws(state, action_packet)
    if not action_packet or not action_packet.UserId then return end

    local cat = tonumber(action_packet.Type or action_packet.Category or action_packet.ActionType or 0) or 0
    if cat ~= 3 then return end

    local uid = tonumber(action_packet.UserId) or 0
    if uid <= 0 then return end

    local self_sid = get_player_server_id()
    if self_sid > 0 and uid == self_sid then return end   -- self handled elsewhere

    local ok = pcall(function()
        local party = AshitaCore:GetMemoryManager():GetParty()
        if not party then return end
        for i = 1, 5 do
            if (tonumber(party:GetMemberServerId(i) or 0) or 0) == uid then
                local nm = tostring(party:GetMemberName(i) or ''):lower()
                if nm ~= '' then
                    state.combat = state.combat or {}
                    state.combat.party_ws_at = state.combat.party_ws_at or {}
                    state.combat.party_ws_at[nm] = now_sec()
                end
                return
            end
        end
    end)
    if not ok then return end
end

local function record_self_sneak_attack(state, action_packet)
    if not action_packet or not action_packet.UserId then return end
    local self_sid = get_player_server_id()
    if self_sid <= 0 then return end
    if tonumber(action_packet.UserId) ~= self_sid then return end

    local cat = tonumber(action_packet.Type or action_packet.Category or action_packet.ActionType or 0) or 0
    if cat ~= 6 then return end

    local ab_id = 0
    if action_packet.Targets and action_packet.Targets[0]
        and action_packet.Targets[0].Actions and action_packet.Targets[0].Actions[0] then
        ab_id = tonumber(action_packet.Targets[0].Actions[0].Param or 0) or 0
    end
    if ab_id <= 0 then ab_id = tonumber(action_packet.Param or 0) or 0 end
    if ab_id <= 0 then return end

    local name = ''
    local ok, rm = pcall(function() return AshitaCore:GetResourceManager() end)
    if ok and rm and type(rm.GetAbilityById) == 'function' then
        local ab = rm:GetAbilityById(ab_id)
        if ab and ab.Name and ab.Name[1] then
            name = tostring(ab.Name[1]):lower()
        end
    end
    if name:find('sneak attack', 1, true) then
        local G = package.loaded['general']
        if G and G.cooldowns and type(G.cooldowns.set) == 'function' then
            G.cooldowns.set('SNEAK_ATTACK', 60.0)
        end
    end
end

local function get_pet_index()
    local p = get_entity(0)
    if not p then return 0 end
    return tonumber(p.PetTargetIndex or 0) or 0
end
local function get_entity_server_id(index)
    local ent = get_entity(index)
    if not ent then return 0 end

    return tonumber(
        ent.ServerId or
        ent.ServerID or
        ent.Id or
        ent.ID or
        ent.EntityId or
        ent.EntityID or
        0
    ) or 0
end

local function get_entity_claim_id(index)
    local ent = get_entity(index)
    if not ent then return 0 end

    return tonumber(
        ent.ClaimId or
        ent.ClaimID or
        ent.ClaimOwnerId or
        ent.ClaimOwnerID or
        ent.ClaimServerId or
        ent.ClaimServerID or
        0
    ) or 0
end

local function get_entity_name(index)
    local ent = get_entity(index)
    if not ent then return nil end

    local name = ent.Name
    if type(name) ~= 'string' or name == '' then
        return nil
    end

    return name
end

local function get_entity_distance(index)
    local ent = get_entity(index)
    if not ent then return nil end

    local d = tonumber(ent.Distance)
    if not d or d < 0 then return nil end
    return math.sqrt(d)
end

local function get_debuff_handler()
    return rawget(_G, 'DebuffHandler')
end

local function update_tracked_mob(state, mob_index, opts)
    if not mob_index or mob_index == 0 then return end
    if not is_valid_mob(mob_index) then return end

    ensure_tracked_mobs_state(state)

    local sid = get_entity_server_id(mob_index)
    if sid == 0 then return end

    local row = state.tracked_mobs.by_index[mob_index] or T{}
    local tnow = now_sec()

    row.mob_index = mob_index
    row.server_id = sid
    row.name = get_entity_name(mob_index)
    row.claim_id = get_entity_claim_id(mob_index)
    row.distance = get_entity_distance(mob_index)
    row.updated_at = tnow
    row.seen_action = (opts and opts.seen_action == true) or row.seen_action == true
    row.seen_claim_update = (opts and opts.seen_claim_update == true) or row.seen_claim_update == true

    if opts and opts.claim_id ~= nil then
        row.claim_id = tonumber(opts.claim_id or 0) or 0
    end

    state.tracked_mobs.by_index[mob_index] = row
end

local function prune_invalid_tracked_mobs(state)
    ensure_tracked_mobs_state(state)
    state.all_claimed_targets = state.all_claimed_targets or T{}

    local tnow = now_sec()

    for idx, row in pairs(state.tracked_mobs.by_index) do
        local valid = is_valid_mob(idx)
        local stale = false

        if row and row.updated_at ~= nil then
            stale = (tnow - (tonumber(row.updated_at) or 0)) > 20.0
        end

        if (not valid) or stale then
            state.tracked_mobs.by_index[idx] = nil
            state.all_claimed_targets[idx] = nil
        else
            local hp_ent = get_entity(idx)
            local hp = hp_ent and tonumber(hp_ent.HPPercent or hp_ent.HPP or 0) or 0
            if hp <= 0 then
                state.tracked_mobs.by_index[idx] = nil
                state.all_claimed_targets[idx] = nil
            end
        end
    end

    for idx, v in pairs(state.all_claimed_targets) do
        if v ~= nil then
            if not is_valid_mob(idx) then
                state.all_claimed_targets[idx] = nil
            else
                local hp_ent = get_entity(idx)
                local hp = hp_ent and tonumber(hp_ent.HPPercent or hp_ent.HPP or 0) or 0
                if hp <= 0 then
                    state.all_claimed_targets[idx] = nil
                end
            end
        end
    end
end

function PacketParser.on_packet_in(args)
    local event = args.event
    local state = args.state

    if not event then return end
    if event.injected then return end

    state.all_claimed_targets = state.all_claimed_targets or T{}
    ensure_mob_status_state(state)
    ensure_tracked_mobs_state(state)

    -- Refresh "this index is somebody's pet" set on a 2s cadence.
    -- Cheap enough not to matter, fast enough to spot new pets quickly.
    local tnow = now_sec()
    if tnow - _pet_index_set_built_at >= 2.0 then
        refresh_pet_index_set()
        _pet_index_set_built_at = tnow
    end

    -- Party buff packet: keep StatusHandler current
    if event.id == 0x076 then
        local sh = rawget(_G, 'StatusHandler')
        if sh and type(sh.ReadPartyBuffsFromPacket) == 'function' then
            sh.ReadPartyBuffsFromPacket(event)
        end
        return
    end

    if event.id == 0x0A then
        state.all_claimed_targets = T{}
        state.mob_status.by_server_id = T{}
        state.tracked_mobs.by_index = T{}
        state.live = state.live or {}
        state.live.player_pet_target_server_id = nil
        local dh = get_debuff_handler()
        if dh then dh.HandleZonePacket(event) end
        return
    end

    local action_packet = ParseActionPacket(event)
    if action_packet then
        -- Delegate debuff tracking to DebuffHandler. UNFILTERED -- mousseng's
        -- design is to track every debuff event from every action packet,
        -- with claim filtering applied at query/display time by walking
        -- state.all_claimed_targets (mob-on-party hate set), the same way
        -- enemylist does. Filtering intake by UserId-in-party here would
        -- miss debuffs landed before the bot starts hitting the mob.
        local dh = get_debuff_handler()
        if dh then dh.HandleActionPacket(action_packet) end

        -- Unconditional last-cast logging from the completion packet.
        record_completed_self_cast(state, action_packet)
        record_self_sneak_attack(state, action_packet)
        record_party_ws(state, action_packet)

        -- Player cast completion via action packet. Fires when the
        -- action packet for our own spell finish arrives -- typically
        -- ~0.5s after the cast bar fills, well before the "X casts Y"
        -- chat-line (which can lag 3-5s on HorizonXI for party/mob
        -- target spells). Cuts the is_casting=true tail to
        -- ~bar+0.5s, making the next cast-eligible decision land
        -- sooner. Mirrors nomount's try_action_completion gate.
        --
        -- Gate (all required):
        --   1. is_casting is true (a cast we initiated is tracked)
        --   2. action_packet.UserId equals the local player's
        --      server ID -- the action came from us, not someone else
        --   3. action_packet.Type == 4 (spell finish) when the field
        --      is exposed by this helpers build. Type 8 is the
        --      "magic start" packet at /ma send time; we never want
        --      to credit on that. If no Type field is exposed at all,
        --      we fall through and rely on (4) -- the type-8 packet
        --      arrives at elapsed=~0, well below cast_time.
        --   4. elapsed since spell_started_at must be >= the
        --      tracked spell's cast_time_sec. Rejects type-8 starts
        --      and any non-spell action (job ability mid-cast, etc.)
        --      that lands before the bar could have finished.
        --
        -- On a hit: TextParser.confirm_player_spell runs the same
        -- bookkeeping the chat-line path does (cooldown set, HB
        -- notify, last_confirmed_*) -- single source of truth.
        do
            local combat = state.combat
            if combat and combat.is_casting == true and action_packet.UserId then
                local self_sid = get_player_server_id()
                if self_sid > 0 and tonumber(action_packet.UserId) == self_sid then
                    local ap_type = tonumber(
                        action_packet.Type
                        or action_packet.Category
                        or action_packet.ActionType
                        or 0)
                    if ap_type == 0 or ap_type == 4 then
                        local started_at = tonumber(combat.spell_started_at or 0) or 0
                        local cast_time  = tonumber(combat.cast_time_sec or 4.0) or 4.0
                        local elapsed    = now_sec() - started_at
                        if elapsed >= cast_time then
                            local spell_name = combat.current_spell
                            if type(spell_name) == 'string' and #spell_name > 0 then
                                local TextParser = package.loaded['text_parser']
                                    or require('text_parser')
                                if TextParser and type(TextParser.confirm_player_spell) == 'function' then
                                    TextParser.confirm_player_spell(state, spell_name, now_sec(), 'action')
                                end
                            end
                        end
                    end
                end
            end
        end

        -- Player ranged-shot resolution for the RA-skill loop. A completed
        -- ranged attack (hit OR miss) arrives as action.Type == 2 from the
        -- local player. Stamp the resolve time so the loop refires a couple
        -- seconds after the shot lands rather than spamming /ra mid-flight.
        -- Interrupts produce no action packet and are caught by text_parser.
        do
            local combat = state.combat
            if combat and action_packet.UserId then
                local self_sid = get_player_server_id()
                if self_sid > 0 and tonumber(action_packet.UserId) == self_sid then
                    local ap_type = tonumber(
                        action_packet.Type
                        or action_packet.Category
                        or action_packet.ActionType
                        or 0)
                    if ap_type == 2 then
                        combat.ranged_resolved_at = now_sec()
                    end
                end
            end
        end

        -- Pet target tracking: if actor is our pet, the primary target is what the pet is on.
        local pet_idx = get_pet_index()
        if pet_idx ~= 0 and action_packet.UserIndex == pet_idx
           and action_packet.Targets and action_packet.Targets[0] then
            local tid = tonumber(action_packet.Targets[0].Id or 0) or 0
            if tid ~= 0 then
                state.live = state.live or {}
                state.live.player_pet_target_server_id = tid
            end

            -- Wyvern HB detection (fast path). When our wyvern fires
            -- HB, the action packet comes through as a mob-skill /
            -- pet-ability category. BUT wyvern also uses attack
            -- breaths (Flame/Frost/Sand/Lightning/Hydro/Gust Breath)
            -- in attack mode -- those are the same category. A
            -- category-only filter would false-trigger HB-ready on
            -- attack breaths -> bot fires next trigger spell -> MP
            -- wasted on a wyvern that's not in HB mode.
            --
            -- So we additionally gate on the packet's skill ID (Param
            -- at packet level). WYVERN_HB_IDS holds the known IDs.
            -- These are best-effort guesses for HorizonXI; if they're
            -- wrong, the chat-line fallback in text_parser still
            -- fires notify_hb_actually_fired (slower by ~0.5s but
            -- reliable). The diagnostic log below records every
            -- wyvern mob-skill packet's ID so the user can confirm
            -- which IDs map to HB on their server and tune the table.
            local cat = tonumber(
                action_packet.Type
                or action_packet.Category
                or action_packet.ActionType
                or 0)
            if cat == 11 or cat == 13 then
                local param = tonumber(action_packet.Param or 0) or 0

                -- Diagnostic: every wyvern mob-skill firing, ID + cat,
                -- so HB IDs can be identified by correlation with
                -- chat-line.
                local ok_log, CastLog = pcall(require, 'cast_log')
                if ok_log and CastLog and type(CastLog.note) == 'function' then
                    CastLog.note(string.format(
                        'wyvern mob_skill cat=%d param=%d', cat, param))
                end

                if WYVERN_HB_IDS[param] then
                    local HbS = package.loaded['hb_shadows_helper']
                    if HbS and type(HbS.notify_hb_actually_fired) == 'function' then
                        HbS.notify_hb_actually_fired(state, 'packet')
                    end
                end
            end
        end

        if action_packet.UserIndex and GetIsMobByIndex(action_packet.UserIndex) and is_valid_mob(action_packet.UserIndex) then
            local party_member_ids = get_party_member_ids()

            update_tracked_mob(state, action_packet.UserIndex, {
                seen_action = true,
            })

            for i = 0, #action_packet.Targets do
                local target = action_packet.Targets[i]
                if target and party_member_ids:contains(target.Id) then
                    state.all_claimed_targets[action_packet.UserIndex] = 1
                    break
                end
            end
        end
    end

    -- Message packet (0x029): wear-off and death clearing via DebuffHandler
    local message_packet = ParseMessagePacket(event.data)
    if message_packet then
        local dh = get_debuff_handler()
        if dh then dh.HandleMessagePacket(message_packet) end
    end

    local mob_update = ParseMobUpdatePacket(event)
    if mob_update and mob_update.monsterIndex and is_valid_mob(mob_update.monsterIndex) then
        update_tracked_mob(state, mob_update.monsterIndex, {
            claim_id = mob_update.newClaimId,
            seen_claim_update = true,
        })

        if mob_update.newClaimId then
            local party_member_ids = get_party_member_ids()
            if party_member_ids:contains(mob_update.newClaimId) then
                state.all_claimed_targets[mob_update.monsterIndex] = 1
            end
        end
    end

    -- Pet target via raw 0x068: when owner_sid (0x08) == us, target_id (0x14) is the pet's target.
    -- Same offsets bsthud.lua uses; this is the most responsive signal (updates without an attack swing).
    if event.id == 0x068 then
        local me = get_player_server_id()
        if me ~= 0 then
            local owner_sid = pkt_u32(event.data, 0x08)
            if owner_sid == me then
                local tid = pkt_u32(event.data, 0x14)
                if tid ~= 0 then
                    state.live = state.live or {}
                    state.live.player_pet_target_server_id = tid
                end
            end
        end
    end

    prune_invalid_tracked_mobs(state)
end

return PacketParser