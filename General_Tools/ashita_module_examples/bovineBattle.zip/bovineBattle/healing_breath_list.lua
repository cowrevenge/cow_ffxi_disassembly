-- healing_breath_list.lua
-- Aggregates HB trigger spell lists from subjob-specific files.

local GeneralL = {}

local function try_require(name)
    local ok, mod = pcall(require, name)
    if not ok or type(mod) ~= 'table' then
        return {}
    end
    return mod
end

local function append_all(dst, src)
    if type(src) ~= 'table' then
        return
    end

    for i = 1, #src do
        local ent = src[i]
        if type(ent) == 'table' and ent.name then
            dst[#dst + 1] = ent
        end
    end
end

local hb_whm = try_require('hb_whm')
local hb_rdm = try_require('hb_rdm')
local hb_nin = try_require('hb_nin')
local hb_blu = try_require('hb_blu')
local hb_brd = try_require('hb_brd')
local hb_pld = try_require('hb_pld')

GeneralL.list = {}

append_all(GeneralL.list, hb_whm)
append_all(GeneralL.list, hb_rdm)
append_all(GeneralL.list, hb_nin)
append_all(GeneralL.list, hb_blu)
append_all(GeneralL.list, hb_brd)
append_all(GeneralL.list, hb_pld)

GeneralL.reset_after_sec = 30.0
GeneralL.force_me_targets = false

return GeneralL