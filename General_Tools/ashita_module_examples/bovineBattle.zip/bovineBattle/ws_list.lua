--[[---------------------------------------------------------------------------
ws_list.lua
HorizonXI 75-cap weapon skill list, parsed from LandSandBoat weapon_skills.sql
and cross-referenced with HorizonXI wiki.

Filter:
  - 12 melee weapon skills + Archery + Marksmanship.
  - Excluded: Throwing, instruments, automaton, fishing.
  - skill_level <= 250 (rules out WotG cap-raise WS at 290+ and Aftermath at 357).
  - Quest/relic/mythic unlocks: LSB stores these as skilllevel=0, but on HXI
    they still require 240 weapon skill to use, so they are recorded as 240 here.
  - Confirmed post-era exclusions: Victory Smite, Final Paradise, Chant du Cygne,
    Knights of Rotund (Empyrean/Mythic Aftermath).

Sources:
  https://github.com/LandSandBoat/server/blob/base/sql/weapon_skills.sql
  https://horizonxi.fandom.com/wiki/Weapon_skill_quests

FIELDS

  skill_level  What to gate on. The curated HXI-usable number, unchanged from
               the previous revision of this file.

  lsb_skill    The raw skilllevel column out of weapon_skills.sql. Added so
               the curation is auditable instead of implicit.

  unlock       weapon_skills.unlock_id, present only when non-zero. A WS with
               an unlock id is quest-gated.

  range        weapon_skills.range, in yalms. THIS IS THE INTERESTING ONE --
               see the note below.

  main_only    weapon_skills.main_only, present only when 1. When set, a
               SUBJOB entry in jobs does not count.

  jobs         Space-separated job abbreviations from weapon_skills.jobs,
               decoded. ABSENT MEANS NO JOB RESTRICTION, NOT 'nobody' -- see
               below. Do not treat a missing jobs field as an empty set.

CURATION AUDIT: all 177 entries were re-checked against LSB. 51 differ from
the raw column and every one of them is the documented quest case -- LSB has
0, this file has 240. There is not a single entry where LSB carries a real
number that disagrees with the curated value. The hand-curation was right.

JOBS, AND THE TRAP IN IT

weapon_skills.jobs is a 22-byte blob, one byte per job, and LSB memcpys it to
index 1 of its array (battleutils.cpp), so blob byte i is job i+1. Decoded and
cross-checked: Dancing Edge comes out THF DNC, Blade: Ku comes out NIN,
Tachi: Kasha comes out SAM, Asuran Fists comes out MNK PUP.

THE TRAP: relic and mythic WS have an ALL-ZERO jobs blob. Final Heaven, Mercy
Stroke, Namas Arrow and Coronach all decode to nothing. That is not 'no job
can use this' -- those WS are granted by the WEAPON, so any job holding the
relic can use them, and they never go through the normal job check. 18 of the
177 entries are in this state. Filter them out as 'no matching job' and they
vanish from the picker for the one character who actually has the relic.

So: jobs is OMITTED for those rows, and M.job_can_use returns true when it is
missing. The server-side rule this mirrors is CanUseWeaponskill in
battleutils.cpp:

    getJob(MainJob) > 0 || (getJob(SubJob) > 0 && !mainOnly)

NOT MODELLED: CanUseWeaponskill also requires hasLearnedWeaponskill for any WS
with an unlock id, and that is per-character quest state we cannot see from
here. A quest WS you have not unlocked will still be listed.

RANGE, AND WHY IT MATTERS FOR THE RANGED MODE

Melee WS are range 3. Archery and Marksmanship WS are range 20. That is not a
detail: a ranged WS can be thrown from twenty yalms out, so gating one behind
a melee reach check makes it unusable forever rather than merely late.

range is FORCED here, not copied: 3 for every melee skill, 20 for Archery and
Marksmanship. Five rows in LSB disagree and are deliberately overridden --
Gust Slash, Cyclone and Mistral Axe are 14 in the SQL, Blast Arrow and Blast
Shot are 5. Do not "fix" these back to the SQL values; the flat 3/20 split is
the intended behaviour and a regeneration script must reapply it.
---------------------------------------------------------------------------]]--

local M = {}

-- Grouped by weapon skill name (matches weapon_db.lua skill strings).
-- Each entry: { id=, name=, skill_level=, lsb_skill=, range=, [unlock=], [jobs=], [main_only=] }
M.WEAPON_SKILLS = {
    ["Hand-to-Hand"] = {
        { id=  1, name="Combo", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR MNK THF NIN PUP DNC" },
        { id=  2, name="Shoulder Tackle", skill_level= 40, lsb_skill= 40, range= 3, jobs="WAR MNK THF NIN PUP DNC" },
        { id=  3, name="One Inch Punch", skill_level= 75, lsb_skill= 75, range= 3, jobs="MNK PUP" },
        { id=  4, name="Backhand Blow", skill_level=100, lsb_skill=100, range= 3, jobs="WAR MNK THF NIN PUP DNC" },
        { id=  5, name="Raging Fists", skill_level=125, lsb_skill=125, range= 3, jobs="MNK PUP" },
        { id=  6, name="Spinning Attack", skill_level=150, lsb_skill=150, range= 3, jobs="WAR MNK THF NIN PUP DNC" },
        { id=  7, name="Howling Fist", skill_level=200, lsb_skill=200, range= 3, jobs="MNK PUP", main_only=1 },
        { id=  8, name="Dragon Kick", skill_level=225, lsb_skill=225, range= 3, jobs="MNK PUP", main_only=1 },
        { id= 10, name="Final Heaven", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id= 11, name="Ascetic's Fury", skill_level=240, lsb_skill=  0, range= 3, unlock=15, jobs="MNK", main_only=1 },
        { id= 12, name="Stringing Pummel", skill_level=240, lsb_skill=  0, range= 3, unlock=16, jobs="PUP", main_only=1 },
        { id=  9, name="Asuran Fists", skill_level=250, lsb_skill=250, range= 3, unlock=1, jobs="MNK PUP", main_only=1 },
    },
    ["Dagger"] = {
        { id= 16, name="Wasp Sting", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN COR PUP DNC SCH" },
        { id= 19, name="Gust Slash", skill_level= 40, lsb_skill= 40, range= 3, jobs="WAR BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN COR PUP DNC SCH" },
        { id= 18, name="Shadowstitch", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN COR PUP DNC SCH" },
        { id= 17, name="Viper Bite", skill_level=100, lsb_skill=100, range= 3, jobs="RDM THF BRD RNG NIN DNC" },
        { id= 20, name="Cyclone", skill_level=125, lsb_skill=125, range= 3, jobs="RDM THF BRD RNG NIN DNC" },
        { id= 21, name="Energy Steal", skill_level=150, lsb_skill=150, range= 3, jobs="WAR BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN COR PUP DNC SCH" },
        { id= 22, name="Energy Drain", skill_level=175, lsb_skill=175, range= 3, jobs="RDM THF BRD RNG NIN DNC" },
        { id= 23, name="Dancing Edge", skill_level=200, lsb_skill=200, range= 3, jobs="THF DNC", main_only=1 },
        { id= 24, name="Shark Bite", skill_level=225, lsb_skill=225, range= 3, jobs="THF DNC", main_only=1 },
        { id= 25, name="Evisceration", skill_level=230, lsb_skill=230, range= 3, unlock=2, jobs="WAR RDM THF BST BRD RNG NIN COR DNC", main_only=1 },
        { id= 26, name="Mercy Stroke", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id= 27, name="Mandalic Stab", skill_level=240, lsb_skill=  0, range= 3, unlock=17, jobs="THF", main_only=1 },
        { id= 28, name="Mordant Rime", skill_level=240, lsb_skill=  0, range= 3, unlock=18, jobs="BRD", main_only=1 },
        { id= 29, name="Pyrrhic Kleos", skill_level=240, lsb_skill=  0, range= 3, unlock=19, jobs="DNC", main_only=1 },
        { id= 31, name="Rudra's Storm", skill_level=240, lsb_skill=  0, range= 3, unlock=36, jobs="THF BRD DNC", main_only=1 },
    },
    ["Sword"] = {
        { id= 32, name="Fast Blade", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR RDM THF PLD DRK BST BRD RNG SAM NIN DRG BLU COR DNC RUN" },
        { id= 33, name="Burning Blade", skill_level= 30, lsb_skill= 30, range= 3, jobs="WAR RDM THF PLD DRK BST BRD RNG SAM NIN DRG BLU COR DNC RUN" },
        { id= 34, name="Red Lotus Blade", skill_level= 50, lsb_skill= 50, range= 3, jobs="WAR RDM PLD DRK BLU RUN" },
        { id= 35, name="Flat Blade", skill_level= 75, lsb_skill= 75, range= 3, jobs="WAR RDM THF PLD DRK BST BRD RNG SAM NIN DRG BLU COR DNC RUN" },
        { id= 36, name="Shining Blade", skill_level=100, lsb_skill=100, range= 3, jobs="WAR RDM THF PLD DRK BST BRD RNG SAM NIN DRG BLU COR DNC RUN" },
        { id= 37, name="Seraph Blade", skill_level=125, lsb_skill=125, range= 3, jobs="WAR RDM PLD DRK BLU RUN" },
        { id= 38, name="Circle Blade", skill_level=150, lsb_skill=150, range= 3, jobs="WAR RDM THF PLD DRK BST BRD RNG SAM NIN DRG BLU COR DNC RUN" },
        { id= 39, name="Spirits Within", skill_level=175, lsb_skill=175, range= 3, jobs="WAR RDM THF PLD DRK BST BRD RNG SAM NIN DRG BLU COR DNC RUN" },
        { id= 40, name="Vorpal Blade", skill_level=200, lsb_skill=200, range= 3, jobs="WAR RDM PLD DRK BLU RUN" },
        { id= 41, name="Swift Blade", skill_level=225, lsb_skill=225, range= 3, jobs="PLD RUN", main_only=1 },
        { id= 42, name="Savage Blade", skill_level=240, lsb_skill=240, range= 3, unlock=3, jobs="WAR RDM PLD DRK BLU COR RUN", main_only=1 },
        { id= 43, name="Knights of Round", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id= 44, name="Death Blossom", skill_level=240, lsb_skill=  0, range= 3, unlock=20, jobs="RDM", main_only=1 },
        { id= 45, name="Atonement", skill_level=240, lsb_skill=  0, range= 3, unlock=21, jobs="PLD", main_only=1 },
        { id= 46, name="Expiacion", skill_level=240, lsb_skill=  0, range= 3, unlock=22, jobs="BLU", main_only=1 },
        { id=238, name="Uriel Blade", skill_level=240, lsb_skill=  0, range= 3 },
        { id=239, name="Glory Slash", skill_level=240, lsb_skill=  0, range= 3 },
    },
    ["Great Sword"] = {
        { id= 48, name="Hard Slash", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR PLD DRK RUN" },
        { id= 49, name="Power Slash", skill_level= 30, lsb_skill= 30, range= 3, jobs="WAR PLD DRK RUN" },
        { id= 50, name="Frostbite", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR PLD DRK RUN" },
        { id= 51, name="Freezebite", skill_level=100, lsb_skill=100, range= 3, jobs="WAR PLD DRK RUN" },
        { id= 52, name="Shockwave", skill_level=150, lsb_skill=150, range= 3, jobs="WAR PLD DRK RUN" },
        { id= 53, name="Crescent Moon", skill_level=175, lsb_skill=175, range= 3, jobs="WAR PLD DRK RUN" },
        { id= 54, name="Sickle Moon", skill_level=200, lsb_skill=200, range= 3, jobs="PLD DRK RUN", main_only=1 },
        { id= 55, name="Spinning Slash", skill_level=225, lsb_skill=225, range= 3, jobs="PLD DRK RUN", main_only=1 },
        { id= 57, name="Scourge", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id= 59, name="Torcleaver", skill_level=240, lsb_skill=  0, range= 3, unlock=38, jobs="PLD DRK", main_only=1 },
        { id= 61, name="Dimidiation", skill_level=240, lsb_skill=  0, range= 3, unlock=49, jobs="RUN", main_only=1 },
        { id= 56, name="Ground Strike", skill_level=250, lsb_skill=250, range= 3, unlock=4, jobs="WAR PLD DRK RUN" },
    },
    ["Axe"] = {
        { id= 64, name="Raging Axe", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR DRK BST RNG RUN" },
        { id= 65, name="Smash Axe", skill_level= 40, lsb_skill= 40, range= 3, jobs="WAR DRK BST RNG RUN" },
        { id= 66, name="Gale Axe", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR DRK BST RNG RUN" },
        { id= 67, name="Avalanche Axe", skill_level=100, lsb_skill=100, range= 3, jobs="WAR DRK BST RNG RUN" },
        { id= 68, name="Spinning Axe", skill_level=150, lsb_skill=150, range= 3, jobs="WAR DRK BST RUN" },
        { id= 69, name="Rampage", skill_level=175, lsb_skill=175, range= 3, jobs="WAR DRK BST RNG RUN" },
        { id= 70, name="Calamity", skill_level=200, lsb_skill=200, range= 3, jobs="WAR BST", main_only=1 },
        { id= 71, name="Mistral Axe", skill_level=225, lsb_skill=225, range= 3, jobs="WAR BST", main_only=1 },
        { id= 72, name="Decimation", skill_level=240, lsb_skill=240, range= 3, unlock=5, jobs="WAR DRK BST RNG RUN", main_only=1 },
        { id= 73, name="Onslaught", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id= 74, name="Primal Rend", skill_level=240, lsb_skill=  0, range= 3, unlock=23, jobs="BST", main_only=1 },
        { id= 76, name="Cloudsplitter", skill_level=240, lsb_skill=  0, range= 3, unlock=39, jobs="WAR BST", main_only=1 },
    },
    ["Great Axe"] = {
        { id= 80, name="Shield Break", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR DRK RUN" },
        { id= 81, name="Iron Tempest", skill_level= 40, lsb_skill= 40, range= 3, jobs="WAR DRK RUN" },
        { id= 82, name="Sturmwind", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR DRK RUN" },
        { id= 83, name="Armor Break", skill_level=100, lsb_skill=100, range= 3, jobs="WAR DRK RUN" },
        { id= 84, name="Keen Edge", skill_level=150, lsb_skill=150, range= 3, jobs="WAR DRK RUN" },
        { id= 85, name="Weapon Break", skill_level=175, lsb_skill=175, range= 3, jobs="WAR DRK RUN" },
        { id= 86, name="Raging Rush", skill_level=200, lsb_skill=200, range= 3, jobs="WAR", main_only=1 },
        { id= 87, name="Full Break", skill_level=225, lsb_skill=225, range= 3, jobs="WAR", main_only=1 },
        { id= 88, name="Steel Cyclone", skill_level=240, lsb_skill=240, range= 3, unlock=6, jobs="WAR DRK RUN", main_only=1 },
        { id= 89, name="Metatron Torment", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id= 90, name="King's Justice", skill_level=240, lsb_skill=  0, range= 3, unlock=24, jobs="WAR", main_only=1 },
        { id= 92, name="Ukko's Fury", skill_level=240, lsb_skill=  0, range= 3, unlock=40, jobs="WAR", main_only=1 },
    },
    ["Scythe"] = {
        { id= 96, name="Slice", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR BLM DRK BST" },
        { id= 97, name="Dark Harvest", skill_level= 30, lsb_skill= 30, range= 3, jobs="WAR BLM DRK BST" },
        { id= 98, name="Shadow of Death", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR DRK" },
        { id= 99, name="Nightmare Scythe", skill_level=100, lsb_skill=100, range= 3, jobs="WAR BLM DRK BST" },
        { id=100, name="Spinning Scythe", skill_level=125, lsb_skill=125, range= 3, jobs="WAR BLM DRK BST" },
        { id=101, name="Vorpal Scythe", skill_level=150, lsb_skill=150, range= 3, jobs="WAR BLM DRK BST" },
        { id=102, name="Guillotine", skill_level=200, lsb_skill=200, range= 3, jobs="DRK", main_only=1 },
        { id=103, name="Cross Reaper", skill_level=225, lsb_skill=225, range= 3, jobs="DRK", main_only=1 },
        { id=104, name="Spiral Hell", skill_level=240, lsb_skill=240, range= 3, unlock=7, jobs="WAR DRK BST", main_only=1 },
        { id=105, name="Catastrophe", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=106, name="Insurgency", skill_level=240, lsb_skill=  0, range= 3, unlock=25, jobs="DRK", main_only=1 },
        { id=108, name="Quietus", skill_level=240, lsb_skill=  0, range= 3, unlock=41, jobs="DRK", main_only=1 },
    },
    ["Polearm"] = {
        { id=112, name="Double Thrust", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR PLD SAM DRG" },
        { id=113, name="Thunder Thrust", skill_level= 30, lsb_skill= 30, range= 3, jobs="WAR PLD SAM DRG" },
        { id=114, name="Raiden Thrust", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR PLD DRG" },
        { id=115, name="Leg Sweep", skill_level=100, lsb_skill=100, range= 3, jobs="WAR PLD SAM DRG" },
        { id=116, name="Penta Thrust", skill_level=150, lsb_skill=150, range= 3, jobs="WAR PLD SAM DRG" },
        { id=117, name="Vorpal Thrust", skill_level=175, lsb_skill=175, range= 3, jobs="WAR PLD SAM DRG" },
        { id=118, name="Skewer", skill_level=200, lsb_skill=200, range= 3, jobs="DRG", main_only=1 },
        { id=119, name="Wheeling Thrust", skill_level=225, lsb_skill=225, range= 3, jobs="DRG", main_only=1 },
        { id=120, name="Impulse Drive", skill_level=240, lsb_skill=240, range= 3, unlock=8, jobs="WAR SAM DRG", main_only=1 },
        { id=121, name="Geirskogul", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=122, name="Drakesbane", skill_level=240, lsb_skill=  0, range= 3, unlock=26, jobs="DRG", main_only=1 },
        { id=124, name="Camlann's Torment", skill_level=240, lsb_skill=  0, range= 3, unlock=42, jobs="DRG", main_only=1 },
    },
    ["Katana"] = {
        { id=128, name="Blade: Rin", skill_level=  5, lsb_skill=  5, range= 3, jobs="NIN" },
        { id=129, name="Blade: Retsu", skill_level= 30, lsb_skill= 30, range= 3, jobs="NIN" },
        { id=130, name="Blade: Teki", skill_level= 70, lsb_skill= 70, range= 3, jobs="NIN" },
        { id=131, name="Blade: To", skill_level=100, lsb_skill=100, range= 3, jobs="NIN" },
        { id=132, name="Blade: Chi", skill_level=150, lsb_skill=150, range= 3, jobs="NIN" },
        { id=133, name="Blade: Ei", skill_level=175, lsb_skill=175, range= 3, jobs="NIN" },
        { id=134, name="Blade: Jin", skill_level=200, lsb_skill=200, range= 3, jobs="NIN", main_only=1 },
        { id=135, name="Blade: Ten", skill_level=225, lsb_skill=225, range= 3, jobs="NIN", main_only=1 },
        { id=137, name="Blade: Metsu", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=138, name="Blade: Kamu", skill_level=240, lsb_skill=  0, range= 3, unlock=27, jobs="NIN", main_only=1 },
        { id=140, name="Blade: Hi", skill_level=240, lsb_skill=  0, range= 3, unlock=43, jobs="NIN", main_only=1 },
        { id=136, name="Blade: Ku", skill_level=250, lsb_skill=250, range= 3, unlock=9, jobs="NIN", main_only=1 },
    },
    ["Great Katana"] = {
        { id=144, name="Tachi: Enpi", skill_level=  5, lsb_skill=  5, range= 3, jobs="SAM NIN" },
        { id=145, name="Tachi: Hobaku", skill_level= 30, lsb_skill= 30, range= 3, jobs="SAM NIN" },
        { id=146, name="Tachi: Goten", skill_level= 70, lsb_skill= 70, range= 3, jobs="SAM NIN" },
        { id=147, name="Tachi: Kagero", skill_level=100, lsb_skill=100, range= 3, jobs="SAM NIN" },
        { id=148, name="Tachi: Jinpu", skill_level=150, lsb_skill=150, range= 3, jobs="SAM NIN" },
        { id=149, name="Tachi: Koki", skill_level=175, lsb_skill=175, range= 3, jobs="SAM NIN" },
        { id=150, name="Tachi: Yukikaze", skill_level=200, lsb_skill=200, range= 3, jobs="SAM", main_only=1 },
        { id=151, name="Tachi: Gekko", skill_level=225, lsb_skill=225, range= 3, jobs="SAM", main_only=1 },
        { id=153, name="Tachi: Kaiten", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=154, name="Tachi: Rana", skill_level=240, lsb_skill=  0, range= 3, unlock=28, jobs="SAM", main_only=1 },
        { id=156, name="Tachi: Fudo", skill_level=240, lsb_skill=  0, range= 3, unlock=44, jobs="SAM", main_only=1 },
        { id=158, name="Tachi: Suikawari", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=152, name="Tachi: Kasha", skill_level=250, lsb_skill=250, range= 3, unlock=10, jobs="SAM", main_only=1 },
    },
    ["Club"] = {
        { id=160, name="Shining Strike", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR MNK WHM BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN BLU PUP SCH GEO RUN" },
        { id=161, name="Seraph Strike", skill_level= 40, lsb_skill= 40, range= 3, jobs="WAR WHM PLD DRK SAM BLU GEO" },
        { id=162, name="Brainshaker", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR MNK WHM BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN BLU PUP SCH GEO RUN" },
        { id=163, name="Starlight", skill_level=100, lsb_skill=100, range= 3, jobs="WAR MNK WHM BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN BLU PUP SCH GEO RUN" },
        { id=164, name="Moonlight", skill_level=125, lsb_skill=125, range= 3, jobs="WAR WHM PLD DRK SAM BLU SCH GEO" },
        { id=165, name="Skullbreaker", skill_level=150, lsb_skill=150, range= 3, jobs="WAR MNK WHM BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN BLU PUP SCH GEO RUN" },
        { id=166, name="True Strike", skill_level=175, lsb_skill=175, range= 3, jobs="WAR MNK WHM BLM RDM THF PLD DRK BST BRD RNG SAM NIN DRG SMN BLU PUP SCH GEO RUN" },
        { id=167, name="Judgment", skill_level=200, lsb_skill=200, range= 3, jobs="WAR WHM PLD DRK SAM BLU SCH GEO RUN" },
        { id=168, name="Hexa Strike", skill_level=220, lsb_skill=220, range= 3, jobs="WHM GEO", main_only=1 },
        { id=169, name="Black Halo", skill_level=230, lsb_skill=230, range= 3, unlock=11, jobs="WAR MNK WHM BLM PLD SMN BLU SCH GEO RUN", main_only=1 },
        { id=170, name="Randgrith", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=171, name="Mystic Boon", skill_level=240, lsb_skill=  0, range= 3, unlock=29, jobs="WHM", main_only=1 },
        { id=173, name="Dagan", skill_level=240, lsb_skill=  0, range= 3, unlock=45, jobs="WHM", main_only=1 },
    },
    ["Staff"] = {
        { id=176, name="Heavy Swing", skill_level=  5, lsb_skill=  5, range= 3, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO" },
        { id=177, name="Rock Crusher", skill_level= 40, lsb_skill= 40, range= 3, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO" },
        { id=178, name="Earth Crusher", skill_level= 70, lsb_skill= 70, range= 3, jobs="WAR MNK WHM PLD SCH GEO" },
        { id=179, name="Starburst", skill_level=100, lsb_skill=100, range= 3, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO" },
        { id=180, name="Sunburst", skill_level=150, lsb_skill=150, range= 3, jobs="WAR MNK WHM PLD SCH GEO" },
        { id=181, name="Shell Crusher", skill_level=175, lsb_skill=175, range= 3, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO" },
        { id=182, name="Full Swing", skill_level=200, lsb_skill=200, range= 3, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO" },
        { id=183, name="Spirit Taker", skill_level=215, lsb_skill=215, range= 3, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO" },
        { id=184, name="Retribution", skill_level=230, lsb_skill=230, range= 3, unlock=12, jobs="WAR MNK WHM BLM PLD BRD DRG SMN SCH GEO", main_only=1 },
        { id=185, name="Gate of Tartarus", skill_level=240, lsb_skill=  0, range= 3, main_only=1 },
        { id=186, name="Vidohunir", skill_level=240, lsb_skill=  0, range= 3, unlock=30, jobs="BLM", main_only=1 },
        { id=187, name="Garland of Bliss", skill_level=240, lsb_skill=  0, range= 3, unlock=31, jobs="SMN", main_only=1 },
        { id=188, name="Omniscience", skill_level=240, lsb_skill=  0, range= 3, unlock=32, jobs="SCH", main_only=1 },
        { id=190, name="Myrkr", skill_level=240, lsb_skill=  0, range= 3, unlock=46, jobs="BLM SMN SCH", main_only=1 },
        { id=240, name="Tartarus Torpor", skill_level=240, lsb_skill=  0, range= 3 },
    },
    ["Archery"] = {
        { id=192, name="Flaming Arrow", skill_level=  5, lsb_skill=  5, range=20, jobs="RNG" },
        { id=193, name="Piercing Arrow", skill_level= 40, lsb_skill= 40, range=20, jobs="RNG" },
        { id=194, name="Dulling Arrow", skill_level= 80, lsb_skill= 80, range=20, jobs="RNG" },
        { id=196, name="Sidewinder", skill_level=175, lsb_skill=175, range=20, jobs="RNG" },
        { id=197, name="Blast Arrow", skill_level=200, lsb_skill=200, range=20, jobs="RNG", main_only=1 },
        { id=198, name="Arching Arrow", skill_level=225, lsb_skill=225, range=20, jobs="RNG", main_only=1 },
        { id=200, name="Namas Arrow", skill_level=240, lsb_skill=  0, range=20, main_only=1 },
        { id=202, name="Jishnu's Radiance", skill_level=240, lsb_skill=  0, range=20, unlock=47, jobs="RNG", main_only=1 },
        { id=199, name="Empyreal Arrow", skill_level=250, lsb_skill=250, range=20, unlock=13, jobs="RNG", main_only=1 },
    },
    ["Marksmanship"] = {
        { id=208, name="Hot Shot", skill_level=  5, lsb_skill=  5, range=20, jobs="RNG COR" },
        { id=209, name="Split Shot", skill_level= 40, lsb_skill= 40, range=20, jobs="RNG COR" },
        { id=210, name="Sniper Shot", skill_level= 80, lsb_skill= 80, range=20, jobs="RNG COR" },
        { id=212, name="Slug Shot", skill_level=175, lsb_skill=175, range=20, jobs="RNG COR" },
        { id=213, name="Blast Shot", skill_level=200, lsb_skill=200, range=20, jobs="RNG", main_only=1 },
        { id=214, name="Heavy Shot", skill_level=225, lsb_skill=225, range=20, jobs="RNG", main_only=1 },
        { id=216, name="Coronach", skill_level=240, lsb_skill=  0, range=20, main_only=1 },
        { id=217, name="Trueflight", skill_level=240, lsb_skill=  0, range=20, unlock=33, jobs="RNG", main_only=1 },
        { id=218, name="Leaden Salute", skill_level=240, lsb_skill=  0, range=20, unlock=34, jobs="COR", main_only=1 },
        { id=220, name="Wildfire", skill_level=240, lsb_skill=  0, range=20, unlock=48, jobs="RNG COR", main_only=1 },
        { id=215, name="Detonator", skill_level=250, lsb_skill=250, range=20, unlock=14, jobs="RNG COR", main_only=1 },
    },
}

-- Job id -> abbreviation, matching the jobs strings above. Index is the FFXI
-- job id as the client reports it, confirmed by the blob decode (Dancing Edge
-- landing on THF 6 / DNC 19, Flaming Arrow on RNG 11, Slug Shot on RNG + COR
-- 17). Jobs past the server's era simply never match anything.
M.JOB_NAMES = {
    [ 1] = 'WAR', [ 2] = 'MNK', [ 3] = 'WHM', [ 4] = 'BLM',
    [ 5] = 'RDM', [ 6] = 'THF', [ 7] = 'PLD', [ 8] = 'DRK',
    [ 9] = 'BST', [10] = 'BRD', [11] = 'RNG', [12] = 'SAM',
    [13] = 'NIN', [14] = 'DRG', [15] = 'SMN', [16] = 'BLU',
    [17] = 'COR', [18] = 'PUP', [19] = 'DNC', [20] = 'SCH',
    [21] = 'GEO', [22] = 'RUN',
}

-- nil for 0 / out of range / non-numeric, which all mean "no job".
function M.job_name_of(job_id)
    local id = tonumber(job_id)
    if id == nil then return nil end
    return M.JOB_NAMES[id]
end

-- Convenience: list of WS for a weapon skill string ("Sword", "Marksmanship", ...).
function M.for_weapon(skill_name)
    return M.WEAPON_SKILLS[skill_name] or {}
end

-- Convenience: lookup WS by its LSB weaponskillid.
function M.by_id(id)
    for _, group in pairs(M.WEAPON_SKILLS) do
        for _, ws in ipairs(group) do
            if ws.id == id then return ws end
        end
    end
    return nil
end

-- Convenience: lookup WS by display name (case-sensitive).
function M.by_name(name)
    for _, group in pairs(M.WEAPON_SKILLS) do
        for _, ws in ipairs(group) do
            if ws.name == name then return ws end
        end
    end
    return nil
end

-- WS for a weapon that the given skill level actually reaches.
--
-- have_skill of nil returns the FULL list rather than an empty one. A caller
-- that cannot read the player's skill should see every option, not none of
-- them -- silently hiding the whole dropdown is a worse failure than showing
-- a WS that turns out to be unavailable.
function M.usable_for_weapon(skill_name, have_skill)
    local all = M.for_weapon(skill_name)
    have_skill = tonumber(have_skill)
    if have_skill == nil then return all end

    local out = {}
    for i = 1, #all do
        if (tonumber(all[i].skill_level) or 0) <= have_skill then
            out[#out + 1] = all[i]
        end
    end
    return out
end

-- Does this WS's job list admit the given main/sub job?
--
-- Mirrors CanUseWeaponskill's job clause. A MISSING jobs field means the WS
-- is weapon-granted (relic/mythic) and carries no job restriction, so it
-- returns true -- see the header. main_only suppresses the subjob half.
--
-- Job strings are matched whole, not by substring, so no abbreviation can
-- accidentally match inside another.
function M.job_can_use(ws, main_job, sub_job)
    if ws == nil then return false end

    local jobs = ws.jobs
    if jobs == nil or jobs == '' then return true end   -- weapon-granted

    local function listed(j)
        if j == nil or j == '' then return false end
        return (' ' .. jobs .. ' '):find(' ' .. tostring(j) .. ' ', 1, true) ~= nil
    end

    if listed(main_job) then return true end
    if ws.main_only ~= 1 and listed(sub_job) then return true end
    return false
end

-- Skill AND job filtered, the one to call from the UI.
--
-- have_skill nil means unknown and does not filter (see usable_for_weapon).
-- main_job nil likewise does not filter -- an unknown job should show
-- everything rather than nothing.
function M.usable_for(skill_name, have_skill, main_job, sub_job)
    local all = M.usable_for_weapon(skill_name, have_skill)
    if main_job == nil or main_job == '' then return all end

    local out = {}
    for i = 1, #all do
        if M.job_can_use(all[i], main_job, sub_job) then
            out[#out + 1] = all[i]
        end
    end
    return out
end

-- Can this main/sub combination use ANY ranged weaponskill at all?
--
-- Deliberately job-only: skill level is not considered, because skill is
-- trainable and a RNG with Archery 3 should still see the option (and get an
-- honest "nothing at this skill yet" from the picker) rather than have the
-- control disappear on them.
--
-- WEAPON-GRANTED ROWS ARE SKIPPED HERE, and that is the whole subtlety. The
-- 18 relic entries carry no jobs field, and job_can_use answers true for
-- those by design -- so counting them would make this return true for every
-- job in the game, which is exactly backwards from what it is for. Owning
-- Annihilator is not a reason to show a RNG-only control to a WHM.
function M.job_has_ranged_ws(main_job, sub_job)
    local RANGED_SKILLS = { 'Archery', 'Marksmanship' }
    for s = 1, #RANGED_SKILLS do
        local list = M.for_weapon(RANGED_SKILLS[s])
        for i = 1, #list do
            local ws = list[i]
            if ws.jobs ~= nil and ws.jobs ~= ''
                and M.job_can_use(ws, main_job, sub_job)
            then
                return true
            end
        end
    end
    return false
end

-- Range in yalms for a WS by display name, nil if unknown. Melee is 3,
-- Archery/Marksmanship is 20. Anything deciding "are we close enough to WS"
-- should ask this rather than assume melee reach.
function M.range_of(name)
    local ws = M.by_name(name)
    return ws and ws.range or nil
end

return M