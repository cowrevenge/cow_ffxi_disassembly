--[[---------------------------------------------------------------------------
worm_list.lua
Worm-family mob names, generated from LandSandBoat.

WHY THIS EXISTS

Worms burrow. While one is underground the server answers /attack with
"You cannot attack that target." and the client keeps the mob targetable, so
a retry loop will sit there emitting that line as fast as it can retry. It
is not a failure worth backing off a full engage over -- the worm surfaces
on its own a moment later -- it just needs a longer pause than the generic
one before trying again.

SOURCE

  mob_species_system, families with "worm" in the name:
    Sandworm   familyID 7   ecosystem Amorph
    Worm       familyID 10  ecosystem Amorph
  joined to mob_pools on speciesid.

  76 pool rows, 70 distinct names after cleaning.

NAME CLEANING: mob_pools disambiguates duplicates with a trailing tag that
the client never shows -- Cave_Worm_KT, Flesh_Eater_AC, Mountain_Worm_NM,
Rock_Eater_past, Cave_Worm_DoR. Those tags are stripped here, so this list
holds the name as it appears in game. Underscores become spaces for the same
reason.

The stripped tags are an EXPLICIT whitelist -- WS, KT, EAD, AC, NM, DoR, past,
future -- taken from a census of every trailing token in the worm rows. It is
not a pattern, on purpose: anything shaped like "short capitalised word at
the end" would also eat Worm, Grub, Eater and Digger, which are the actual
names.

ERA: generated from current LSB, so it includes worms that do not exist on a
75-cap server (Abyssea, Voidwatch, Escha). Harmless -- a name that never
appears never matches.
---------------------------------------------------------------------------]]--

local M = {}

-- Lowercase name -> true. Lowercase because every lookup normalises first.
M.WORMS = {
    ['abyss worm'] = true,
    ['amphisbaena'] = true,
    ['anemic aloysius'] = true,
    ['bedrock barry'] = true,
    ['bigmouth billy'] = true,
    ['boulder eater'] = true,
    ['burrower worm'] = true,
    ['carrion worm'] = true,
    ['cave worm'] = true,
    ['crepuscular worm'] = true,
    ['desert worm'] = true,
    ['dirt eater'] = true,
    ['earth eater'] = true,
    ['ectozoon'] = true,
    ['einherjar eater'] = true,
    ['entozoon'] = true,
    ['eschan worm'] = true,
    ['flayer franz'] = true,
    ['flesh eater'] = true,
    ['giant grub'] = true,
    ['glacier eater'] = true,
    ['glavoid'] = true,
    ['ground guzzler'] = true,
    ['hugemaw harold'] = true,
    ['ischyros sandworm'] = true,
    ['kuftal delver'] = true,
    ['kuftal digger'] = true,
    ['laidly laurence'] = true,
    ['lambton worm'] = true,
    ['land worm'] = true,
    ['leujaoam worm'] = true,
    ['locus tomb worm'] = true,
    ['maze maker'] = true,
    ['megamaw mikey'] = true,
    ['metalcruncher worm'] = true,
    ['midnight worm'] = true,
    ['mineral eater'] = true,
    ['minhocao'] = true,
    ['mold eater'] = true,
    ['morion worm'] = true,
    ['mountain worm'] = true,
    ['nightmare worm'] = true,
    ['olgoi-khorkhoi'] = true,
    ['onychophora'] = true,
    ['onycophoras sandworm'] = true,
    ['ore eater'] = true,
    ['oregorger worm'] = true,
    ['pallid percy'] = true,
    ['patrol worm'] = true,
    ['phantom worm'] = true,
    ['rock eater'] = true,
    ['rock grinder'] = true,
    ['rockmill'] = true,
    ['sallow seymour'] = true,
    ['sand digger'] = true,
    ['sand eater'] = true,
    ['sandworm'] = true,
    ['slime eater'] = true,
    ['specter worm'] = true,
    ['stone eater'] = true,
    ['trembler tabitha'] = true,
    ['tunnel worm'] = true,
    ['ulhuadshi'] = true,
    ['veiled gigaworm'] = true,
    ['veiled sandworm'] = true,
    ['vermes carnium'] = true,
    ['void worm'] = true,
    ['witchetty grub'] = true,
    ['ziryu'] = true,
}

-- Display-cased names, for UI and debug output.
M.NAMES = {
    'Abyss Worm',
    'Amphisbaena',
    'Anemic Aloysius',
    'Bedrock Barry',
    'Bigmouth Billy',
    'Boulder Eater',
    'Burrower Worm',
    'Carrion Worm',
    'Cave Worm',
    'Crepuscular Worm',
    'Desert Worm',
    'Dirt Eater',
    'Earth Eater',
    'Ectozoon',
    'Einherjar Eater',
    'Entozoon',
    'Eschan Worm',
    'Flayer Franz',
    'Flesh Eater',
    'Giant Grub',
    'Glacier Eater',
    'Glavoid',
    'Ground Guzzler',
    'Hugemaw Harold',
    'Ischyros Sandworm',
    'Kuftal Delver',
    'Kuftal Digger',
    'Laidly Laurence',
    'Lambton Worm',
    'Land Worm',
    'Leujaoam Worm',
    'Locus Tomb Worm',
    'Maze Maker',
    'Megamaw Mikey',
    'Metalcruncher Worm',
    'Midnight Worm',
    'Mineral Eater',
    'Minhocao',
    'Mold Eater',
    'Morion Worm',
    'Mountain Worm',
    'Nightmare Worm',
    'Olgoi-Khorkhoi',
    'Onychophora',
    'Onycophoras Sandworm',
    'Ore Eater',
    'Oregorger Worm',
    'Pallid Percy',
    'Patrol Worm',
    'Phantom Worm',
    'Rock Eater',
    'Rock Grinder',
    'Rockmill',
    'Sallow Seymour',
    'Sand Digger',
    'Sand Eater',
    'Sandworm',
    'Slime Eater',
    'Specter Worm',
    'Stone Eater',
    'Trembler Tabitha',
    'Tunnel Worm',
    'Ulhuadshi',
    'Veiled Gigaworm',
    'Veiled Sandworm',
    'Vermes Carnium',
    'Void Worm',
    'Witchetty Grub',
    'Ziryu',
}

local function normalise(name)
    if name == nil then return nil end
    local s = tostring(name)
    -- Strip the control bytes and high-range junk the client pads names
    -- with, same treatment get_equipped_ammo gives item names.
    s = s:gsub('[%z\1-\31\127-\255]', '')
    s = s:lower():gsub('^%s+', ''):gsub('%s+$', ''):gsub('%s+', ' ')
    if s == '' then return nil end
    return s
end

-- Is this mob a worm?
--
-- Exact match on the generated list first. Then a fallback: any name with
-- "worm" as a whole word. The list cannot be complete -- it is a snapshot of
-- one server's data and HorizonXI carries its own NMs -- and the cost of
-- the two failure directions is lopsided. A false positive delays one
-- targeting attempt by a second; a false negative is the log spam this file
-- exists to stop. Whole-word so "Wormtail" style names cannot creep in.
function M.is_worm(name)
    local s = normalise(name)
    if s == nil then return false end

    if M.WORMS[s] then return true end
    if s == 'worm' then return true end
    if s:find('^worm ') then return true end
    if s:find(' worm$') then return true end
    if s:find(' worm ') then return true end

    return false
end

return M