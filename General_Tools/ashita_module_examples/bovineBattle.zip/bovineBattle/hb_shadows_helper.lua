--[[---------------------------------------------------------------------------
hb_shadows_helper.lua

Purpose
  Own shadows and HB helper logic.

Owns
  - shadow counting
  - shadow readiness
  - shadow command selection
  - HB readiness
  - HB command selection

Expected
  - state.flags.player_utsu_tools_out
  - state.combat.is_casting
  - state.combat.current_spell
  - state.combat.spell_lock_until
  - optional Hb_list or passed hb_list table

Notes
  - We do not force casting state here.
  - We only read cast state owned by text_parser.lua.
---------------------------------------------------------------------------]]--

require('common')
require('helpers')

local HbShadows = {}

local JOB_NIN = 13
local JOB_DRG = 14

local SPELL_UTSU_ICHI = 338
local SPELL_UTSU_NI   = 339

local UTSU_ICHI_LV = 12
local UTSU_NI_LV   = 37

-- HB gate windows. Old design used a single HB_CAST_COOLDOWN_SEC of
-- 5.0s set at trigger-spell cast time (dead reckoning). That broke
-- both ways:
--   - HB fired faster than 5s -> bot waited longer than needed
--   - HB never fired at all -> bot retried after 5s and burned
--     more MP on a trigger that still wouldn't get an HB response
-- New design splits into two timeouts driven by actual events:
--   - HB_SAFETY_TIMEOUT_SEC: set by notify_hb_cast at trigger time.
--     Max wait if the wyvern's HB action packet never arrives
--     (wyvern dead, on its own internal cooldown, out of range,
--     DRG HP rose above HB threshold mid-cast, etc.). Long enough
--     that an HB the cast genuinely triggered will have arrived.
--   - HB_REAL_RECAST_SEC: set by notify_hb_actually_fired when the
--     wyvern's HB action packet is detected by packet_parser.
--     Short -- just enough buffer for wyvern TP regen and the next
--     trigger's cast bar. Net effect is the bot chains the next
--     trigger about as fast as the wyvern can chain HBs.
local HB_SAFETY_TIMEOUT_SEC = 12.0
local HB_REAL_RECAST_SEC    = 1.5

local COPY_IMAGE_MAP = {
    -- Client status-icon IDs for Copy Image, keyed to shadow count.
    -- 66 is the single-shadow icon (the original Copy Image icon);
    -- 444/445/446 are the 2/3/4-shadow icons. Without 66, a lone
    -- remaining shadow read as 0 and the bot treated itself as
    -- unshadowed. VERIFY 66 in-game: get to exactly 1 shadow and
    -- confirm shadow_count reports 1, not 0.
    [66]  = 1,
    [444] = 2,
    [445] = 3,
    [446] = 4,
}

local function now_sec()
    return os.clock()
end

-- ---------------------------------------------------------------
-- Ichi-over-Ni shadow cancel.
-- Ichi has no effect if Ni-origin shadows remain (Horizon mechanic).
-- When we cast Ichi while Ni shadows are up, cancel the lingering Copy
-- Image near the end of the Ichi cast so Ichi lands.
-- ---------------------------------------------------------------
local SHADOW_CANCEL_DELAY_SEC = 1.5   -- fixed for now; does NOT account for Fast Cast
local COUNT_TO_COPY_IMAGE_ID = { [1] = 66, [2] = 444, [3] = 445, [4] = 446 }

local function shadow_dbg_echo(state, msg)
    if not (state and state.ui and state.ui.debug_enabled == true) then return end
    if not AshitaCore then return end
    local cm = AshitaCore:GetChatManager()
    if cm and type(cm.QueueCommand) == 'function' then
        cm:QueueCommand(1, '/echo [SHADOW] ' .. tostring(msg))
    end
end

-- Send the client status-cancel packet (0x0F1) for a status ID. Mirrors the
-- outbound packet convention used elsewhere in the suite.
local function shadow_send_cancel(status_id)
    status_id = tonumber(status_id or 0) or 0
    if status_id <= 0 then return end
    local payload_str = struct.pack('bbxxH', 0xF1, 0x04, status_id)
    local payload = {}
    for i = 1, #payload_str do payload[i] = payload_str:byte(i) end
    AshitaCore:GetPacketManager():AddOutgoingPacket(0x0F1, payload)
end

-- Arm a pending cancel. Called from general's do_shadows when it dispatches
-- Ichi while Ni-origin shadows are up. Stores fire time only.
function HbShadows.arm_shadow_cancel(state)
    state.combat = state.combat or {}
    state.combat.shadow_cancel_at = now_sec() + SHADOW_CANCEL_DELAY_SEC
    shadow_dbg_echo(state, string.format('cancel ARMED, fires in %.1fs', SHADOW_CANCEL_DELAY_SEC))
end

-- Frame tick. Fires the armed cancel once its time arrives, ONLY if a Copy
-- Image buff still exists and count is 1-2 (never cancel a healthy 3-4 set).
function HbShadows.tick_shadow_cancel(state)
    state.combat = state.combat or {}
    local at = tonumber(state.combat.shadow_cancel_at or 0) or 0
    if at <= 0 then return end
    if now_sec() < at then return end
    state.combat.shadow_cancel_at = 0

    local count = tonumber(HbShadows.shadow_count(state) or 0) or 0
    shadow_dbg_echo(state, string.format('cancel FIRE check, count=%d', count))
    if count <= 0 then shadow_dbg_echo(state, 'skip: no shadows'); return end
    if count >= 3 then shadow_dbg_echo(state, 'skip: 3+ shadows'); return end
    local id = COUNT_TO_COPY_IMAGE_ID[count]
    if not id then shadow_dbg_echo(state, 'skip: no id for count'); return end
    shadow_dbg_echo(state, string.format('SENDING cancel status id=%d', id))
    shadow_send_cancel(id)
end

local function memory_manager()
    return AshitaCore:GetMemoryManager()
end

local function party_manager()
    local m = memory_manager()
    return m and m:GetParty() or nil
end

local function player_mp_percent()
    local party = party_manager()
    if not party then return 100 end
    if type(party.GetMemberMPPercent) == 'function' then
        local ok, v = pcall(function() return party:GetMemberMPPercent(0) end)
        if ok and v ~= nil then return tonumber(v) or 100 end
    end
    -- Fallback: compute from MP/MPMax
    local mp, mpmax = 0, 0
    if type(party.GetMemberMP) == 'function' then
        local ok, v = pcall(function() return party:GetMemberMP(0) end)
        if ok then mp = tonumber(v) or 0 end
    end
    if type(party.GetMemberMPMax) == 'function' then
        local ok, v = pcall(function() return party:GetMemberMPMax(0) end)
        if ok then mpmax = tonumber(v) or 0 end
    end
    if mpmax > 0 then return (mp / mpmax) * 100 end
    return 100
end

local function player_manager()
    local m = memory_manager()
    return m and m:GetPlayer() or nil
end

local function recast_manager()
    local m = memory_manager()
    return m and m:GetRecast() or nil
end

-- Spell name -> spell ID cache. The resource manager scan to resolve
-- a name is not free, so cache results (including negatives, as `false`)
-- so a typo'd entry doesn't re-scan every frame. Cache lives in module
-- scope -- HB list contents are static across a session.
local _spell_id_cache = {}

local function spell_id_by_name(name)
    if type(name) ~= 'string' or #name == 0 then return nil end

    local key = name:lower()
    local hit = _spell_id_cache[key]
    if hit ~= nil then
        if hit == false then return nil end
        return hit
    end

    local rm = AshitaCore and AshitaCore.GetResourceManager
        and AshitaCore:GetResourceManager()
    if not rm or type(rm.GetSpellById) ~= 'function' then
        _spell_id_cache[key] = false
        return nil
    end

    -- Spell IDs in retail/Horizon fit below 1024. Compare against
    -- English name (Name[1] on Ashita's localised array).
    for id = 1, 1023 do
        local ok, spell = pcall(function() return rm:GetSpellById(id) end)
        if ok and spell ~= nil then
            local nm
            local ok2, v = pcall(function() return spell.Name and spell.Name[1] end)
            if ok2 then nm = v end
            if type(nm) == 'string' and nm:lower() == key then
                _spell_id_cache[key] = id
                return id
            end
        end
    end

    _spell_id_cache[key] = false
    return nil
end

local function get_job_info()
    local party = party_manager()
    if not party then return nil end

    return {
        mainJob = tonumber(party:GetMemberMainJob(0) or 0) or 0,
        subJob  = tonumber(party:GetMemberSubJob(0) or 0) or 0,
        mainLv  = tonumber(party:GetMemberMainJobLevel(0) or 0) or 0,
        subLv   = tonumber(party:GetMemberSubJobLevel(0) or 0) or 0,
    }
end

local function nin_level(job_info)
    if not job_info then return 0 end
    if job_info.mainJob == JOB_NIN then return tonumber(job_info.mainLv or 0) or 0 end
    if job_info.subJob  == JOB_NIN then return tonumber(job_info.subLv or 0) or 0 end
    return 0
end

local function spell_recast_ready(spell_id)
    local rm = recast_manager()
    if not rm then return nil end

    if type(rm.GetSpellTimer) == 'function' then
        local t = tonumber(rm:GetSpellTimer(spell_id) or 0) or 0
        return t <= 0
    end

    if type(rm.GetSpellRecast) == 'function' then
        local t = tonumber(rm:GetSpellRecast(spell_id) or 0) or 0
        return t <= 0
    end

    return nil
end

local function utsu_ichi_ready(job_info)
    if nin_level(job_info) < UTSU_ICHI_LV then return false end
    local r = spell_recast_ready(SPELL_UTSU_ICHI)
    return (r == nil) and true or r
end

local function utsu_ni_ready(job_info)
    if nin_level(job_info) < UTSU_NI_LV then return false end
    local r = spell_recast_ready(SPELL_UTSU_NI)
    return (r == nil) and true or r
end

function HbShadows.shadow_count(_state)
    local best = 0
    local pm = player_manager()

    if pm and type(pm.GetBuffs) == 'function' then
        local buffs = pm:GetBuffs()
        if buffs then
            for i = 1, #buffs do
                local buff_id = tonumber(buffs[i]) or 0
                local count = COPY_IMAGE_MAP[buff_id]
                if count and count > best then
                    best = count
                end
            end
            return best
        end
    end

    local party = party_manager()
    if party and type(party.GetMemberBuff) == 'function' then
        for i = 0, 31 do
            local buff_id = tonumber(party:GetMemberBuff(0, i) or 0) or 0
            local count = COPY_IMAGE_MAP[buff_id]
            if count and count > best then
                best = count
            end
        end
    end

    return best
end

local function pick_utsu_spell(job_info)
    if utsu_ni_ready(job_info) then return 'Utsusemi: Ni' end
    if utsu_ichi_ready(job_info) then return 'Utsusemi: Ichi' end
    return nil
end

function HbShadows.shadows_ready(state, max_shadows_before_recast)
    local job_info = get_job_info()
    if not job_info then return false end
    if nin_level(job_info) < UTSU_ICHI_LV then return false end

    state.flags = state.flags or {}
    state.combat = state.combat or {}

    if state.flags.player_utsu_tools_out == true then return false end
    if state.combat.is_casting == true then return false end
    if now_sec() < (tonumber(state.combat.spell_lock_until or 0) or 0) then return false end
    if pick_utsu_spell(job_info) == nil then return false end

    local shadows = HbShadows.shadow_count(state)
    shadows = tonumber(shadows or 0) or 0

    local max_allowed = tonumber(max_shadows_before_recast)
    if max_allowed == nil then
        max_allowed = 1
    end

    -- Per-spell recast threshold. Ni casts fast and overwrites anything,
    -- so it waits until shadows hit 0 (no waste, no overwrite issue).
    -- Ichi casts slower and only overwrites Ichi/nothing, so it recasts
    -- at <=1 shadow to get a head start before going bare. The picked
    -- spell's natural threshold caps the caller's request (idle/pre-attack
    -- may ask for 0, which stays 0 for both).
    local picked = pick_utsu_spell(job_info)
    local spell_max = 1
    if picked == 'Utsusemi: Ni' then
        spell_max = 0
    elseif picked == 'Utsusemi: Ichi' then
        spell_max = 1
    end
    if spell_max < max_allowed then
        max_allowed = spell_max
    end

    return shadows <= max_allowed
end

function HbShadows.shadow_command(state, max_shadows_before_recast)
    if not HbShadows.shadows_ready(state, max_shadows_before_recast) then return nil end

    local job_info = get_job_info()
    local spell = pick_utsu_spell(job_info)
    if not spell then return nil end

    return '/ma "' .. tostring(spell) .. '" <me>'
end

local function hb_subjob_key(job_info)
    if not job_info then return nil end
    local sub = tonumber(job_info.subJob or 0) or 0

    if sub == 3  then return 'WHM' end
    if sub == 7  then return 'PLD' end
    if sub == 5  then return 'RDM' end
    if sub == 16 then return 'BLU' end
    if sub == 13 then return 'NIN' end
    if sub == 10 then return 'BRD' end

    return nil
end

local function hb_ensure_state(state)
    state.hb = state.hb or {}
    state.hb.last_index = state.hb.last_index or 0
    state.hb.cast_until = state.hb.cast_until  or 0
end

function HbShadows.notify_hb_cast(state)
    -- Trigger spell just confirmed casting by the game. Arm the
    -- safety-timeout window. If the wyvern's HB packet/line arrives
    -- (notify_hb_actually_fired), the gate is replaced with the much
    -- shorter real recast. If HB never fires (wyvern dead, on its own
    -- internal cooldown, out of range, DRG HP rose above HB threshold
    -- mid-cast, etc.), the safety timeout naturally expires.
    --
    -- safety_armed_at = "we are waiting for an HB and it has not
    -- arrived yet." Cleared by notify_hb_actually_fired (HB came) or
    -- notify_hb_cast_interrupted (cast was interrupted, so there was
    -- never going to be an HB). When the cast_until passes while
    -- safety_armed_at is still set, hb_ready emits the visible "HB
    -- not detected" error and resets.
    hb_ensure_state(state)
    state.hb.cast_until      = now_sec() + HB_SAFETY_TIMEOUT_SEC
    state.hb.safety_armed_at = now_sec()
end

function HbShadows.notify_hb_actually_fired(state, source)
    -- Wyvern's HB action was detected (either via action packet in
    -- packet_parser or via chat-line in text_parser). Replace the
    -- safety timeout (set by notify_hb_cast at trigger send time)
    -- with the real recast -- gate releases as soon as the wyvern
    -- can physically chain another HB. Event-driven side of the
    -- gate that prevents wasted MP on premature retries.
    --
    -- source: 'packet' or 'log' for diagnostic. Idempotent if both
    -- fire for the same HB (packet typically wins by ~0.5s).
    hb_ensure_state(state)
    state.hb.cast_until       = now_sec() + HB_REAL_RECAST_SEC
    state.hb.last_hb_fired_at = now_sec()
    state.hb.safety_armed_at  = 0  -- HB arrived; no error owed

    -- Diagnostic: log the HB fire with source so casttimes.txt shows
    -- the trigger -> HB chain timing AND which detection path won.
    -- Silent if cast_log missing.
    local ok, CastLog = pcall(require, 'cast_log')
    if ok and CastLog and type(CastLog.note) == 'function' then
        CastLog.note(string.format('HB fired via=%s', tostring(source or '?')))
    end
end

-- Cast was interrupted (damage, silence, target dropped, etc.).
-- If an HB trigger's safety window was armed, clear it SILENTLY --
-- the cast was interrupted, not the HB detection, so the "HB not
-- detected" error would be a false positive here -- and flag a
-- forced retry so the party-HB paths in idle_rest_engage skip their
-- 1s retry gate / 10s started_at timeout and re-fire next frame.
--
-- Guarded on safety_armed_at: a non-HB-trigger spell (cure/dia/
-- enspell) being interrupted must NOT zero an unrelated in-flight
-- HB safety window or raise a spurious party-HB retry. Those casts
-- never armed the HB safety, so there is nothing to clear.
function HbShadows.notify_hb_cast_interrupted(state)
    hb_ensure_state(state)
    if (tonumber(state.hb.safety_armed_at or 0) or 0) <= 0 then
        return
    end
    state.hb.cast_until       = 0
    state.hb.safety_armed_at  = 0
    state.hb.force_retry_now  = true
end

local function hb_can_cast_entry(entry, job_info)
    if type(entry) ~= 'table' or not job_info then return false end
    if tonumber(job_info.mainJob or 0) ~= JOB_DRG then return false end

    local key = hb_subjob_key(job_info)
    if not key then return false end

    if type(entry.jobs) ~= 'table' then return false end
    if entry.jobs[key] ~= true then return false end

    local sub_lv = tonumber(job_info.subLv or 0) or 0
    local min_lv = tonumber(entry.minLevel or 99) or 99
    if sub_lv < min_lv then return false end

    local min_mp = tonumber(entry.minMp or 0) or 0
    if min_mp > 0 and player_mp_percent() < min_mp then return false end

    if type(entry.name) ~= 'string' or #entry.name == 0 then return false end

    -- Per-spell FFXI recast gate. Resolve spell name -> ID (cached),
    -- then ask Ashita's recast manager. A spell that's on real recast
    -- gets skipped here so hb_command falls through to the next entry
    -- in priority order. If we can't resolve the ID (resource manager
    -- unavailable, name typo, etc.) we leave it castable -- failing
    -- closed would silently disable the whole HB list on any hiccup.
    local sid = spell_id_by_name(entry.name)
    if sid ~= nil then
        local ready = spell_recast_ready(sid)
        if ready == false then return false end
    end

    return true
end

local function get_hb_list(passed_list)
    if type(passed_list) == 'table' and #passed_list > 0 then
        return passed_list
    end
    if rawget(_G, 'Hb_list') and type(rawget(_G, 'Hb_list')) == 'table' then
        return rawget(_G, 'Hb_list')
    end
    return nil
end

function HbShadows.hb_ready(state, hb_list)
    state.combat = state.combat or {}
    if state.combat.is_casting == true then return false end
    if now_sec() < (tonumber(state.combat.spell_lock_until or 0) or 0) then return false end

    hb_ensure_state(state)

    -- Safety-timeout expiry detection. If we armed a safety window at
    -- cast-start (notify_hb_cast) and the wyvern's HB never arrived
    -- before cast_until elapsed -- no notify_hb_actually_fired call,
    -- and no notify_hb_cast_interrupted -- then HB detection has
    -- failed for some reason. Emit a visible chat error (not behind
    -- debug) and reset the lock so the bot can try again.
    --
    -- This branch is one-shot: clearing safety_armed_at means the
    -- error fires at most once per failed detection cycle.
    local armed_at = tonumber(state.hb.safety_armed_at or 0) or 0
    if armed_at > 0 and now_sec() >= (tonumber(state.hb.cast_until or 0) or 0) then
        if AshitaCore then
            local cm = AshitaCore:GetChatManager()
            if cm and type(cm.QueueCommand) == 'function' then
                cm:QueueCommand(1, string.format(
                    '/echo [HB] not detected, lock reset after %d seconds',
                    math.floor(HB_SAFETY_TIMEOUT_SEC + 0.5)))
            end
        end
        state.hb.safety_armed_at = 0
        state.hb.cast_until      = 0
        -- After the safety expires we've already burned the full
        -- safety window with nothing to show for it. The polite
        -- per-attempt retry gate and the 10s started_at "we've been
        -- spinning, take a breather" timeout in idle_rest_engage no
        -- longer make sense -- they'd add 1-2s of additional delay
        -- to a recovery that's already overdue. Force a clean retry
        -- on the very next tick.
        state.hb.force_retry_now = true
    end

    if now_sec() < (tonumber(state.hb.cast_until or 0) or 0) then return false end

    local job_info = get_job_info()
    local list = get_hb_list(hb_list)
    if not job_info or not list then return false end
    if tonumber(job_info.mainJob or 0) ~= JOB_DRG then return false end

    for i = 1, #list do
        if hb_can_cast_entry(list[i], job_info) then
            return true
        end
    end

    return false
end

function HbShadows.hb_command(state, hb_list)
    local job_info = get_job_info()
    local list = get_hb_list(hb_list)
    if not job_info or not list or #list == 0 then return nil end

    hb_ensure_state(state)

    -- Walk the HB list in priority order. Slot 1 is the preferred
    -- trigger; later slots are only reached when earlier ones are on
    -- real FFXI recast (or otherwise ineligible). No rotation: if
    -- Barfire is up, it always wins. hb_can_cast_entry handles the
    -- per-spell recast filter -- so "if 4 are on CD, cast #5" works
    -- automatically.
    for i = 1, #list do
        local entry = list[i]
        if hb_can_cast_entry(entry, job_info) then
            local target = entry.target or 'me'
            if type(target) ~= 'string' or #target == 0 then
                target = 'me'
            end
            if target:sub(1, 1) == '<' and target:sub(-1) == '>' then
                target = target:sub(2, -2)
            end
            -- last_index kept as a diagnostic of the most recent pick,
            -- not used for selection. Useful in debug output.
            state.hb.last_index = i
            return '/ma "' .. tostring(entry.name) .. '" <' .. tostring(target) .. '>'
        end
    end

    return nil
end

return HbShadows