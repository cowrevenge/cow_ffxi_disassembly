--[[---------------------------------------------------------------------------
cast_log.lua

Purpose
  Lightweight cast-timing diagnostic log for MeleeNostrum.
  Mirrors nomount's casttimes.txt so the action-packet vs chat-line
  completion paths can be verified against real elapsed timings.

Output
  <ashita>/addons/meleenostrum/casttimes.txt

Format
  [HH:MM:SS] <spell> elapsed=N.NNs via=<method>
  [HH:MM:SS] <spell> FAILED reason=<reason>

Usage
  local CastLog = require('cast_log')
  CastLog.pending('Cure III', os.clock())
  CastLog.confirmed('Cure III', os.clock(), 'action')
  CastLog.failed('Refresh', os.clock(), 'utc')

Notes
  - Pending state is keyed by normalized spell name.
  - File append is best-effort; failures are silent (no chat spam).
  - Defaults ON. Toggle off via CastLog.enabled = false.
---------------------------------------------------------------------------]]--

local CastLog = {
    enabled = true,
}

local pending = {}

local function now_sec()
    return os.clock()
end

local function normalize(name)
    name = tostring(name or ''):lower()
    name = name:gsub('_', ' ')
    name = name:gsub('%s+', ' ')
    name = name:gsub('^%s+', '')
    name = name:gsub('%s+$', '')
    return name
end

local function log_path()
    local install = AshitaCore and AshitaCore:GetInstallPath() or ''
    if install == '' then return nil end
    return install .. 'addons/meleenostrum/casttimes.txt'
end

local function append(line)
    if not CastLog.enabled then return end
    local path = log_path()
    if not path then return end
    local ok, f = pcall(io.open, path, 'a')
    if not ok or not f then return end
    pcall(function()
        f:write(line)
        f:write('\n')
        f:close()
    end)
end

function CastLog.pending(spell_name, send_time)
    local key = normalize(spell_name)
    if key == '' then return end
    pending[key] = {
        display_name = tostring(spell_name or ''),
        sent_at = tonumber(send_time) or now_sec(),
    }
end

function CastLog.confirmed(spell_name, current_time, via)
    local key = normalize(spell_name)
    local p = pending[key]
    if not p then
        -- No pending row -- log anyway, no elapsed available
        append(string.format('[%s] %s confirmed (no pending) via=%s',
            os.date('%H:%M:%S'),
            tostring(spell_name or ''),
            tostring(via or '?')))
        return
    end
    pending[key] = nil
    local elapsed = (tonumber(current_time) or now_sec()) - p.sent_at
    append(string.format('[%s] %s elapsed=%.2fs via=%s',
        os.date('%H:%M:%S'),
        p.display_name,
        elapsed,
        tostring(via or '?')))
end

function CastLog.failed(spell_name, current_time, reason)
    local key = normalize(spell_name)
    local p = pending[key]
    pending[key] = nil
    local elapsed_str = ''
    if p then
        local elapsed = (tonumber(current_time) or now_sec()) - p.sent_at
        elapsed_str = string.format(' elapsed=%.2fs', elapsed)
    end
    append(string.format('[%s] %s FAILED%s reason=%s',
        os.date('%H:%M:%S'),
        tostring(spell_name or '?'),
        elapsed_str,
        tostring(reason or 'unknown')))
end

-- Clear all pending rows (e.g. on zone change)
function CastLog.clear_pending()
    pending = {}
end

-- Free-form timestamped note. Used for events outside the player
-- cast lifecycle (e.g. wyvern HB firing detected via packet).
function CastLog.note(text)
    append(string.format('[%s] %s',
        os.date('%H:%M:%S'),
        tostring(text or '')))
end

return CastLog
