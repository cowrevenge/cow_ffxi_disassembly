--[[---------------------------------------------------------------------------
atk_list.lua
Purpose:
  - Offensive ladder that runs on player attack rounds.
  - Items here respect the main/global gate.
Rules:
  - Pure LIST: no cfg/S/settings references.
  - Uses new config keys:
      * jump_hp
      * hb_hp
      * auto.hb_mode
      * auto.shadows_mode
---------------------------------------------------------------------------]]--

local JOB_WAR, JOB_WHM, JOB_BLM, JOB_RDM, JOB_DRK, JOB_BST, JOB_NIN, JOB_DRG, JOB_SAM = 1, 3, 4, 5, 8, 9, 13, 14, 12
local JOB_THF = 6
local JOB_MNK, JOB_BRD = 2, 10

local function any_enspell_active(ctx)
  if not ctx.buff_active then return false end
  return
    ctx.buff_active('Enfire') or
    ctx.buff_active('Enblizzard') or
    ctx.buff_active('Enaero') or
    ctx.buff_active('Enstone') or
    ctx.buff_active('Enwater') or
    ctx.buff_active('Enthunder')
end

-- Mirror of any_enspell_active for the three damage spike spells.
-- Spikes are mutually exclusive among THEMSELVES (only one spike type can
-- be active at a time, server-side overwrite), but they DO stack with
-- enspells -- a RDM running Enfire + Blaze Spikes is the common case --
-- so this check deliberately does not consider enspells.
local function any_spike_active(ctx)
  if not ctx.buff_active then return false end
  return
    ctx.buff_active('Blaze Spikes') or
    ctx.buff_active('Ice Spikes') or
    ctx.buff_active('Shock Spikes')
end

local function enspell_ok(ctx, cfgkey)
  if not ctx.cfgget(cfgkey) then return false end
  if ctx.engaged01 ~= 1 then return false end
  if ctx.resting01 == 1 then return false end
  if ctx.spells_locked then return false end
  if ctx.ws_blocked then return false end
  if any_enspell_active(ctx) then return false end

  local ji = ctx.job_info
  if not ji then return false end

  local main_ok = (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 16)
  local sub_ok  = (ji.subJob == JOB_RDM and (ji.subLv or 0) >= 8)

  if not (main_ok or sub_ok) then return false end
  return true
end

-- Mirror of enspell_ok for spike spells. Differences:
--   * Job/level check is NOT done here -- spike spells have different
--     levels per element (Blaze 12, Ice 23-25, Shock 56) and are
--     available to BLM as well as RDM, so the entry's `req` does it.
--   * Blocks on any_spike_active(), not any_enspell_active() -- spikes
--     and enspells stack, but spikes are mutually exclusive among
--     themselves.
local function spike_ok(ctx, cfgkey)
  if not ctx.cfgget(cfgkey) then return false end
  if ctx.engaged01 ~= 1 then return false end
  if ctx.resting01 == 1 then return false end
  if ctx.spells_locked then return false end
  if ctx.ws_blocked then return false end
  if any_spike_active(ctx) then return false end
  return true
end

-- DIA entry tier picker. Maps the user's radio choice (1=Dia I, 2=Dia II,
-- 3=Bio I, 4=Bio II) to the actual spell name to cast, with same-family
-- tier fallback if their level can only handle tier I. Single source of
-- truth used by both eligible() (for the MP check) and act() (for the
-- actual cast) so the two paths can't drift.
local function pick_dia_name(ji, want)
  ji = ji or {}
  want = tonumber(want or 1) or 1
  local has_dia2 =
    (ji.mainJob == JOB_WHM and (ji.mainLv or 0) >= 36) or
    (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 31) or
    (ji.subJob  == JOB_WHM and (ji.subLv  or 0) >= 36) or
    (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 31)
  local has_bio2 =
    (ji.mainJob == JOB_BLM and (ji.mainLv or 0) >= 35) or
    (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 36) or
    (ji.mainJob == JOB_DRK and (ji.mainLv or 0) >= 40) or
    (ji.subJob  == JOB_BLM and (ji.subLv  or 0) >= 35) or
    (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 36) or
    (ji.subJob  == JOB_DRK and (ji.subLv  or 0) >= 40)
  if     want == 4 then return has_bio2 and 'Bio II' or 'Bio'
  elseif want == 3 then return 'Bio'
  elseif want == 2 then return has_dia2 and 'Dia II' or 'Dia'
  else                  return 'Dia'
  end
end

return {

  {
    id='JUMP',
    kind='ja',
    priority=5501,             -- after HIGH_JUMP (5500): HJ leads the chain
    req={
      main={
        { job=JOB_DRG, lv=10 },
      },
    },
    cooldown_sec=90.0,
    gate_time=1.0,
    ui={
      { kind='checkbox',      label='Auto Jump', cfgkey='auto.jump', default=false },
      { kind='checkbox_same', label='HJ',        cfgkey='auto.highjump', default=false },
      { kind='radio3',
        labelA='10%##jump', valA=10,
        labelB='25%##jump', valB=25,
        labelC='Any##jump', valC=0,
        cfgkey='jump_hp', default=0 },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.jump') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if not (ctx.dist and ctx.dist <= 5) then return false end
      if not ctx.jump_hp_ok then return false end
      if (ctx.tp or 0) >= 1000 then return false end
      return ctx.is_ready('JUMP')
    end,
    act=function(ctx)
      return ctx.do_ja('Jump', '<t>', 'JUMP')
    end,
  },

  {
    id='HIGH_JUMP',
    kind='ja',
    priority=5500,             -- before JUMP (5501): first hit fires HJ, then Jump
    req={
      main={
        { job=JOB_DRG, lv=35 },
      },
    },
    cooldown_sec=120.0,
    gate_time=1.0,
    ui=nil,
    eligible=function(ctx)
      if not ctx.cfgget('auto.jump') then return false end
      if not ctx.cfgget('auto.highjump') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if not (ctx.dist and ctx.dist <= 5) then return false end
      if not ctx.jump_hp_ok then return false end
      if (ctx.tp or 0) >= 1000 then return false end
      return ctx.is_ready('HIGH_JUMP')
    end,
    act=function(ctx)
      return ctx.do_ja('High Jump', '<t>', 'HIGH_JUMP')
    end,
  },

  {
    id='FOOD_BUFF',
    kind='ja',
    priority=4500,             -- very early; cheaper than spending a swing without food
    req=nil,                 -- universal: all jobs eat food
    cooldown_sec=8.0,        -- ~4s item-use cast + buffer; also anti-spam if item not in inventory
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Food Buff', cfgkey='auto.food', default=false },
      { kind='input_text',
        label='Food Name',
        cfgkey='food_name',
        default='',
        max_len=64,
      },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.food') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.has_food then return false end           -- already buffed, nothing to do

      local name = tostring(ctx.cfgget('food_name') or '')
      if name == '' then return false end             -- nothing to eat

      return ctx.is_ready('FOOD_BUFF')
    end,
    act=function(ctx)
      local name = tostring(ctx.cfgget('food_name') or '')
      return ctx.do_item(name, '<me>', 'FOOD_BUFF')
    end,
  },

  {
    id='DIA',
    priority=8000,
    -- HorizonXI: Dia and Bio share / overwrite each other on the mob's
    -- enfeeble slot, so we expose both spell lines under a single ladder
    -- entry with a 4-way tier picker. The cooldown is shared (id='DIA'
    -- regardless of family) -- after we cast one, the other is gated by
    -- the same 8s recast which matches the "they overwrite each other"
    -- behavior on the server side.
    --
    -- Spell levels (HorizonXI wiki):
    --   Dia      WHM  3 / RDM  1
    --   Dia II   WHM 36 / RDM 31
    --   Bio      BLM 10 / RDM 10 / DRK 15
    --   Bio II   BLM 35 / RDM 36 / DRK 40
    req={
      any=true,
      main={
        { job=JOB_WHM, lv=3  },
        { job=JOB_RDM, lv=1  },
        { job=JOB_BLM, lv=10 },
        { job=JOB_DRK, lv=15 },
      },
      sub={
        { job=JOB_WHM, lv=3  },
        { job=JOB_RDM, lv=1  },
        { job=JOB_BLM, lv=10 },
        { job=JOB_DRK, lv=15 },
      },
    },
    cooldown_sec=8.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Dia / Bio', cfgkey='auto.dia', default=false },
      { kind='radio4',
        labelA='Dia I##dia_tier',  valA=1,
        labelB='Dia II##dia_tier', valB=2,
        labelC='Bio I##dia_tier',  valC=3,
        labelD='Bio II##dia_tier', valD=4,
        cfgkey='dia_tier', default=1,
      },
    },
    eligible=function(ctx)
      if ctx.target_dead then return false end
      if not ctx.cfgget('auto.dia') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if not (ctx.dist and ctx.dist <= 20) then return false end

      local ji = ctx.job_info
      if not ji then return false end

      local want = tonumber(ctx.cfgget('dia_tier') or 1) or 1
      local is_bio = (want == 3 or want == 4)

      if is_bio then
        -- Bio I gate (BLM 10 / RDM 10 / DRK 15, main or sub).
        local main_ok =
          ((ji.mainJob == JOB_BLM and (ji.mainLv or 0) >= 10) or
           (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 10) or
           (ji.mainJob == JOB_DRK and (ji.mainLv or 0) >= 15))
        local sub_ok =
          ((ji.subJob  == JOB_BLM and (ji.subLv  or 0) >= 10) or
           (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 10) or
           (ji.subJob  == JOB_DRK and (ji.subLv  or 0) >= 15))
        if not (main_ok or sub_ok) then return false end

        -- Skip if Bio is already on the target. Dia presence is NOT
        -- a gate here -- if the user picked Bio, we deliberately
        -- overwrite an existing Dia (they expressed a preference for
        -- the att-down debuff over Dia's def-down).
        if not (ctx.mob_debuff_ready and ctx.mob_debuff_ready('BIO')) then return false end
        if ctx.target_has_debuff and ctx.target_has_debuff('bio') then return false end
      else
        -- Dia I gate (HorizonXI: WHM 3 / RDM 1, main or sub).
        local main_ok =
          ((ji.mainJob == JOB_WHM and (ji.mainLv or 0) >= 3) or
           (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 1))
        local sub_ok =
          ((ji.subJob  == JOB_WHM and (ji.subLv  or 0) >= 3) or
           (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 1))
        if not (main_ok or sub_ok) then return false end

        if not (ctx.mob_debuff_ready and ctx.mob_debuff_ready('DIA')) then return false end
        if ctx.target_has_debuff and ctx.target_has_debuff('dia') then return false end
      end

      -- MP check is against the actual spell we'd cast. pick_dia_name
      -- mirrors the same tier-fallback act() uses, so the two can't drift.
      if ctx.has_spell_mp and not ctx.has_spell_mp(pick_dia_name(ji, ctx.cfgget('dia_tier'))) then
        return false
      end

      return ctx.is_ready('DIA')
    end,
    act=function(ctx)
      -- Same-family tier fallback. If user picked tier II of a family
      -- but their job/level can only cast tier I, drop to tier I --
      -- guards against stale config carried over from a higher level.
      -- No cross-family fallback (Dia <-> Bio); the user's family
      -- choice is honored even if it would require a re-pick later.
      local name = pick_dia_name(ctx.job_info, ctx.cfgget('dia_tier'))
      return ctx.do_spell(name, '<t>', 'DIA')
    end,
  },

  {
    id='HASTE',
    priority=7500,
    req={
      any=true,
      main={
        { job=JOB_WHM, lv=40 },
        { job=JOB_RDM, lv=48 },
      },
      sub={
        { job=JOB_WHM, lv=40 },
        { job=JOB_RDM, lv=48 },
      },
    },
    cooldown_sec=20.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Haste', cfgkey='auto.haste', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.haste') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if ctx.self_haste_active then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Haste') then return false end
      return ctx.is_ready('HASTE')
    end,
    act=function(ctx)
      return ctx.do_spell('Haste', '<me>', 'HASTE')
    end,
  },

  {
    id='REFRESH',
    priority=7600,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=41 } },
      sub={  { job=JOB_RDM, lv=41 } },
    },
    cooldown_sec=16.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Refresh', cfgkey='auto.refresh', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.refresh') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if ctx.self_refresh_active then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Refresh') then return false end
      return ctx.is_ready('REFRESH')
    end,
    act=function(ctx)
      return ctx.do_spell('Refresh', '<me>', 'REFRESH')
    end,
  },

  {
    id='ENFIRE',
    priority=8800,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=16 } },
      sub={  { job=JOB_RDM, lv=8  } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui={
      { kind='checkbox',      label='Enfire',  cfgkey='auto.enfire',     default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.enblizzard', false); cfg_set('auto.enaero', false); cfg_set('auto.enstone', false); cfg_set('auto.enwater', false); cfg_set('auto.enthunder', false) end end },
      { kind='checkbox_same', label='Enbliz',  cfgkey='auto.enblizzard', default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.enfire', false); cfg_set('auto.enaero', false); cfg_set('auto.enstone', false); cfg_set('auto.enwater', false); cfg_set('auto.enthunder', false) end end },
      { kind='checkbox_same', label='Enaero',  cfgkey='auto.enaero',     default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.enfire', false); cfg_set('auto.enblizzard', false); cfg_set('auto.enstone', false); cfg_set('auto.enwater', false); cfg_set('auto.enthunder', false) end end },
      { kind='checkbox',      label='Enstone', cfgkey='auto.enstone',    default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.enfire', false); cfg_set('auto.enblizzard', false); cfg_set('auto.enaero', false); cfg_set('auto.enwater', false); cfg_set('auto.enthunder', false) end end },
      { kind='checkbox_same', label='Enwater', cfgkey='auto.enwater',    default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.enfire', false); cfg_set('auto.enblizzard', false); cfg_set('auto.enaero', false); cfg_set('auto.enstone', false); cfg_set('auto.enthunder', false) end end },
      { kind='checkbox_same', label='Enthun',  cfgkey='auto.enthunder',  default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.enfire', false); cfg_set('auto.enblizzard', false); cfg_set('auto.enaero', false); cfg_set('auto.enstone', false); cfg_set('auto.enwater', false) end end },
    },
    eligible=function(ctx)
      if not enspell_ok(ctx, 'auto.enfire') then return false end
      return ctx.is_ready('ENFIRE')
    end,
    act=function(ctx)
      return ctx.do_spell('Enfire', '<me>', 'ENFIRE')
    end,
  },

  {
    id='ENBLIZZARD',
    priority=8801,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=16 } },
      sub={  { job=JOB_RDM, lv=8  } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui=nil,
    eligible=function(ctx)
      if not enspell_ok(ctx, 'auto.enblizzard') then return false end
      return ctx.is_ready('ENBLIZZARD')
    end,
    act=function(ctx)
      return ctx.do_spell('Enblizzard', '<me>', 'ENBLIZZARD')
    end,
  },

  {
    id='ENAERO',
    priority=8802,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=16 } },
      sub={  { job=JOB_RDM, lv=8  } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui=nil,
    eligible=function(ctx)
      if not enspell_ok(ctx, 'auto.enaero') then return false end
      return ctx.is_ready('ENAERO')
    end,
    act=function(ctx)
      return ctx.do_spell('Enaero', '<me>', 'ENAERO')
    end,
  },

  {
    id='ENSTONE',
    priority=8803,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=16 } },
      sub={  { job=JOB_RDM, lv=8  } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui=nil,
    eligible=function(ctx)
      if not enspell_ok(ctx, 'auto.enstone') then return false end
      return ctx.is_ready('ENSTONE')
    end,
    act=function(ctx)
      return ctx.do_spell('Enstone', '<me>', 'ENSTONE')
    end,
  },

  {
    id='ENWATER',
    priority=8804,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=16 } },
      sub={  { job=JOB_RDM, lv=8  } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui=nil,
    eligible=function(ctx)
      if not enspell_ok(ctx, 'auto.enwater') then return false end
      return ctx.is_ready('ENWATER')
    end,
    act=function(ctx)
      return ctx.do_spell('Enwater', '<me>', 'ENWATER')
    end,
  },

  {
    id='ENTHUNDER',
    priority=8805,
    req={
      any=true,
      main={ { job=JOB_RDM, lv=16 } },
      sub={  { job=JOB_RDM, lv=8  } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui=nil,
    eligible=function(ctx)
      if not enspell_ok(ctx, 'auto.enthunder') then return false end
      return ctx.is_ready('ENTHUNDER')
    end,
    act=function(ctx)
      return ctx.do_spell('Enthunder', '<me>', 'ENTHUNDER')
    end,
  },

  -- ---------------------------------------------------------------------
  -- DAMAGE SPIKES (Blaze / Ice / Shock). Self-target reactive buffs that
  -- damage attackers in melee. BLM and RDM native. Mutually exclusive
  -- WITHIN this group (server-side: a new spike overwrites the old) but
  -- they STACK with enspells -- the typical RDM melee setup runs an
  -- enspell + a spike together. Mirrors the enspell entry pattern:
  -- BLAZE_SPIKES carries the UI cluster (three boxes, one per spike);
  -- ICE_SPIKES and SHOCK_SPIKES set ui=nil and share the cluster.
  --
  -- Priorities sit at 8810-8812 -- one band past the enspell cluster
  -- (8800-8805) with a small visual gap. Levels listed are standard
  -- 75-cap entry points; the entry's `req` allows both BLM and RDM where
  -- applicable.
  -- ---------------------------------------------------------------------
  {
    id='BLAZE_SPIKES',
    priority=8810,
    req={
      any=true,
      main={
        { job=JOB_BLM, lv=10 },         -- HorizonXI: BLM 10 / RDM 20
        { job=JOB_RDM, lv=20 },
      },
      sub={
        { job=JOB_BLM, lv=10 },
        { job=JOB_RDM, lv=20 },
      },
    },
    cooldown_sec=10.0,                  -- HorizonXI recast (10s; 3min duration)
    gate_time=1.0,
    ui={
      { kind='checkbox',      label='Blaze', cfgkey='auto.blaze_spikes', default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.ice_spikes', false); cfg_set('auto.shock_spikes', false) end end },
      { kind='checkbox_same', label='Ice',   cfgkey='auto.ice_spikes',   default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.blaze_spikes', false); cfg_set('auto.shock_spikes', false) end end },
      { kind='checkbox_same', label='Shock', cfgkey='auto.shock_spikes', default=false,
        on_set=function(v, cfg_set) if v then cfg_set('auto.blaze_spikes', false); cfg_set('auto.ice_spikes', false) end end },
    },
    eligible=function(ctx)
      if not spike_ok(ctx, 'auto.blaze_spikes') then return false end
      return ctx.is_ready('BLAZE_SPIKES')
    end,
    act=function(ctx)
      return ctx.do_spell('Blaze Spikes', '<me>', 'BLAZE_SPIKES')
    end,
  },

  {
    id='ICE_SPIKES',
    priority=8811,
    req={
      any=true,
      main={
        { job=JOB_BLM, lv=20 },         -- HorizonXI: BLM 20 / RDM 40
        { job=JOB_RDM, lv=40 },
      },
      sub={
        { job=JOB_BLM, lv=20 },
        { job=JOB_RDM, lv=40 },
      },
    },
    cooldown_sec=10.0,                  -- HorizonXI recast (10s; 3min duration)
    gate_time=1.0,
    ui=nil,                            -- shared cluster on BLAZE_SPIKES
    eligible=function(ctx)
      if not spike_ok(ctx, 'auto.ice_spikes') then return false end
      return ctx.is_ready('ICE_SPIKES')
    end,
    act=function(ctx)
      return ctx.do_spell('Ice Spikes', '<me>', 'ICE_SPIKES')
    end,
  },

  {
    id='SHOCK_SPIKES',
    priority=8812,
    req={
      any=true,
      main={
        { job=JOB_BLM, lv=30 },         -- HorizonXI wiki: BLM 30 / RDM 60
        { job=JOB_RDM, lv=60 },
      },
      sub={
        { job=JOB_BLM, lv=30 },
        { job=JOB_RDM, lv=60 },
      },
    },
    cooldown_sec=10.0,                  -- HorizonXI recast (10s; 3min duration)
    gate_time=1.0,
    ui=nil,                            -- shared cluster on BLAZE_SPIKES
    eligible=function(ctx)
      if not spike_ok(ctx, 'auto.shock_spikes') then return false end
      return ctx.is_ready('SHOCK_SPIKES')
    end,
    act=function(ctx)
      return ctx.do_spell('Shock Spikes', '<me>', 'SHOCK_SPIKES')
    end,
  },

  {
    id='STONESKIN',
    kind='spell',
    weight=2,
    priority=3800,
    req={
      any=true,
      main={
        { job=JOB_WHM, lv=28 },
        { job=JOB_RDM, lv=34 },
      },
      sub={
        { job=JOB_WHM, lv=28 },
        { job=JOB_RDM, lv=34 },
      },
    },
    cooldown_sec=300.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Stoneskin', cfgkey='auto.stoneskin', default=false },
      { kind='checkbox_same', label='Atk', cfgkey='auto.stoneskin_mode_atk', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.stoneskin_mode', 'atk')
            ctx_set('auto.stoneskin_mode_atk', true)
            ctx_set('auto.stoneskin_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='Def', cfgkey='auto.stoneskin_mode_def', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.stoneskin_mode', 'def')
            ctx_set('auto.stoneskin_mode_atk', false)
            ctx_set('auto.stoneskin_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.stoneskin') then return false end
      if ctx.cfgget('auto.stoneskin_mode') ~= 'atk' then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if ctx.self_stoneskin_active then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Stoneskin') then return false end
      return ctx.is_ready('STONESKIN')
    end,
    act=function(ctx)
      return ctx.do_spell('Stoneskin', '<me>', 'STONESKIN')
    end,
  },

  {
    id='BLINK',
    weight=2,
    priority=3900,
    req={
      any=true,
      main={
        { job=JOB_WHM, lv=19 },
        { job=JOB_RDM, lv=23 },
      },
      sub={
        { job=JOB_WHM, lv=19 },
        { job=JOB_RDM, lv=23 },
      },
    },
    cooldown_sec=15.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Blink', cfgkey='auto.blink', default=false },
      { kind='checkbox_same', label='Atk', cfgkey='auto.blink_mode_atk', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.blink_mode', 'atk')
            ctx_set('auto.blink_mode_atk', true)
            ctx_set('auto.blink_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='Def', cfgkey='auto.blink_mode_def', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.blink_mode', 'def')
            ctx_set('auto.blink_mode_atk', false)
            ctx_set('auto.blink_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.blink') then return false end
      if ctx.cfgget('auto.blink_mode') ~= 'atk' then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if ctx.self_blink_active then return false end
      -- Defer to shadows. Utsusemi takes hit priority over Blink images,
      -- so casting Blink while shadows are up is wasted MP. If auto-shadows
      -- is enabled and a shadow cast is ready, skip Blink so we don't
      -- preempt or race the shadow cast.
      if (ctx.shadow_count or 0) > 0 then return false end
      if ctx.cfgget('auto.shadows')
         and ctx.shadows_can_attempt
         and ctx.shadows_can_attempt('atk') then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Blink') then return false end
      return ctx.is_ready('BLINK')
    end,
    act=function(ctx)
      return ctx.do_spell('Blink', '<me>', 'BLINK')
    end,
  },

  {
    id='PHALANX',
    priority=3950,
    -- HorizonXI: RDM Lv.33 only (PLD 77 / RUN 68 unreachable at 75-cap).
    -- 21 MP, 3s cast, 10s recast, 3-minute buff duration. Status ID 116.
    -- Lower priority than Stoneskin/Blink (the harder safety layers);
    -- Phalanx is a softer flat-DR buff and shouldn't preempt them.
    req={
      any=true,
      main={
        { job=JOB_RDM, lv=33 },
      },
      sub={
        { job=JOB_RDM, lv=33 },
      },
    },
    cooldown_sec=10.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Phalanx', cfgkey='auto.phalanx', default=false },
      { kind='checkbox_same', label='Atk', cfgkey='auto.phalanx_mode_atk', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.phalanx_mode', 'atk')
            ctx_set('auto.phalanx_mode_atk', true)
            ctx_set('auto.phalanx_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='Def', cfgkey='auto.phalanx_mode_def', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.phalanx_mode', 'def')
            ctx_set('auto.phalanx_mode_atk', false)
            ctx_set('auto.phalanx_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.phalanx') then return false end
      if ctx.cfgget('auto.phalanx_mode') ~= 'atk' then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if ctx.self_phalanx_active then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Phalanx') then return false end
      return ctx.is_ready('PHALANX')
    end,
    act=function(ctx)
      return ctx.do_spell('Phalanx', '<me>', 'PHALANX')
    end,
  },

  {
    id='PARALYZE',
    priority=8100,
    req={
      any=true,
      main={
        { job=JOB_WHM, lv=4 },
        { job=JOB_RDM, lv=6 },
      },
      sub={
        { job=JOB_WHM, lv=4 },
        { job=JOB_RDM, lv=6 },
      },
    },
    cooldown_sec=8.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Paralyze', cfgkey='auto.paralyze', default=false },
    },
    eligible=function(ctx)
      if ctx.target_dead then return false end
      if not ctx.cfgget('auto.paralyze') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if not (ctx.dist and ctx.dist <= 20) then return false end
      if not (ctx.mob_debuff_ready and ctx.mob_debuff_ready('PARALYZE')) then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Paralyze') then return false end

      local ji = ctx.job_info
      if not ji then return false end

      -- HorizonXI: Paralyze = WHM 4 / RDM 6.
      local main_ok =
        ((ji.mainJob == JOB_WHM and (ji.mainLv or 0) >= 4) or
         (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 6))
      local sub_ok =
        ((ji.subJob  == JOB_WHM and (ji.subLv  or 0) >= 4) or
         (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 6))

      if not (main_ok or sub_ok) then return false end

      return ctx.is_ready('PARALYZE')
    end,
    act=function(ctx)
      return ctx.do_spell('Paralyze', '<t>', 'PARALYZE')
    end,
  },

  {
    id='SLOW',
    priority=8200,
    req={
      any=true,
      main={
        { job=JOB_WHM, lv=13 },
        { job=JOB_RDM, lv=13 },
      },
      sub={
        { job=JOB_WHM, lv=13 },
        { job=JOB_RDM, lv=13 },
      },
    },
    cooldown_sec=8.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Slow', cfgkey='auto.slow', default=false },
    },
    eligible=function(ctx)
      if ctx.target_dead then return false end
      if not ctx.cfgget('auto.slow') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if not (ctx.dist and ctx.dist <= 20) then return false end
      if not (ctx.mob_debuff_ready and ctx.mob_debuff_ready('SLOW')) then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Slow') then return false end

      local ji = ctx.job_info
      if not ji then return false end

      -- HorizonXI: Slow = WHM 13 / RDM 13.
      local main_ok =
        ((ji.mainJob == JOB_WHM and (ji.mainLv or 0) >= 13) or
         (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 13))
      local sub_ok =
        ((ji.subJob  == JOB_WHM and (ji.subLv  or 0) >= 13) or
         (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 13))

      if not (main_ok or sub_ok) then return false end

      return ctx.is_ready('SLOW')
    end,
    act=function(ctx)
      return ctx.do_spell('Slow', '<t>', 'SLOW')
    end,
  },

  {
    id='BLIND',
    priority=8300,
    req={
      any=true,
      main={
        { job=JOB_BLM, lv=4 },
        { job=JOB_RDM, lv=8 },
      },
      sub={
        { job=JOB_BLM, lv=4 },
        { job=JOB_RDM, lv=8 },
      },
    },
    cooldown_sec=8.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Blind', cfgkey='auto.blind', default=false },
    },
    eligible=function(ctx)
      if ctx.target_dead then return false end
      if not ctx.cfgget('auto.blind') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if not (ctx.dist and ctx.dist <= 20) then return false end
      if not (ctx.mob_debuff_ready and ctx.mob_debuff_ready('BLIND')) then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Blind') then return false end

      local ji = ctx.job_info
      if not ji then return false end

      -- HorizonXI: Blind = BLM 4 / RDM 8.
      local main_ok =
        ((ji.mainJob == JOB_BLM and (ji.mainLv or 0) >= 4) or
         (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 8))
      local sub_ok =
        ((ji.subJob  == JOB_BLM and (ji.subLv  or 0) >= 4) or
         (ji.subJob  == JOB_RDM and (ji.subLv  or 0) >= 8))

      if not (main_ok or sub_ok) then return false end

      return ctx.is_ready('BLIND')
    end,
    act=function(ctx)
      return ctx.do_spell('Blind', '<t>', 'BLIND')
    end,
  },

  {
    id='POISON',
    priority=8400,
    req={
      any=true,
      main={
        { job=JOB_BLM, lv=3 },
        { job=JOB_RDM, lv=5 },
      },
      sub={
        { job=JOB_BLM, lv=3 },
        { job=JOB_RDM, lv=5 },
      },
    },
    cooldown_sec=8.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Poison', cfgkey='auto.poison', default=false },
    },
    eligible=function(ctx)
      if ctx.target_dead then return false end
      if not ctx.cfgget('auto.poison') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if not (ctx.dist and ctx.dist <= 20) then return false end
      if not (ctx.mob_debuff_ready and ctx.mob_debuff_ready('POISON')) then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Poison') then return false end

      local ji = ctx.job_info
      if not ji then return false end

      local main_ok =
        ((ji.mainJob == JOB_BLM and (ji.mainLv or 0) >= 3) or
         (ji.mainJob == JOB_RDM and (ji.mainLv or 0) >= 5))

      local sub_ok =
        ((ji.subJob == JOB_BLM and (ji.subLv or 0) >= 3) or
         (ji.subJob == JOB_RDM and (ji.subLv or 0) >= 5))

      if not (main_ok or sub_ok) then return false end

      return ctx.is_ready('POISON')
    end,
    act=function(ctx)
      return ctx.do_spell('Poison', '<t>', 'POISON')
    end,
  },

  {
    id='STONE',
    priority=9900,          -- skill-up filler floor. Stone and RANGED never
                             -- fire on the same job, so relative ordering
                             -- against RANGED (9800) doesn't matter. Sits
                             -- below every functional ladder entry.
    req={
      any=true,
      main={
        { job=JOB_BLM, lv=4 },
        { job=JOB_RDM, lv=5 },
      },
      sub={
        { job=JOB_BLM, lv=4 },
        { job=JOB_RDM, lv=5 },
      },
    },
    cooldown_sec=5.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Stone', cfgkey='auto.stone', default=false },
    },
    eligible=function(ctx)
      if ctx.target_dead then return false end
      if not ctx.cfgget('auto.stone') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.ws_blocked then return false end
      if not (ctx.dist and ctx.dist <= 20) then return false end
      if ctx.has_spell_mp and not ctx.has_spell_mp('Stone') then return false end
      return ctx.is_ready('STONE')
    end,
    act=function(ctx)
      return ctx.do_spell('Stone', '<t>', 'STONE')
    end,
  },

  {
    id='PROVOKE',
    kind='ja',
    priority=4000,                       -- fires before Berserk(5555)/Warcry(5556) so claim taunt lands first
    req={
      any=true,
      main={ { job=JOB_WAR, lv=5 } },    -- WAR Lv5
      sub={  { job=JOB_WAR, lv=5 } },    -- /WAR caps at half main, so this needs main >= 10
    },
    cooldown_sec=30.0,                   -- 0:30 recast, 0:30 duration, 18 yalm range
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Provoke', cfgkey='auto.provoke', default=false },
      { kind='radio3',
          labelA='Claim only##voke', valA=97,
          labelB='>50%##voke',       valB=50,
          labelC='>25%##voke',       valC=25,
          cfgkey='voke_hp', default=97
      },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.provoke') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if not (ctx.dist and ctx.dist <= 18) then return false end
      local voke_hp = tonumber(ctx.cfgget('voke_hp') or 97) or 97
      if not (ctx.target_hp and ctx.target_hp >= voke_hp) then return false end
      -- Claim-only mode: one voke per mob. Sustain modes (50/25) re-fire on CD
      -- and rely solely on the HP threshold to bound the loop.
      if voke_hp >= 90 and ctx.voke_already_done_on_target then return false end
      return ctx.is_ready('PROVOKE')
    end,
    act=function(ctx)
      local ok = ctx.do_ja('Provoke', '<t>', 'PROVOKE')
      if ok and ctx.mark_target_voked then
        ctx.mark_target_voked(ctx.target_server_id)
      end
      return ok
    end,
  },

  {
    id='BERSERK',
    kind='ja',
    priority=6100,
    req={
      any=true,
      main={
        { job=JOB_WAR, lv=15 },        -- WAR Lv15
      },
      sub={
        { job=JOB_WAR, lv=15 },        -- /WAR caps at half main, so this needs main >= 30
      },
    },
    cooldown_sec=300.0,                 -- 5:00 recast, 3:00 duration (retail-standard)
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Berserk', cfgkey='auto.berserk', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.berserk') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      -- Skip if Berserk buff already active. 3m duration vs 5m recast means a
      -- manual use would otherwise waste the recast on a re-fire 2 minutes later.
      if ctx.buff_active and ctx.buff_active('Berserk') then return false end
      if (ctx.tp or 0) < 1000 then return false end
      if not ctx.ws_hp_ok then return false end
      return ctx.is_ready('BERSERK')
    end,
    act=function(ctx)
      return ctx.do_ja('Berserk', '<me>', 'BERSERK')
    end,
  },

  {
    id='WARCRY',
    kind='ja',
    priority=6000,
    req={
      any=true,
      main={
        { job=JOB_WAR, lv=35 },        -- WAR Lv35
      },
      sub={
        { job=JOB_WAR, lv=35 },        -- /WAR caps at half main, so this needs main >= 70
      },
    },
    cooldown_sec=300.0,                 -- 5:00 recast, 0:30 duration (retail-standard)
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Warcry', cfgkey='auto.warcry', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.warcry') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      -- Skip if Warcry buff already active. 30s duration vs 5m recast means a
      -- manual use would otherwise waste 4:30 of recast on a re-fire 30s later.
      if ctx.buff_active and ctx.buff_active('Warcry') then return false end
      if (ctx.tp or 0) < 1000 then return false end
      if not ctx.ws_hp_ok then return false end
      return ctx.is_ready('WARCRY')
    end,
    act=function(ctx)
      return ctx.do_ja('Warcry', '<me>', 'WARCRY')
    end,
  },

  {
    id='BOOST',
    kind='ja',
    priority=6200,                      -- after Berserk(6100)/Warcry(6000), still before the WS
    req={
      any=true,
      main={ { job=JOB_MNK, lv=5 } },   -- MNK Lv5
      sub={  { job=JOB_MNK, lv=5 } },   -- /MNK caps at half main, so this needs main >= 10
    },
    cooldown_sec=15.0,                  -- 0:15 recast; stacks, so no buff-active skip
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Boost', cfgkey='auto.boost', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.boost') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      -- WS-prep: only boost when we're about to WS, so the attack bonus lands
      -- on the weaponskill rather than bleeding onto normal swings.
      if (ctx.tp or 0) < 1000 then return false end
      if not ctx.ws_hp_ok then return false end
      return ctx.is_ready('BOOST')
    end,
    act=function(ctx)
      return ctx.do_ja('Boost', '<me>', 'BOOST')
    end,
  },

  {
    id='THIRD_EYE',
    kind='ja',
    priority=3600,
    req={
      any=true,
      main={ { job=JOB_SAM, lv=15 } },
      sub={  { job=JOB_SAM, lv=15 } },
    },
    cooldown_sec=60.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Third Eye', cfgkey='auto.thirdeye', default=false },
      { kind='checkbox_same', label='TAtk', cfgkey='auto.thirdeye_mode_atk', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.thirdeye_mode', 'atk')
            ctx_set('auto.thirdeye_mode_atk', true)
            ctx_set('auto.thirdeye_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='TDef', cfgkey='auto.thirdeye_mode_def', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.thirdeye_mode', 'def')
            ctx_set('auto.thirdeye_mode_atk', false)
            ctx_set('auto.thirdeye_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.thirdeye') then return false end
      if ctx.cfgget('auto.thirdeye_mode') ~= 'atk' then return false end
      if ctx.self_thirdeye_active then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      return ctx.is_ready('THIRD_EYE')
    end,
    act=function(ctx)
      return ctx.do_ja('Third Eye', '<me>', 'THIRD_EYE')
    end,
  },

  {
    id='HASSO',
    kind='ja',
    priority=5000,
    req={
      any=true,
      main={ { job=JOB_SAM, lv=25 } },  -- SAM Lv25
      sub={  { job=JOB_SAM, lv=25 } },  -- /SAM caps at half main, so this needs main >= 50
    },
    cooldown_sec=45.0,                  -- HorizonXI-specific: 0:45 recast (retail 1:00), 5:00 duration
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Hasso', cfgkey='auto.hasso', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.hasso') then return false end
      if ctx.self_hasso_active then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      return ctx.is_ready('HASSO')
    end,
    act=function(ctx)
      return ctx.do_ja('Hasso', '<me>', 'HASSO')
    end,
  },

  {
    id='MEDITATE',
    kind='ja',
    priority=5600,
    req={
      any=true,
      main={ { job=JOB_SAM, lv=30 } },
      sub={  { job=JOB_SAM, lv=30 } },
    },
    cooldown_sec=180.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Meditate', cfgkey='auto.meditate', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.meditate') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if (ctx.tp or 0) >= 600 then return false end
      return ctx.is_ready('MEDITATE')
    end,
    act=function(ctx)
      return ctx.do_ja('Meditate', '<me>', 'MEDITATE')
    end,
  },

  {
    id='SEIGAN',
    kind='ja',
    priority=5100,
    req={
      any=true,
      main={ { job=JOB_SAM, lv=35 } },
      sub={  { job=JOB_SAM, lv=35 } },
    },
    cooldown_sec=45.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Seigan', cfgkey='auto.seigan', default=false },
      { kind='checkbox_same', label='GAtk', cfgkey='auto.seigan_mode_atk', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.seigan_mode', 'atk')
            ctx_set('auto.seigan_mode_atk', true)
            ctx_set('auto.seigan_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='GDef', cfgkey='auto.seigan_mode_def', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.seigan_mode', 'def')
            ctx_set('auto.seigan_mode_atk', false)
            ctx_set('auto.seigan_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.seigan') then return false end
      if ctx.cfgget('auto.seigan_mode') ~= 'atk' then return false end
      if ctx.self_seigan_active then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      return ctx.is_ready('SEIGAN')
    end,
    act=function(ctx)
      return ctx.do_ja('Seigan', '<me>', 'SEIGAN')
    end,
  },

  {
    id='CALL_WYVERN',
    kind='ja',
    priority=1100,
    req={
      main={
        { job=JOB_DRG, lv=1 },
      },
    },
    cooldown_sec=300.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Call Wyvern', cfgkey='auto.callwyvern', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.callwyvern') then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.pet_present then return false end
      return ctx.is_ready('CALL_WYVERN')
    end,
    act=function(ctx)
      return ctx.do_ja('Call Wyvern', '<me>', 'CALL_WYVERN')
    end,
  },

  {
    -- Emergency sleep: at 0 shadows, equip the sleep bolt/arrow and /ra in the
    -- SAME round, one priority ahead of the shadows recast so it fires first.
    -- The ranged readying then holds the Utsusemi cast until the shot lands.
    id='SLEEP_SHADOWS',
    kind='spell',
    priority=3499,
    req={
      any=true,
      main={ { job=JOB_NIN, lv=12 } },
      sub={ { job=JOB_NIN, lv=12 } },
    },
    gate_time=0.5,
    ui=nil,
    eligible=function(ctx)
      if not ctx.cfgget('auto.shadows') then return false end
      if not ctx.cfgget('auto.shadows_sleep') then return false end
      if ctx.cfgget('auto.shadows_mode') ~= 'atk' then return false end
      if (tonumber(ctx.shadow_count or 0) or 0) > 0 then return false end
      if ctx.spells_locked then return false end
      if ctx.ranged_busy or not ctx.ra_ready then return false end
      if ctx.target_dead then return false end
      -- No point sleeping if a shadow spell isn't ready to recast anyway.
      if not ctx.shadow_recast_ready() then return false end
      -- No point sleeping a mob that already has a DoT (it'll wake instantly).
      if ctx.target_has_waking_dot() then return false end
      local ammo = tostring(ctx.sleep_ammo_name or '')
      if ammo == '' then return false end
      if ctx.tool_missing(ammo) then return false end
      if not ctx.sleep_ammo_equipped and not ctx.sleep_ammo_available then
        ctx.mark_tool_missing(ammo)
        return false
      end
      return true
    end,
    act=function(ctx)
      return ctx.sleep_shot(tostring(ctx.sleep_ammo_name or ''))
    end,
  },

  {
    id='SHADOWS',
    kind='spell',
    priority=3500,
    req={
      any=true,
      main={ { job=JOB_NIN, lv=12 } },
      sub={ { job=JOB_NIN, lv=12 } },
    },
    cooldown_sec=0.0,
    gate_time=0.5,
    ui={
      { kind='shadows_master', label='Auto Shadows (NIN)', cfgkey='auto.shadows', default=false },
      { kind='checkbox_same', label='SAtk', cfgkey='auto.shadows_mode_atk', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.shadows_mode', 'atk')
            ctx_set('auto.shadows_mode_atk', true)
            ctx_set('auto.shadows_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='SDef', cfgkey='auto.shadows_mode_def', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.shadows_mode', 'def')
            ctx_set('auto.shadows_mode_atk', false)
            ctx_set('auto.shadows_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.shadows') then return false end
      if ctx.cfgget('auto.shadows_mode') ~= 'atk' then return false end
      if ctx.spells_locked then return false end
      return ctx.shadows_can_attempt('atk', false)
    end,
    act=function(ctx)
      return ctx.do_shadows(false, 'atk')
    end,
  },

  {
    -- Auto Sleep/Sneak (THF). If no OTHER bolt mode is firing this round,
    -- and SA is off cooldown, and the target's HP is under the configured
    -- threshold, and we have TP under 800 (WS gets priority above that):
    -- fire a sleep bolt at <t>, then run the S/S/D pipeline starting at
    -- wait -- confirm sleep landed, disengage, walk behind, SA, /attack.
    -- Priority 9750 sits just above RANGED (9800) so this preempts the
    -- 'normal' /ra case (when no specific bolt mode is on), but the
    -- eligibility explicitly bails when ranged_plan returns bloody /
    -- sleep_other / acid / blind so those still fire from RANGED.
    id='SLEEP_SNEAK',
    kind='ra',
    priority=9750,
    req={
      any=true,
      main={ { job=JOB_THF, lv=15 } },
      sub={  { job=JOB_THF, lv=15 } },
    },
    gate_time=0.5,
    -- Must be truthy for entry_is_visible; render_mode_controls_for_entry
    -- intercepts SLEEP_SNEAK before this list is walked.
    ui={},
    eligible=function(ctx)
      if not ctx.cfgget('thief.auto_sleep_sneak') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.target_dead then return false end
      if ctx.spells_locked_soft then return false end
      if ctx.ranged_busy or not ctx.ra_ready then return false end
      -- Need a real bow/xbow AND a sleep bolt / arrow lined up.
      if not ctx.ranged_weapon_ok then return false end
      local ammo = tostring(ctx.sleep_ammo_name or '')
      if ammo == '' then return false end
      if ctx.tool_missing(ammo) then return false end
      if not ctx.sleep_ammo_equipped and not ctx.sleep_ammo_available then
        ctx.mark_tool_missing(ammo)
        return false
      end
      -- SA off cooldown.
      if not ctx.sneak_attack_ready() then return false end
      -- Target must not already be asleep (would waste the combo) and
      -- must have no DoT (any DoT wakes on tick).
      if ctx.target_has_debuff and ctx.target_has_debuff('sleep') then return false end
      if ctx.target_has_waking_dot() then return false end
      -- Target HP threshold. 0 == "Any" (no gate). Fires when target HP is
      -- AT OR ABOVE the threshold; below it the mob is about to die and the
      -- S/S/D combo isn't worth setting up.
      local hp_thresh = tonumber(ctx.cfgget('thief.auto_sleep_sneak_hp') or 0) or 0
      if hp_thresh > 0 then
        local thp = tonumber(ctx.target_hp)
        if thp == nil or thp < hp_thresh then return false end
      end
      -- TP gate: save the combo when we're about to WS.
      if (tonumber(ctx.tp) or 0) >= 800 then return false end
      -- "No other bolt is ready" -- let RANGED fire its specific-mode
      -- bolts first. ranged_plan is idempotent so calling it here is
      -- safe; RANGED's own eligibility calls it again.
      if type(ctx.ranged_plan) == 'function' then
        local plan = ctx.ranged_plan()
        if plan == 'blood' or plan == 'sleep'
           or plan == 'acid' or plan == 'blind' then
          return false
        end
      end
      return true
    end,
    act=function(ctx)
      return ctx.do_auto_sleep_sneak and ctx.do_auto_sleep_sneak() or false
    end,
  },

  {
    -- Auto Sneak Only (THF). Walk behind mob and fire SA. Party context:
    -- mob is on the tank, so we can freely position. kind='ra': the
    -- dispatcher only scans spell/ja/ws/ra/hb, and the single ra_slot
    -- gives natural mutual exclusion with SLEEP_SNEAK and RANGED.
    -- Priority 9770 = LAST of the thief trio (lower number wins the
    -- slot): SLEEP_SNEAK 9750 > TRICK_ATTACK 9760 > this > RANGED 9800.
    -- Also defers in eligible() when TA is ready.
    id='SNEAK_ONLY',
    kind='ra',
    priority=9770,
    req={
      any=true,
      main={ { job=JOB_THF, lv=15 } },
      sub={  { job=JOB_THF, lv=15 } },
    },
    gate_time=0.5,
    ui={},   -- rendered via render_mode_controls_for_entry
    eligible=function(ctx)
      if not ctx.cfgget('thief.auto_sneak_only') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.target_dead then return false end
      if ctx.spells_locked_soft then return false end
      -- Movement lane busy (sleep-other strafe or an in-flight thief
      -- action) -> stand down; whatever is running finishes first.
      if ctx.thief_movement_active and ctx.thief_movement_active() then
        return false
      end
      if not ctx.sneak_attack_ready() then return false end
      -- Defer to TA when it's up (TA has the higher movement priority);
      -- either Auto TA or Hold WS can drive it.
      if (ctx.cfgget('thief.auto_trick_attack') or ctx.cfgget('thief.hold_ws'))
         and ctx.trick_attack_ready() then
        return false
      end
      -- HP: mob must be at/above the threshold (25 = fire 25-100%);
      -- don't waste SA on a nearly-dead mob. 0 = Any.
      local hp_thresh = tonumber(ctx.cfgget('thief.auto_sneak_only_hp') or 0) or 0
      if hp_thresh > 0 then
        local thp = tonumber(ctx.target_hp)
        if thp == nil or thp < hp_thresh then return false end
      end
      -- "Nothing else is ready": SA is the fallback for the round. If
      -- Auto Ranged has a specific bolt queued (bloody / sleep-other /
      -- acid / blind), that fires instead; SA takes a quiet round.
      if ctx.cfgget('auto.ranged') == true
         and type(ctx.ranged_plan) == 'function' then
        local plan = ctx.ranged_plan()
        if plan == 'blood' or plan == 'sleep'
           or plan == 'acid' or plan == 'blind' then
          return false
        end
      end
      return true
    end,
    act=function(ctx)
      return ctx.start_sneak_only and ctx.start_sneak_only() or false
    end,
  },

  {
    -- Auto Trick Attack (THF). Walk behind the named tank (line: us ->
    -- tank -> mob), fire TA. Priority 9760: below SLEEP_SNEAK (9750),
    -- above SNEAK_ONLY (9770) -- lower number wins the ra_slot. When Hold
    -- WS is on and TP >= 1000, the same entry drives TA + WS (staged
    -- with the with_ws flag; the WS fires from tick_thief_action after
    -- TA lands).
    id='TRICK_ATTACK',
    kind='ra',
    priority=9760,
    req={
      any=true,
      main={ { job=JOB_THF, lv=15 } },
      sub={  { job=JOB_THF, lv=15 } },
    },
    gate_time=0.5,
    ui={},
    eligible=function(ctx)
      local ta_on  = ctx.cfgget('thief.auto_trick_attack') == true
      local hws_on = ctx.cfgget('thief.hold_ws')           == true
      if not (ta_on or hws_on) then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.target_dead then return false end
      if ctx.spells_locked_soft then return false end
      if ctx.thief_movement_active and ctx.thief_movement_active() then
        return false
      end
      if not ctx.trick_attack_ready() then return false end
      local tank = ctx.tank_entity and ctx.tank_entity() or nil
      if not tank then return false end
      -- Hold WS path: TP >= 1000 + its own HP threshold.
      if hws_on and (tonumber(ctx.tp) or 0) >= 1000 then
        local hp_thresh = tonumber(ctx.cfgget('thief.hold_ws_hp') or 0) or 0
        if hp_thresh > 0 then
          local thp = tonumber(ctx.target_hp)
          if thp == nil or thp < hp_thresh then return false end
        end
        return true
      end
      -- Plain Auto TA path.
      if not ta_on then return false end
      local hp_thresh = tonumber(ctx.cfgget('thief.auto_trick_attack_hp') or 0) or 0
      if hp_thresh > 0 then
        local thp = tonumber(ctx.target_hp)
        if thp == nil or thp < hp_thresh then return false end
      end
      return true
    end,
    act=function(ctx)
      local combo = ctx.cfgget('thief.hold_ws') == true
                    and (tonumber(ctx.tp) or 0) >= 1000
      return ctx.start_trick_attack and ctx.start_trick_attack(combo) or false
    end,
  },

  {
    id='SONG',
    priority=7700,
    req={
      any=true,
      main={ { job=JOB_BRD, lv=5 } },
      sub={  { job=JOB_BRD, lv=5 } },
    },
    cooldown_sec=12.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label="Auto Army's Paeon", cfgkey='auto.song', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.song') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if ctx.buff_active and ctx.buff_active('Paeon') then return false end
      return ctx.is_ready('SONG')
    end,
    act=function(ctx)
      return ctx.do_spell("Army's Paeon", '<me>', 'SONG')
    end,
  },

  {
    id='HB',
    kind='hb',
    priority=2000,
    req={
      main={
        { job=JOB_DRG, lv=1 },
      },
    },
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Healing Breath', cfgkey='auto.hb', default=false },
      { kind='radio3',
        labelA='25%##hb', valA=25,
        labelB='33%##hb', valB=33,
        labelC='50%##hb', valC=50,
        cfgkey='hb_hp', default=25 },
      { kind='checkbox_same', label='HAtk', cfgkey='auto.hb_mode_atk', default=true,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.hb_mode', 'atk')
            ctx_set('auto.hb_mode_atk', true)
            ctx_set('auto.hb_mode_def', false)
          end
        end },
      { kind='checkbox_same', label='HDef', cfgkey='auto.hb_mode_def', default=false,
        on_set=function(v, ctx_set)
          if v then
            ctx_set('auto.hb_mode', 'def')
            ctx_set('auto.hb_mode_atk', false)
            ctx_set('auto.hb_mode_def', true)
          end
        end },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.hb') then return false end
      if ctx.cfgget('auto.hb_mode') ~= 'atk' then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.resting01 == 1 then return false end
      if ctx.spells_locked then return false end
      if not ctx.hb_hp_ok then return false end
      return ctx.hb_ready
    end,
    act=function(ctx)
      return ctx.do_hb('HB')
    end,
  },
  {
    id='PET_FIGHT',
    kind='ja',
    priority=3000,            -- fire early; one-shot per mob, doesn't block bursts
    req={
      any=true,
      main={
        { job=JOB_BST, lv=1 },
      },
      sub={
        { job=JOB_BST, lv=1 },
      },
    },
    cooldown_sec=2.0,        -- light spam guard; real gate is "pet already on this mob"
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Pet Fight', cfgkey='auto.petfight', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.petfight') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if not ctx.pet_present then return false end
      if ctx.target_dead then return false end
      if not ctx.target_valid then return false end
      if not ctx.target_claim_free_or_party then return false end

      local target_sid = tonumber(ctx.target_server_id or 0) or 0
      if target_sid <= 0 then return false end

      -- Skip if pet is already on this mob (live signal from packet_parser).
      local pet_target_sid = tonumber(ctx.pet_target_server_id or 0) or 0
      if pet_target_sid == target_sid then return false end

      return ctx.is_ready('PET_FIGHT')
    end,
    act=function(ctx)
      return ctx.do_pet('Fight', '<t>', 'PET_FIGHT')
    end,
  },
  {
    id='PET_READY',
    kind='ja',
    priority=3001,            -- after PET_FIGHT (100), before REWARD (105)
    req={
      -- Main-only: Ready is BST 25 main JA only, no /BST.
      main={
        { job=JOB_BST, lv=25 },
      },
    },
    cooldown_sec=2.0,        -- light spam guard between attempts; real gate is charges
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Pet Ready', cfgkey='auto.ready', default=false },
      { kind='input_text',
        label='Ready Move',
        cfgkey='pet_ready_name',
        default='',
        max_len=64,
      },
      { kind='radio3',
        labelA='1##petready_charges', valA=1,
        labelB='2##petready_charges', valB=2,
        labelC='3##petready_charges', valC=3,
        cfgkey='pet_ready_charges', default=1,
      },
      { kind='radio4',
        labelA='25%##petready_thp',  valA=25,
        labelB='33%##petready_thp',  valB=33,
        labelC='50%##petready_thp',  valC=50,
        labelD='Any##petready_thp',  valD=0,
        cfgkey='pet_ready_target_hp', default=0,
      },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.ready') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if not ctx.pet_present then return false end
      if not ctx.pet_engaged then return false end       -- pet must be on a target

      local name = tostring(ctx.cfgget('pet_ready_name') or '')
      if name == '' then return false end                -- no move configured

      -- Charge gate: user-selected minimum (1/2/3).
      local need = tonumber(ctx.cfgget('pet_ready_charges') or 1) or 1
      if need < 1 then need = 1 elseif need > 3 then need = 3 end
      if (tonumber(ctx.pet_ready_charges or 0) or 0) < need then return false end

      -- Target-HP gate: only fire when enemy HP% is at or above the floor.
      -- 0 = Any (no gate). Mirrors the ws_hp_ok pattern used by ctx.do_ws.
      local floor = tonumber(ctx.cfgget('pet_ready_target_hp') or 0) or 0
      if floor > 0 then
        local thp = tonumber(ctx.target_hp)
        if thp == nil then return false end              -- can't read = don't fire
        if thp < floor then return false end
      end

      return ctx.is_ready('PET_READY')
    end,
    act=function(ctx)
      local name = tostring(ctx.cfgget('pet_ready_name') or '')
      -- Ready moves use /pet not /ja; bsthud confirms format /pet "Move" <t>.
      return ctx.do_pet(name, '<t>', 'PET_READY')
    end,
  },
  {
    id='REWARD',
    kind='ja',
    priority=7200,            -- between PET_FIGHT (100) and CALL_BEAST (110); pet dying is urgent
    req={
      any=true,
      -- Pet food is universal-equip, and /BST sub gets the JA, so allow both main and sub.
      main={
        { job=JOB_BST, lv=12 },
      },
      sub={
        { job=JOB_BST, lv=12 },
      },
    },
    cooldown_sec=90.0,       -- 1:30 recast. Auto-synced from "Time left:" log lines if game disagrees.
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Reward', cfgkey='auto.reward', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.reward') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if not ctx.pet_present then return false end

      -- pet_hp is 0-100 percent. Fire at or below 33%.
      local hp = tonumber(ctx.pet_hp or 0) or 0
      if hp <= 0 then return false end       -- safety: 0 == dead/no pet
      if hp > 33 then return false end

      -- Note: if no pet food is equipped, the JA fails silently in-game but our
      -- local cooldown still bumps to 90s on dispatch, so we won't spam.
      return ctx.is_ready('REWARD')
    end,
    act=function(ctx)
      return ctx.do_ja('Reward', '<me>', 'REWARD')
    end,
  },
  {
    id='CALL_BEAST',
    kind='ja',
    priority=1000,            -- right after PET_FIGHT; without a pet, this is the urgent thing
    req={
      -- Main-only: /BST cannot equip jugs, so the JA is unusable as a subjob.
      main={
        { job=JOB_BST, lv=23 },
      },
    },
    cooldown_sec=300.0,      -- 5min recast. Auto-synced from "Time left:" log lines if game disagrees.
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Call Beast', cfgkey='auto.callbeast', default=false },
    },
    eligible=function(ctx)
      -- Eligibility kept clean; the live "why not?" reason is computed every
      -- tick in general.lua's refresh_live and shown in the debug panel.
      if not ctx.cfgget('auto.callbeast') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.pet_present then return false end           -- REWARD handles low-HP pet, not Call Beast
      return ctx.is_ready('CALL_BEAST')
    end,
    act=function(ctx)
      return ctx.do_ja('Call Beast', '<me>', 'CALL_BEAST')
    end,
  },
  {
    id='STEADY_WING',
    kind='ja',
    priority=7100,
    req={
      main={
        { job=JOB_DRG, lv=35},  
      },
    },
    cooldown_sec=300.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Steady Wing', cfgkey='auto.steadywing', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.steadywing') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if not ctx.pet_present then return false end
      if ctx.pet_hp <= 0 or ctx.pet_hp >= 80 then return false end
      return ctx.is_ready('STEADY_WING')
    end,
    act=function(ctx)
      return ctx.do_pet('Steady Wing', '<me>', 'STEADY_WING')
    end,
  },
  {
    id='SPIRIT_LINK',
    kind='ja',
    priority=7000,
    req={
      main={
        { job=JOB_DRG, lv=35},
      },
    },
    cooldown_sec=300.0,
    gate_time=1.0,
    ui={
      { kind='checkbox', label='Auto Spirit Link', cfgkey='auto.spiritlink', default=false },
    },
    eligible=function(ctx)
      if not ctx.cfgget('auto.spiritlink') then return false end
      if ctx.engaged01 ~= 1 then return false end
      if ctx.spells_locked then return false end
      if not ctx.pet_present then return false end
      if (ctx.player_hp or 0) < 80 then return false end
      if ctx.pet_hp <= 0 or ctx.pet_hp >= 50 then return false end
      if (ctx.target_hp or 100) >= 10 then return false end
      return ctx.is_ready('SPIRIT_LINK')
    end,
    act=function(ctx)
      return ctx.do_ja('Spirit Link', '<me>', 'SPIRIT_LINK')
    end,
  },

}