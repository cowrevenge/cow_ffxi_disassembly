--[[---------------------------------------------------------------------------
def_list.lua
Purpose:
	- Defensive ladder that runs on mob attacks against you.
	- DEF shadows must ignore the global gate; main runs this ladder under soft-lock only.
Rules:
	- Pure LIST: no cfg/S/settings references.
	- Uses new config keys:
		* auto.shadows_mode
		* auto.hb_mode
		* auto.callwyvern
		* auto.protect
		* auto.shell
		* auto.cure
		* cure_hp
	- Use ctx.spells_locked_soft for DEF actions that should ignore gate/WS-block but still
	  respect casting/spell-lock.
---------------------------------------------------------------------------]]--

local JOB_WHM, JOB_BLM, JOB_RDM, JOB_PLD, JOB_NIN, JOB_DRG, JOB_SAM = 3, 4, 5, 7, 13, 14, 12

return {

	{
		-- Emergency Warp. HP hits the threshold, /item "Instant Warp" <me>.
		-- Priority 1 sits above CURE (5) and every other def action -- when
		-- we're this low, a warp beats a Cure III that might not land in time.
		-- 15s cooldown covers the item's own cast + a buffer so we don't spam
		-- the same warp if HP wobbles back over the threshold and drops again.
		id='EMERG_WARP',
		kind='item',
		priority=1,
		cooldown_sec=15.0,
		gate_time=1.0,
		ui={
			{ kind='checkbox', label='Emergency Warp', cfgkey='auto.warp', default=false },
			{ kind='radio3',
				labelA='5%##warp',  valA=5,
				labelB='10%##warp', valB=10,
				labelC='15%##warp', valC=15,
				cfgkey='warp_hp', default=5
			},
		},
		eligible=function(ctx)
			if not ctx.cfgget('auto.warp') then return false end
			-- No jobs gate -- Instant Warp is an item, anyone can use it.
			-- Fires while resting too: a rested mage at 5% HP dying is still
			-- a mage that wants out.
			if ctx.spells_locked_soft then return false end
			local thresh = tonumber(ctx.cfgget('warp_hp') or 5) or 5
			local hp = tonumber(ctx.player_hp)
			if hp == nil or hp <= 0 or hp > thresh then return false end
			return ctx.is_ready('EMERG_WARP')
		end,
		act=function(ctx)
			return ctx.do_item('Instant Warp', '<me>', 'EMERG_WARP')
		end,
	},

	{
		id='SUPER_JUMP',
		kind='ja',
		priority=10,
		req={
			main={
				{ job=JOB_DRG, lv=50 },
			},
		},
		cooldown_sec=180.0,
		gate_time=1.0,
		ui={
			{ kind='checkbox', label='Auto Super Jump', cfgkey='auto.superjump', default=false },
		},
		eligible=function(ctx)
			if not ctx.cfgget('auto.jump') then return false end
			if not ctx.cfgget('auto.superjump') then return false end
			if ctx.engaged01 ~= 1 then return false end
			if ctx.spells_locked_soft then return false end
			if not (ctx.dist and ctx.dist <= 5) then return false end
			if not ctx.hp_emerg then return false end
			return ctx.is_ready('SUPER_JUMP')
		end,
		act=function(ctx)
			return ctx.do_ja('Super Jump', '<t>', 'SUPER_JUMP')
		end,
	},

	{
		id='THIRD_EYE',
		kind='ja',
		priority=8600,
		req={
			any=true,
			main={ { job=JOB_SAM, lv=15 } },
			sub={  { job=JOB_SAM, lv=15 } },
		},
		cooldown_sec=60.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.thirdeye') then return false end
			if ctx.cfgget('auto.thirdeye_mode') ~= 'def' then return false end
			if ctx.self_thirdeye_active then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			return ctx.is_ready('THIRD_EYE')
		end,
		act=function(ctx)
			return ctx.do_ja('Third Eye', '<me>', 'THIRD_EYE')
		end,
	},

	{
		id='SEIGAN',
		kind='ja',
		priority=8597,
		req={
			any=true,
			main={ { job=JOB_SAM, lv=35 } },
			sub={  { job=JOB_SAM, lv=35 } },
		},
		cooldown_sec=45.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.seigan') then return false end
			if ctx.cfgget('auto.seigan_mode') ~= 'def' then return false end
			if ctx.self_seigan_active then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			return ctx.is_ready('SEIGAN')
		end,
		act=function(ctx)
			return ctx.do_ja('Seigan', '<me>', 'SEIGAN')
		end,
	},

	{
		-- Emergency sleep: at 0 shadows, equip the sleep bolt/arrow and /ra in
		-- the SAME round, one priority ahead of the shadows recast so it fires
		-- first. The ranged readying holds the Utsusemi cast until it lands.
		id='SLEEP_SHADOWS',
		kind='spell',
		priority=8887,
		req={
			any=true,
			main={ { job=JOB_NIN, lv=12 } },
			sub={ { job=JOB_NIN, lv=12 } },
		},
		gate_time=0.5,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.shadows') then return false end
			if not ctx.cfgget('auto.shadows_sleep') then return false end
			if ctx.cfgget('auto.shadows_mode') ~= 'def' then return false end
			if (tonumber(ctx.shadow_count or 0) or 0) > 0 then return false end
			if ctx.spells_locked_soft then return false end
			if ctx.ranged_busy or not ctx.ra_ready then return false end
			if ctx.target_dead then return false end
			-- No point sleeping if a shadow spell isn't ready to recast anyway.
			if not ctx.shadow_recast_ready() then return false end
			-- No point sleeping a mob that already has a DoT (wakes instantly).
			if ctx.target_has_waking_dot() then return false end
			local ammo = tostring(ctx.sleep_ammo_name or '')
			if ammo == '' then return false end
			if ctx.tool_missing(ammo) then return false end
			if not ctx.sleep_ammo_equipped and not ctx.sleep_ammo_available then
				ctx.mark_tool_missing(ammo)
				return false
			end
			return true
		end,
		act=function(ctx)
			return ctx.sleep_shot(tostring(ctx.sleep_ammo_name or ''))
		end,
	},

	{
		id='SHADOWS',
		kind='spell',
		priority=8888,
		req={
			any=true,
			main={
				{ job=JOB_NIN, lv=12 },
			},
			sub={
				{ job=JOB_NIN, lv=12 },
			},
		},
		gate_time=0.5,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.shadows') then return false end
			if ctx.cfgget('auto.shadows_mode') ~= 'def' then return false end
			if ctx.spells_locked_soft then return false end
			return ctx.shadows_can_attempt('def', true)
		end,
		act=function(ctx)
			return ctx.do_shadows(true, 'def')
		end,
	},

	{
		id='CALL_WYVERN',
		kind='ja',
		priority=8889,
		req={
			main={
				{ job=JOB_DRG, lv=1 },
			},
		},
		cooldown_sec=300.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.callwyvern') then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if ctx.pet_present then return false end
			return ctx.is_ready('CALL_WYVERN')
		end,
		act=function(ctx)
			return ctx.do_ja('Call Wyvern', '<me>', 'CALL_WYVERN')
		end,
	},

	{
		id='PROTECT',
		priority=8890,
		req={
			any=true,
			main={
				{ job=JOB_WHM, lv=7 },
				{ job=JOB_RDM, lv=7 },
				{ job=JOB_PLD, lv=10 },
			},
			sub={
				{ job=JOB_WHM, lv=7 },
				{ job=JOB_RDM, lv=7 },
			},
		},
		cooldown_sec=1800.0,
		gate_time=1.0,
		ui={
			{ kind='checkbox', label='Auto Pro', cfgkey='auto.protect', default=false },
			{ kind='checkbox_same', label='Auto Shell', cfgkey='auto.shell', default=false },
		},
		eligible=function(ctx)
			if not ctx.cfgget('auto.protect') then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if not ctx.protect_should_cast then return false end
			if not ctx.best_protect_spell then return false end
			if ctx.has_spell_mp and not ctx.has_spell_mp(ctx.best_protect_spell) then return false end
			return ctx.is_ready('PROTECT')
		end,
		act=function(ctx)
			return ctx.do_spell(ctx.best_protect_spell, '<me>', 'PROTECT')
		end,
	},

	{
		id='SHELL',
		priority=8891,
		req={
			any=true,
			main={
				{ job=JOB_WHM, lv=17 },
				{ job=JOB_RDM, lv=17 },
				{ job=JOB_PLD, lv=20 },
			},
			sub={
				{ job=JOB_WHM, lv=17 },
				{ job=JOB_RDM, lv=17 },
			},
		},
		cooldown_sec=1800.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.shell') then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if not ctx.shell_should_cast then return false end
			if not ctx.best_shell_spell then return false end
			if ctx.has_spell_mp and not ctx.has_spell_mp(ctx.best_shell_spell) then return false end
			return ctx.is_ready('SHELL')
		end,
		act=function(ctx)
			return ctx.do_spell(ctx.best_shell_spell, '<me>', 'SHELL')
		end,
	},

	{
		id='STONESKIN',
		kind='spell',
		weight=2,
		priority=8891.5,
		req={
			any=true,
			main={
				{ job=JOB_WHM, lv=28 },
				{ job=JOB_RDM, lv=34 },
			},
			sub={
				{ job=JOB_WHM, lv=28 },
				{ job=JOB_RDM, lv=34 },
			},
		},
		cooldown_sec=300.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.stoneskin') then return false end
			if ctx.cfgget('auto.stoneskin_mode') ~= 'def' then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if ctx.self_stoneskin_active then return false end
			if ctx.has_spell_mp and not ctx.has_spell_mp('Stoneskin') then return false end
			-- Stoneskin only survives if we have cover during the cast. Without
			-- shadows / blink / sleep the mob's next melee round eats through
			-- the shield before it can absorb anything meaningful. Require ONE
			-- of these safe-cover conditions.
			local has_shadows = (tonumber(ctx.shadow_count or 0) or 0) > 0
			local has_blink   = ctx.self_blink_active == true
			local mob_asleep  = ctx.target_has_debuff
			                    and ctx.target_has_debuff('sleep') == true
			if not (has_shadows or has_blink or mob_asleep) then return false end
			return ctx.is_ready('STONESKIN')
		end,
		act=function(ctx)
			return ctx.do_spell('Stoneskin', '<me>', 'STONESKIN')
		end,
	},

	{
		id='BLINK',
		kind='spell',
		weight=2,
		priority=8891.6,
		req={
			any=true,
			main={
				{ job=JOB_WHM, lv=19 },
				{ job=JOB_RDM, lv=23 },
			},
			sub={
				{ job=JOB_WHM, lv=19 },
				{ job=JOB_RDM, lv=23 },
			},
		},
		cooldown_sec=15.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.blink') then return false end
			if ctx.cfgget('auto.blink_mode') ~= 'def' then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if ctx.self_blink_active then return false end
			-- Defer to shadows. Utsusemi takes hit priority over Blink
			-- images, so casting Blink while shadows are up is wasted MP.
			-- If auto-shadows is enabled and a shadow cast is ready, skip
			-- Blink so we don't preempt or race the shadow cast.
			if (ctx.shadow_count or 0) > 0 then return false end
			if ctx.cfgget('auto.shadows')
			   and ctx.shadows_can_attempt
			   and ctx.shadows_can_attempt('def') then return false end
			if ctx.has_spell_mp and not ctx.has_spell_mp('Blink') then return false end
			return ctx.is_ready('BLINK')
		end,
		act=function(ctx)
			return ctx.do_spell('Blink', '<me>', 'BLINK')
		end,
	},

	{
		id='PHALANX',
		priority=8891.7,
		req={
			any=true,
			main={
				{ job=JOB_RDM, lv=33 },
			},
			sub={
				{ job=JOB_RDM, lv=33 },
			},
		},
		cooldown_sec=10.0,
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.phalanx') then return false end
			if ctx.cfgget('auto.phalanx_mode') ~= 'def' then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if ctx.self_phalanx_active then return false end
			if ctx.has_spell_mp and not ctx.has_spell_mp('Phalanx') then return false end
			return ctx.is_ready('PHALANX')
		end,
		act=function(ctx)
			return ctx.do_spell('Phalanx', '<me>', 'PHALANX')
		end,
	},

	{
		id='CURE',
		priority=5,              -- ABSOLUTE TOP of the def ladder: when HP is
		                         -- low, healing beats every buff/debuff/JA.
		                         -- Was 8892 (below Protect/Shell/Stoneskin/etc),
		                         -- which let the bot buff while dying.
		req={
			any=true,
			main={
				{ job=JOB_WHM, lv=1 },
				{ job=JOB_RDM, lv=3 },
				{ job=JOB_PLD, lv=5 },
			},
			sub={
				{ job=JOB_WHM, lv=1 },
				{ job=JOB_RDM, lv=3 },
			},
		},
		cooldown_sec=2.0,
		gate_time=1.0,
		ui={
			{ kind='checkbox', label='Auto Cure', cfgkey='auto.cure', default=false },
			{ kind='radio3',
				labelA='50%##cure', valA=50,
				labelB='75%##cure', valB=75,
				labelC='100%##cure', valC=99,
				cfgkey='cure_hp', default=50
			},
		},
		eligible=function(ctx)
			if not ctx.cfgget('auto.cure') then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if not ctx.cure_hp_ok then return false end
			if not ctx.best_cure_spell then return false end
			if ctx.has_spell_mp and not ctx.has_spell_mp(ctx.best_cure_spell) then return false end
			return ctx.is_ready('CURE')
		end,
		act=function(ctx)
			return ctx.do_spell(ctx.best_cure_spell, '<me>', 'CURE')
		end,
	},

	{
		id='HB',
		kind='hb',
		priority=8893,
		req={
			main={
				{ job=JOB_DRG, lv=1 },
			},
		},
		gate_time=1.0,
		ui=nil,
		eligible=function(ctx)
			if not ctx.cfgget('auto.hb') then return false end
			if ctx.cfgget('auto.hb_mode') ~= 'def' then return false end
			if ctx.resting01 == 1 then return false end
			if ctx.spells_locked_soft then return false end
			if not ctx.pet_present then return false end
			if not ctx.hb_hp_ok then return false end
			return ctx.hb_ready
		end,
		act=function(ctx)
			return ctx.do_hb('HB_DEF')
		end,
	},

}