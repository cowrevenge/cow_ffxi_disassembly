--[[---------------------------------------------------------------------------
fooddb.lua
Food list used by the Auto Food Buff dropdown in atk_list.lua.

Add/remove entries here as needed. Names must match the in-game item name
exactly (case and apostrophes matter) so /item commands resolve correctly.
---------------------------------------------------------------------------]]--

local M = {}

M.FOODS = {
    'Rice Dumpling',
    'Rice Dumpling +1',
    'Sole Sushi',
    'Sole Sushi +1',
    'Squid Sushi',
    'Squid Sushi +1',
}

return M