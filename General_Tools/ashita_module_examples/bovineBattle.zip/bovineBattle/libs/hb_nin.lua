-- hb_nin.lua
-- NIN subjob trigger list.
-- Ninjutsu uses no MP so minMp = 0.
--
--[[
    { name = 'Dokumori: Ichi', target = 't', minLevel = 6,  minMp = 0, recast_sec = 30, jobs = { NIN = true } },
    { name = 'Hojo: Ichi',     target = 't', minLevel = 9,  minMp = 0, recast_sec = 30, jobs = { NIN = true } },
    { name = 'Jubaku: Ichi',   target = 't', minLevel = 15, minMp = 0, recast_sec = 30, jobs = { NIN = true } },

    { name = 'Katon: Ichi',    target = 't', minLevel = 15, minMp = 0, recast_sec = 30, jobs = { NIN = true } },
    { name = 'Hyoton: Ichi',   target = 't', minLevel = 15, minMp = 0, recast_sec = 30, jobs = { NIN = true } },
    { name = 'Raiton: Ichi',   target = 't', minLevel = 15, minMp = 0, recast_sec = 30, jobs = { NIN = true } },
    { name = 'Doton: Ichi',    target = 't', minLevel = 15, minMp = 0, recast_sec = 30, jobs = { NIN = true } },
    { name = 'Suiton: Ichi',   target = 't', minLevel = 15, minMp = 0, recast_sec = 30, jobs = { NIN = true } },
--]]

    { name = 'Kurayami: Ichi', target = 't', minLevel = 12, minMp = 0, recast_sec = 31, jobs = { NIN = true } },
}