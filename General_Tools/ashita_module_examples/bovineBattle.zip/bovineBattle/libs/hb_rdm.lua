-- hb_rdm.lua
-- RDM subjob trigger list for Healing Breath.
-- Uses bar spells — instant cast, so they trigger HB without wasting MP.
-- RDM gets bar spells starting at lv 15 (sub = lv 8+).
--
-- minMp: Don't attempt if player MP% is below this threshold.
-- recast_sec: bar spells share a ~10s recast per spell.

return {
    { name = 'Barfire',     target = 'me', minLevel = 8, minMp = 8, recast_sec = 11, jobs = { RDM = true } },
    { name = 'Barblizzard', target = 'me', minLevel = 8, minMp = 8, recast_sec = 11, jobs = { RDM = true } },
    { name = 'Baraero',     target = 'me', minLevel = 8, minMp = 8, recast_sec = 11, jobs = { RDM = true } },
    { name = 'Barstone',    target = 'me', minLevel = 8, minMp = 8, recast_sec = 11, jobs = { RDM = true } },
    { name = 'Barwater',    target = 'me', minLevel = 8, minMp = 8, recast_sec = 11, jobs = { RDM = true } },
    { name = 'Barthunder',  target = 'me', minLevel = 8, minMp = 8, recast_sec = 11, jobs = { RDM = true } },
}