-- hb_whm.lua
-- WHM subjob trigger list (Healing Magic). Targets self.
-- DRG/Wyvern HB is most reliable off cures.
--
-- minMp: Don't attempt if player MP% is below this threshold.

return {
    { name = 'Barfira',    target = 'me', minLevel = 8, minMp = 12, recast_sec = 11, jobs = { WHM = true } },
    { name = 'Barblizzara',target = 'me', minLevel = 8, minMp = 12, recast_sec = 11, jobs = { WHM = true } },
    { name = 'Baraera',    target = 'me', minLevel = 8, minMp = 12, recast_sec = 11, jobs = { WHM = true } },
    { name = 'Barstonra',  target = 'me', minLevel = 8, minMp = 12, recast_sec = 11, jobs = { WHM = true } },
    { name = 'Barwatera',  target = 'me', minLevel = 8, minMp = 12, recast_sec = 11, jobs = { WHM = true } },
    { name = 'Barthundra', target = 'me', minLevel = 8, minMp = 12, recast_sec = 11, jobs = { WHM = true } },
}