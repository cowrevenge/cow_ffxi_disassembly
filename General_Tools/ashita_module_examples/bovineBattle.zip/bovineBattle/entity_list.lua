--[[---------------------------------------------------------------------------
entity_list.lua
Purpose:
  - Standalone Entity List panel for bovinebattle.
  - Walks the entity array, classifies each entity (GM / Player / Mob / NPC /
    Self), sorts GM-first then by distance, and renders a color-coded list
    inside its own collapsing header.
Ported from bovinefh's state.scan_entities -- self-contained (resolves the
player name inline rather than a module-level current_player_name).

Usage (from bovinebattle):
    local EntityList = require('entity_list')
    ...
    EntityList.render()   -- draws the "Entity List" CollapsingHeader + list
---------------------------------------------------------------------------]]--

local imgui = require('imgui')
local bit   = require('bit')

local EntityList = {}

-- Scan the entity table. Returns an array of { name, kind, dist, idx },
-- sorted GM-first then nearest-first. Empty when the entity manager can't
-- be read.
function EntityList.scan()
    local out = {}
    -- Render flag bits (Ashita): 0x200 = visible, 0x4000 = hidden.
    local RF_VISIBLE, RF_HIDDEN = 0x200, 0x4000
    local ok_em, em = pcall(function() return AshitaCore:GetMemoryManager():GetEntity() end)
    if not ok_em or em == nil then return out end

    -- Our own name, lowercased, so Self never counts as another player.
    local self_name = ''
    do
        local ok, ply = pcall(GetPlayerEntity)
        if ok and ply and ply.Name then self_name = tostring(ply.Name):lower() end
    end

    for i = 1, 2303 do
        local ok, ent = pcall(function() return GetEntity(i) end)
        if ok and ent ~= nil and ent.Name ~= nil and ent.Name ~= '' then
            -- Validity: visible and not hidden (skip unrendered array slots).
            local flags = select(2, pcall(function() return em:GetRenderFlags0(i) end)) or 0
            local visible = bit.band(flags, RF_VISIBLE) ~= 0
            local hidden  = bit.band(flags, RF_HIDDEN) ~= 0
            if visible and not hidden then
                local nm = tostring(ent.Name)
                -- GM detection: staff carry bit 0x1000 in RenderFlags2.
                -- bit.band exactly like XIUI -- a Flags2 with 0x80000000
                -- set comes back negative in Lua, so division/modulo would
                -- corrupt and false-flag people.
                local f2 = select(2, pcall(function() return em:GetRenderFlags2(i) end)) or 0
                local is_gm = bit.band(f2, 0x1000) ~= 0
                -- Type from SpawnFlags: 0x01 player, 0x02 NPC, 0x10 mob.
                local sf = ent.SpawnFlags or 0
                local kind
                if self_name ~= '' and nm:lower() == self_name then
                    kind = 'Self'
                elseif is_gm then kind = 'GM'
                elseif bit.band(sf, 0x01) ~= 0 then kind = 'Player'
                elseif bit.band(sf, 0x10) ~= 0 then kind = 'Mob'
                elseif bit.band(sf, 0x02) ~= 0 then kind = 'NPC'
                else kind = '?' end
                local dist = nil
                if ent.Distance ~= nil and ent.Distance > 0 then
                    dist = math.sqrt(ent.Distance)   -- Distance is stored squared
                end
                out[#out+1] = { name = nm, kind = kind, dist = dist, idx = i }
            end
        end
    end

    local rank = { GM = 1, Player = 2, NPC = 3, Mob = 4, Self = 5, ['?'] = 6 }
    table.sort(out, function(a, b)
        if rank[a.kind] ~= rank[b.kind] then return rank[a.kind] < rank[b.kind] end
        return (a.dist or 1e9) < (b.dist or 1e9)
    end)
    return out
end

-- Draw the Entity List collapsing header + list. Call inside an active
-- imgui window.
function EntityList.render()
    if not imgui.CollapsingHeader('Entity List') then return end

    local ents = EntityList.scan()
    local players, gms = 0, 0
    for _, en in ipairs(ents) do
        if en.kind == 'Player' then players = players + 1
        elseif en.kind == 'GM' then gms = gms + 1 end
    end
    imgui.TextColored({ 0.8, 0.9, 1, 1 }, string.format(
        '%d players, %d GMs, %d entities total', players, gms, #ents))
    imgui.Separator()
    -- Players and GMs sort to the top (rank); mobs/NPCs below.
    for _, en in ipairs(ents) do
        local col = { 0.7, 0.7, 0.7, 1 }
        if en.kind == 'GM' then col = { 1.0, 0.4, 0.4, 1 }
        elseif en.kind == 'Player' then col = { 1.0, 0.85, 0.3, 1 }
        elseif en.kind == 'NPC' then col = { 0.6, 0.9, 0.7, 1 }
        elseif en.kind == 'Mob' then col = { 0.8, 0.6, 0.9, 1 } end
        local dtxt = en.dist and string.format('%.0fy', en.dist) or '-'
        imgui.TextColored(col, string.format('[%s] %s  (%s)', en.kind, en.name, dtxt))
    end
    if #ents == 0 then
        imgui.TextDisabled('(nothing detected)')
    end
end

return EntityList