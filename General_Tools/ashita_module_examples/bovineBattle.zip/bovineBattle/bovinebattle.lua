--[[---------------------------------------------------------------------------
main.lua

Thin shell only.
Owns:
  - addon bootstrap
  - settings load/save
  - top-level state table
  - event wiring
  - GUI window
  - close button => /addon unload bovinebattle
  - header controls including Pause and Reset

Delegates:
  - runtime live refresh
  - runtime ctx
  - packet parsing
  - text parsing
  - command handling
  - dispatch / gate handling
  - ladder session ticking
  - idle / rest / engage behavior

UI ownership:
  - Top shell UI stays here
  - Ladder entry UI is rendered from atk_list.lua / def_list.lua
---------------------------------------------------------------------------]]--

addon.name    = 'bovinebattle'
addon.author  = 'ShadowCow'
addon.version = '1.4'
addon.desc    = 'Bovine Battle - melee/ability automation GUI'

package.path = package.path
    .. ';' .. addon.path .. '?.lua'
    .. ';' .. addon.path .. 'libs/?.lua'

require('common')
require('helpers')

local imgui    = require('imgui')
local bit      = require('bit')
local settings = require('settings')

local GeneralLua     = require('general')
local IdleRestEngage = require('idle_rest_engage')
local movement       = require('movement')
Hb_shadows    = require('hb_shadows_helper')
Hb_list       = require('healing_breath_list').list
DebuffHandler = require('debuffhandler')
StatusHandler = require('statushandler')

-- Force memory read so pre-existing buffs are captured immediately
if StatusHandler and type(StatusHandler.refreshFromMemory) == 'function' then
    StatusHandler.refreshFromMemory()
end

local general_list   = GeneralLua.ladder
local atk_list       = require('atk_list')
local def_list       = require('def_list')

-- FOOD_BUFF entry rendered standalone (above the Ranged section), so it's
-- skipped in the list pass to avoid drawing twice. See render swap below.
local FOOD_ENTRY = nil
for _, e in ipairs(atk_list) do
    if e and e.id == 'FOOD_BUFF' then FOOD_ENTRY = e break end
end

-- Forward declaration: render_core_controls (defined earlier in the file)
-- calls this to place Auto Food Buff right under Auto Rest MP, but the
-- function body is defined later. Assigned to the real function below.
local render_food_buff_entry
local WeaponDB       = require('weapon_db')
local WSL            = require('ws_list')
local FoodDB         = require('fooddb')
local EntityList     = require('entity_list')

-- Auto-updater (updater.lua). pcall'd on purpose: a missing or broken
-- updater.lua must never stop the addon itself from loading. When it fails
-- to load, Updater stays nil and the Updates section simply is not drawn.
local Updater = nil
do
    local ok, mod = pcall(require, 'updater')
    if ok and type(mod) == 'table' then Updater = mod end
end


-- Override map: when a list entry has kind='input_text' with one of these
-- cfgkeys, render as a dropdown using the listed options instead. Lets us
-- promote text fields to dropdowns without touching atk_list/def_list.
local CFGKEY_DROPDOWN_OPTIONS = {
    food_name = FoodDB.FOODS,
}

local function now_sec()
    return os.clock()
end

--------------------------------------------------------------------------------
-- SETTINGS
--------------------------------------------------------------------------------

local default_settings = T{
    ui = T{
        visible  = true,
        x        = 20,
        y        = 180,
        alpha    = 0.85,
        autosave = true,
    },

    debug = T{
        enabled = false,
    },

    update = T{
        auto = false,   -- check GitHub on load and apply changed files (only while PAUSED)
    },


    auto = T{
        paused  = false,
        attack  = false,
        run     = true,
        party   = false,
        bot     = false,
        rest    = false,
        rest_mp = false,
        ws      = false,
        ranged  = false,

        shadows      = false,
        shadows_mode = 'atk',

        hb       = false,
        hb_mode  = 'atk',
        hb_party = false,

        food = false,

        ws_mp_override    = false,
        ws_haste_override = false,
    },

    ws_name = 'Double Thrust',
    ws_name_per_weapon = T{},  -- skill_name (e.g. 'Polearm') -> last WS picked for that weapon type
    food_name = '',
    pet_ready_name = '',
    pet_ready_charges = 1,   -- 1, 2, or 3 - minimum charges required before firing
    pet_ready_target_hp = 0, -- 0 = Any; otherwise 25/33/50 (only fires if target HP >= this %)

    ws_hp        = 25,
    jump_hp      = 0,
    hb_hp        = 25,
    hb_party_hp  = 33,
    rest_hp      = 75,
    rest_mp      = 75,
}

local cfg = settings.load(default_settings)

settings.register('settings', 'settings_update', function(s)
    if s ~= nil then
        cfg = s
        if S then
            S.config_ref = cfg
            S.config_view = cfg
        end
    end
    settings.save()
end)

--------------------------------------------------------------------------------
-- STATE
--------------------------------------------------------------------------------

local S = {
    config_ref  = cfg,
    config_view = cfg,

    ui = {
        is_visible    = cfg.ui.visible == true,
        debug_enabled = cfg.debug.enabled == true,
        last_saved_x  = cfg.ui.x,
        last_saved_y  = cfg.ui.y,
        save_cooldown_until = 0.0,
    },

    live = {},
    combat = {},
    flags = {},
    all_claimed_targets = T{},
    last_action_ts = {},
}

--------------------------------------------------------------------------------
-- COMMAND AUTHORITY
--------------------------------------------------------------------------------

local function send_echo(text)
    AshitaCore:GetChatManager():QueueCommand(1, '/echo [MN] ' .. tostring(text))
end

local function send_cmd(s)
    s = tostring(s or '')
    if s == '' then return false end

    if not s:match('^%s*/') then
        send_echo('CHATERROR blocked non-command text: ' .. s)
        return false
    end

    if s:match('^%s*/say%s') or
       s:match('^%s*/p%s') or
       s:match('^%s*/party%s') or
       s:match('^%s*/sh%s') or
       s:match('^%s*/tell%s') then
        send_echo('CHATERROR blocked unsafe chat command: ' .. s)
        return false
    end

    if S.ui.debug_enabled then
        send_echo(s)
    end

    AshitaCore:GetChatManager():QueueCommand(1, s)
    return true
end

-- Expose send_cmd + send_echo to general.lua so its raw sends (bolt swaps,
-- /ra, /attack off, echoes) route through the same safety filter as everything
-- else -- non-command text and unsafe chat commands (/say, /p, /tell) get
-- blocked and echoed as CHATERROR instead of leaking to chat.
if GeneralLua then
    GeneralLua.send_cmd  = send_cmd
    GeneralLua.send_echo = send_echo
end

local function dbg(text)
    if S.ui.debug_enabled then
        send_echo(tostring(text))
    end
end

local function dispatch(command_text, gate_time)
    return GeneralLua.dispatch(S, command_text, gate_time, send_cmd)
end

--------------------------------------------------------------------------------
-- PLAYER CACHE HELPERS
--------------------------------------------------------------------------------

local function get_entity(index)
    local ok, entity = pcall(GetEntity, index)
    return ok and entity or nil
end

local function escape_lua_pattern(text)
    if type(text) ~= 'string' then return '' end
    return (text:gsub('([^%w])', '%%%1'))
end

local function get_player_entity_for_cache()
    local ok, ent = pcall(GetPlayerEntity)
    if ok and ent and type(ent.Name) == 'string' and #ent.Name > 0 then
        return ent
    end

    local mm = AshitaCore:GetMemoryManager()
    local party = mm and mm:GetParty() or nil
    if not party then return nil end

    local player_server_id = tonumber(party:GetMemberServerId(0) or 0) or 0
    if player_server_id == 0 then return nil end

    for i = 0, 2047 do
        local entity = get_entity(i)
        if entity then
            local sid =
                entity.ServerId or
                entity.ServerID or
                entity.Id or
                entity.ID or
                entity.EntityId or
                entity.EntityID

            if tonumber(sid or 0) == player_server_id then
                return entity
            end
        end
    end

    return nil
end

local function refresh_player_name_cache()
    local ent = get_player_entity_for_cache()
    if not ent then return end

    local name = ent.Name
    if type(name) ~= 'string' or #name == 0 then return end

    S.cached_player_name = name
    S.cached_player_pat  = escape_lua_pattern(name:lower())
end

--------------------------------------------------------------------------------
-- CONFIG HELPERS
--------------------------------------------------------------------------------

local function cfg_get(path)
    local current = cfg
    for segment in tostring(path):gmatch('[^%.]+') do
        if type(current) ~= 'table' then return nil end
        current = current[segment]
    end
    return current
end

local function cfg_set(path, value)
    local segments = {}
    for segment in tostring(path):gmatch('[^%.]+') do
        segments[#segments + 1] = segment
    end

    local current = cfg
    for i = 1, #segments - 1 do
        local key = segments[i]
        if type(current[key]) ~= 'table' then
            current[key] = T{}
        end
        current = current[key]
    end

    current[segments[#segments]] = value
end

local function cfg_ensure(path, default)
    local segments = {}
    for segment in tostring(path):gmatch('[^%.]+') do
        segments[#segments + 1] = segment
    end

    local current = cfg
    for i = 1, #segments - 1 do
        local key = segments[i]
        if type(current[key]) ~= 'table' then
            current[key] = T{}
        end
        current = current[key]
    end

    local leaf = segments[#segments]
    if current[leaf] == nil then
        current[leaf] = default
    end
end

local function ensure_core_defaults()
    cfg_ensure('ui.visible', true)
    cfg_ensure('ui.x', 20)
    cfg_ensure('ui.y', 180)
    cfg_ensure('ui.alpha', 0.85)
    cfg_ensure('ui.autosave', true)

    cfg_ensure('debug.enabled', false)

    cfg_ensure('auto.paused', false)
    cfg_ensure('auto.attack', false)

    -- Repair: a build briefly used the config path 'auto.target.range'.
    -- cfg_ensure walks dot paths and replaces any non-table node it needs
    -- to descend through, so that path silently overwrote the BOOLEAN
    -- 'auto.target' with a table -- a key cannot be both a leaf and a
    -- parent. Settings files saved by that build have auto.target as a
    -- table, which makes the Auto Target checkbox read as "on" forever
    -- and hides everything nested under it. Clear it so the cfg_ensure
    -- below restores a proper boolean. (Range now lives at the
    -- non-colliding 'auto.targetrange'.)
    if type(cfg.auto) == 'table' and type(cfg.auto.target) == 'table' then
        cfg.auto.target = nil
    end

    cfg_ensure('auto.target', false)
    cfg_ensure('auto.targetrange', 15)   -- yalms: 15 / 20 / 30 / 40 / 50
    -- Names of mobs auto-target should skip. Case-insensitive substring
    -- match: "Water Elemental" also catches "Angry Water Elemental" etc.
    -- Sibling of auto.target so cfg_ensure doesn't collide with the
    -- boolean leaf (the old auto.target.range bug documented above).
    cfg_ensure('auto.target_ignore_list', T{'Water Elemental'})
    -- Home anchor. When enabled (default), auto-target measures range from
    -- HOME instead of from the player, so chasing a mob cannot drag the
    -- camp across the zone one reasonable step at a time.
    cfg_ensure('home.disabled', false)
    -- 1=/ra 2=Dia 3=/attack. 0 still means 'no pull' to tick_auto_pull and is
    -- kept as a legal value for that reason, but the UI no longer offers it:
    -- Auto Target existing at all implies pulling what it acquires, so the
    -- method is the only real choice. Old settings carrying 0 are coerced to
    -- a default on render.
    cfg_ensure('auto.pull', 3)
    cfg_ensure('auto.run', true)
    cfg_ensure('auto.party', false)
    -- Standoff ranged mode (top-row 'Ranged'). Sibling leaf of
    -- 'auto.ranged' on purpose -- NOT a child of it. See the
    -- auto.target.range post-mortem above for why nesting under an
    -- existing boolean leaf is a trap.
    cfg_ensure('auto.rangedmode', false)
    -- Ammo the Ranged mode keeps loaded. Stored as the DISPLAY NAME, not an
    -- item id, because that is what /equip takes and it survives id drift
    -- between servers -- same reasoning as the bolt needles above it.
    cfg_ensure('ranged.ammo_pick', '')
    cfg_ensure('auto.bot', false)
    cfg_ensure('auto.rest', false)
    cfg_ensure('auto.rest_mp', false)
    cfg_ensure('auto.ws', false)
    cfg_ensure('auto.ws_mp_override', false)
    cfg_ensure('auto.ws_haste_override', false)
    -- Point the WS Name picker at the RANGED slot instead of the main hand,
    -- so a ranged WS (Slug Shot, Sidewinder, ...) can be chosen. Purely a UI
    -- scope switch: the chosen name still lands in cfg.ws_name like any other.
    cfg_ensure('ws_ranged', false)
    cfg_ensure('auto.ranged', false)
    cfg_ensure('ranged.def_down_only', false)
    cfg_ensure('ranged.hp_drain', false)
    cfg_ensure('ranged.hp_drain_hp', 50)
    cfg_ensure('ranged.blind_bolt', false)
    -- Stop-at-10: when on, skip firing Acid / Blind status bolts once the
    -- target is at 10% HP or below. Bloody Bolts and Sleep Other are NOT
    -- affected (Bloody drains -- lower HP is the whole point; Sleep Other
    -- fires at an add, whose HP is unrelated to <t>).
    cfg_ensure('ranged.status_stop_at_10', false)

    -- Auto Antidote: fires /item "Antidote" <me> when poisoned + HP < 25%
    -- + not busy (no cast, no /ra, no imminent WS). Runs from the main
    -- tick, not the atk/def ladder, so it fires during idle or engaged
    -- ticks alike -- just not during rounds we can't act.
    cfg_ensure('auto.antidote', false)

    -- Thief: Auto Sleep/Sneak. When engaged and no other bolt mode is
    -- ready to fire, throw a sleep bolt at <t> and run the SSD combo
    -- (skip fire phase, start at wait). Gates: THF main/sub Lv15, sleep
    -- ammo available, SA off CD, target has no DoT / not already asleep,
    -- target HP under threshold (0 = Any), TP under 800 (WS wins above).
    cfg_ensure('thief.auto_sleep_sneak',    false)
    cfg_ensure('thief.auto_sleep_sneak_hp', 25)     -- % target HP; 0 = Any

    -- Auto Sneak Only: walk behind mob and fire SA (rear_facing_plan
    -- heading equality). HP toggle mirrors sleep/sneak.
    cfg_ensure('thief.auto_sneak_only',    false)
    cfg_ensure('thief.auto_sneak_only_hp', 25)

    -- Auto Trick Attack: walk behind the named tank (line us -> tank ->
    -- mob), fire TA. Priority over Sneak Only.
    cfg_ensure('thief.auto_trick_attack',    false)
    cfg_ensure('thief.auto_trick_attack_hp', 25)
    cfg_ensure('thief.tank_name',            '')

    -- Hold WS: replaces Auto WS. At TP >= 1000 + HP threshold + tank set,
    -- run the TA positioning then fire the configured WS (same WS Name
    -- dropdown as auto.ws).
    cfg_ensure('thief.hold_ws',    false)
    cfg_ensure('thief.hold_ws_hp', 25)
    -- Sleep Other: with 2+ mobs on the hate list and Bloody Bolts NOT
    -- currently triggered, put a Sleep Bolt into the nearest mob that is
    -- NOT our target so we fight them one at a time.
    cfg_ensure('ranged.sleep_other', false)
    cfg_ensure('auto.shadows', false)
    cfg_ensure('auto.shadows_mode', 'atk')
    cfg_ensure('auto.shadows_sleep', false)
    cfg_ensure('auto.hb', false)
    cfg_ensure('auto.hb_mode', 'atk')
    cfg_ensure('auto.hb_party', false)
    cfg_ensure('auto.thirdeye', false)
    cfg_ensure('auto.thirdeye_mode', 'atk')
    cfg_ensure('auto.thirdeye_mode_atk', true)
    cfg_ensure('auto.thirdeye_mode_def', false)
    cfg_ensure('auto.hasso', false)
    cfg_ensure('auto.meditate', false)
    cfg_ensure('auto.seigan', false)
    cfg_ensure('auto.seigan_mode', 'atk')
    cfg_ensure('auto.seigan_mode_atk', true)
    cfg_ensure('auto.seigan_mode_def', false)
    cfg_ensure('auto.stoneskin', false)
    cfg_ensure('auto.stoneskin_mode', 'def')
    cfg_ensure('auto.stoneskin_mode_atk', false)
    cfg_ensure('auto.stoneskin_mode_def', true)
    cfg_ensure('auto.blink', false)
    cfg_ensure('auto.blink_mode', 'def')
    cfg_ensure('auto.blink_mode_atk', false)
    cfg_ensure('auto.blink_mode_def', true)
    cfg_ensure('auto.phalanx', false)
    cfg_ensure('auto.phalanx_mode', 'def')
    cfg_ensure('auto.phalanx_mode_atk', false)
    cfg_ensure('auto.phalanx_mode_def', true)

    cfg_ensure('ws_name', 'Double Thrust')
    if type(cfg.ws_name_per_weapon) ~= 'table' then cfg.ws_name_per_weapon = T{} end

    cfg_ensure('ws_hp', 25)
    cfg_ensure('jump_hp', 0)
    cfg_ensure('hb_hp', 25)
    cfg_ensure('hb_party_hp', 33)
    cfg_ensure('rest_hp', 75)
    cfg_ensure('rest_mp', 75)
end

local function init_cfg_from_list_ui(list, label)
    if type(list) ~= 'table' then
        print(chat.header('bovinebattle'):append(chat.error(string.format(
            "init_cfg_from_list_ui: '%s' is %s (expected table). Skipping.",
            tostring(label or '?'), type(list)))))
        return
    end
    for i = 1, #list do
        local entry = list[i]
        if entry and entry.ui then
            for j = 1, #entry.ui do
                local u = entry.ui[j]
                if u and u.cfgkey ~= nil then
                    cfg_ensure(u.cfgkey, u.default)
                end
            end
        end
    end
end

ensure_core_defaults()
init_cfg_from_list_ui(atk_list,     'atk_list')
init_cfg_from_list_ui(def_list,     'def_list')
init_cfg_from_list_ui(general_list, 'general_list')
settings.save()

S.config_ref = cfg
S.config_view = cfg

--------------------------------------------------------------------------------
-- RESET
--------------------------------------------------------------------------------

local function reset_runtime_state()
    if movement and type(movement.force_release) == 'function' then
        movement.force_release()
    end

    S.config_ref  = cfg
    S.config_view = cfg

    S.ui = {
        is_visible    = cfg.ui.visible == true,
        debug_enabled = cfg.debug.enabled == true,
        last_saved_x  = cfg.ui.x,
        last_saved_y  = cfg.ui.y,
        save_cooldown_until = 0.0,
    }

    S.live = {}
    S.combat = {}
    S.flags = {}
    S.debug = {}
    S.all_claimed_targets = T{}
    S.last_action_ts = {}

    S.idle_rest_engage = nil
    S.zoning = nil

    S.cached_player_name = nil
    S.cached_player_pat = nil

    S.cooldown_id_map = nil
    S.cooldown_action_name_map = nil
    S.cooldown_maps_built = nil

    S.atk_runtime_list = nil
    S._lists_sorted = nil

    if GeneralLua and GeneralLua.cooldowns and type(GeneralLua.cooldowns) == 'table' then
        GeneralLua.cooldowns.abilities = {}
    end

    refresh_player_name_cache()
    GeneralLua.runtime.refresh_live_state(S)
end

local function reset_tool_flags()
    S.flags = S.flags or {}
    S.flags.player_utsu_tools_out = false
    S.flags.player_ranged_no_weapon = false
    S.flags.player_cannot_see_target = false
    S.flags.missing_tools = {}
    S.flags.missing_tools_echoed = {}
end

--------------------------------------------------------------------------------
-- UI RENDER HELPERS
--------------------------------------------------------------------------------

local function get_window_pos_xy()
    local ok, a, b = pcall(function() return imgui.GetWindowPos() end)
    if not ok then return nil, nil end

    if type(a) == 'number' and type(b) == 'number' then
        return a, b
    end

    if type(a) == 'table' then
        if a.x ~= nil and a.y ~= nil then
            return a.x, a.y
        end
        if a[1] ~= nil and a[2] ~= nil then
            return a[1], a[2]
        end
    end

    return nil, nil
end

local function maybe_autosave_window_pos()
    if cfg.ui.autosave ~= true then return end

    local tnow = now_sec()
    if tnow < (S.ui.save_cooldown_until or 0.0) then return end

    local x, y = get_window_pos_xy()
    if x == nil or y == nil then return end

    x = math.floor(x + 0.5)
    y = math.floor(y + 0.5)

    if x ~= (S.ui.last_saved_x or cfg.ui.x) or y ~= (S.ui.last_saved_y or cfg.ui.y) then
        cfg.ui.x = x
        cfg.ui.y = y
        S.ui.last_saved_x = x
        S.ui.last_saved_y = y
        S.ui.save_cooldown_until = tnow + 0.5
        settings.save()
    end
end

-- A button in its ACTIVE ("running", tap-to-stop) state, tinted green to
-- match the go/on accent used for checkmarks. Returns true when clicked.
-- Category = color: green always means "on / active" across the UI.
local function ui_button_active(label)
    imgui.PushStyleColor(ImGuiCol_Button,        {0.22, 0.50, 0.28, 1.0})
    imgui.PushStyleColor(ImGuiCol_ButtonHovered, {0.28, 0.60, 0.34, 1.0})
    imgui.PushStyleColor(ImGuiCol_ButtonActive,  {0.34, 0.70, 0.40, 1.0})
    local clicked = imgui.Button(label)
    imgui.PopStyleColor(3)
    return clicked
end

local function ui_checkbox(label, path, on_set)
    local v = { cfg_get(path) and true or false }
    if imgui.Checkbox(label, v) then
        cfg_set(path, v[1])
        if type(on_set) == 'function' then
            on_set(v[1], cfg_set)
        end
        settings.save()
    end
end

local function ui_checkbox_same(label, path, on_set)
    imgui.SameLine()
    ui_checkbox(label, path, on_set)
end

-- Little (?) hung off the widget that came before it. Hover for the
-- explanation. SameLine is done here so the caller reads as
-- "widget, then its help" -- but note it leaves the cursor ON that line, so
-- a following widget still needs its own SameLine.
local function ui_help(text)
    imgui.SameLine()
    imgui.TextDisabled('(?)')
    if imgui.IsItemHovered() then
        imgui.SetTooltip(tostring(text or ''))
    end
end

local function ui_radio2(path, label_a, val_a, label_b, val_b)
    local cur = tonumber(cfg_get(path) or 0) or 0

    if imgui.RadioButton(label_a, cur == val_a) then
        cfg_set(path, val_a)
        settings.save()
    end
    imgui.SameLine()
    if imgui.RadioButton(label_b, cur == val_b) then
        cfg_set(path, val_b)
        settings.save()
    end
end

local function ui_radio3(path, label_a, val_a, label_b, val_b, label_c, val_c)
    local cur = tonumber(cfg_get(path) or 0) or 0

    if imgui.RadioButton(label_a, cur == val_a) then
        cfg_set(path, val_a)
        settings.save()
    end
    imgui.SameLine()
    if imgui.RadioButton(label_b, cur == val_b) then
        cfg_set(path, val_b)
        settings.save()
    end
    imgui.SameLine()
    if imgui.RadioButton(label_c, cur == val_c) then
        cfg_set(path, val_c)
        settings.save()
    end
end

local function ui_radio4(path, label_a, val_a, label_b, val_b, label_c, val_c, label_d, val_d)
    local cur = tonumber(cfg_get(path) or 0) or 0

    if imgui.RadioButton(label_a, cur == val_a) then
        cfg_set(path, val_a); settings.save()
    end
    imgui.SameLine()
    if imgui.RadioButton(label_b, cur == val_b) then
        cfg_set(path, val_b); settings.save()
    end
    imgui.SameLine()
    if imgui.RadioButton(label_c, cur == val_c) then
        cfg_set(path, val_c); settings.save()
    end
    imgui.SameLine()
    if imgui.RadioButton(label_d, cur == val_d) then
        cfg_set(path, val_d); settings.save()
    end
end

-- Returns the equipped main weapon's item ID, or nil if none.
-- Ashita v4: GetEquippedItem returns an IEquipped struct whose Index packs both
-- the bag and slot. The mapping below mirrors the canonical Ashita pattern (used
-- by EquipViewer etc). Wrapped in pcall because the API surface differs slightly
-- across Ashita builds.
local function get_main_weapon_id()
    local ok, id = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        if not inv then return nil end
        local eq = inv:GetEquippedItem(0)  -- slot 0 = main hand
        if not eq then return nil end
        local idx = tonumber(eq.Index or eq.ItemIndex or 0) or 0
        if idx == 0 then return nil end
        local bag, slot_in_bag
        if     idx < 2048 then bag, slot_in_bag =  0, idx           -- inventory
        elseif idx < 2560 then bag, slot_in_bag =  8, idx - 2048    -- wardrobe 1
        elseif idx < 2816 then bag, slot_in_bag = 10, idx - 2560    -- wardrobe 2
        elseif idx < 3072 then bag, slot_in_bag = 11, idx - 2816    -- wardrobe 3
        elseif idx < 3328 then bag, slot_in_bag = 12, idx - 3072    -- wardrobe 4
        elseif idx < 3584 then bag, slot_in_bag = 13, idx - 3328    -- wardrobe 5
        elseif idx < 3840 then bag, slot_in_bag = 14, idx - 3584    -- wardrobe 6
        elseif idx < 4096 then bag, slot_in_bag = 15, idx - 3840    -- wardrobe 7
        elseif idx < 4352 then bag, slot_in_bag = 16, idx - 4096    -- wardrobe 8
        else return nil end
        local item = inv:GetContainerItem(bag, slot_in_bag)
        if not item then return nil end
        local item_id = tonumber(item.Id or 0) or 0
        return (item_id > 0) and item_id or nil
    end)
    return ok and id or nil
end

-- Returns { id, name, count } for the equipped ammo, or nil if the ammo slot
-- is empty. Mirrors get_main_weapon_id's index-decode pattern (slot 3 = ammo).
-- Live-read each frame so the stack count updates per shot.
local function get_equipped_ammo()
    local ok, info = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        if not inv then return nil end
        local eq = inv:GetEquippedItem(3)  -- slot 3 = ammo
        if not eq then return nil end
        local idx = tonumber(eq.Index or eq.ItemIndex or 0) or 0
        if idx == 0 then return nil end
        local bag, slot_in_bag
        if     idx < 2048 then bag, slot_in_bag =  0, idx
        elseif idx < 2560 then bag, slot_in_bag =  8, idx - 2048
        elseif idx < 2816 then bag, slot_in_bag = 10, idx - 2560
        elseif idx < 3072 then bag, slot_in_bag = 11, idx - 2816
        elseif idx < 3328 then bag, slot_in_bag = 12, idx - 3072
        elseif idx < 3584 then bag, slot_in_bag = 13, idx - 3328
        elseif idx < 3840 then bag, slot_in_bag = 14, idx - 3584
        elseif idx < 4096 then bag, slot_in_bag = 15, idx - 3840
        elseif idx < 4352 then bag, slot_in_bag = 16, idx - 4096
        else return nil end
        local item = inv:GetContainerItem(bag, slot_in_bag)
        if not item then return nil end
        local item_id = tonumber(item.Id or 0) or 0
        if item_id <= 0 then return nil end
        local name = '?'
        local rm = AshitaCore:GetResourceManager()
        if rm then
            local res = rm:GetItemById(item_id)
            if res and res.Name and res.Name[1] then
                name = tostring(res.Name[1])
                    :gsub('[%z\1-\31\127-\255]', '')
                    :gsub('^%s+', '')
                    :gsub('%s+$', '')
                if name == '' then name = '?' end
            end
        end
        return { id = item_id, name = name, count = tonumber(item.Count or 0) or 0 }
    end)
    return ok and info or nil
end

-- Reads the equipped ranged weapon (slot 2) id, or nil. Mirrors
-- get_main_weapon_id's index-decode.
local function get_ranged_weapon_id()
    local ok, id = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        if not inv then return nil end
        local eq = inv:GetEquippedItem(2)  -- slot 2 = range
        if not eq then return nil end
        local idx = tonumber(eq.Index or eq.ItemIndex or 0) or 0
        if idx == 0 then return nil end
        local bag, slot_in_bag
        if     idx < 2048 then bag, slot_in_bag =  0, idx
        elseif idx < 2560 then bag, slot_in_bag =  8, idx - 2048
        elseif idx < 2816 then bag, slot_in_bag = 10, idx - 2560
        elseif idx < 3072 then bag, slot_in_bag = 11, idx - 2816
        elseif idx < 3328 then bag, slot_in_bag = 12, idx - 3072
        elseif idx < 3584 then bag, slot_in_bag = 13, idx - 3328
        elseif idx < 3840 then bag, slot_in_bag = 14, idx - 3584
        elseif idx < 4096 then bag, slot_in_bag = 15, idx - 3840
        elseif idx < 4352 then bag, slot_in_bag = 16, idx - 4096
        else return nil end
        local item = inv:GetContainerItem(bag, slot_in_bag)
        if not item then return nil end
        local item_id = tonumber(item.Id or 0) or 0
        return (item_id > 0) and item_id or nil
    end)
    return ok and id or nil
end

-- Picks the sleep ammo matching the equipped ranged weapon: crossbow ->
-- 'Sleep Bolt', bow -> 'Sleep Arrow'. Returns '' if there's no bow/crossbow
-- equipped (or it can't be classified). Name-based off the weapon's resource
-- name, with a WeaponDB skill fallback.
local function sleep_ammo_for_ranged()
    local rid = get_ranged_weapon_id()
    if not rid then return '' end

    local name = ''
    local rm = AshitaCore:GetResourceManager()
    if rm then
        local res = rm:GetItemById(rid)
        if res and res.Name and res.Name[1] then
            name = tostring(res.Name[1]):gsub('[%z\1-\31\127-\255]', ''):lower()
        end
    end
    if name:find('crossbow', 1, true) then return 'Sleep Bolt' end
    if name:find('bow', 1, true) then return 'Sleep Arrow' end

    local skill = (WeaponDB.skill_of and WeaponDB.skill_of(rid)) or ''
    skill = tostring(skill):lower()
    if skill:find('marks', 1, true) then return 'Sleep Bolt' end
    if skill:find('arch', 1, true) then return 'Sleep Arrow' end
    return ''
end

-- Bolt support for the ranged modes (Def Down Only -> Acid Bolts, HP Drain
-- -> Bloody Bolts). Each frame the ranged ladder needs, per bolt type: is it
-- currently equipped, and (if not) is any in inventory to equip. Matched by
-- name substring rather than a hardcoded item id so it survives server-side
-- id differences.
local function ammo_name_contains(name, needle)
    return type(name) == 'string'
        and name:lower():find(needle, 1, true) ~= nil
end

local function equipped_ammo_is(needle)
    local ammo = get_equipped_ammo()
    -- FFXI briefly keeps the empty stack sitting in the ammo slot at
    -- count=0 before removing it entirely. Ignoring the count treated
    -- that transient state as "still equipped" and skipped the re-equip
    -- on the next round, so /ra fired with empty ammo and got refused.
    -- A 0-count stack is no ammo.
    return ammo ~= nil
        and (tonumber(ammo.count or 0) or 0) > 0
        and ammo_name_contains(ammo.name, needle)
end

-- Bags /equip can pull ammo from: Inventory (0) + wardrobes (8, 10-16).
local BOLT_BAGS = { 0, 8, 10, 11, 12, 13, 14, 15, 16 }

-- Throttled per needle so each bag walk runs at most once a second (only
-- consulted while the relevant mode is active and the bolt isn't equipped).
local _bolt_avail_cache = {}
local function bolt_in_inventory(needle)
    local now = now_sec()
    local c = _bolt_avail_cache[needle]
    if c and (now - c.ts) < 1.0 then
        return c.val
    end

    local ok, found = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        if not inv then return false end
        local rm = AshitaCore:GetResourceManager()
        if not rm then return false end

        for _, bag in ipairs(BOLT_BAGS) do
            for slot = 0, 80 do
                local item = inv:GetContainerItem(bag, slot)
                if item then
                    local item_id = tonumber(item.Id or 0) or 0
                    local count = tonumber(item.Count or 0) or 0
                    if item_id > 0 and count > 0 then
                        local res = rm:GetItemById(item_id)
                        if res and res.Name and res.Name[1] then
                            local nm = tostring(res.Name[1])
                                :gsub('[%z\1-\31\127-\255]', '')
                            if ammo_name_contains(nm, needle) then
                                return true
                            end
                        end
                    end
                end
            end
        end
        return false
    end)

    local val = ok and found or false
    _bolt_avail_cache[needle] = { ts = now, val = val }
    return val
end

-- Same bag walk as bolt_in_inventory but sums Count across every matching
-- stack. Equipped stacks live in bags (the ammo slot is a reference to a
-- bag+slot), so this returns the true total: what's loaded plus what's
-- sitting in inventory/wardrobes. 1s cache per needle keeps cost trivial.
local _bolt_count_cache = {}
local function bolt_count_in_inventory(needle)
    local now = now_sec()
    local c = _bolt_count_cache[needle]
    if c and (now - c.ts) < 1.0 then
        return c.val
    end

    local ok, total = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        if not inv then return 0 end
        local rm = AshitaCore:GetResourceManager()
        if not rm then return 0 end

        local sum = 0
        for _, bag in ipairs(BOLT_BAGS) do
            for slot = 0, 80 do
                local item = inv:GetContainerItem(bag, slot)
                if item then
                    local item_id = tonumber(item.Id or 0) or 0
                    local count = tonumber(item.Count or 0) or 0
                    if item_id > 0 and count > 0 then
                        local res = rm:GetItemById(item_id)
                        if res and res.Name and res.Name[1] then
                            local nm = tostring(res.Name[1])
                                :gsub('[%z\1-\31\127-\255]', '')
                            if ammo_name_contains(nm, needle) then
                                sum = sum + count
                            end
                        end
                    end
                end
            end
        end
        return sum
    end)

    local val = ok and total or 0
    _bolt_count_cache[needle] = { ts = now, val = val }
    return val
end

-- Every stack of LAUNCHER-COMPATIBLE ammo across the /equip-able bags,
-- collapsed to one row per item id with the counts summed.
--
-- Compatibility is decided by weapon_db, not by name. Bolts and arrows carry
-- their launcher's skill in LSB (Sleep Bolt is Marksmanship, same as Power
-- Crossbow), so comparing ammo skill against the equipped launcher's skill is
-- exactly the test the server is applying when it says "You do not have an
-- appropriate ranged weapon equipped" -- which is what that message really
-- means: the launcher and the ammo disagree.
--
-- ammo_is_usable drops the dmg == 0 stat sticks (Hedgehog Bomb and friends),
-- which are in the ammo slot but are not something to shoot.
--
-- Returns a list sorted by name: { { id=, name=, count= }, ... }
local _ammo_list_cache = { ts = 0.0, skill = nil, val = {} }
local function compatible_ammo_in_bags()
    local skill = S.live and S.live.ranged_weapon_skill or nil
    if skill == nil then return {} end

    local now = now_sec()
    if _ammo_list_cache.skill == skill and (now - _ammo_list_cache.ts) < 1.0 then
        return _ammo_list_cache.val
    end

    local ok, list = pcall(function()
        local inv = AshitaCore:GetMemoryManager():GetInventory()
        if not inv then return {} end
        local rm = AshitaCore:GetResourceManager()
        if not rm then return {} end

        local by_id = {}
        for _, bag in ipairs(BOLT_BAGS) do
            for slot = 0, 80 do
                local item = inv:GetContainerItem(bag, slot)
                if item then
                    local item_id = tonumber(item.Id or 0) or 0
                    local count   = tonumber(item.Count or 0) or 0
                    if item_id > 0 and count > 0
                        and WeaponDB.ammo_is_usable(item_id)
                        and WeaponDB.ammo_skill_of(item_id) == skill
                    then
                        local row = by_id[item_id]
                        if row then
                            row.count = row.count + count
                        else
                            local nm = nil
                            local res = rm:GetItemById(item_id)
                            if res and res.Name and res.Name[1] then
                                nm = tostring(res.Name[1])
                                    :gsub('[%z\1-\31\127-\255]', '')
                                    :gsub('^%s+', ''):gsub('%s+$', '')
                            end
                            if nm == nil or nm == '' then nm = '?' end
                            by_id[item_id] = { id = item_id, name = nm, count = count }
                        end
                    end
                end
            end
        end

        local out = {}
        for _, row in pairs(by_id) do out[#out + 1] = row end
        table.sort(out, function(a, b) return a.name < b.name end)
        return out
    end)

    local val = (ok and list) or {}
    _ammo_list_cache = { ts = now, skill = skill, val = val }
    return val
end

-- Does anything currently want ammo kept loaded? Either ranged mode counts.
-- Auto Ranged (the atk-round ladder) burns ammo exactly as fast as the
-- standoff loop does, and used to run the slot dry and stop with a full
-- inventory sitting one bag away.
local function ammo_keeper_wanted()
    return (cfg_get('auto.rangedmode') == true)
        or (cfg_get('auto.ranged') == true)
end

-- Keeps the picked ammo loaded. Throttled hard: /equip is a real command and
-- spamming it while the swap is in flight just queues duplicates.
local _ammo_equip_last_try = 0.0
local function keep_picked_ammo_equipped()
    if not ammo_keeper_wanted() then return end

    local want = tostring(cfg_get('ranged.ammo_pick') or '')
    if want == '' then return end

    -- Already loaded (and not an empty stack -- see equipped_ammo_is).
    --
    -- The count > 0 half is what makes NEXT STACK work. FFXI leaves the spent
    -- stack sitting in the slot at count 0 for a moment before removing it,
    -- and by NAME it still looks like the ammo we asked for. Treat that as
    -- still-equipped and we stop shooting with 90 more arrows in the bag; treat
    -- it as empty and the /equip below pulls the next stack in.
    local ammo = get_equipped_ammo()
    if ammo ~= nil
        and (tonumber(ammo.count or 0) or 0) > 0
        and tostring(ammo.name or '') == want
    then
        return
    end

    local now = now_sec()
    if (now - _ammo_equip_last_try) < 3.0 then return end

    -- Only reach for it if it is actually there. Firing /equip at nothing
    -- gets us a client error line every 3s.
    local have = false
    local list = compatible_ammo_in_bags()
    for i = 1, #list do
        if list[i].name == want then have = true break end
    end
    if not have then return end

    _ammo_equip_last_try = now
    send_cmd('/equip ammo "' .. want .. '"')
end

-- Ammo picker. Rendered in two places (the Auto Battle row and the Ranged
-- Attacks section) so it lives here rather than being written twice.
--
-- id MUST be unique per call site. ImGui identifies widgets by label, so two
-- combos sharing '##ranged_ammo_pick' would be treated as ONE widget -- open
-- either and both open, and the second one drawn wins any click.
--
-- Both call sites drive the same cfg key on purpose: there is one ammo slot,
-- so there is one pick.
--
-- indent is the leading spacer text, so each caller can line the row up with
-- whatever it sits under.
-- Width of the ammo combo, in pixels. SetNextItemWidth is already used this
-- way for the ignore-list input and the tank picker, so it is a known-good
-- call on this imgui build.
local AMMO_COMBO_WIDTH = 140

-- Same idea for the WS picker. Wider than the ammo one because WS names run
-- long ("Camlann's Torment", "Tachi: Suikawari").
local WS_COMBO_WIDTH = 180

local function ui_ammo_picker(id, indent, show_help)
    local pick = tostring(cfg_get('ranged.ammo_pick') or '')
    local list = compatible_ammo_in_bags()

    -- Count shown BESIDE the combo, not inside its label. The combo is for
    -- choosing; the count is status, and status belongs in the same green
    -- x## the rest of this panel already uses for ammo.
    --
    -- It is the BAG TOTAL, the same number the dropdown rows show, so the two
    -- agree. It used to be the equipped stack, which is why the combo said
    -- 396 while the green said x99: a stack caps at 99 and the other 297 were
    -- sitting in the bag. Total is also the number worth knowing -- 99 is
    -- just 'a full stack', it never tells you when to go buy more.
    local total = 0
    for i = 1, #list do
        if list[i].name == pick then total = list[i].count break end
    end

    local label = (pick ~= '') and pick or '(none)'

    imgui.Text(tostring(indent or '') .. 'Ammo:')
    imgui.SameLine()
    -- Without this the combo takes imgui's default item width, which is a
    -- fraction of the WINDOW, not of its contents -- so it stretched to twice
    -- what an item name needs and dragged the panel wide with it. 140 fits
    -- the longest ammo names with room for the arrow.
    imgui.SetNextItemWidth(AMMO_COMBO_WIDTH)
    if imgui.BeginCombo('##' .. tostring(id), label) then
        if S.live == nil or S.live.ranged_weapon_skill == nil then
            imgui.Text('(equip a bow/xbow/gun first)')
        elseif #list == 0 then
            imgui.Text('(no matching ammo in bags)')
        else
            for i = 1, #list do
                local row = list[i]
                local sel = (row.name == pick)
                if imgui.Selectable(string.format('%s (%d)', row.name, row.count), sel) then
                    cfg_set('ranged.ammo_pick', row.name)
                    settings.save()
                end
                if sel then imgui.SetItemDefaultFocus() end
            end
        end
        imgui.EndCombo()
    end

    -- Green when we have any, red x0 when we are out -- same convention
    -- bolt_count_text uses, so the whole panel reads the same way.
    imgui.SameLine()
    if total > 0 then
        imgui.TextColored({ 0.7, 0.85, 0.7, 1.0 }, string.format('x%d', total))
    else
        imgui.TextColored({ 1.0, 0.5, 0.5, 1.0 }, 'x0')
    end

    -- Help is opt-in per call site. In Ranged Attacks the control sits under
    -- a header that already says what it is, so the marker is just clutter.
    if show_help then
        ui_help('Ammo to keep loaded.\n' ..
            'Only ammo matching the equipped launcher is listed.\n' ..
            'Re-equipped automatically when the stack runs out.')
    end

    -- Loud about the one state that silently burns rounds.
    if S.live and S.live.ranged_ammo_compatible == false then
        imgui.Text(tostring(indent or ''))
        imgui.SameLine()
        imgui.TextColored({ 1.0, 0.4, 0.4, 1.0 },
            'Loaded ammo does not match the launcher')
    end
end

-- File-level: tracks the weapon-skill string we last saw equipped, so we can
-- detect transitions in update_ws_for_weapon_swap() and react exactly once.
local LAST_SEEN_WEAPON_SKILL = nil

-- Called every frame from bovinebattle_present. When the equipped main weapon
-- changes to a different *type* (Polearm -> Axe etc), restore the WS that was
-- last picked for that type. Stays a no-op when the type is unchanged or when
-- nothing is equipped.
local function update_ws_for_weapon_swap()
    local mw_id = get_main_weapon_id()
    local skill = mw_id and WeaponDB.skill_of(mw_id) or nil
    S.live = S.live or {}
    S.live.main_weapon_skill = skill  -- exposed for do_ws overrides + anyone else

    -- Track the main hand regardless, so unticking Ranged later still sees the
    -- right 'last seen' and does not fire a spurious restore.
    if cfg_get('ws_ranged') == true then
        LAST_SEEN_WEAPON_SKILL = skill
        return
    end

    if skill == LAST_SEEN_WEAPON_SKILL then return end

    LAST_SEEN_WEAPON_SKILL = skill
    if not skill then return end           -- weapon removed/unknown; keep last cfg.ws_name

    cfg.ws_name_per_weapon = cfg.ws_name_per_weapon or T{}
    local remembered = cfg.ws_name_per_weapon[skill]
    if remembered and remembered ~= cfg.ws_name then
        cfg.ws_name = remembered
        settings.save()
    end
end

-- Player's current skill level for a weapon type, e.g. 'Archery' -> 14.
-- Returns nil when it cannot be read, which callers must treat as "unknown",
-- NOT as zero.
--
-- API SHAPE IS PROBED, NOT ASSUMED. Ashita exposes combat skills off the
-- player object, but the exact Lua binding for the returned value differs
-- between builds -- it may come back as a plain number, or as an object with
-- a Skill field, or with a GetSkill() accessor. Rather than hardcode one and
-- have the dropdown silently empty itself on a build that disagrees, try each
-- shape and give up quietly.
--
-- The raw value packs a 'capped' flag into bit 15, so the level is the low 15
-- bits. 32768 is subtracted rather than masked to keep this free of the bit
-- library at this point in the file.
local _combat_skill_cache = { ts = 0.0, val = {} }
local function player_combat_skill(skill_name)
    local id = WeaponDB.skill_id_of(skill_name)
    if id == nil then return nil end

    local now = now_sec()
    if (now - (_combat_skill_cache.ts or 0.0)) >= 1.0 then
        _combat_skill_cache = { ts = now, val = {} }
    end
    local cached = _combat_skill_cache.val[id]
    if cached ~= nil then
        if cached == false then return nil end
        return cached
    end

    local ok, lvl = pcall(function()
        local mm = AshitaCore and AshitaCore:GetMemoryManager()
        local pl = mm and mm:GetPlayer()
        if pl == nil or type(pl.GetCombatSkill) ~= 'function' then return nil end

        local cs = pl:GetCombatSkill(id)
        if cs == nil then return nil end

        local raw = nil
        if type(cs) == 'number' then
            raw = cs
        elseif type(cs) == 'table' or type(cs) == 'userdata' then
            if type(cs.Skill) == 'number' then
                raw = cs.Skill
            elseif type(cs.GetSkill) == 'function' then
                raw = cs:GetSkill()
            end
        end
        if type(raw) ~= 'number' then return nil end

        if raw >= 32768 then raw = raw - 32768 end   -- strip the capped bit
        return raw
    end)

    local val = (ok and type(lvl) == 'number') and lvl or nil
    _combat_skill_cache.val[id] = (val == nil) and false or val
    return val
end

-- Player's main and sub job as abbreviations ('THF', 'NIN'), or nil each when
-- unreadable / not set. Same probe-don't-assume approach as
-- player_combat_skill: the accessor may be a method or a plain field
-- depending on the Ashita build, and guessing wrong here would filter the WS
-- list down to nothing rather than fail visibly.
local _jobs_cache = { ts = 0.0, main = nil, sub = nil }
local function player_jobs()
    local now = now_sec()
    if (now - (_jobs_cache.ts or 0.0)) < 1.0 then
        return _jobs_cache.main, _jobs_cache.sub
    end

    local ok, mj, sj = pcall(function()
        local mm = AshitaCore and AshitaCore:GetMemoryManager()
        local pl = mm and mm:GetPlayer()
        if pl == nil then return nil, nil end

        local function read(method_name, field_name)
            if type(pl[method_name]) == 'function' then
                local v = pl[method_name](pl)
                if type(v) == 'number' then return v end
            end
            if type(pl[field_name]) == 'number' then return pl[field_name] end
            return nil
        end

        return read('GetMainJob', 'MainJob'), read('GetSubJob', 'SubJob')
    end)

    local main_name = ok and WSL.job_name_of(mj) or nil
    local sub_name  = ok and WSL.job_name_of(sj) or nil

    _jobs_cache = { ts = now, main = main_name, sub = sub_name }
    return main_name, sub_name
end

-- Main job level, or nil when unreadable. Probed the same way as the job and
-- skill reads: method first, plain field second, pcall around the lot.
local _mlevel_cache = { ts = 0.0, val = nil }
local function player_main_level()
    local now = now_sec()
    if (now - (_mlevel_cache.ts or 0.0)) < 1.0 then
        return _mlevel_cache.val
    end

    local ok, lv = pcall(function()
        local mm = AshitaCore and AshitaCore:GetMemoryManager()
        local pl = mm and mm:GetPlayer()
        if pl == nil then return nil end
        if type(pl.GetMainJobLevel) == 'function' then
            local v = pl:GetMainJobLevel()
            if type(v) == 'number' and v > 0 then return v end
        end
        if type(pl.MainJobLevel) == 'number' and pl.MainJobLevel > 0 then
            return pl.MainJobLevel
        end
        return nil
    end)

    _mlevel_cache = { ts = now, val = (ok and type(lv) == 'number') and lv or nil }
    return _mlevel_cache.val
end

-- Which weapon's WS list the picker is showing. Main hand normally; the
-- ranged slot when the Ranged box next to the label is ticked. Takes the
-- flag as an argument so the checkbox callback can ask about the state it is
-- about to move INTO, before cfg has settled.
local function ws_picker_skill(use_ranged)
    if use_ranged then
        return S.live and S.live.ranged_weapon_skill or nil
    end
    local mw_id = get_main_weapon_id()
    return mw_id and WeaponDB.skill_of(mw_id) or nil
end

local function ui_ws_name()
    local mjob, sjob = player_jobs()

    -- Does this job have any business with ranged weaponskills? Every Archery
    -- WS in the data is RNG-only, and Marksmanship is RNG or COR, so on any
    -- other job the Ranged scope control is a switch to an empty list. Hide it
    -- rather than offer a dead end.
    --
    -- Asked of the DATA rather than hardcoded to RNG on purpose: that picks up
    -- COR for Marksmanship without a second rule, and if HorizonXI ever hands
    -- a ranged WS to another job the control appears on its own.
    --
    -- An unreadable job (mjob nil) counts as allowed. Hiding a control because
    -- a read failed is the worst of both worlds -- the feature looks deleted
    -- and there is nothing on screen to explain why.
    local ranged_ws_possible = (mjob == nil) or WSL.job_has_ranged_ws(mjob, sjob)

    -- Stranded setting: the box was ticked on a job that could use it and we
    -- have since changed jobs. Drop it, otherwise the picker sits pointed at a
    -- scope whose control is no longer on screen to un-tick.
    if not ranged_ws_possible and cfg_get('ws_ranged') == true then
        cfg_set('ws_ranged', false)
        settings.save()
    end

    -- Scope the dropdown to whatever slot we're pointed at right now.
    -- Re-detected every frame so swapping weapons updates the list live.
    local use_ranged = ranged_ws_possible and (cfg_get('ws_ranged') == true)
    local skill  = ws_picker_skill(use_ranged)

    -- Filter to what the character can actually use: skill level AND job.
    -- Both inputs treat nil as "unknown" and stop filtering on that axis, so a
    -- failed read shows too much rather than an empty dropdown -- see the
    -- comments on usable_for in ws_list.
    local have = skill and player_combat_skill(skill) or nil
    local ws_for = skill and WSL.usable_for(skill, have, mjob, sjob) or {}

    local current = tostring(cfg.ws_name or '')
    -- Skill number and job in the label double as the reads' status lights: a
    -- bare '(Archery)' means neither could be read and nothing is filtered.
    local scope = skill or (use_ranged and 'no ranged weapon' or 'no main weapon')
    if skill then
        if have then scope = string.format('%s %d', skill, have) end
        if mjob then
            scope = scope .. ' ' .. mjob .. (sjob and ('/' .. sjob) or '')
        end
    end
    local label = string.format('WS Name (%s)', scope)

    imgui.Text(label)
    if ranged_ws_possible then
        imgui.SameLine()
        -- Flipping this re-points the list AND restores whatever was last
        -- picked for the newly-selected skill, so bouncing between melee and
        -- ranged does not make you re-choose each time. ws_name_per_weapon is
        -- keyed by skill string, and 'Marksmanship' is just another key in it.
        ui_checkbox('Ranged##ws_ranged_scope', 'ws_ranged', function(v)
            local sk = ws_picker_skill(v == true)
            local remembered = sk and cfg.ws_name_per_weapon and cfg.ws_name_per_weapon[sk]
            if remembered ~= nil and remembered ~= '' then
                cfg.ws_name = remembered
            end
        end)
        ui_help('Pick a weaponskill for the RANGED slot instead of the main hand.\n' ..
            'Remembers a separate choice per weapon type either way.')
    end

    -- Same reason as the ammo combo: imgui sizes an unset combo off the
    -- WINDOW, not its contents, so it stretches to roughly twice what a WS
    -- name needs and (with AlwaysAutoResize) widens the whole panel.
    imgui.SetNextItemWidth(WS_COMBO_WIDTH)
    if imgui.BeginCombo('##ws_name_combo', current) then
        if #ws_for == 0 then
            if skill == nil then
                imgui.Text(use_ranged
                    and '(equip a bow/xbow/gun to see ranged WS options)'
                    or '(equip a weapon to see WS options)')
            else
                imgui.Text(string.format('(no %s WS for %s at skill %d)',
                    skill,
                    (mjob or '?') .. (sjob and ('/' .. sjob) or ''),
                    tonumber(have) or 0))
            end
        else
            for _, ws in ipairs(ws_for) do
                local selected = (ws.name == current)
                if imgui.Selectable(ws.name, selected) then
                    cfg.ws_name = ws.name
                    cfg.ws_name_per_weapon = cfg.ws_name_per_weapon or T{}
                    cfg.ws_name_per_weapon[skill] = ws.name  -- remember per weapon type
                    settings.save()
                end
                if selected then
                    imgui.SetItemDefaultFocus()
                end
            end
        end
        imgui.EndCombo()
    end
end

local function format_elapsed(ts, engaged01)
    if engaged01 ~= 1 then return '--' end
    ts = tonumber(ts or 0) or 0
    if ts <= 0 then return '--' end

    local dt = now_sec() - ts
    if dt < 0 then dt = 0 end
    return string.format('%.1fs', dt)
end

local function render_header_controls()
    local paused_now = (cfg.auto and cfg.auto.paused) == true
    local pause_label = paused_now and 'Unpause' or 'Pause'

    -- Pause carries state: when the bot IS paused, the button glows amber
    -- (a "stopped, tap to resume" signal). Otherwise it's a neutral slate
    -- action button like the rest. Green = go, amber = halted.
    local pushed_pause_color = false
    if paused_now then
        imgui.PushStyleColor(ImGuiCol_Button,        {0.62, 0.44, 0.16, 1.0})
        imgui.PushStyleColor(ImGuiCol_ButtonHovered, {0.72, 0.52, 0.20, 1.0})
        imgui.PushStyleColor(ImGuiCol_ButtonActive,  {0.80, 0.58, 0.24, 1.0})
        pushed_pause_color = true
    end
    if imgui.Button(pause_label .. '##pause_btn') then
        cfg.auto.paused = not paused_now
        if movement and type(movement.force_release) == 'function' then
            movement.force_release()
        end
        settings.save()
    end
    if pushed_pause_color then
        imgui.PopStyleColor(3)
    end

    imgui.SameLine()
    if imgui.Button('Reset##reset_btn') then
        reset_runtime_state()
    end

    -- Rehome: re-anchor the camp to wherever you are standing NOW. Only
    -- REQUESTS it -- the capture happens inside the tick, where the player
    -- position is known good, rather than from a UI callback mid-render.
    imgui.SameLine()
    if imgui.Button('Rehome##rehome_btn') then
        if IdleRestEngage and type(IdleRestEngage.rehome) == 'function' then
            IdleRestEngage.rehome(S)
        end
    end

    -- (Debug toggle moved to the "Other (Emergency)" collapse.)

    -- Disable Home lives here (directly under Rehome) so the home controls
    -- stay together, instead of being buried inside the Auto Target block.
    ui_checkbox('Disable Home (use player pos)', 'home.disabled')

    -- Per-tool reset buttons: one per currently-missing tool, on their own
    -- line so a few of them don't crowd the header row. Resetting clears the
    -- flag (and the matching legacy flag) so the bot retries that tool.
    if S.flags and type(S.flags.missing_tools) == 'table' then
        local names = {}
        for name, on in pairs(S.flags.missing_tools) do
            if on == true then names[#names + 1] = name end
        end
        table.sort(names)
        for i = 1, #names do
            if i > 1 then imgui.SameLine() end
            local nm = names[i]
            if imgui.Button('Reset ' .. tostring(nm) .. '##reset_tool_' .. tostring(nm)) then
                GeneralLua.runtime.clear_tool_missing(S, nm)
                if nm == 'Shihei'        then S.flags.player_utsu_tools_out = false end
                if nm == 'Ranged Weapon' then S.flags.player_ranged_no_weapon = false end
            end
        end
    end
end

local function render_top_status(ctx)
    local mob_count = tonumber((S.live and S.live.mobs_attacking) or 0) or 0
    local mob_dist = (S.live and S.live.nearest_hate_distance)
    local mob_dist_text = mob_dist and string.format('%.1f', mob_dist) or '--'

    imgui.Text(string.format('Mobs Attacking: %d   Dist: %s', mob_count, mob_dist_text))
    imgui.Text(string.format('Time Since Last Attack:  %s', format_elapsed(S.combat and S.combat.last_attack_ts, ctx and ctx.engaged01 or 0)))
    imgui.Text(string.format('Time Since Last Defence: %s', format_elapsed(S.combat and S.combat.last_defence_ts, ctx and ctx.engaged01 or 0)))
    imgui.Separator()

    -- APPROACH TOGGLE: Run/Party and Ranged are two answers to the same
    -- question (how do we get damage onto the mob) and they fight each other
    -- if both are set -- Run walks into melee, Ranged wants to stand still
    -- and shoot. Setting either side clears the other here. Party is on the
    -- Run side because it only modifies Run's stop distance.
    --
    -- tick_engaged_run ALSO gates on auto.rangedmode. That is not redundant:
    -- this only fires when a box is clicked, and a settings file written
    -- before this existed can still have both true on load.
    local function clear_ranged(_v, set_cfg)
        if _v == true then set_cfg('auto.rangedmode', false) end
    end

    ui_checkbox('Auto Battle', 'auto.attack', function(v, set_cfg)
        if v ~= true then
            set_cfg('auto.bot', false)
        end
    end)
    ui_help('Attacks mobs. Runs the whole combat ladder on the current target.')
    imgui.SameLine()
    ui_checkbox('Run', 'auto.run', clear_ranged)
    ui_help('Runs at mobs within X distance.\nTurns Ranged off.')

    -- Second row, indented under Auto Battle. All four on one line ran the
    -- window wide enough to need dragging.
    imgui.Text('        ')
    imgui.SameLine()
    ui_checkbox('Party', 'auto.party', clear_ranged)
    ui_help('Lowers the X distance of Run.\nTurns Ranged off.')
    imgui.SameLine()
    -- Standoff ranged. Stand still and fire /ra on the shot's own resolve
    -- cadence instead of waiting for melee atk rounds. Distinct from
    -- 'Auto Ranged on Attack' (cfg auto.ranged) under the Ranged Attacks
    -- header, which rides the atk-round ladder.
    ui_checkbox('Ranged', 'auto.rangedmode', function(v, set_cfg)
        if v == true then
            set_cfg('auto.run', false)
            set_cfg('auto.party', false)
        end
    end)
    ui_help('Fires /ra at the targeted mob without running at it.\nTurns Run and Party off.')

    -- AMMO PICKER. Only while Ranged is on. Shared implementation -- the
    -- Ranged Attacks section renders the same control against the same cfg
    -- key.
    if cfg_get('auto.rangedmode') == true then
        ui_ammo_picker('ranged_ammo_pick_top', '        ', true)
    end

    -- Auto Target: when idle (not engaged, not resting) and no target for
    -- 5s, target the nearest mob within the configured range. Auto Pull
    -- then opens on it 1s later. Both handled in idle_rest_engage
    -- (tick_auto_target / tick_auto_pull).
    --
    -- HIDDEN UNLESS AUTO BATTLE IS ON. Targeting exists to feed the fight;
    -- with Auto Battle off there is nothing downstream to hand a mob to, so
    -- acquiring one just puts the cursor on something at random.
    if cfg_get('auto.attack') == true then
    ui_checkbox('Auto Target', 'auto.target')
    if cfg_get('auto.target') == true then
        -- Distance the auto-targeter will reach out to.
        imgui.Text('  Range:')
        imgui.SameLine()
        ui_radio3('auto.targetrange', '15y', 15, '20y', 20, '30y', 30)
        imgui.Text('        ')
        imgui.SameLine()
        ui_radio2('auto.targetrange', '40y', 40, '50y', 50)

        -- PULL METHOD. No on/off: Auto Target being on IS pull being on --
        -- acquiring a mob and then not opening on it is not a mode anyone
        -- wants, it is just the bot staring at things. So the only question
        -- left is which opener, and that is what these three are.
        --
        -- 0 stays legal in cfg (tick_auto_pull reads it as 'no pull') but is
        -- unreachable from the UI. A settings file written before this
        -- change can still hold it, so coerce once here rather than leaving
        -- a saved 0 to silently disable pulling with no control to fix it.
        if (tonumber(cfg_get('auto.pull')) or 0) == 0 then
            cfg_set('auto.pull', 3)   -- /attack: works on any job, no ammo needed
            settings.save()
        end

        -- RANGED MODE FORCES AN RA PULL.
        --
        -- The other two openers are broken in this mode, not merely worse:
        --
        --   Atk  chases to PULL_RANGE_YALMS[3] = 30y and sends /attack. That
        --        engages at 30y and then NOTHING CLOSES -- Ranged mode gates
        --        tick_engaged_run off on purpose, so we stand there engaged
        --        and out of reach, swinging at nothing, and the handoff to
        --        Auto Battle never happens.
        --   Dia  needs the spell, which a ranged setup generally has no
        --        business assuming.
        --
        -- RA is the only opener that works from a standstill, which is the
        -- entire premise of the mode. Coerced rather than offered: a radio
        -- you must not pick is not a choice.
        local ranged_pull = (cfg_get('auto.rangedmode') == true)
        if ranged_pull and (tonumber(cfg_get('auto.pull')) or 0) ~= 1 then
            cfg_set('auto.pull', 1)
            settings.save()
        end

        imgui.Text('  Pull:')
        imgui.SameLine()
        if ranged_pull then
            -- Green, not greyed. Greyed reads as 'unavailable'; this is
            -- an active setting that simply is not yours to change here.
            -- Same green the rest of the panel uses for live state.
            imgui.TextColored({ 0.7, 0.85, 0.7, 1.0 }, 'Ranged Mode')
        else
            ui_radio3('auto.pull', 'Atk', 3, 'RA', 1, 'Dia', 2)

            -- An RA pull needs ammo just as much as Ranged mode does, and
            -- with Ranged off there is no other picker on screen -- the top
            -- one is gated on rangedmode and the Ranged Attacks one on
            -- auto.ranged. So a plain melee setup pulling with /ra had no way
            -- to choose or even see its ammo. Third call site, same shared
            -- control and the same cfg key.
            --
            -- Not rendered when ranged_pull is true: the top-row picker is
            -- already showing in that case and two of them would be the same
            -- fact twice.
            if (tonumber(cfg_get('auto.pull')) or 0) == 1 then
                ui_ammo_picker('ranged_ammo_pick_pull', '  ')
            end
        end

        -- Ignore list: mob names auto-target skips. Case-insensitive
        -- substring match. Toggle the button to open/close; the number
        -- in the label is the current entry count.
        do
            local ig = cfg_get('auto.target_ignore_list')
            if type(ig) ~= 'table' then
                ig = T{}
                cfg_set('auto.target_ignore_list', ig)
            end
            local count = #ig
            S.ui.show_ignore_list = S.ui.show_ignore_list == true
            local arrow = S.ui.show_ignore_list and 'v' or '>'
            if imgui.SmallButton(string.format('Ignore list (%d) %s##auto_target_ignore', count, arrow)) then
                S.ui.show_ignore_list = not S.ui.show_ignore_list
            end
            if S.ui.show_ignore_list then
                for i = #ig, 1, -1 do
                    local entry = tostring(ig[i] or '')
                    imgui.PushID('ignore_row_' .. i)
                    imgui.Text('    ')
                    imgui.SameLine()
                    if imgui.SmallButton('X##remove') then
                        table.remove(ig, i)
                        cfg_set('auto.target_ignore_list', ig)
                        settings.save()
                    else
                        imgui.SameLine()
                        imgui.Text(entry)
                    end
                    imgui.PopID()
                end
                S.ui.ignore_add_buf = S.ui.ignore_add_buf or { '' }
                imgui.Text('    ')
                imgui.SameLine()
                imgui.SetNextItemWidth(150)
                imgui.InputText('##ignore_add_input', S.ui.ignore_add_buf, 64)
                imgui.SameLine()
                if imgui.SmallButton('Add##ignore_add_btn') then
                    local name = tostring(S.ui.ignore_add_buf[1] or '')
                        :gsub('^%s+', ''):gsub('%s+$', '')
                    if name ~= '' then
                        ig[#ig + 1] = name
                        cfg_set('auto.target_ignore_list', ig)
                        settings.save()
                        S.ui.ignore_add_buf[1] = ''
                    end
                end
            end
        end
    end
    end   -- auto.attack gate on the whole Auto Target block

    -- (Auto Antidote + Emergency Warp moved to the "Other (Emergency)"
    -- collapsing section, rendered lower down.)

    -- Full-Buff (WHM/RDM) or, for a NIN who can't cast those buffs, a Cast
    -- Shadows button; then RA Skill. Each only shows when it's meaningful for
    -- the current job / loadout.
    local rendered_buff_btn = false
    if ctx and (ctx.cap_full_buff or ctx.cap_shadows) then
        -- WHM/RDM run the full self-buff sequence. A NIN-only loadout gets a
        -- Cast Shadows button instead (buildbuff only fires the shadows step
        -- for them). Disabled while engaged -- it's a pre-fight setup tool.
        -- Label flips to Stop while a sequence is running.
        local label      = ctx.cap_full_buff and 'Full-Buff' or 'Cast Shadows'
        local stop_label = ctx.cap_full_buff and 'Stop Buff'  or 'Stop Shadows'
        local engaged = (S.live and S.live.player_status == GeneralLua.status.ENGAGED)
        local running = GeneralLua.runtime.buildbuff_is_active(S)

        if running then
            if ui_button_active(stop_label .. '##fullbuff_btn') then
                GeneralLua.runtime.buildbuff_stop(S)
            end
        elseif engaged then
            imgui.PushStyleColor(ImGuiCol_Text, { 0.50, 0.50, 0.50, 1.00 })
            imgui.Button(label .. '##fullbuff_btn_disabled')
            imgui.PopStyleColor()
            if imgui.IsItemHovered() then
                imgui.SetTooltip('Disabled while engaged')
            end
        else
            if imgui.Button(label .. '##fullbuff_btn') then
                GeneralLua.runtime.buildbuff_start(S)
            end
        end
        rendered_buff_btn = true
    end

    if S.live and S.live.ranged_capable then
        if rendered_buff_btn then imgui.SameLine() end
        -- RA Skill: ranged-skillup session on the current target. Flips to
        -- Stop while running. Self-stops on target death / out of ammo / no
        -- ranged weapon; Stop cancels manually.
        if GeneralLua.runtime.ra_skill_is_active(S) then
            if ui_button_active('Stop RA##ra_skill_btn') then
                GeneralLua.runtime.ra_skill_stop(S)
            end
        else
            if imgui.Button('RA Skill##ra_skill_btn') then
                GeneralLua.runtime.ra_skill_start(S)
            end
        end
    end

    -- Sleep/Sneak/Disengage: manual assist for a THF with a bow/xbow. On its
    -- own line below the buff/RA row. Disabled (greyed) unless the target has
    -- no waking DoT, sleep ammo is on hand, and Sneak Attack is off cooldown.
    if ctx and ctx.can_sneak_attack and tostring(ctx.sleep_ammo_name or '') ~= '' then
        if GeneralLua.runtime.ssd_is_active(S) then
            if ui_button_active('Stop##ssd_btn') then
                GeneralLua.runtime.ssd_stop(S)
            end
        else
            local engaged  = (S.live and S.live.player_status == GeneralLua.status.ENGAGED)
            local ammo_ok = (S.live and S.live.sleep_ammo_available) == true
            local has_dot  = ctx.target_has_waking_dot()
            local sa_ok    = ctx.sneak_attack_ready()
            local ra_ok    = (ctx.ra_ready == true) and (ctx.ranged_busy ~= true)
            local has_tgt  = (tonumber(ctx.target_server_id or 0) or 0) ~= 0
                             and not ctx.target_dead
            if engaged and has_tgt and ammo_ok and (not has_dot) and sa_ok and ra_ok then
                if imgui.Button('Sleep/Sneak/Disengage##ssd_btn') then
                    GeneralLua.runtime.ssd_start(S)
                end
            else
                imgui.PushStyleColor(ImGuiCol_Text, { 0.50, 0.50, 0.50, 1.00 })
                imgui.Button('Sleep/Sneak/Disengage##ssd_btn_disabled')
                imgui.PopStyleColor()
                if imgui.IsItemHovered() then
                    local why = (not engaged) and 'not engaged'
                        or (not has_tgt) and 'no target'
                        or (not ammo_ok) and 'no sleep ammo'
                        or (has_dot and 'target has a DoT')
                        or (not ra_ok and '/ra on cooldown')
                        or 'Sneak Attack on cooldown'
                    imgui.SetTooltip(why)
                end
            end
        end
    end

    -- Bot mode UI disabled. Re-enable by uncommenting:
    -- imgui.SameLine()
    -- ui_checkbox('Bot', 'auto.bot', function(v, set_cfg)
    --     if v == true then
    --         set_cfg('auto.attack', true)
    --     end
    -- end)

    imgui.Separator()
end

local function render_core_controls()
    -- Checkbox leads (it's the enable + the label); the % threshold radio
    -- sits on the line below it, matching the checkbox-then-controls
    -- layout used elsewhere in the panel.
    ui_checkbox('Auto Rest HP', 'auto.rest')
    ui_radio3('rest_hp', '50%##rest_hp_shell', 50, '75%##rest_hp_shell', 75, '100%##rest_hp_shell', 100)

    imgui.Separator()

    ui_checkbox('Auto Rest MP', 'auto.rest_mp')
    ui_radio3('rest_mp', '50%##rest_mp_shell', 50, '75%##rest_mp_shell', 75, '100%##rest_mp_shell', 100)

    imgui.Separator()

    -- Auto Food Buff -- sits directly under Auto Rest MP.
    if FOOD_ENTRY then
        render_food_buff_entry(FOOD_ENTRY)
        imgui.Separator()
    end

    -- Auto WeaponSkill: its own collapse. Auto WS vs Hold WS (THF) are
    -- mutually exclusive: the Auto WS checkbox always renders so it's
    -- reachable, but when Hold WS owns weaponskilling the sub-controls
    -- (HP, WS Name, SC, Dagger overrides) hide -- the selector relocates
    -- into the THF section and SC does not exist under THF.
    if imgui.CollapsingHeader('Auto WeaponSkill', ImGuiTreeNodeFlags_DefaultOpen) then
        ui_checkbox('Auto WS', 'auto.ws', function(v, set)
            if v then set('thief.hold_ws', false) end
        end)
        -- Sub-controls follow the MASTER TOGGLE, not just the THF override.
        -- This used to be gated on hold_ws alone, so with Auto WS off you
        -- still got the threshold, the WS picker, the SC pair and the Dagger
        -- overrides -- a full block of settings for a feature that is not
        -- running. hold_ws stays in the condition because when THF owns
        -- weaponskilling the picker relocates into the Thief section and
        -- these must not draw twice.
        if cfg_get('auto.ws') == true and cfg_get('thief.hold_ws') ~= true then
            imgui.SameLine()
            ui_radio3('ws_hp', '10%##ws_shell', 10, '25%##ws_shell', 25, 'Any##ws_shell', 0)
            ui_ws_name()

            -- SC partner coordination. Pick ONE role (mutually exclusive):
            --   SC Open : fire our WS when the partner holds 1000+ TP (they close).
            --   SC Close: fire our WS within 5s after the partner's WS (we close).
            ui_checkbox('SC Open', 'auto.ws_sc_open', function(v, set)
                if v then set('auto.ws_sc_close', false) end
            end)
            imgui.SameLine()
            ui_checkbox('SC Close', 'auto.ws_sc_close', function(v, set)
                if v then set('auto.ws_sc_open', false) end
            end)
            if cfg_get('auto.ws_sc_open') or cfg_get('auto.ws_sc_close') then
                local val = tostring(cfg_get('ws_sc_partner') or '')
                if cfg_get('auto.paused') ~= true then
                    imgui.Text(string.format('Playername: %s', val ~= '' and val or '(none)'))
                    imgui.SameLine()
                    imgui.Text('(Pause to edit)')
                else
                    local buf = { val }
                    if imgui.InputText('Playername##ws_sc_partner', buf, 20) then
                        cfg_set('ws_sc_partner', buf[1])
                        settings.save()
                    end
                end
            end

            -- Dagger-only WS overrides. Swap the picked WS for Energy Steal /
            -- Drain when the trigger fires. MP wins over Haste if both fire.
            -- Only while Dagger is the equipped main weapon.
            --
            -- Each rides ONE specific weaponskill, so it is gated on that WS
            -- being usable rather than on the weapon type alone. Energy Steal
            -- wants Dagger 150 and Energy Drain 175 -- offering them at skill
            -- 36 is offering a switch wired to nothing.
            if S.live and S.live.main_weapon_skill == 'Dagger' then
                local have = player_combat_skill('Dagger')
                local mjob, sjob = player_jobs()

                -- nil on either axis means UNKNOWN and does not filter, same
                -- convention as the WS picker: a failed read shows the control
                -- rather than silently deleting it.
                local function dagger_ws_row(label, cfgkey, ws_name)
                    local ws = WSL.by_name(ws_name)
                    if ws == nil then
                        ui_checkbox(label, cfgkey)   -- not in the list; show it
                        return
                    end

                    local need = tonumber(ws.skill_level) or 0
                    if have ~= nil and have < need then
                        imgui.TextDisabled(string.format('%s (Dagger %d)', label, need))
                        return
                    end
                    if mjob ~= nil and not WSL.job_can_use(ws, mjob, sjob) then
                        imgui.TextDisabled(string.format('%s (not %s)', label, mjob))
                        return
                    end

                    ui_checkbox(label, cfgkey)
                end

                dagger_ws_row('Auto MP (Energy Steal)',    'auto.ws_mp_override',    'Energy Steal')
                dagger_ws_row('Auto Haste (Energy Drain)', 'auto.ws_haste_override', 'Energy Drain')
            end
        end
    end
end

local function render_ranged_controls()
    if imgui.CollapsingHeader('Ranged Attacks', ImGuiTreeNodeFlags_DefaultOpen) then
        ui_checkbox('Auto Ranged', 'auto.ranged')
        if cfg_get('auto.ranged') then
            -- The equipped ammo name + count used to be echoed on this line.
            -- The picker below says the same thing in the same green, so it
            -- was the same fact twice, one line apart. Picker wins: it also
            -- lets you change the ammo instead of only watching it drain.
            ui_ammo_picker('ranged_ammo_pick_section', '  ')
            local function bolt_count_text(n)
                n = tonumber(n or 0) or 0
                if n > 0 then
                    return {0.7, 0.85, 0.7, 1.0}, string.format('x%d', n)
                else
                    return {1.0, 0.5, 0.5, 1.0}, 'x0'
                end
            end

            -- BOLTS NEED A CROSSBOW.
            --
            -- Bloody, Acid and Blind exist ONLY as bolts -- there is no
            -- Bloody Arrow anywhere in item_weapon. With a bow equipped these
            -- three rows are dead controls that can never do anything, and
            -- showing 'Bloody Bolts x0' next to a full quiver of arrows reads
            -- as a bug in the counter rather than as 'wrong launcher'.
            --
            -- Sleep Other is deliberately NOT in here: Sleep Arrow exists
            -- (level 35) and sleep_ammo_for_ranged already picks bolt vs
            -- arrow off the launcher, so it works on both.
            local rskill = S.live and S.live.ranged_weapon_skill or nil
            local bolts_usable = (rskill == 'Marksmanship')

            -- Level gate. Each of these rides one specific item, so the level
            -- to check is that item's, straight out of item_equipment via
            -- weapon_db -- not a number typed in here.
            local mlvl = player_main_level()
            local function bolt_row(label, cfgkey, ammo_name, count)
                local need = WeaponDB.ammo_level_of(ammo_name)
                if mlvl ~= nil and need ~= nil and mlvl < need then
                    -- Too low to equip it at all. Show it greyed with the
                    -- requirement rather than hiding it, so the answer to
                    -- "where did that option go" is on screen.
                    imgui.TextDisabled(string.format('%s (Lv%d)', label, need))
                    return false
                end
                ui_checkbox(label, cfgkey)
                imgui.SameLine()
                do local c, t = bolt_count_text(count); imgui.TextColored(c, t) end
                return true
            end

            -- Bolt-only controls. Hidden outright with a bow, not explained:
            -- 'bolt options need a crossbow' is telling you something you
            -- already know, and a line of text where a control used to be is
            -- still clutter.
            if bolts_usable then
                if bolt_row('Bloody Bolts', 'ranged.hp_drain', 'Bloody Bolt',
                    S.live and S.live.blood_bolt_count) then
                    ui_radio3('ranged.hp_drain_hp', '33%##hpdrain', 33, '50%##hpdrain', 50, '75%##hpdrain', 75)
                end

                bolt_row('Def Down', 'ranged.def_down_only', 'Acid Bolt',
                    S.live and S.live.acid_bolt_count)

                bolt_row('Blind Bolts', 'ranged.blind_bolt', 'Blind Bolt',
                    S.live and S.live.blind_bolt_count)

                -- Stop-at-10: no point applying def down / blind to a mob
                -- about to die. Does NOT affect Bloody Bolts (drain wants low
                -- HP) or Sleep Other (fires at an add, not <t>).
                --
                -- Lives INSIDE the bolt block because the only two things it
                -- governs are Def Down and Blind, both bolt-only. Leaving it
                -- outside left a control saying 'bolts' on screen for someone
                -- holding a bow, governing nothing.
                ui_checkbox('Stop status bolts at 10%', 'ranged.status_stop_at_10')
            end

            -- Sleep Other. Only possible now that a ranged attack can name
            -- its target in the packet (0x01A Shoot) -- with /ra <t> you
            -- had to drop your target to shoot an add, which is why this
            -- never existed before.
            -- Sleep Other works on either launcher, but the two items have
            -- very different level requirements (Sleep Bolt 20, Sleep Arrow
            -- 35), so ask about whichever one this launcher actually uses.
            local sleep_name = (S.live and S.live.sleep_ammo_name) or ''
            local sleep_need = (sleep_name ~= '') and WeaponDB.ammo_level_of(sleep_name) or nil
            if mlvl ~= nil and sleep_need ~= nil and mlvl < sleep_need then
                imgui.TextDisabled(string.format('Sleep Other (%s, Lv%d)',
                    sleep_name, sleep_need))
            else
                ui_checkbox('Sleep Other', 'ranged.sleep_other')
                imgui.SameLine()
                do local c, t = bolt_count_text(S.live and S.live.sleep_ammo_count); imgui.TextColored(c, t) end
            end
        end
    end
end

local function normalize_ui_cfgkey(key)
    if key == 'hb_hp_mode' then return 'hb_hp' end
    if key == 'jump_hp_mode' then return 'jump_hp' end
    if key == 'ws_hp_mode' then return 'ws_hp' end
    if key == 'rest_hp_mode' then return 'rest_hp' end
    if key == 'rest_mp_mode' then return 'rest_mp' end
    return key
end

local function should_skip_ui_item(u)
    if not u then return true end
    local key = normalize_ui_cfgkey(u.cfgkey)

    if key == 'auto.hb_atk' or key == 'auto.hb_def' then return true end
    if key == 'auto.shadows_atk' or key == 'auto.shadows_def' then return true end
    if key == 'auto.hb' then return true end
    if key == 'auto.shadows' then return true end
    if key == 'hb_hp' then return true end

    if key == 'auto.ws' or key == 'ws_name' or key == 'ws_hp' then return true end
    if key == 'auto.ranged' then return true end

    return false
end

local function render_ui_item(u)
    if not u or not u.kind then return end
    if should_skip_ui_item(u) then return end

    local cfgkey = normalize_ui_cfgkey(u.cfgkey)

    if u.kind == 'text_separator' then
        imgui.Text(tostring(u.label or ''))
        return
    end

    if u.kind == 'checkbox' then
        ui_checkbox(u.label, cfgkey, u.on_set)
        return
    end

    if u.kind == 'checkbox_same' then
        ui_checkbox_same(u.label, cfgkey, u.on_set)
        return
    end

    if u.kind == 'radio2' then
        ui_radio2(cfgkey, u.labelA, u.valA, u.labelB, u.valB)
        return
    end

    if u.kind == 'radio3' then
        ui_radio3(cfgkey, u.labelA, u.valA, u.labelB, u.valB, u.labelC, u.valC)
        return
    end

    if u.kind == 'radio4' then
        ui_radio4(cfgkey,
            u.labelA, u.valA,
            u.labelB, u.valB,
            u.labelC, u.valC,
            u.labelD, u.valD)
        return
    end

    if u.kind == 'ws_name' then
        ui_ws_name()
        return
    end

    if u.kind == 'shadows_master' then
        ui_checkbox(u.label, cfgkey, u.on_set)
        return
    end

    if u.kind == 'input_text' then
        -- Override: certain cfgkeys render as dropdowns even when the list
        -- entry says input_text. Lets atk_list/def_list stay unchanged.
        local override_options = CFGKEY_DROPDOWN_OPTIONS[cfgkey]
        if override_options then
            local val = tostring(cfg_get(cfgkey) or u.default or '')
            imgui.Text(tostring(u.label or ''))
            if imgui.BeginCombo('##' .. tostring(cfgkey), val) then
                for _, opt in ipairs(override_options) do
                    local selected = (opt == val)
                    if imgui.Selectable(opt, selected) then
                        cfg_set(cfgkey, opt)
                        settings.save()
                    end
                    if selected then
                        imgui.SetItemDefaultFocus()
                    end
                end
                imgui.EndCombo()
            end
            return
        end

        -- u.cfgkey: top-level cfg field that holds the string value (e.g. 'food_name')
        -- u.label: imgui label
        -- u.max_len: input max length, default 64
        -- Editable only while paused (same gate as WS Name).
        local val = tostring(cfg_get(cfgkey) or u.default or '')
        local max_len = tonumber(u.max_len or 64) or 64

        if (cfg.auto and cfg.auto.paused) ~= true then
            imgui.Text(string.format('%s: %s', tostring(u.label or ''), val))
            imgui.SameLine()
            imgui.Text('(Pause to edit)')
        else
            local buf = { val }
            if imgui.InputText(tostring(u.label or ''), buf, max_len) then
                cfg_set(cfgkey, buf[1])
                settings.save()
            end
        end
        return
    end

    if u.kind == 'dropdown' then
        -- u.cfgkey: top-level cfg field that holds the string value (e.g. 'food_name')
        -- u.label:   imgui label
        -- u.options: array of strings to choose from
        -- u.default: value used when cfg is unset
        -- No pause gate; picking a value from a dropdown can't desync game targeting
        -- the way typing in an InputText could.
        local val = tostring(cfg_get(cfgkey) or u.default or '')
        local options = u.options or {}
        if imgui.BeginCombo(tostring(u.label or ''), val) then
            for _, opt in ipairs(options) do
                local selected = (opt == val)
                if imgui.Selectable(opt, selected) then
                    cfg_set(cfgkey, opt)
                    settings.save()
                end
                if selected then
                    imgui.SetItemDefaultFocus()
                end
            end
            imgui.EndCombo()
        end
        return
    end
end

local function render_mode_controls_for_entry(entry)
    if not entry or not entry.id then return false end

    if entry.id == 'SHADOWS' then
        ui_checkbox('Auto Shadows', 'auto.shadows')
        imgui.SameLine()
        if imgui.RadioButton('SAtk##shadows_mode', tostring(cfg_get('auto.shadows_mode') or 'atk') == 'atk') then
            cfg_set('auto.shadows_mode', 'atk')
            settings.save()
        end
        imgui.SameLine()
        if imgui.RadioButton('SDef##shadows_mode', tostring(cfg_get('auto.shadows_mode') or 'atk') == 'def') then
            cfg_set('auto.shadows_mode', 'def')
            settings.save()
        end
        if cfg_get('auto.shadows') then
            ui_checkbox('Sleep Bolt/Arrow', 'auto.shadows_sleep')
            if cfg_get('auto.shadows_sleep') then
                imgui.SameLine()
                local sa = S.live and S.live.sleep_ammo_name or ''
                if sa ~= '' then
                    imgui.TextColored({0.7, 0.85, 0.7, 1.0}, sa)
                else
                    imgui.TextColored({1.0, 0.5, 0.5, 1.0}, '(no bow/xbow)')
                end
            end
        end
        return true
    end

    if entry.id == 'SLEEP_SNEAK' then
        ui_checkbox('Auto Slp/Snk (Solo)', 'thief.auto_sleep_sneak', function(v, set)
            -- Slp/Snk and Sneak Only are mutually exclusive: one or the
            -- other, or neither.
            if v then set('thief.auto_sneak_only', false) end
        end)
        if cfg_get('thief.auto_sleep_sneak') then
            imgui.SameLine()
            local sa = S.live and S.live.sleep_ammo_name or ''
            if sa ~= '' then
                imgui.TextColored({0.7, 0.85, 0.7, 1.0}, sa)
            else
                imgui.TextColored({1.0, 0.5, 0.5, 1.0}, '(no bow/xbow)')
            end
            -- HP threshold: target must be ABOVE this % to fire (25 =
            -- fire 26-100%; skip nearly-dead mobs). 0 = Any (no gate).
            imgui.Text('  HP:')
            imgui.SameLine()
            ui_radio4('thief.auto_sleep_sneak_hp',
                '10%##sss_hp', 10,
                '25%##sss_hp', 25,
                '50%##sss_hp', 50,
                'Any##sss_hp', 0)
        end
        return true
    end

    if entry.id == 'SNEAK_ONLY' then
        ui_checkbox('Auto Sneak Only', 'thief.auto_sneak_only', function(v, set)
            -- Mutually exclusive with Slp/Snk (Solo).
            if v then set('thief.auto_sleep_sneak', false) end
        end)
        if cfg_get('thief.auto_sneak_only') then
            imgui.Text('  HP:')
            imgui.SameLine()
            ui_radio4('thief.auto_sneak_only_hp',
                '10%##sno_hp', 10,
                '25%##sno_hp', 25,
                '50%##sno_hp', 50,
                'Any##sno_hp', 0)
        end
        return true
    end

    if entry.id == 'TRICK_ATTACK' then
        ui_checkbox('Auto Trick Attack', 'thief.auto_trick_attack', function(v, set)
            -- Auto TA and Hold WS both drive the trick-attack machine and
            -- can't coexist; enabling this clears Hold WS.
            if v then set('thief.hold_ws', false) end
        end)
        if cfg_get('thief.auto_trick_attack') then
            imgui.Text('  HP:')
            imgui.SameLine()
            ui_radio4('thief.auto_trick_attack_hp',
                '10%##ta_hp', 10,
                '25%##ta_hp', 25,
                '50%##ta_hp', 50,
                'Any##ta_hp', 0)
        end

        -- Hold WS: disables Auto WS while on; at 1000 TP runs the TA
        -- positioning then fires the WS from the WS Name dropdown.
        -- Hold WS replaces Auto WS entirely. Mutually exclusive; SC
        -- Open/Close do not exist under THF -- enabling force-clears all
        -- three. The WS Name selector relocates in HERE.
        ui_checkbox('Auto TA/WS Tank', 'thief.hold_ws', function(v, set)
            if v then
                set('thief.auto_trick_attack', false)
                set('auto.ws', false)
                set('auto.ws_sc_open', false)
                set('auto.ws_sc_close', false)
            end
        end)
        if cfg_get('thief.hold_ws') then
            imgui.Text('  HP:')
            imgui.SameLine()
            ui_radio4('thief.hold_ws_hp',
                '10%##hws_hp', 10,
                '25%##hws_hp', 25,
                '50%##hws_hp', 50,
                'Any##hws_hp', 0)
            -- WS Name selector, relocated from Controls. Same cfg key
            -- (ws_name) so the pick is shared with Auto WS.
            imgui.Text('  WS:')
            imgui.SameLine()
            ui_ws_name()
        end

        -- Tank -- party-member dropdown. Only relevant to Auto TA / Hold
        -- WS (who to stand behind), so hidden when neither is on. Stores
        -- the chosen name in thief.tank_name (ctx.tank_entity matches it
        -- case-insensitively).
        if cfg_get('thief.auto_trick_attack') or cfg_get('thief.hold_ws') then
            local current = tostring(cfg_get('thief.tank_name') or '')
            imgui.Text('  Tank:')
            imgui.SameLine()
            imgui.SetNextItemWidth(160)
            if imgui.BeginCombo('##thf_tank_name', current ~= '' and current or '(pick tank)') then
                local party = AshitaCore:GetMemoryManager():GetParty()
                local any = false
                local seen = {}
                if party and type(party.GetMemberName) == 'function' then
                    for i = 0, 5 do   -- main party only, not alliance (6-17)
                        -- A slot is a REAL current member only when it's
                        -- flagged active AND has a nonzero server id. The
                        -- old GetMemberActive name doesn't exist on this
                        -- build, so the check silently passed every slot
                        -- and showed stale/left members. GetMemberIsActive
                        -- + GetMemberServerId is what the rest of the code
                        -- uses.
                        local is_active = true
                        if type(party.GetMemberIsActive) == 'function' then
                            local ok, a = pcall(function() return party:GetMemberIsActive(i) end)
                            if ok then is_active = (tonumber(a or 0) or 0) == 1 end
                        end
                        local sid = 0
                        if type(party.GetMemberServerId) == 'function' then
                            local ok, s = pcall(function() return party:GetMemberServerId(i) end)
                            if ok then sid = tonumber(s or 0) or 0 end
                        end
                        local nm = tostring(party:GetMemberName(i) or '')
                        if is_active and sid ~= 0 and nm ~= '' and not seen[nm] then
                            seen[nm] = true
                            any = true
                            local selected = (nm == current)
                            if imgui.Selectable(nm, selected) then
                                cfg_set('thief.tank_name', nm)
                                settings.save()
                            end
                            if selected then imgui.SetItemDefaultFocus() end
                        end
                    end
                end
                if not any then
                    imgui.Text('(no party members)')
                end
                imgui.EndCombo()
            end
        end
        return true
    end

    if entry.id == 'HB' then
        ui_checkbox('Auto HB Solo', 'auto.hb')
        imgui.SameLine()
        if imgui.RadioButton('HAtk##hb_mode', tostring(cfg_get('auto.hb_mode') or 'atk') == 'atk') then
            cfg_set('auto.hb_mode', 'atk')
            settings.save()
        end
        imgui.SameLine()
        if imgui.RadioButton('HDef##hb_mode', tostring(cfg_get('auto.hb_mode') or 'atk') == 'def') then
            cfg_set('auto.hb_mode', 'def')
            settings.save()
        end
        ui_radio3('hb_hp', '25%##hb_shell', 25, '33%##hb_shell', 33, '50%##hb_shell', 48)

        imgui.Separator()

        ui_checkbox('Auto HB Party', 'auto.hb_party')
        imgui.SameLine()
        ui_radio2('hb_party_hp', '33%##hbp_shell', 33, '50%##hbp_shell', 50)

        return true
    end

    -- Stoneskin and Blink use the same SHADOWS/HB pattern: one master
    -- checkbox + two RadioButtons for Atk/Def. The radio LABEL is the click
    -- target -- a true fake-toggle, in the user's words -- and there is
    -- exactly one source of truth (auto.stoneskin_mode / auto.blink_mode),
    -- never two booleans to drift out of sync with the mode string.
    --
    -- The atk_list.lua entries for these still have legacy `checkbox_same`
    -- items for Atk/Def that wrote auto.<spell>_mode_atk / _mode_def. Those
    -- items don't render any more because we return true here, but the
    -- vestigial cfg keys are harmless if left over from a previous version.
    if entry.id == 'STONESKIN' then
        ui_checkbox('Auto Stoneskin', 'auto.stoneskin')
        imgui.SameLine()
        if imgui.RadioButton('Atk##stoneskin_mode', tostring(cfg_get('auto.stoneskin_mode') or 'def') == 'atk') then
            cfg_set('auto.stoneskin_mode', 'atk')
            settings.save()
        end
        imgui.SameLine()
        if imgui.RadioButton('Def##stoneskin_mode', tostring(cfg_get('auto.stoneskin_mode') or 'def') == 'def') then
            cfg_set('auto.stoneskin_mode', 'def')
            settings.save()
        end
        return true
    end

    if entry.id == 'BLINK' then
        ui_checkbox('Auto Blink', 'auto.blink')
        imgui.SameLine()
        if imgui.RadioButton('Atk##blink_mode', tostring(cfg_get('auto.blink_mode') or 'def') == 'atk') then
            cfg_set('auto.blink_mode', 'atk')
            settings.save()
        end
        imgui.SameLine()
        if imgui.RadioButton('Def##blink_mode', tostring(cfg_get('auto.blink_mode') or 'def') == 'def') then
            cfg_set('auto.blink_mode', 'def')
            settings.save()
        end
        return true
    end

    if entry.id == 'PHALANX' then
        ui_checkbox('Auto Phalanx', 'auto.phalanx')
        imgui.SameLine()
        if imgui.RadioButton('Atk##phalanx_mode', tostring(cfg_get('auto.phalanx_mode') or 'def') == 'atk') then
            cfg_set('auto.phalanx_mode', 'atk')
            settings.save()
        end
        imgui.SameLine()
        if imgui.RadioButton('Def##phalanx_mode', tostring(cfg_get('auto.phalanx_mode') or 'def') == 'def') then
            cfg_set('auto.phalanx_mode', 'def')
            settings.save()
        end
        return true
    end

    return false
end

local function player_can_use_spell_debuff(entry_id, ctx)
    if not ctx or not ctx.job_info then return false end

    local ji = ctx.job_info
    local main_job = tonumber(ji.mainJob or 0) or 0
    local sub_job  = tonumber(ji.subJob or 0) or 0
    local main_lv  = tonumber(ji.mainLv or 0) or 0
    local sub_lv   = tonumber(ji.subLv or 0) or 0

    local WHM = tonumber(GeneralLua.jobs and GeneralLua.jobs.WHM or 3) or 3
    local BLM = tonumber(GeneralLua.jobs and GeneralLua.jobs.BLM or 4) or 4
    local RDM = tonumber(GeneralLua.jobs and GeneralLua.jobs.RDM or 5) or 5
    local DRK = tonumber(GeneralLua.jobs and GeneralLua.jobs.DRK or 8) or 8

    if entry_id == 'DIA' then
        -- DIA entry now covers both Dia (WHM/RDM) and Bio (BLM/RDM/DRK).
        -- Entry is visible if the player can cast at least the tier-I
        -- spell of EITHER family. The tier picker / family branch in
        -- atk_list eligible+act enforces per-family job/level inside.
        local dia_main_ok = ((main_job == WHM and main_lv >= 3) or (main_job == RDM and main_lv >= 1))
        local dia_sub_ok  = ((sub_job  == WHM and sub_lv  >= 3) or (sub_job  == RDM and sub_lv  >= 1))
        local bio_main_ok =
            ((main_job == BLM and main_lv >= 10) or
             (main_job == RDM and main_lv >= 10) or
             (main_job == DRK and main_lv >= 15))
        local bio_sub_ok =
            ((sub_job  == BLM and sub_lv  >= 10) or
             (sub_job  == RDM and sub_lv  >= 10) or
             (sub_job  == DRK and sub_lv  >= 15))
        return dia_main_ok or dia_sub_ok or bio_main_ok or bio_sub_ok
    end

    if entry_id == 'PARALYZE' then
        local main_ok = ((main_job == WHM and main_lv >= 4) or (main_job == RDM and main_lv >= 6))
        local sub_ok  = ((sub_job  == WHM and sub_lv  >= 4) or (sub_job  == RDM and sub_lv  >= 6))
        return main_ok or sub_ok
    end

    if entry_id == 'SLOW' then
        local main_ok = ((main_job == WHM and main_lv >= 13) or (main_job == RDM and main_lv >= 13))
        local sub_ok  = ((sub_job  == WHM and sub_lv  >= 13) or (sub_job  == RDM and sub_lv  >= 13))
        return main_ok or sub_ok
    end

    if entry_id == 'BLIND' then
        -- HorizonXI: Blind = BLM 4 / RDM 8.
        local main_ok = ((main_job == BLM and main_lv >= 4) or (main_job == RDM and main_lv >= 8))
        local sub_ok  = ((sub_job  == BLM and sub_lv  >= 4) or (sub_job  == RDM and sub_lv  >= 8))
        return main_ok or sub_ok
    end

    return true
end

local function player_can_use_def_spell(entry_id, ctx)
    if not ctx or not ctx.job_info then return false end

    if entry_id == 'PROTECT' then
        return ctx.can_use_protect == true
    end

    if entry_id == 'SHELL' then
        return ctx.can_use_shell == true
    end

    if entry_id == 'CURE' then
        return ctx.can_use_cure == true
    end

    return true
end

local ENSPELL_IDS = {
    ENFIRE=true, ENBLIZZARD=true, ENAERO=true,
    ENSTONE=true, ENWATER=true, ENTHUNDER=true,
}

local function entry_visible_for_current_mode(entry, ctx)
    if not entry or not entry.id then return false end

    local id = tostring(entry.id)

    if id == 'DIA' or id == 'PARALYZE' or id == 'SLOW' or id == 'BLIND' then
        return player_can_use_spell_debuff(id, ctx)
    end

    if id == 'PROTECT' or id == 'SHELL' or id == 'CURE' then
        return player_can_use_def_spell(id, ctx)
    end

    -- HB requires DRG main + a mage-capable subjob (WHM/RDM/PLD/BRD/NIN/BLU)
    if id == 'HB' or id == 'HB_PARTY' then
        if not ctx or not ctx.job_info then return false end
        local ji = ctx.job_info
        local DRG = 14
        if tonumber(ji.mainJob or 0) ~= DRG then return false end
        local valid_hb_subs = { [3]=true, [5]=true, [7]=true, [10]=true, [13]=true, [16]=true }
        return valid_hb_subs[tonumber(ji.subJob or 0) or 0] == true
    end

    -- En spells require RDM main or sub; use req_ok to check
    if ENSPELL_IDS[id] and entry.req == nil then
        -- No req means no job restriction in the entry itself, but enspell_ok
        -- inside eligible already checks. Mirror that here for UI visibility:
        if not ctx or not ctx.job_info then return false end
        local ji = ctx.job_info
        local RDM = 5
        local main_ok = (ji.mainJob == RDM and (ji.mainLv or 0) >= 16)
        local sub_ok  = (ji.subJob  == RDM and (ji.subLv  or 0) >= 8)
        return main_ok or sub_ok
    end

    return true
end

-- Map each entry id -> job group key. Entries in the same group are wrapped
-- in a single CollapsingHeader. Entries with no group render flat.
local ENTRY_GROUP = {
    -- Beastmaster
    PET_FIGHT   = 'BST',
    PET_READY   = 'BST',
    REWARD      = 'BST',
    CALL_BEAST  = 'BST',
    -- Ninja
    SHADOWS     = 'NIN',
    -- Thief
    SLEEP_SNEAK  = 'THF',
    SNEAK_ONLY   = 'THF',
    TRICK_ATTACK = 'THF',
    -- Samurai
    THIRD_EYE   = 'SAM',
    HASSO       = 'SAM',
    MEDITATE    = 'SAM',
    SEIGAN      = 'SAM',
    -- Dragoon
    JUMP        = 'DRG',
    HIGH_JUMP   = 'DRG',
    SUPER_JUMP  = 'DRG',
    CALL_WYVERN = 'DRG',
    STEADY_WING = 'DRG',
    SPIRIT_LINK = 'DRG',
    HB          = 'DRG',
    -- Warrior
    PROVOKE     = 'WAR',
    BERSERK     = 'WAR',
    WARCRY      = 'WAR',
    -- Monk
    BOOST       = 'MNK',
    -- Bard
    SONG        = 'BRD',
    -- White Magic Debuffs (under WHM parent)
    DIA         = 'DEBUFF_W',
    PARALYZE    = 'DEBUFF_W',
    SLOW        = 'DEBUFF_W',
    -- Black Magic Debuffs (under BLM parent)
    BLIND       = 'DEBUFF_B',
    POISON      = 'DEBUFF_B',
    -- Black Magic Elemental (under BLM parent)
    STONE       = 'ELEM_B',
    -- Self Buff Spells (under WHM parent)
    PROTECT     = 'SELF_BUFF',
    SHELL       = 'SELF_BUFF',
    STONESKIN   = 'SELF_BUFF',
    BLINK       = 'SELF_BUFF',
    -- Self Heal / Debuff (under WHM parent)
    CURE        = 'SELF_HEAL',
    -- Red Mage (enspells + self buffs + damage spikes)
    HASTE       = 'RDM',
    REFRESH     = 'RDM',
    PHALANX     = 'RDM',
    ENFIRE      = 'RDM',
    ENBLIZZARD  = 'RDM',
    ENAERO      = 'RDM',
    ENSTONE     = 'RDM',
    ENWATER     = 'RDM',
    ENTHUNDER   = 'RDM',
    -- Damage Spikes (BLM-native but RDM-accessible; grouped with RDM
    -- since the in-party use case is a RDM running enspell + spike).
    -- A BLM main can also see/use these via the same RDM section.
    BLAZE_SPIKES = 'RDM',
    ICE_SPIKES   = 'RDM',
    SHOCK_SPIKES = 'RDM',
}

-- Optional parent grouping. Child groups listed here render as nested
-- CollapsingHeaders inside the parent's CollapsingHeader.
local GROUP_PARENT = {
    DEBUFF_W  = 'WHM',
    SELF_BUFF = 'WHM',
    SELF_HEAL = 'WHM',
    DEBUFF_B  = 'BLM',
    ELEM_B    = 'BLM',
}

-- Group label and header color (RGBA in 0..1).
local GROUP_LABEL = {
    BST       = 'Beastmaster',
    NIN       = 'Ninja',
    THF       = 'Thief',
    SAM       = 'Samurai',
    DRG       = 'Dragoon',
    WAR       = 'Warrior',
    MNK       = 'Monk',
    BRD       = 'Bard',
    WHM       = 'White Magic',
    BLM       = 'Black Mage',
    DEBUFF_W  = 'White Magic Debuffs',
    DEBUFF_B  = 'Black Magic Debuffs',
    ELEM_B    = 'Black Magic Elemental',
    SELF_BUFF = 'Self Buff Spells',
    SELF_HEAL = 'Self Heal / Debuff',
    RDM       = 'Red Mage',
}
local GROUP_COLOR = {
    -- Per-job identity colors -- each visually distinct so no two jobs read
    -- as the same hue. FFXI has no official job colors, so these are a
    -- hand-tuned distinct set (WAR/THF/RNG/NIN anchored by request).
    WAR       = { 0.90, 0.20, 0.20, 1.00 },  -- hard red
    MNK       = { 0.95, 0.55, 0.20, 1.00 },  -- orange
    WHM       = { 0.92, 0.92, 0.95, 1.00 },  -- white
    BLM       = { 0.42, 0.38, 0.92, 1.00 },  -- indigo
    RDM       = { 0.95, 0.50, 0.68, 1.00 },  -- rose
    THF       = { 0.35, 0.80, 0.40, 1.00 },  -- green
    PLD       = { 0.62, 0.72, 0.85, 1.00 },  -- steel blue
    DRK       = { 0.85, 0.20, 0.55, 1.00 },  -- magenta
    BST       = { 0.68, 0.52, 0.32, 1.00 },  -- tan / brown
    BRD       = { 0.45, 0.82, 0.96, 1.00 },  -- sky cyan
    RNG       = { 0.95, 0.85, 0.30, 1.00 },  -- yellow
    SAM       = { 0.25, 0.78, 0.72, 1.00 },  -- teal
    NIN       = { 0.65, 0.45, 0.90, 1.00 },  -- purple
    DRG       = { 0.30, 0.50, 0.95, 1.00 },  -- royal blue
    SMN       = { 0.65, 0.85, 0.25, 1.00 },  -- lime
    BLU       = { 0.20, 0.65, 0.90, 1.00 },  -- cerulean
    COR       = { 0.80, 0.62, 0.15, 1.00 },  -- amber-gold

    -- Non-job spell-category tints (used by grouped magic entries, not job
    -- headers) -- left as-is.
    DEBUFF_W  = { 0.85, 0.85, 0.92, 1.00 },  -- dimmer near-white (child contrasts a bit)
    DEBUFF_B  = { 0.70, 0.55, 0.88, 1.00 },  -- dimmer purple (child)
    ELEM_B    = { 0.72, 0.60, 0.95, 1.00 },  -- elemental nuke purple (child)
    SELF_BUFF = { 0.55, 0.95, 0.70, 1.00 },  -- mint green
    SELF_HEAL = { 0.65, 0.95, 0.55, 1.00 },  -- spring green
}

-- Optional per-group display order. Entries pool into a group in whatever
-- order they appear across the source lists (atk_list then def_list), which
-- meant PROTECT/SHELL (defined in def_list) always rendered below STONESKIN/
-- BLINK (defined in atk_list). Where a group is listed here, members are
-- re-sorted by the per-id rank below before rendering; un-ranked members
-- keep natural insertion order after the ranked block. Add new groups here
-- only when you want to override the default source-list ordering.
local GROUP_MEMBER_ORDER = {
    SELF_BUFF = { PROTECT = 1, SHELL = 2, STONESKIN = 3, BLINK = 4 },
}

local function ui_label_text(s)
    -- Plain label with no trailing newline; used as inline prefix before radios.
    imgui.Text(tostring(s))
    imgui.SameLine()
end

render_food_buff_entry = function(entry)
    -- Auto Food Buff (always)
    -- Food Name input (only when auto.food is on)
    for j = 1, #entry.ui do
        local u = entry.ui[j]
        local key = u and normalize_ui_cfgkey(u.cfgkey) or ''
        if key == 'auto.food' then
            render_ui_item(u)
        elseif key == 'food_name' then
            if cfg_get('auto.food') then
                render_ui_item(u)
            end
        else
            render_ui_item(u)
        end
    end
end

local function render_pet_ready_entry(entry)
    -- Auto Pet Ready (always)
    -- Ready Move + Charges + Min Enemy HP (only when auto.ready is on)
    local ready_on = cfg_get('auto.ready')

    for j = 1, #entry.ui do
        local u = entry.ui[j]
        if not u then goto continue end
        local key = normalize_ui_cfgkey(u.cfgkey)

        if key == 'auto.ready' then
            render_ui_item(u)
        elseif not ready_on then
            -- Sub-controls hidden until parent is enabled.
        elseif key == 'pet_ready_name' then
            render_ui_item(u)
        elseif key == 'pet_ready_charges' then
            ui_label_text('Charges:')
            render_ui_item(u)
        elseif key == 'pet_ready_target_hp' then
            ui_label_text('Min Enemy HP:')
            render_ui_item(u)
        else
            render_ui_item(u)
        end

        ::continue::
    end
end

local _rendered_ids_this_frame = {}

-- Job-aware render for the DIA entry. The default radio4 unconditionally
-- shows all 4 tiers (Dia I/II, Bio I/II); for jobs that can only cast one
-- family (e.g. DRG/WHM can do Dia, no Bio) we hide the other family's
-- options entirely and label the checkbox accordingly. Also clamps the
-- saved tier cfg if it points to a spell the player can't cast (e.g. the
-- player swapped from /RDM to /WHM while dia_tier was set to 4=Bio II).
local function render_dia_entry(entry, ctx)
    local ji = (ctx and ctx.job_info) or {}
    local WHM = tonumber(GeneralLua.jobs and GeneralLua.jobs.WHM or 3) or 3
    local BLM = tonumber(GeneralLua.jobs and GeneralLua.jobs.BLM or 4) or 4
    local RDM = tonumber(GeneralLua.jobs and GeneralLua.jobs.RDM or 5) or 5
    local DRK = tonumber(GeneralLua.jobs and GeneralLua.jobs.DRK or 8) or 8

    local main_job = tonumber(ji.mainJob or 0) or 0
    local sub_job  = tonumber(ji.subJob  or 0) or 0
    local main_lv  = tonumber(ji.mainLv  or 0) or 0
    local sub_lv   = tonumber(ji.subLv   or 0) or 0

    local dia_ok =
        ((main_job == WHM and main_lv >= 3) or (main_job == RDM and main_lv >= 1) or
         (sub_job  == WHM and sub_lv  >= 3) or (sub_job  == RDM and sub_lv  >= 1))
    local bio_ok =
        ((main_job == BLM and main_lv >= 10) or (main_job == RDM and main_lv >= 10) or
         (main_job == DRK and main_lv >= 15) or
         (sub_job  == BLM and sub_lv  >= 10) or (sub_job  == RDM and sub_lv  >= 10) or
         (sub_job  == DRK and sub_lv  >= 15))
    local dia2_ok =
        ((main_job == WHM and main_lv >= 36) or (main_job == RDM and main_lv >= 31) or
         (sub_job  == WHM and sub_lv  >= 36) or (sub_job  == RDM and sub_lv  >= 31))
    local bio2_ok =
        ((main_job == BLM and main_lv >= 35) or (main_job == RDM and main_lv >= 36) or
         (main_job == DRK and main_lv >= 40) or
         (sub_job  == BLM and sub_lv  >= 35) or (sub_job  == RDM and sub_lv  >= 36) or
         (sub_job  == DRK and sub_lv  >= 40))

    -- Clamp saved tier if it now points to a spell the player can't cast.
    -- Family preference is preserved when possible (Bio II -> Bio I, etc.).
    local cur = tonumber(cfg_get('dia_tier') or 1) or 1
    local function tier_valid(t)
        if t == 1 then return dia_ok end
        if t == 2 then return dia2_ok end
        if t == 3 then return bio_ok end
        if t == 4 then return bio2_ok end
        return false
    end
    if not tier_valid(cur) then
        local new
        if     cur == 2 and dia_ok then new = 1
        elseif cur == 4 and bio_ok then new = 3
        elseif dia_ok then              new = 1
        elseif bio_ok then              new = 3
        end
        if new then
            cfg_set('dia_tier', new)
            settings.save()
            cur = new
        end
    end

    -- Checkbox label reflects what the player can actually cast.
    local label
    if dia_ok and bio_ok then     label = 'Auto Dia / Bio'
    elseif dia_ok then            label = 'Auto Dia'
    elseif bio_ok then            label = 'Auto Bio'
    else                          label = 'Auto Dia / Bio'   -- shouldn't render but safe
    end
    ui_checkbox(label, 'auto.dia')

    -- Render only the radio buttons the player can actually use. ##dia_tier
    -- suffix kept on each label so imgui ids stay stable across job swaps.
    local first = true
    local function radio(lbl, val)
        if not first then imgui.SameLine() end
        first = false
        if imgui.RadioButton(lbl, cur == val) then
            cfg_set('dia_tier', val)
            settings.save()
        end
    end
    if dia_ok  then radio('Dia I##dia_tier',  1) end
    if dia2_ok then radio('Dia II##dia_tier', 2) end
    if bio_ok  then radio('Bio I##dia_tier',  3) end
    if bio2_ok then radio('Bio II##dia_tier', 4) end
end

local function render_entry_body(entry, ctx)
    -- EMERG_WARP's UI lives in the hand-drawn "Other (Emergency)" collapse
    -- now, not in the ladder flow. Skip it here so it doesn't double-draw.
    if entry and entry.id == 'EMERG_WARP' then return end
    -- Hard dedup: an entry id may exist in BOTH atk and def lists (e.g. SAM
    -- abilities with shared UI). Guarantee it draws at most once per frame,
    -- regardless of list/ui state. Reset each frame in render_ui_from_lists.
    if entry and entry.id then
        if _rendered_ids_this_frame[entry.id] then return end
        _rendered_ids_this_frame[entry.id] = true
    end
    local handled_mode_block = render_mode_controls_for_entry(entry)
    if handled_mode_block then return end

    if entry.id == 'CURE' then
        local pending_same_line = false
        for j = 1, #entry.ui do
            local u = entry.ui[j]
            if u and u.kind == 'checkbox' and normalize_ui_cfgkey(u.cfgkey) == 'auto.cure' then
                render_ui_item(u)
                pending_same_line = true
            elseif u and u.kind == 'radio3' and normalize_ui_cfgkey(u.cfgkey) == 'cure_hp' then
                if pending_same_line then
                    imgui.SameLine()
                    pending_same_line = false
                end
                render_ui_item(u)
            else
                pending_same_line = false
                render_ui_item(u)
            end
        end
    elseif entry.id == 'EMERG_WARP' then
        -- Same layout pattern as CURE: checkbox, then the HP-threshold
        -- radio inline on the same line.
        local pending_same_line = false
        for j = 1, #entry.ui do
            local u = entry.ui[j]
            if u and u.kind == 'checkbox' and normalize_ui_cfgkey(u.cfgkey) == 'auto.warp' then
                render_ui_item(u)
                pending_same_line = true
            elseif u and u.kind == 'radio3' and normalize_ui_cfgkey(u.cfgkey) == 'warp_hp' then
                if pending_same_line then
                    imgui.SameLine()
                    pending_same_line = false
                end
                render_ui_item(u)
            else
                pending_same_line = false
                render_ui_item(u)
            end
        end
    elseif entry.id == 'DIA' then
        render_dia_entry(entry, ctx)
    elseif entry.id == 'FOOD_BUFF' then
        render_food_buff_entry(entry)
    elseif entry.id == 'PET_READY' then
        render_pet_ready_entry(entry)
    else
        for j = 1, #entry.ui do
            render_ui_item(entry.ui[j])
        end
    end
end

local function entry_is_visible(entry, ctx)
    return entry and entry.ui
        and GeneralLua.utils.req_ok(entry.req, ctx and ctx.job_info)
        and entry_visible_for_current_mode(entry, ctx)
end

-- Stable per-list tag so the same group rendered into different lists (atk vs
-- def) gets distinct CollapsingHeader IDs, but the SAME group within the SAME
-- list keeps the same ID across frames (ImGui needs that for click-state to
-- persist - otherwise clicks "snap back" because each frame looks like a new
-- widget and DefaultOpen re-applies).
local _list_tag_cache = setmetatable({}, { __mode = 'k' })   -- weak keys
local _list_tag_seq = 0
local function list_tag_for(list)
    local t = _list_tag_cache[list]
    if t then return t end
    _list_tag_seq = _list_tag_seq + 1
    t = tostring(_list_tag_seq)
    _list_tag_cache[list] = t
    return t
end

local function render_ui_from_lists(lists, ctx)
    _rendered_ids_this_frame = {}
    -- Stable tag derived from list identities so atk+def get a unique combined
    -- tag (different from rendering atk alone, etc.). Same logic as before but
    -- keyed by the FIRST list since that's the entry point.
    local tag = list_tag_for(lists[1] or lists)

    -- First pass: across ALL provided lists, mark visible entries and pool
    -- group members. Groups are list-agnostic - atk Dragoon and def Dragoon
    -- entries pool together under one Dragoon header.
    local visible = {}                  -- (list_idx, entry_idx) -> true
    local group_first_pos = {}          -- group -> [list_idx, entry_idx] of first visible
    local group_members  = {}           -- group -> ordered list of visible entries
    for li = 1, #lists do
        local list = lists[li]
        local v = {}
        visible[li] = v
        for i = 1, #list do
            local entry = list[i]
            if entry_is_visible(entry, ctx) and entry.id ~= 'FOOD_BUFF' then
                v[i] = true
                local g = ENTRY_GROUP[entry.id]
                if g then
                    if group_first_pos[g] == nil then
                        group_first_pos[g] = { li, i }
                        group_members[g] = {}
                    end
                    local mems = group_members[g]
                    mems[#mems + 1] = entry
                end
            end
        end
    end

    -- Apply explicit display order where configured (GROUP_MEMBER_ORDER).
    -- Natural insertion order from the pooling pass above interleaves entries
    -- in source-list order, which puts atk_list members before def_list ones
    -- and gave the wrong order for Self Buff Spells (Stoneskin/Blink were
    -- ahead of Protect/Shell because atk_list is traversed first). Re-sort
    -- the affected groups using a stable comparator: ranked ids by rank,
    -- everything else by original insertion index after the ranked block.
    for g, mems in pairs(group_members) do
        local order = GROUP_MEMBER_ORDER[g]
        if order and #mems > 1 then
            local orig_index = {}
            for k = 1, #mems do
                orig_index[mems[k]] = k
            end
            table.sort(mems, function(a, b)
                local ra = order[tostring(a.id or '')]
                local rb = order[tostring(b.id or '')]
                if ra and rb then return ra < rb end
                if ra and not rb then return true  end   -- ranked before un-ranked
                if rb and not ra then return false end
                return orig_index[a] < orig_index[b]     -- stable for un-ranked
            end)
        end
    end

    -- Second pass: walk lists in order. When we hit the first visible entry
    -- of a group, render the whole group's header at that spot. Skip any
    -- later visible entries that belong to an already-rendered group.
    --
    -- Parent groups (GROUP_PARENT) get rendered as an outer CollapsingHeader
    -- containing their children's CollapsingHeaders. The parent header is
    -- drawn at the FIRST visible entry of ANY of its children.
    local rendered_group  = {}
    local rendered_parent = {}

    local function child_groups_of(parent)
        local kids = {}
        for child, p in pairs(GROUP_PARENT) do
            if p == parent then kids[#kids + 1] = child end
        end
        return kids
    end

    local function render_group_block(g, ctx)
        local label = GROUP_LABEL[g] or g
        local color = GROUP_COLOR[g] or { 1.00, 0.85, 0.40, 1.00 }
        local header_id = string.format('%s##group_%s_%s', label, g, tag)

        imgui.PushStyleColor(ImGuiCol_Text, color)
        local open = imgui.CollapsingHeader(header_id, ImGuiTreeNodeFlags_DefaultOpen)
        imgui.PopStyleColor()

        if open then
            local mems = group_members[g]
            for k = 1, #mems do
                render_entry_body(mems[k], ctx)
            end
        end
        rendered_group[g] = true
    end

    local function render_parent_block(parent, ctx)
        local label = GROUP_LABEL[parent] or parent
        local color = GROUP_COLOR[parent] or { 1.00, 0.85, 0.40, 1.00 }
        local header_id = string.format('%s##group_%s_%s', label, parent, tag)

        imgui.PushStyleColor(ImGuiCol_Text, color)
        local open = imgui.CollapsingHeader(header_id, ImGuiTreeNodeFlags_DefaultOpen)
        imgui.PopStyleColor()

        if open then
            -- Render each visible child group's own CollapsingHeader, in the
            -- order of their first-visible-entry positions across the lists.
            local kids = child_groups_of(parent)
            -- Sort by group_first_pos so children appear in source order.
            table.sort(kids, function(a, b)
                local pa = group_first_pos[a]
                local pb = group_first_pos[b]
                if not pa and not pb then return false end
                if not pa then return false end
                if not pb then return true end
                if pa[1] ~= pb[1] then return pa[1] < pb[1] end
                return pa[2] < pb[2]
            end)
            for _, child in ipairs(kids) do
                if group_first_pos[child] and not rendered_group[child] then
                    render_group_block(child, ctx)
                end
            end
        end
        rendered_parent[parent] = true
    end

    -- Second pass, EXPLICITLY ORDERED (was: source-list position order).
    --
    -- Order applied:
    --   1. FOOD_BUFF first, above everything (it's a global toggle, not a
    --      job thing -- belongs at the top, not buried under Red Mage).
    --   2. Top-level job groups in a defined sequence (TOP_GROUP_ORDER):
    --      WHM, BLM, RDM, then the melee jobs. Within that, the player's
    --      MAIN JOB group is hoisted to the very top so your own job is
    --      first.
    --   3. Anything else (standalone entries, groups not in the order
    --      list) after, in source order, as a fallback.
    --
    -- A "top-level group" is either a parent group (WHM/BLM via
    -- GROUP_PARENT) or a standalone group with no parent (RDM, NIN, SAM,
    -- DRG, WAR, BST). Child groups (DEBUFF_W etc.) are rendered inside
    -- their parent block and are not top-level.

    -- Map each top-level group to the job number it represents, so we can
    -- hoist the player's main job. Parent groups WHM/BLM map directly;
    -- standalone job groups share their id with the job constant name.
    local J = GeneralLua.jobs or {}
    local GROUP_JOB = {
        WHM = J.WHM, BLM = J.BLM, RDM = J.RDM,
        NIN = J.NIN, SAM = J.SAM, DRG = J.DRG, WAR = J.WAR, BST = J.BST,
    }

    -- Base sequence: mages first in the requested order, then melee.
    local TOP_GROUP_ORDER = { 'WHM', 'BLM', 'RDM', 'DRG', 'SAM', 'NIN', 'WAR', 'BST' }

    -- Determine which top-level groups are actually present this frame.
    -- A parent group is present if any of its children have a first_pos;
    -- a standalone group is present if it has a first_pos.
    local function parent_present(parent)
        for _, child in ipairs(child_groups_of(parent)) do
            if group_first_pos[child] then return true end
        end
        return false
    end
    local function group_present(g)
        if GROUP_PARENT[g] then return false end          -- child, not top-level
        if g == 'WHM' or g == 'BLM' then return parent_present(g) end
        return group_first_pos[g] ~= nil
    end

    -- Build the ordered list of present top-level groups.
    local ordered_groups = {}
    for _, g in ipairs(TOP_GROUP_ORDER) do
        if group_present(g) then ordered_groups[#ordered_groups + 1] = g end
    end

    -- Hoist the player's main-job group to the front.
    local main_job = ctx and ctx.job_info and tonumber(ctx.job_info.mainJob or 0) or 0
    if main_job ~= 0 then
        for idx, g in ipairs(ordered_groups) do
            if GROUP_JOB[g] == main_job then
                if idx > 1 then
                    table.remove(ordered_groups, idx)
                    table.insert(ordered_groups, 1, g)
                end
                break
            end
        end
    end

    -- 1) FOOD_BUFF at the very top.
    for li = 1, #lists do
        local list = lists[li]
        local v = visible[li]
        for i = 1, #list do
            if v[i] and list[i].id == 'FOOD_BUFF' then
                render_entry_body(list[i], ctx)
                imgui.Separator()
            end
        end
    end

    -- 2) Top-level job groups in the computed order.
    for _, g in ipairs(ordered_groups) do
        if g == 'WHM' or g == 'BLM' then
            if not rendered_parent[g] then
                render_parent_block(g, ctx)
                imgui.Separator()
            end
        else
            if not rendered_group[g] then
                render_group_block(g, ctx)
                imgui.Separator()
            end
        end
    end

    -- 3) Fallback: anything still unrendered, in source order. Covers
    --    standalone entries (other than FOOD_BUFF, already drawn) and any
    --    group not listed in TOP_GROUP_ORDER. Group members already drawn
    --    via their group/parent block are skipped by rendered_* flags and
    --    the _rendered_ids_this_frame dedup in render_entry_body.
    for li = 1, #lists do
        local list = lists[li]
        local v = visible[li]
        for i = 1, #list do
            if v[i] then
                local entry = list[i]
                if entry.id ~= 'FOOD_BUFF' then
                    local g = ENTRY_GROUP[entry.id]
                    if g then
                        local parent = GROUP_PARENT[g]
                        if parent then
                            if not rendered_parent[parent] then
                                render_parent_block(parent, ctx)
                                imgui.Separator()
                            end
                        else
                            if not rendered_group[g] then
                                render_group_block(g, ctx)
                                imgui.Separator()
                            end
                        end
                    else
                        -- EMERG_WARP's body is suppressed (drawn in the
                        -- Other collapse instead); don't emit its separator
                        -- either, or it leaves a phantom divider here.
                        if entry.id ~= 'EMERG_WARP' then
                            render_entry_body(entry, ctx)
                            imgui.Separator()
                        end
                    end
                end
            end
        end
    end
end

-- Backwards-compatible single-list wrapper (still used in places that pass
-- one list at a time, e.g. debug/preview panels).
local function render_ui_from_list(list, ctx)
    return render_ui_from_lists({ list }, ctx)
end

--------------------------------------------------------------------------------
-- DEBUG HELPERS
--------------------------------------------------------------------------------

local function player_can_use_shadows(ctx)
    if not ctx or not ctx.job_info then return false end
    local ji = ctx.job_info
    local nin = tonumber(GeneralLua.jobs and GeneralLua.jobs.NIN or 13) or 13
    local main_job = tonumber(ji.mainJob or 0) or 0
    local sub_job  = tonumber(ji.subJob  or 0) or 0
    local main_lv  = tonumber(ji.mainLv  or 0) or 0
    local sub_lv   = tonumber(ji.subLv   or 0) or 0

    if main_job == nin and main_lv >= 12 then return true end
    if sub_job == nin and sub_lv >= 12 then return true end
    return false
end

local function player_can_use_hb(ctx)
    if not ctx or not ctx.job_info then return false end
    local hb_shadows = rawget(_G, 'Hb_shadows') or Hb_shadows
    if hb_shadows and type(hb_shadows.hb_command) == 'function' then
        return hb_shadows.hb_command(S, rawget(_G, 'Hb_list')) ~= nil
    end
    return false
end

-- Maps each ladder entry id to its primary "auto.X" cfg toggle. Keep this
-- in sync with atk_list.lua / def_list.lua / general.lua ladder entries --
-- a missing id silently shows "Enabled: True" in the debug ladder
-- regardless of the actual toggle, which is exactly the bug the screenshot
-- caught (all enspells + spikes + food + stoneskin etc. reading True).
--
-- Compound toggles (HIGH_JUMP / SUPER_JUMP) require BOTH the parent
-- auto.jump AND their own sub-toggle, so they get explicit branches below
-- rather than table entries.
local DEBUG_AUTO_CFGKEY = {
    -- atk_list.lua
    JUMP         = 'auto.jump',
    FOOD_BUFF    = 'auto.food',
    DIA          = 'auto.dia',
    HASTE        = 'auto.haste',
    REFRESH      = 'auto.refresh',
    ENFIRE       = 'auto.enfire',
    ENBLIZZARD   = 'auto.enblizzard',
    ENAERO       = 'auto.enaero',
    ENSTONE      = 'auto.enstone',
    ENWATER      = 'auto.enwater',
    ENTHUNDER    = 'auto.enthunder',
    BLAZE_SPIKES = 'auto.blaze_spikes',
    ICE_SPIKES   = 'auto.ice_spikes',
    SHOCK_SPIKES = 'auto.shock_spikes',
    STONESKIN    = 'auto.stoneskin',
    BLINK        = 'auto.blink',
    PHALANX      = 'auto.phalanx',
    PARALYZE     = 'auto.paralyze',
    SLOW         = 'auto.slow',
    BLIND        = 'auto.blind',
    POISON       = 'auto.poison',
    STONE        = 'auto.stone',
    PROVOKE      = 'auto.provoke',
    BERSERK      = 'auto.berserk',
    WARCRY       = 'auto.warcry',
    THIRD_EYE    = 'auto.thirdeye',
    HASSO        = 'auto.hasso',
    MEDITATE     = 'auto.meditate',
    SEIGAN       = 'auto.seigan',
    CALL_WYVERN  = 'auto.callwyvern',
    SHADOWS      = 'auto.shadows',
    HB           = 'auto.hb',
    PET_FIGHT    = 'auto.petfight',
    PET_READY    = 'auto.ready',
    REWARD       = 'auto.reward',
    CALL_BEAST   = 'auto.callbeast',
    STEADY_WING  = 'auto.steadywing',
    SPIRIT_LINK  = 'auto.spiritlink',
    SLEEP_SNEAK  = 'thief.auto_sleep_sneak',
    -- general.lua
    WS           = 'auto.ws',
    RANGED       = 'auto.ranged',
    -- def_list.lua
    PROTECT      = 'auto.protect',
    SHELL        = 'auto.shell',
    CURE         = 'auto.cure',
    EMERG_WARP   = 'auto.warp',
}

local function debug_entry_enabled(entry_id)
    -- Compound toggles: child gated by parent JUMP toggle AND own sub-toggle.
    if entry_id == 'HIGH_JUMP' then
        return cfg_get('auto.jump') == true and cfg_get('auto.highjump') == true
    end
    if entry_id == 'SUPER_JUMP' then
        return cfg_get('auto.jump') == true and cfg_get('auto.superjump') == true
    end

    local cfgkey = DEBUG_AUTO_CFGKEY[entry_id]
    if cfgkey then
        return cfg_get(cfgkey) == true
    end

    -- Unknown id: default to false rather than true, so a missing mapping
    -- shows up as obviously off in the debug panel instead of pretending
    -- everything is enabled. Real toggles must be added to the table above.
    return false
end

-- Returns a status string describing why this entry isn't ready, in
-- priority order (No Tools > On Cooldown > Buff Found > Ready).
-- Situational gates (engaged, resting, spells_locked, ws_blocked, dist,
-- tp, hp, mp) are intentionally NOT surfaced -- they're noisy when the
-- player is standing around peacefully. Returns 'Ready' when only
-- situational gates remain (i.e. the entry would fire in combat).
local function debug_hb_ready(ctx)
    if not ctx then return 'Ready' end
    -- HB capability (DRG main + mage-capable sub) is enforced by the
    -- visibility filter, so if we're called here the player has tools.
    --
    -- Sub-state priorities:
    --   1. No Pet -- wyvern not present (dismissed/dead/never summoned).
    --      Most permanent block; nothing else matters if there's no
    --      wyvern to breathe.
    --   2. All Spells on CD -- the HB JA recast (state.hb.cast_until)
    --      is active. This is the dominant "On Cooldown"-style state
    --      after HB just fired (~14s recast at 75-cap).
    --   3. Player/Party HP Too High -- nobody needs HB. Player HP is
    --      above the auto.hb threshold AND no party member with low
    --      HP is in range (hb_party_hp_ok false).
    if ctx.pet_present ~= true then return 'No Pet' end
    local cast_until = tonumber(S.hb and S.hb.cast_until or 0) or 0
    if cast_until > 0 and now_sec() < cast_until then return 'All Spells on CD' end
    if ctx.hb_hp_ok ~= true and ctx.hb_party_hp_ok ~= true then
        return 'Player/Party HP Too High'
    end
    -- Fallback: HbShadows.hb_ready returns false for situational reasons
    -- (silence, sleep, in-cast lock, post-WS lockout, etc.) that we
    -- intentionally collapse to Ready -- they'll clear within seconds.
    if ctx.hb_ready ~= true then return 'Ready' end
    return 'Ready'
end

local function debug_shadows_ready(ctx)
    if not ctx then return 'Ready' end
    local shadows_mode = tostring(cfg_get('auto.shadows_mode') or 'atk')
    -- Capability for utsusemi is checked at visibility time via
    -- player_can_use_shadows(); if we're called, the player can cast it.
    -- shadows_can_attempt() combines "have a scroll equipped" + "recast
    -- ready" + "shadow count < max". The first half is a tools check,
    -- but distinguishing them from the outside is awkward; "On Cooldown"
    -- is the dominant case and accurate enough for v1.
    if not ctx.shadows_can_attempt then return 'Ready' end
    if ctx.shadows_can_attempt(shadows_mode, false) ~= true then
        -- shadow_count == max means utsusemi already up: "Buff Found".
        if (ctx.shadow_count or 0) > 0 then return 'Buff Found' end
        return 'On Cooldown'
    end
    return 'Ready'
end

-- Returns a status string for the debug ladder display, in priority
-- order: 'No Tools' > 'On Cooldown' > 'Buff Found' > 'Ready'.
--
-- - 'No Tools'   : fundamental capability blocked (wrong job/level,
--                  missing spell, no ranged weapon, etc.).
-- - 'On Cooldown': recast/JA timer not ready.
-- - 'Buff Found' : the effect we'd apply is already up (self buff or
--                  mob debuff). For Blink this also covers utsusemi
--                  shadows being up, which makes Blink redundant.
-- - 'Ready'      : would fire when situational conditions match.
--
-- Situational gates -- engaged, resting, spells_locked, ws_blocked,
-- dist, tp, hp, mp -- are intentionally NOT surfaced. Those are noise
-- when the player is standing around peacefully; an entry blocked
-- only by "not engaged" still shows 'Ready' here because it would
-- fire the moment combat starts.
-- Returns true if `entry_id` is currently sitting in any dispatch pool,
-- queue, or slot waiting to fire. Highest debug-status priority: when an
-- entry is queued, it has already passed every other check (req_ok,
-- eligible() including all the buff/cooldown/MP/HP gates), so reporting
-- any lower-priority status would be misleading.
local function debug_entry_is_queued(entry_id)
    local d = S and S.dispatch
    if not d or not entry_id then return false end

    local function match(slot)
        return slot and tostring(slot.id or '') == entry_id
    end
    if match(d.hb_slot) or match(d.ws_slot) or match(d.ra_slot) then
        return true
    end

    local function in_list(t)
        if not t then return false end
        for i = 1, #t do
            if match(t[i]) then return true end
        end
        return false
    end
    return in_list(d.ja_queue) or in_list(d.def_ja_queue) or in_list(d.def_pool) or in_list(d.atk_pool)
end

local function debug_entry_ready(entry, ctx)
    if not entry or not ctx then return 'Ready' end

    local id = tostring(entry.id or '')

    -- In Queue beats every other status -- the entry has already
    -- cleared eligible() and is waiting for the cast lock to open.
    if debug_entry_is_queued(id) then return 'In Queue' end

    if id == 'WS' then
        -- WS has no buff to check and no JA-style cooldown; TP/hp_ok
        -- are situational. The master toggle is enforced by the
        -- ladder filter, so just report Ready.
        return 'Ready'
    end

    if id == 'RANGED' then
        if ctx.ranged_no_weapon == true then return 'No Tools' end
        if ctx.ranged_plan then
            local plan = ctx.ranged_plan()
            if plan == 'none' then return 'No Tools' end
            if plan == 'hold' then return 'Debuff Found' end
        end
        return 'Ready'
    end

    if id == 'SLEEP_SNEAK' then
        -- Priority order mirrors atk_list.lua SLEEP_SNEAK.eligible().
        -- Situational gates (engaged/target_dead/spells_locked/ranged_busy/
        -- TP-over-800) collapse to Ready like the rest of the ladder.
        if ctx.ranged_weapon_ok ~= true then return 'No Tools' end
        local ammo = tostring(ctx.sleep_ammo_name or '')
        if ammo == '' then return 'No Tools' end
        if ctx.tool_missing and ctx.tool_missing(ammo) then return 'No Tools' end
        if ctx.sleep_ammo_equipped ~= true
           and ctx.sleep_ammo_available ~= true then
            return 'No Sleep Ammo'
        end
        if ctx.sneak_attack_ready and ctx.sneak_attack_ready() ~= true then
            return 'On Cooldown'
        end
        if ctx.target_has_debuff and ctx.target_has_debuff('sleep') then
            return 'Buff Found'
        end
        if ctx.target_has_waking_dot and ctx.target_has_waking_dot() then
            return 'Mob has DoT'
        end
        local hp_thresh = tonumber(cfg_get('thief.auto_sleep_sneak_hp') or 0) or 0
        if hp_thresh > 0 then
            local thp = tonumber(ctx.target_hp)
            if thp == nil or thp < hp_thresh then
                return string.format('HP < %d%%', hp_thresh)
            end
        end
        if type(ctx.ranged_plan) == 'function' then
            local plan = ctx.ranged_plan()
            if plan == 'blood' or plan == 'sleep'
               or plan == 'acid'  or plan == 'blind' then
                return 'Bolt Mode Wins'
            end
        end
        return 'Ready'
    end

    if id == 'HB' then
        return debug_hb_ready(ctx)
    end

    if id == 'SHADOWS' then
        return debug_shadows_ready(ctx)
    end

    if id == 'DIA' or id == 'PARALYZE' or id == 'SLOW' or id == 'BLIND' then
        -- The DIA entry covers both Dia and Bio under one ladder slot;
        -- the debug-ready indicator should reflect whichever family the
        -- user currently has picked via dia_tier (1/2 = Dia, 3/4 = Bio),
        -- not always 'DIA'. Other debuff entries map 1:1 to their id.
        local debuff_id = id
        if id == 'DIA' then
            local tier = tonumber(cfg_get('dia_tier') or 1) or 1
            if tier == 3 or tier == 4 then debuff_id = 'BIO' end
        end

        -- Split the three sub-cases that the impl collapses into a single
        -- false return from mob_debuff_ready. Priority:
        --   1. Debuff Found    -- mob already has the debuff (dominant case).
        --   2. On Cooldown     -- our own cast is in flight (pending, <12s).
        --                         The 12s window matches the impl's stale-
        --                         pending threshold; older pending entries
        --                         are treated as ready by the impl, so
        --                         we treat them the same here for parity.
        --   3. No Target Found -- no first-attack-seen for any mob, or
        --                         tracked target server_id/index both 0.
        -- 1. Debuff on mob?
        if ctx.target_has_debuff and ctx.target_has_debuff(string.lower(debuff_id)) then
            return 'Debuff Found'
        end

        -- 2. In-flight pending cast?
        local md = S.combat and S.combat.mob_debuffs
        if md and md.pending and md.pending.id == debuff_id then
            local sent_at = tonumber(md.pending.sent_at or 0.0) or 0.0
            if sent_at > 0.0 and (now_sec() - sent_at) <= 12.0 then
                return 'On Cooldown'
            end
        end

        -- 3. No target / no fight started?
        if not md or md.first_atk_seen ~= true then
            return 'No Target Found'
        end
        local sid = tonumber(md.target_server_id or 0) or 0
        local idx = tonumber(md.target_index or 0) or 0
        if sid == 0 and idx == 0 then
            return 'No Target Found'
        end

        return 'Ready'
    end

    if id == 'PROTECT' then
        if ctx.can_use_protect ~= true then return 'No Tools' end
        if ctx.best_protect_spell == nil then return 'No Tools' end
        if ctx.self_protect_active == true then return 'Buff Found' end
        if ctx.has_spell_mp and ctx.has_spell_mp(ctx.best_protect_spell) ~= true then
            return 'Not Enough MP'
        end
        return 'Ready'
    end

    if id == 'SHELL' then
        if ctx.can_use_shell ~= true then return 'No Tools' end
        if ctx.best_shell_spell == nil then return 'No Tools' end
        if ctx.self_shell_active == true then return 'Buff Found' end
        if ctx.has_spell_mp and ctx.has_spell_mp(ctx.best_shell_spell) ~= true then
            return 'Not Enough MP'
        end
        return 'Ready'
    end

    if id == 'CURE' then
        -- Capability/inventory: no cure spell available (sub-level too
        -- low to know any of them, or main isn't a healer at all).
        if ctx.can_use_cure ~= true then return 'No Tools' end
        if ctx.best_cure_spell == nil then return 'No Tools' end
        -- MP check uses the SPECIFIC best_cure_spell so the threshold
        -- matches what we'd actually try to cast (Cure VI's MP need is
        -- different from Cure I's). Sits above HP because "would heal
        -- if you had MP" is more actionable than "would heal if you
        -- were hurt enough".
        if ctx.has_spell_mp and ctx.has_spell_mp(ctx.best_cure_spell) ~= true then
            return 'Not Enough MP'
        end
        if ctx.cure_hp_ok ~= true then return 'Player HP Too High' end
        return 'Ready'
    end

    if id == 'BERSERK' then
        if ctx.buff_active and ctx.buff_active('Berserk') then return 'Buff Found' end
        if ctx.is_ready('BERSERK') ~= true then return 'On Cooldown' end
        -- ws_hp_ok / TP gates: Berserk and Warcry are WS-prep JAs that
        -- fire in the window where we're about to WS. If the mob is
        -- too healthy to WS yet, or we don't have enough TP for the
        -- impending WS, the JA is held. Surface both so the user can
        -- tell which is the active blocker (mob HP first because it's
        -- usually the slower-to-change gate -- TP fills faster than
        -- mob HP drops).
        if ctx.ws_hp_ok ~= true then return 'Mob HP Too High' end
        if (tonumber(ctx.tp or 0) or 0) < 1000 then return 'TP Too Low' end
        return 'Ready'
    end

    if id == 'PROVOKE' then
        if ctx.is_ready('PROVOKE') ~= true then return 'On Cooldown' end
        return 'Ready'
    end

    if id == 'WARCRY' then
        if ctx.buff_active and ctx.buff_active('Warcry') then return 'Buff Found' end
        if ctx.is_ready('WARCRY') ~= true then return 'On Cooldown' end
        if ctx.ws_hp_ok ~= true then return 'Mob HP Too High' end
        if (tonumber(ctx.tp or 0) or 0) < 1000 then return 'TP Too Low' end
        return 'Ready'
    end

    if id == 'HASSO' then
        if ctx.self_hasso_active == true then return 'Buff Found' end
        if ctx.is_ready('HASSO') ~= true then return 'On Cooldown' end
        return 'Ready'
    end

    if id == 'SEIGAN' then
        if ctx.self_seigan_active == true then return 'Buff Found' end
        if ctx.is_ready('SEIGAN') ~= true then return 'On Cooldown' end
        return 'Ready'
    end

    if id == 'THIRD_EYE' then
        if ctx.self_thirdeye_active == true then return 'Buff Found' end
        if ctx.is_ready('THIRD_EYE') ~= true then return 'On Cooldown' end
        return 'Ready'
    end

    if id == 'MEDITATE' then
        if ctx.is_ready('MEDITATE') ~= true then return 'On Cooldown' end
        -- Meditate is a TP-gen JA, only useful when we're below cap.
        -- "TP Too High" reads naturally as "you're already at WS range,
        -- save the Meditate for after this WS".
        if (tonumber(ctx.tp or 0) or 0) >= 1000 then return 'TP Too High' end
        return 'Ready'
    end

    if id == 'STONESKIN' then
        -- Capability for Stoneskin is checked by entry.req at the
        -- ladder-filter step (req_ok), so if we're called the player
        -- has the spell.
        if ctx.self_stoneskin_active == true then return 'Buff Found' end
        if ctx.is_ready('STONESKIN') ~= true then return 'On Cooldown' end
        if ctx.has_spell_mp and ctx.has_spell_mp('Stoneskin') ~= true then
            return 'Not Enough MP'
        end
        return 'Ready'
    end

    if id == 'BLINK' then
        -- Same capability/MP logic as Stoneskin. Blink additionally
        -- treats utsusemi shadows being up (or auto.shadows about to
        -- fire) as the buff-equivalent because the eligible() function
        -- defers to shadows in that case -- the user sees one of the
        -- two "shadow-class" protections up, which is the win state.
        if ctx.self_blink_active == true then return 'Buff Found' end
        local mode = tostring(cfg_get('auto.blink_mode') or 'def')
        local shadows_block =
            ((ctx.shadow_count or 0) > 0)
            or (cfg_get('auto.shadows') == true
                and ctx.shadows_can_attempt
                and ctx.shadows_can_attempt(mode) == true)
        if shadows_block then return 'Buff Found' end
        if ctx.is_ready('BLINK') ~= true then return 'On Cooldown' end
        if ctx.has_spell_mp and ctx.has_spell_mp('Blink') ~= true then
            return 'Not Enough MP'
        end
        return 'Ready'
    end

    if id == 'PHALANX' then
        if ctx.self_phalanx_active == true then return 'Buff Found' end
        if ctx.is_ready('PHALANX') ~= true then return 'On Cooldown' end
        if ctx.has_spell_mp and ctx.has_spell_mp('Phalanx') ~= true then
            return 'Not Enough MP'
        end
        return 'Ready'
    end

    if id == 'JUMP' or
       id == 'HIGH_JUMP' or
       id == 'SUPER_JUMP' or
       id == 'CALL_WYVERN'
    then
        if ctx.is_ready(id) ~= true then return 'On Cooldown' end
        return 'Ready'
    end

    -- Default for entries without a custom branch: assume ready.
    -- Better to show "Ready" than spurious "False" -- the entry is in
    -- the ladder, the user enabled it, situational gating will sort
    -- the rest out at fire time.
    return 'Ready'
end

local function debug_entry_belongs_in_atk(entry)
    if not entry or not entry.id then return false end
    local id = tostring(entry.id)

    if id == 'SHADOWS' then
        return tostring(cfg_get('auto.shadows_mode') or 'atk') == 'atk'
    end
    if id == 'HB' then
        return tostring(cfg_get('auto.hb_mode') or 'atk') == 'atk'
    end
    -- Stoneskin/Blink use the same single-string-mode pattern as SHADOWS/HB
    -- (one source of truth, set by the radio buttons in render_mode_controls_
    -- for_entry). The mode string defaults to 'def' on first run -- if a
    -- player wipes the cfg, Stoneskin/Blink appear only on the Def Ladder
    -- until they pick a side, which matches the default GUI state.
    if id == 'STONESKIN' then
        return tostring(cfg_get('auto.stoneskin_mode') or 'def') == 'atk'
    end
    if id == 'BLINK' then
        return tostring(cfg_get('auto.blink_mode') or 'def') == 'atk'
    end
    if id == 'PHALANX' then
        return tostring(cfg_get('auto.phalanx_mode') or 'def') == 'atk'
    end
    if id == 'CALL_WYVERN' then
        return false
    end
    if id == 'SUPER_JUMP' then
        return false
    end
    if id == 'PROTECT' or id == 'SHELL' or id == 'CURE' or id == 'EMERG_WARP' then
        return false
    end

    return true
end

local function debug_entry_belongs_in_def(entry)
    if not entry or not entry.id then return false end
    local id = tostring(entry.id)

    if id == 'SHADOWS' then
        return tostring(cfg_get('auto.shadows_mode') or 'atk') == 'def'
    end
    if id == 'HB' then
        return tostring(cfg_get('auto.hb_mode') or 'atk') == 'def'
    end
    if id == 'STONESKIN' then
        return tostring(cfg_get('auto.stoneskin_mode') or 'def') == 'def'
    end
    if id == 'BLINK' then
        return tostring(cfg_get('auto.blink_mode') or 'def') == 'def'
    end
    if id == 'PHALANX' then
        return tostring(cfg_get('auto.phalanx_mode') or 'def') == 'def'
    end
    if id == 'THIRD_EYE' then
        return tostring(cfg_get('auto.thirdeye_mode') or 'atk') == 'def'
    end
    if id == 'SEIGAN' then
        return tostring(cfg_get('auto.seigan_mode') or 'atk') == 'def'
    end
    if id == 'CALL_WYVERN' then
        return true
    end
    if id == 'SUPER_JUMP' then
        return true
    end
    if id == 'PROTECT' or id == 'SHELL' or id == 'CURE' or id == 'EMERG_WARP' then
        return true
    end

    return false
end

local function build_real_current_atk_debug_list(ctx)
    local out = {}

    local function add_from(list)
        for i = 1, #list do
            local entry = list[i]
            if entry and entry.id and GeneralLua.utils.req_ok(entry.req, ctx and ctx.job_info) and debug_entry_belongs_in_atk(entry) then
                out[#out + 1] = entry
            end
        end
    end

    add_from(atk_list)
    add_from(general_list)

    table.sort(out, function(a, b)
        return tonumber(a.priority or 99999) < tonumber(b.priority or 99999)
    end)

    return out
end

local function build_real_current_def_debug_list(ctx)
    local out = {}

    for i = 1, #def_list do
        local entry = def_list[i]
        if entry and entry.id and GeneralLua.utils.req_ok(entry.req, ctx and ctx.job_info) and debug_entry_belongs_in_def(entry) then
            out[#out + 1] = entry
        end
    end

    table.sort(out, function(a, b)
        return tonumber(a.priority or 99999) < tonumber(b.priority or 99999)
    end)

    return out
end

-- Pretty display name for each ladder entry. Falls back to the raw id
-- if missing -- but every known entry should be in this table so the
-- debug ladder is human-readable. Keep keys in sync with DEBUG_AUTO_CFGKEY
-- and the ladder entries themselves.
local DEBUG_PRETTY_NAME = {
    -- atk_list.lua
    JUMP         = 'Jump',
    HIGH_JUMP    = 'High Jump',
    SUPER_JUMP   = 'Super Jump',
    FOOD_BUFF    = 'Food Buff',
    DIA          = 'Dia',
    HASTE        = 'Haste',
    REFRESH      = 'Refresh',
    ENFIRE       = 'Enfire',
    ENBLIZZARD   = 'Enblizzard',
    ENAERO       = 'Enaero',
    ENSTONE      = 'Enstone',
    ENWATER      = 'Enwater',
    ENTHUNDER    = 'Enthunder',
    BLAZE_SPIKES = 'Blaze Spikes',
    ICE_SPIKES   = 'Ice Spikes',
    SHOCK_SPIKES = 'Shock Spikes',
    STONESKIN    = 'Stoneskin',
    BLINK        = 'Blink',
    PHALANX      = 'Phalanx',
    PARALYZE     = 'Paralyze',
    SLOW         = 'Slow',
    BLIND        = 'Blind',
    POISON       = 'Poison',
    STONE        = 'Stone',
    PROVOKE      = 'Provoke',
    BERSERK      = 'Berserk',
    WARCRY       = 'Warcry',
    THIRD_EYE    = 'Third Eye',
    HASSO        = 'Hasso',
    MEDITATE     = 'Meditate',
    SEIGAN       = 'Seigan',
    CALL_WYVERN  = 'Call Wyvern',
    SHADOWS      = 'Shadows',
    HB           = 'Healing Breath',
    PET_FIGHT    = 'Pet Fight',
    PET_READY    = 'Pet Ready',
    REWARD       = 'Reward',
    CALL_BEAST   = 'Call Beast',
    STEADY_WING  = 'Steady Wing',
    SPIRIT_LINK  = 'Spirit Link',
    -- general.lua
    WS           = 'Weapon Skill',
    RANGED       = 'Ranged',
    -- def_list.lua
    PROTECT      = 'Protect',
    SHELL        = 'Shell',
    CURE         = 'Cure',
}

local function debug_pretty_name(entry_id)
    return DEBUG_PRETTY_NAME[entry_id] or tostring(entry_id)
end

local function render_debug_real_ladder(title, list, ctx)
    imgui.Text(title)

    if not list or #list == 0 then
        imgui.Text('(empty)')
        return
    end

    -- Filter to enabled-only. With ~40 entries the unfiltered list buried
    -- the few that actually matter; showing every disabled entry's status
    -- line was noise. After filtering we drop the "Enabled: True" column
    -- itself -- every visible row is enabled by construction. The status
    -- column now shows one of {Ready, No Tools, On Cooldown, Buff Found}
    -- via debug_entry_ready -- situational gates (engaged/ws/dist/tp/mp)
    -- collapse to Ready so the panel stays useful while standing around.
    local shown = 0
    for i = 1, #list do
        local entry = list[i]
        if debug_entry_enabled(entry.id) then
            shown = shown + 1
            local status = debug_entry_ready(entry, ctx)
            local pri = tonumber(entry.priority or 99999) or 99999
            imgui.Text(string.format('%s (%d)   Ready: %s',
                debug_pretty_name(entry.id),
                pri,
                tostring(status or 'Ready')))
        end
    end

    if shown == 0 then
        imgui.Text('(none enabled)')
    end
end

local function render_debug_ws_details(ctx)
    if not ctx then return end

    imgui.Text(string.format('WS Blocked: %s', (ctx.ws_blocked == true) and 'True' or 'False'))
end

local function render_debug_session_state()
    imgui.Separator()
    imgui.Text('Dispatch Pools')

    local d = S and S.dispatch
    local function pool_str(p)
        if not p or #p == 0 then return '(empty)' end
        local parts = {}
        for i = 1, #p do
            local w = tonumber(p[i].weight or 1) or 1
            parts[#parts + 1] = string.format('%s(w%d)', tostring(p[i].id or '?'), w)
        end
        return table.concat(parts, ', ')
    end
    local function slot_str(s)
        return s and tostring(s.id or '?') or '(empty)'
    end

    if d then
        imgui.Text(string.format('HB:  %s', slot_str(d.hb_slot)))
        imgui.Text(string.format('JA:  %s', pool_str(d.ja_queue)))
        imgui.Text(string.format('WS:  %s', slot_str(d.ws_slot)))
        imgui.Text(string.format('RA:  %s', slot_str(d.ra_slot)))
        imgui.Text(string.format('DEF: %s', pool_str(d.def_pool)))
        imgui.Text(string.format('DEF JA: %s', pool_str(d.def_ja_queue)))
        imgui.Text(string.format('ATK: %s', pool_str(d.atk_pool)))

        -- Def stale watchdog countdown: shows seconds until the def pool
        -- would be force-cleared (10s with no fire / fresh queue). Only
        -- meaningful while def_pool is non-empty.
        if d.def_pool and #d.def_pool > 0 then
            local prog = tonumber(d.def_progress_at or 0) or 0
            if prog > 0 then
                local elapsed = os.clock() - prog
                local remain = 10.0 - elapsed
                if remain < 0 then remain = 0 end
                imgui.Text(string.format('DEF stale-clear in: %.1fs', remain))
            end
        end
    else
        imgui.Text('(dispatch state uninitialized)')
    end

    imgui.Text(string.format('ATK Seq/Seen: %s / %s',
        tostring((S.combat and S.combat.atk_round_seq) or '--'),
        tostring((S.combat and S.combat.atk_round_seen) or '--')))
    imgui.Text(string.format('DEF Seq/Seen: %s / %s',
        tostring((S.combat and S.combat.def_round_seq) or '--'),
        tostring((S.combat and S.combat.def_round_seen) or '--')))

    imgui.Text(string.format('Last Attempted ID: %s', tostring((S.combat and S.combat.last_attempted_action_id) or '--')))
    imgui.Text(string.format('Last Attempted Name: %s', tostring((S.combat and S.combat.last_attempted_action_name) or '--')))
    imgui.Text(string.format('Last Attempted Kind: %s', tostring((S.combat and S.combat.last_attempted_action_kind) or '--')))
end

-- (render_debug_mode_readiness removed: HB and Shadows used to render
-- as standalone "Shadows (Def) Ready: X" lines beneath the ladder, but
-- they're full ladder entries now -- the standalone line duplicated the
-- ladder row. The mode-aware filtering it did is now handled by
-- debug_entry_belongs_in_atk / debug_entry_belongs_in_def at ladder-
-- build time, so the entry only appears in the matching panel.)

local function render_debug_target_debuffs(ctx)
    local target_sid = nil
    if ctx and ctx.target_server_id ~= nil then
        target_sid = ctx.target_server_id
    elseif S.live and S.live.player_target_server_id ~= nil then
        target_sid = S.live.player_target_server_id
    end

    imgui.Text(string.format('Target SID: %s', tostring(target_sid or '--')))

    -- DebuffHandler liveness + per-target probe. Count is restricted to
    -- CLAIMED mobs only (hate on party) by walking state.all_claimed_targets
    -- and mapping each entity index to its server ID, mirroring the
    -- enemylist filter pattern. Tells us at a glance whether the handler
    -- is loaded AND how many hate-mobs currently carry tracked debuffs.
    do
        local dh = rawget(_G, 'DebuffHandler')
        if not dh then
            imgui.TextColored({1.0, 0.4, 0.4, 1.0}, 'DebuffHandler: NOT LOADED')
        elseif type(dh.GetActiveDebuffs) ~= 'function' then
            imgui.TextColored({1.0, 0.4, 0.4, 1.0}, 'DebuffHandler: loaded, GetActiveDebuffs missing')
        else
            local claimed_with_debuffs = 0
            local claimed_total = 0
            local claimed = S.all_claimed_targets
            if claimed and dh.enemies then
                for idx, _ in pairs(claimed) do
                    claimed_total = claimed_total + 1
                    local ent = get_entity(idx)
                    local sid = ent and tonumber(ent.ServerId or 0) or 0
                    if sid > 0 then
                        local row = dh.enemies[sid]
                        if row then
                            local now = os.time()
                            for _, v in pairs(row) do
                                if v ~= 0 and v > now then
                                    claimed_with_debuffs = claimed_with_debuffs + 1
                                    break
                                end
                            end
                        end
                    end
                end
            end
            imgui.Text(string.format('Hate mobs: %d  with debuffs: %d',
                claimed_total, claimed_with_debuffs))

            if target_sid then
                local row = dh.enemies and dh.enemies[target_sid]
                if row then
                    local now = os.time()
                    local active_count = 0
                    local id_str = ''
                    for k, v in pairs(row) do
                        if v ~= 0 and v > now then
                            active_count = active_count + 1
                            id_str = id_str .. tostring(k) .. ' '
                        end
                    end
                    imgui.Text(string.format('  this mob: %d active', active_count))
                    if active_count > 0 then
                        imgui.Text('  ids: ' .. id_str)
                    end
                else
                    imgui.Text('  this mob: no row yet')
                end
            end
        end
    end

    local ids = (S.live and S.live.target_debuff_ids) or T{}
    local names = (S.live and S.live.target_debuff_names) or T{}

    if not ids or #ids == 0 then
        imgui.Text('Live (cached): (none)')
    else
        local shown = math.min(#ids, 6)
        imgui.Text(string.format('Live (cached): %d/%d', shown, #ids))

        for i = 1, shown do
            local id = tostring(ids[i] or '--')
            local name = tostring(names[i] or ('id:' .. id))
            if #name > 24 then
                name = name:sub(1, 24) .. '...'
            end
            imgui.Text(string.format('  %s  %s', id, name))
        end

        if #ids > shown then
            imgui.Text(string.format('  ... %d more', #ids - shown))
        end
    end
end

local function render_debug_tracked_target()
    local md = S.combat and S.combat.mob_debuffs
    if not md then
        imgui.Text('Tracked Pending: (none)')
        return
    end

    imgui.Text(string.format('Tracked Target SID/Idx: %s / %s',
        tostring(md.target_server_id or '--'),
        tostring(md.target_index or '--')))
    imgui.Text(string.format('First ATK Seen: %s', md.first_atk_seen and 'True' or 'False'))

    local pending = md.pending or {}
    imgui.Text('Pending Cast:')
    imgui.Text(string.format('  id: %s', tostring(pending.id or '--')))
    imgui.Text(string.format('  spell: %s', tostring(pending.spell_name or '--')))
    imgui.Text(string.format('  sid/idx: %s / %s',
        tostring(pending.target_server_id or '--'),
        tostring(pending.target_index or '--')))
    imgui.Text(string.format('  sent_at: %s', tostring(pending.sent_at or '--')))
end

-- "Other (Emergency)" collapse: hand-drawn home for the two panic-button
-- features -- Emergency Warp (logic lives in def_list's EMERG_WARP entry;
-- its ladder UI is suppressed in render_entry_body) and Auto Antidote.
local function render_other_emergency(ctx)
    if not imgui.CollapsingHeader('Other (Emergency)') then return end

    -- Emergency Warp: checkbox + HP-threshold radio inline. cfg keys
    -- unchanged (auto.warp / warp_hp) so the def_list entry still fires.
    ui_checkbox('E. Warp', 'auto.warp')
    imgui.SameLine()
    ui_radio3('warp_hp', '5%##warp', 5, '10%##warp', 10, '15%##warp', 15)

    -- Auto Antidote: /item "Antidote" <me> when poisoned + HP<25% + free.
    ui_checkbox('Auto Antidote', 'auto.antidote')

    -- Debug toggle relocated here from the header row.
    local dbg_enabled = { S.ui.debug_enabled == true }
    if imgui.Checkbox('Debug##dbg', dbg_enabled) then
        cfg.debug.enabled = dbg_enabled[1]
        S.ui.debug_enabled = dbg_enabled[1]
        settings.save()
    end
end

local function render_debug(ctx)
    if not S.ui.debug_enabled then return end

    local has_pet = (S.live and S.live.player_pet_hp ~= nil)
    local show_shadows_debug = player_can_use_shadows(ctx)

    local ji = ctx and ctx.job_info
    local main_job = ji and tonumber(ji.mainJob or 0) or 0
    local sub_job  = ji and tonumber(ji.subJob  or 0) or 0
    local is_bst = (main_job == 9  or sub_job == 9)
    local is_drg = (main_job == 14 or sub_job == 14)

    imgui.Separator()

    -- Program Debug -- bot-level state (paused, ranged-no-weapon, test-w, spells lock).
    if imgui.CollapsingHeader('Program Debug##debug_program', ImGuiTreeNodeFlags_DefaultOpen) then
        imgui.Text(string.format('Paused: %s', (cfg.auto and cfg.auto.paused) and 'True' or 'False'))
        imgui.Text(string.format('Ranged No Weapon: %s', (S.flags and S.flags.player_ranged_no_weapon) and 'True' or 'False'))
        do
            -- Raw skill read, so a binding mismatch is visible here instead of
            -- showing up as a mysteriously unfiltered dropdown.
            local ms = S.live and S.live.main_weapon_skill or nil
            local rs = S.live and S.live.ranged_weapon_skill or nil
            imgui.Text(string.format('Skill (main %s): %s',
                tostring(ms or '--'),
                tostring((ms and player_combat_skill(ms)) or 'unreadable')))
            imgui.Text(string.format('Skill (ranged %s): %s',
                tostring(rs or '--'),
                tostring((rs and player_combat_skill(rs)) or 'unreadable')))
            local mj, sj = player_jobs()
            imgui.Text(string.format('Job: %s/%s',
                tostring(mj or 'unreadable'), tostring(sj or '--')))

            -- RANGED CADENCE. Mirrors ranged_recast_sec in general.lua from
            -- the same two live ids, so this line says whether the shot
            -- interval is the WEAPON's real delay or the 3.5s fallback that
            -- gets used when the launcher cannot be looked up. Those look
            -- identical from inside the game (~3s either way) and need
            -- completely different fixes, which is the whole reason this is
            -- on screen.
            do
                local rid = S.live and S.live.ranged_weapon_id or nil
                local aid = S.live and S.live.equipped_ammo_id or nil
                local ok, secs = pcall(WeaponDB.ranged_delay_sec, rid, aid)
                secs = ok and tonumber(secs) or nil

                local raw = rid and WeaponDB.delay_of(rid) or nil
                local nm  = rid and WeaponDB.name_of(rid) or nil

                if secs and secs > 0 then
                    imgui.Text(string.format('RA recast: %.2fs  (%s delay %s / 120 + %.1f free phase)',
                        secs + 0.5, tostring(nm or '?'), tostring(raw or '?'), 0.5))
                else
                    imgui.TextColored({ 1.0, 0.6, 0.3, 1.0 },
                        string.format('RA recast: 3.50s FALLBACK (launcher id %s not resolved)',
                            tostring(rid or 'nil')))
                end

                -- WHY IT IS NOT SHOOTING. Every early return in
                -- ranged_mode_step labels itself; this is that label. If the
                -- character is standing still doing nothing, this line names
                -- the gate responsible instead of leaving it to guesswork.
                local blk = S.live and S.live.rangedmode_block or nil
                if blk == 'FIRED' then
                    imgui.TextColored({ 0.6, 1.0, 0.6, 1.0 }, 'Ranged gate: FIRED')
                else
                    imgui.TextColored({ 1.0, 0.85, 0.4, 1.0 },
                        'Ranged gate: ' .. tostring(blk or '(loop not running)'))
                end

                -- Standoff filler activity. A frozen ladder and a ladder with
                -- nothing to do are indistinguishable on screen, so count the
                -- synthetic atk events and show how long since the last one.
                local n_refill = tonumber(S.live and S.live.standoff_refills or 0) or 0
                local last     = tonumber(S.live and S.live.standoff_refill_last or 0) or 0
                imgui.Text(string.format('Standoff filler: %d refills, last %s',
                    n_refill,
                    last > 0 and string.format('%.1fs ago', now_sec() - last) or 'never'))
            end
        end
        do
            local last_kill = tonumber(S.combat and S.combat.last_kill_at or 0) or 0
            if last_kill > 0 then
                local rem = 1.5 - (os.clock() - last_kill)
                if rem > 0 then
                    imgui.Text(string.format('Post-Kill Block: %.1fs', rem))
                else
                    imgui.Text('Post-Kill Block: idle')
                end
            else
                imgui.Text('Post-Kill Block: idle')
            end
        end

        if movement and type(movement.test_w_remaining) == 'function' then
            local rem = tonumber(movement.test_w_remaining() or 0.0) or 0.0
            local active = rem > 0.0
            imgui.Text(string.format('Test W Active: %s (%.2fs)', active and 'True' or 'False', rem))
        end
        if movement and type(movement.start_test_w) == 'function' then
            if imgui.Button('Test W##debug_test_w') then
                movement.start_test_w()
            end
        end
    end

    -- Player Status -- live entity stats and buffs.
    if imgui.CollapsingHeader('Player Status##debug_player') then
        imgui.Text(string.format('Player Status: %s', tostring(S.live.player_status or '--')))
        imgui.Text(string.format('Pattern: %s', tostring(S.cached_player_pat or '--')))
        imgui.Text(string.format('HP: %s', tostring(S.live.player_hp or '--')))
        imgui.Text(string.format('MP: %s', tostring(S.live.player_mp or '--')))
        do
            -- Home = where the bot was started (or last Rehome). Auto-target
            -- measures from here unless Disable Home is ticked.
            local hx, hy, hz
            if IdleRestEngage and type(IdleRestEngage.get_home) == 'function' then
                hx, hy, hz = IdleRestEngage.get_home(S)
            end
            if hx == nil then
                imgui.TextDisabled('Home: (not set)')
            else
                local tag = (cfg_get('home.disabled') == true) and ' [DISABLED]' or ''
                imgui.Text(string.format('Home X %.1f  Y %.1f  Z %.1f%s', hx, hy, hz or 0, tag))
            end
        end
        do
            local px = S.live and S.live.player_x
            local py = S.live and S.live.player_y
            local pz = S.live and S.live.player_z
            if px and py and pz then
                imgui.Text(string.format('Pos: %.2f, %.2f, %.2f', px, py, pz))
            else
                imgui.Text('Pos: --')
            end

            -- Player heading via the entity_heading helper (tries the
            -- field names Ashita v4 varies between). Shows '?' if none
            -- matched on this build.
            local ph = nil
            do
                local ok, ply = pcall(GetPlayerEntity)
                if ok and ply then ph = GeneralLua.utils.entity_heading(ply) end
            end
            if ph then
                imgui.Text(string.format('Player Heading: %.3f rad (%.1f deg)', ph, math.deg(ph)))
            else
                imgui.Text('Player Heading: ?')
            end

            -- Target position + heading, on the same read pattern.
            local t_idx = tonumber(S.live and S.live.player_target_index or 0) or 0
            if t_idx > 0 then
                local ok_t, ent = pcall(GeneralLua.utils.get_entity, t_idx)
                if ok_t and ent then
                    local tx, ty, tz = GeneralLua.utils.entity_position(ent)
                    local th = GeneralLua.utils.entity_heading(ent)
                    if tx and ty and tz then
                        imgui.Text(string.format('Target Pos: %.2f, %.2f, %.2f', tx, ty, tz))
                    else
                        imgui.Text('Target Pos: --')
                    end
                    if th then
                        imgui.Text(string.format('Target Heading: %.3f rad (%.1f deg)', th, math.deg(th)))
                    else
                        imgui.Text('Target Heading: ?')
                    end
                else
                    imgui.Text('Target Pos: --')
                    imgui.Text('Target Heading: --')
                end
            else
                imgui.Text('Target Pos: --')
                imgui.Text('Target Heading: --')
            end
        end
        imgui.Text(string.format('Target Dist: %s', tostring(S.live.player_target_distance or '--')))
        imgui.Text(string.format('Target HP: %s (prev: %s)', tostring(S.live.player_target_hp or '--'), tostring(S.live.player_target_hp_prev or '--')))
        imgui.Text(string.format('Target Valid: %s', (S.live.player_target_valid == true) and 'True' or 'False'))
        imgui.Text(string.format('Target Dead (ctx): %s', (ctx and ctx.target_dead == true) and 'True' or 'False'))
        imgui.Text(string.format('Target SID: %s (prev: %s)',
            tostring(S.live.player_target_server_id or '--'),
            tostring(S.live.player_target_sid_prev or '--')))
        imgui.Text(string.format('Food Buff: %s', (ctx and ctx.has_food) and 'food found' or 'food not found'))
        if ctx and type(ctx.player_buff_ids) == 'table' then
            local list = ctx.player_buff_ids
            if #list == 0 then
                imgui.Text('Player Buffs: (none seen)')
            else
                imgui.Text(string.format('Player Buffs: %s', table.concat(list, ', ')))
            end
        end
        if ctx then
            local J = GeneralLua.jobs or {}
            local ji = ctx.job_info or {}
            local mj = tonumber(ji.mainJob or 0) or 0
            local sj = tonumber(ji.subJob or 0) or 0
            local function hasj(j) return j ~= nil and (mj == j or sj == j) end

            -- Only show what the current job can actually use. Wrapped 3/line.
            local flags = {}
            if ctx.cap_shadows then
                flags[#flags + 1] = 'shadow=' .. tostring(ctx.shadow_count or 0)
            end
            if hasj(J.SAM) then
                flags[#flags + 1] = 'hasso='     .. tostring(ctx.self_hasso_active)
                flags[#flags + 1] = 'seigan='    .. tostring(ctx.self_seigan_active)
                flags[#flags + 1] = 'third_eye=' .. tostring(ctx.self_thirdeye_active)
            end
            if hasj(J.RDM) then
                flags[#flags + 1] = 'blink=' .. tostring(ctx.self_blink_active)
            end
            if hasj(J.WHM) or hasj(J.RDM) then
                flags[#flags + 1] = 'stoneskin=' .. tostring(ctx.self_stoneskin_active)
            end
            if ctx.can_use_protect then
                flags[#flags + 1] = 'protect=' .. tostring(ctx.self_protect_active)
            end
            if ctx.can_use_shell then
                flags[#flags + 1] = 'shell=' .. tostring(ctx.self_shell_active)
            end

            if #flags > 0 then
                imgui.Text('Stance flags:')
                for i = 1, #flags, 3 do
                    local row = {}
                    for j = i, math.min(i + 2, #flags) do row[#row + 1] = flags[j] end
                    imgui.Text('  ' .. table.concat(row, '   '))
                end
            end
        end
        do
            local mw_id = get_main_weapon_id()
            if mw_id then
                local skill = WeaponDB.skill_of(mw_id)
                local name  = WeaponDB.name_of(mw_id)
                imgui.Text(string.format('Main weapon: id=%d  name=%s  skill=%s',
                    mw_id,
                    tostring(name or '?'),
                    tostring(skill or 'unknown (not in weapon_db)')))
            else
                imgui.Text('Main weapon: (none equipped)')
            end
        end
    end

    -- Casting Status.
    if imgui.CollapsingHeader('Casting Status##debug_casting') then
        imgui.Text(string.format('Is Casting: %s', (S.combat and S.combat.is_casting) and 'True' or 'False'))
        imgui.Text(string.format('Current Spell: %s', tostring((S.combat and S.combat.current_spell) or '--')))
        imgui.Text(string.format('Spells Locked: %s', (ctx and ctx.spells_locked) and 'True' or 'False'))
    end

    -- Beastmaster Debug.
    if is_bst then
        if imgui.CollapsingHeader('Beastmaster Debug##debug_bst') then
            imgui.Text(string.format('Has Pet: %s', has_pet and 'True' or 'False'))
            if has_pet then
                imgui.Text(string.format('PetHP: %s', tostring(S.live.player_pet_hp or '--')))
                imgui.Text(string.format('Pet Charges: %s', tostring(S.live.player_pet_ready_charges or 0)))
            end
            imgui.Text(string.format('Call Beast: %s', tostring(S.live.callbeast_reason or '--')))
        end
    end

    -- Ninja Debug.
    if show_shadows_debug then
        if imgui.CollapsingHeader('Ninja Debug##debug_nin') then
            imgui.Text(string.format('Shadows: %s', tostring(S.live.player_shadow_count or '--')))
            imgui.Text(string.format('Last Shadow Cast: %s', tostring((S.combat and S.combat.last_shadow_name) or '--')))
            imgui.Text(string.format('Utsu Tools Out: %s', (S.flags and S.flags.player_utsu_tools_out) and 'True' or 'False'))
        end
    end

    -- Pro/Shell Debug -- only shown for jobs that can actually cast Protect/Shell.
    if ctx and (ctx.can_use_protect or ctx.can_use_shell) then
        if imgui.CollapsingHeader('Pro/Shell Debug##debug_proshell') then
            imgui.Text(string.format('Last Pro Cast: %s', tostring((S.combat and S.combat.last_protect_name) or '--')))
            imgui.Text(string.format('Last Shell Cast: %s', tostring((S.combat and S.combat.last_shell_name) or '--')))
            imgui.Separator()
            -- Diagnostics: trace the completion pipeline.
            imgui.Text(string.format('[dbg] is_casting: %s', (S.combat and S.combat.is_casting == true) and 'True' or 'False'))
            imgui.Text(string.format('[dbg] current_spell: %s', tostring((S.combat and S.combat.current_spell) or '--')))
            imgui.Text(string.format('[dbg] last_confirmed_spell: %s', tostring((S.combat and S.combat.last_confirmed_spell) or '--')))
            imgui.Text(string.format('[dbg] last_confirmed_at: %s', tostring((S.combat and S.combat.last_confirmed_spell_at) or '--')))
            imgui.Text(string.format('Best Pro: %s', tostring((ctx and ctx.best_protect_spell) or '--')))
            imgui.Text(string.format('Best Shell: %s', tostring((ctx and ctx.best_shell_spell) or '--')))
            imgui.Text(string.format('Pro Should Cast: %s', (ctx and ctx.protect_should_cast) and 'True' or 'False'))
            imgui.Text(string.format('Shell Should Cast: %s', (ctx and ctx.shell_should_cast) and 'True' or 'False'))
            imgui.Separator()
            -- Remaining cast gates (between should_cast and actual dispatch).
            imgui.Text(string.format('auto.shell: %s', (ctx and ctx.cfgget and ctx.cfgget('auto.shell')) and 'True' or 'False'))
            imgui.Text(string.format('auto.protect: %s', (ctx and ctx.cfgget and ctx.cfgget('auto.protect')) and 'True' or 'False'))
            imgui.Text(string.format('spells_locked_soft: %s', (ctx and ctx.spells_locked_soft) and 'True' or 'False'))
            imgui.Text(string.format('resting01: %s', tostring((ctx and ctx.resting01) or '--')))
            imgui.Text(string.format('SHELL is_ready: %s', (ctx and ctx.is_ready and ctx.is_ready('SHELL')) and 'True' or 'False'))
            imgui.Text(string.format('PROTECT is_ready: %s', (ctx and ctx.is_ready and ctx.is_ready('PROTECT')) and 'True' or 'False'))
            imgui.Text(string.format('Shell MP ok: %s', (ctx and ctx.has_spell_mp and ctx.best_shell_spell and ctx.has_spell_mp(ctx.best_shell_spell)) and 'True' or 'False'))
            imgui.Text(string.format('MP raw: %s', tostring((S.live and S.live.player_mp_raw) or '--')))
        end
    end

    -- Dragoon Debug.
    if is_drg then
        if imgui.CollapsingHeader('Dragoon Debug##debug_drg') then
            imgui.Text(string.format('HB Ready: %s', (ctx and ctx.hb_ready) and 'True' or 'False'))
        end
    end

    -- Collapsing sections (ladders, target info)
    imgui.Separator()

    local real_atk = build_real_current_atk_debug_list(ctx)
    local real_def = build_real_current_def_debug_list(ctx)

    if imgui.CollapsingHeader('Atk Ladder##debug_atk') then
        render_debug_ws_details(ctx)
        imgui.Separator()
        render_debug_real_ladder('ATK Ladder', real_atk, ctx)
    end

    if imgui.CollapsingHeader('Def Ladder##debug_def') then
        render_debug_real_ladder('DEF Ladder', real_def, ctx)
    end

    -- Bolt Status: shows why ranged_plan returned what it did. If bolts
    -- aren't firing, this panel tells you which check killed it.
    if imgui.CollapsingHeader('Bolt Status##debug_bolts') then
        local function yn(v) return v and 'YES' or 'no' end

        local auto_ranged = (cfg_get('auto.ranged') == true)
        local def_on   = (cfg_get('ranged.def_down_only') == true)
        local blind_on = (cfg_get('ranged.blind_bolt')   == true)
        do
            -- Sleep Other visibility. This claimed the RANGED round and then
            -- silently failed once (no Sleep Bolts -> swapped forever ->
            -- blocked /ra with zero output). It is never invisible again.
            local so_on  = (cfg_get('ranged.sleep_other') == true)
            local sa     = tostring(S.live and S.live.sleep_ammo_name or '')
            local savail = (S.live and S.live.sleep_ammo_available == true)
            local tgt, _i, tn = nil, nil, nil
            if ctx and ctx.sleep_other_target then tgt, _i, tn = ctx.sleep_other_target() end
            local why = 'ready'
            if not so_on            then why = 'off'
            elseif sa == ''         then why = 'no bow/xbow'
            elseif not savail       then why = 'NO SLEEP AMMO (would block /ra - now gated)'
            elseif S.combat and S.combat.hp_drain_active then why = 'HP bolts latched (they win)'
            elseif tgt == nil       then
                why = 'no target: ' .. tostring((S.combat and S.combat.sleep_dbg) or '?')
            end
            imgui.Text(string.format('  sleep_other: %s   ammo=%s avail=%s   -> %s',
                yn(so_on), sa ~= '' and sa or '--', yn(savail),
                tgt and string.format('%s sid %d', tostring(tn), tgt) or why))
        end
        local drain_on = (cfg_get('ranged.hp_drain')     == true)
        local hp_thresh = tonumber(cfg_get('ranged.hp_drain_hp') or 0) or 0
        local hp        = tonumber(ctx and ctx.player_hp or 100) or 100

        imgui.Text(string.format('auto.ranged: %s', yn(auto_ranged)))
        imgui.Text(string.format('  def_down_only: %s   blind: %s   hp_drain: %s (thresh=%d, release=%d, hp=%d, latched=%s)',
            yn(def_on), yn(blind_on), yn(drain_on), hp_thresh, hp_thresh + 5, hp,
            yn(S.combat and S.combat.hp_drain_active == true)))

        imgui.Separator()
        imgui.Text('Equipped ammo: ' .. tostring((S.live and S.live.equipped_ammo_name) or '(none)'))
        imgui.Text(string.format('  Acid  Bolt: equipped=%s  available=%s',
            yn(S.live and S.live.acid_bolt_equipped),  yn(S.live and S.live.acid_bolt_available)))
        imgui.Text(string.format('  Blood Bolt: equipped=%s  available=%s',
            yn(S.live and S.live.blood_bolt_equipped), yn(S.live and S.live.blood_bolt_available)))
        imgui.Text(string.format('  Blind Bolt: equipped=%s  available=%s',
            yn(S.live and S.live.blind_bolt_equipped), yn(S.live and S.live.blind_bolt_available)))
        -- Sleep Bolt was missing here: the one bolt whose swap state actually
        -- decides whether Sleep Other can fire, and it was the only one you
        -- could not see. equipped= is what the shot rides on -- the packet
        -- fires whatever is loaded, so a stuck swap means a Bloody Bolt into
        -- the add instead of a Sleep Bolt.
        imgui.Text(string.format('  Sleep Bolt: equipped=%s  available=%s  (%s)',
            yn(S.live and S.live.sleep_ammo_equipped),
            yn(S.live and S.live.sleep_ammo_available),
            tostring((S.live and S.live.sleep_ammo_name) ~= '' and S.live.sleep_ammo_name or 'no bow/xbow')))

        imgui.Separator()
        local has_def_dot   = ctx and ctx.target_has_debuff and ctx.target_has_debuff('def down') or false
        local has_blind_dot = ctx and ctx.target_has_debuff and ctx.target_has_debuff('blind')    or false
        imgui.Text('Mob debuffs (for gate):')
        imgui.Text(string.format('  def down: %s   blind: %s', yn(has_def_dot), yn(has_blind_dot)))

        imgui.Separator()
        if ctx and ctx.ranged_plan then
            local plan = ctx.ranged_plan()
            imgui.Text(string.format('ranged_plan() = %s', tostring(plan)))
            if plan == 'hold' then
                imgui.Text('  -> all enabled debuffs already on mob, holding')
            elseif plan == 'none' then
                imgui.Text('  -> a debuff wants applying but the bolt is unavailable')
                if def_on and not has_def_dot and not (S.live and S.live.acid_bolt_available) then
                    imgui.Text('     Acid Bolt unavailable (mode on, def down not up)')
                end
                if blind_on and not has_blind_dot
                   and ((not def_on) or has_def_dot)
                   and not (S.live and S.live.blind_bolt_available) then
                    imgui.Text('     Blind Bolt unavailable (mode on, blind not up)')
                end
            elseif plan == 'blood' then
                imgui.Text('  -> will fire Bloody Bolt')
            elseif plan == 'acid' then
                imgui.Text('  -> will fire Acid Bolt')
            elseif plan == 'blind' then
                imgui.Text('  -> will fire Blind Bolt')
            elseif plan == 'normal' then
                imgui.Text('  -> will fire plain /ra with whatever is loaded')
            end
        else
            imgui.Text('ranged_plan() not available (ctx not built yet)')
        end
    end

    if imgui.CollapsingHeader('Ladder Session State##debug_session') then
        render_debug_session_state()
    end

    if imgui.CollapsingHeader('Target Status##debug_debuffs') then
        render_debug_target_debuffs(ctx)
    end

    if imgui.CollapsingHeader('Tracked Target Info##debug_tracked') then
        render_debug_tracked_target()
    end
end

--------------------------------------------------------------------------------
-- FRAME
--------------------------------------------------------------------------------

local function refresh_frame_state()
    S.config_ref  = cfg
    S.config_view = cfg
    S.ui.is_visible    = cfg.ui.visible == true
    S.ui.debug_enabled = cfg.debug.enabled == true

    refresh_player_name_cache()
    GeneralLua.runtime.refresh_live_state(S)

    -- Bolt status for the ranged modes. Each is only computed while its mode
    -- is active; otherwise left false (the ladder won't read it unless the
    -- mode is on). When a bolt is equipped, 'available' is implied and that
    -- bolt's inventory scan is skipped.
    do
        S.live = S.live or {}
        local auto_ranged = (cfg_get('auto.ranged') == true)

        local def_down = auto_ranged and (cfg_get('ranged.def_down_only') == true)
        if def_down then
            local eq = equipped_ammo_is('acid bolt')
            S.live.acid_bolt_equipped = eq
            S.live.acid_bolt_available = eq or bolt_in_inventory('acid bolt')
        else
            S.live.acid_bolt_equipped = false
            S.live.acid_bolt_available = false
        end

        local hp_drain = auto_ranged and (cfg_get('ranged.hp_drain') == true)
        if hp_drain then
            local eq = equipped_ammo_is('bloody bolt')
            S.live.blood_bolt_equipped = eq
            S.live.blood_bolt_available = eq or bolt_in_inventory('bloody bolt')
        else
            S.live.blood_bolt_equipped = false
            S.live.blood_bolt_available = false
        end

        local blind = auto_ranged and (cfg_get('ranged.blind_bolt') == true)
        if blind then
            local eq = equipped_ammo_is('blind bolt')
            S.live.blind_bolt_equipped = eq
            S.live.blind_bolt_available = eq or bolt_in_inventory('blind bolt')
        else
            S.live.blind_bolt_equipped = false
            S.live.blind_bolt_available = false
        end
    end

    -- RA-skill out-of-ammo stop: true when the ammo slot holds a stack with
    -- count > 0. Read every frame (the RA-skill loop in general.lua reads
    -- this), so the session ends the moment the last shot is fired.
    do
        S.live = S.live or {}
        local ammo = get_equipped_ammo()
        S.live.ranged_ammo_present =
            (ammo ~= nil and (tonumber(ammo.count or 0) or 0) > 0)
        S.live.equipped_ammo_name = (ammo and tostring(ammo.name or '')) or ''
        -- Item id as well as the name. general.lua needs the id to look the
        -- ammo up in weapon_db for the ranged recast calculation; a display
        -- name cannot be keyed on.
        S.live.equipped_ammo_id = (ammo and tonumber(ammo.id or 0)) or nil

        -- Is this even a /ra job right now? weapon_db covers only Archery +
        -- Marksmanship for the ranged slot (header: "Excluded: Throwing,
        -- instruments, automaton, fishing"), so skill_of() is nil unless a
        -- real bow/xbow/gun is equipped.
        --
        -- That single check is the whole fix for stat sticks. A Hedgehog
        -- Bomb / Tiphia Sting parked for its stats means the job isn't
        -- shooting -- there's no bow, so nil skill, so we never /ra and
        -- never throw it. No need to inspect the ammo slot at all.
        local rid    = get_ranged_weapon_id()
        local rskill = rid and WeaponDB.skill_of(rid) or nil
        S.live.ranged_weapon_skill = rskill
        -- Launcher id, for the same weapon_db recast lookup as the ammo id
        -- above. The launcher is what actually sets /ra cadence.
        S.live.ranged_weapon_id = rid
        S.live.ranged_weapon_ok =
            (rskill == 'Archery' or rskill == 'Marksmanship')

        -- RA Skill button visibility. Was "(ranged weapon) OR (anything in
        -- ammo)" -- that OR is what let a lone stat stick in the ammo slot
        -- look like a working ranged setup.
        S.live.ranged_capable = S.live.ranged_weapon_ok == true

        -- LAUNCHER / AMMO AGREEMENT.
        --
        -- "You do not have an appropriate ranged weapon equipped" does not
        -- mean the ranged slot is empty. It means the slot and the ammo
        -- disagree: arrows under a crossbow, bolts under a bow. Every gate we
        -- had passed in that state (launcher present, ammo present, count > 0)
        -- so the loop just kept firing into a guaranteed refusal.
        --
        -- weapon_db knows the skill of both sides, so this is a direct
        -- comparison rather than a message we have to catch. nil means "can't
        -- tell" (unknown id, empty slot) and is deliberately NOT false --
        -- only a positive disagreement blocks the shot.
        local aid = S.live.equipped_ammo_id
        local askill = aid and WeaponDB.ammo_skill_of(aid) or nil
        if rskill ~= nil and askill ~= nil then
            S.live.ranged_ammo_compatible = (askill == rskill)
        else
            S.live.ranged_ammo_compatible = nil
        end

        -- Flag it as a missing tool so it gets the one-shot echo and a Reset
        -- button, same as Shihei or Sleep Bolt. Only while the mode that
        -- cares is on -- a mismatched ammo slot is nobody's business when we
        -- are not shooting.
        if cfg_get('auto.rangedmode') == true
            and S.live.ranged_ammo_compatible == false
        then
            GeneralLua.runtime.mark_tool_missing(S, 'Ranged Ammo')
        end
    end

    -- Missing-tool announcer. Any tool flagged missing (Shihei, Sleep Bolt,
    -- Ranged Weapon, ...) gets a one-time "no <name> found" echo, tracked so it
    -- doesn't repeat until the tool is reset. Debug-independent.
    do
        S.flags = S.flags or {}
        local mt = S.flags.missing_tools
        if type(mt) == 'table' then
            S.flags.missing_tools_echoed = S.flags.missing_tools_echoed or {}
            local ech = S.flags.missing_tools_echoed
            for name, on in pairs(mt) do
                if on == true and ech[name] ~= true then
                    ech[name] = true
                    send_echo('no ' .. tostring(name) .. ' found')
                end
            end
        end
    end
    -- already equipped. Only computed while the option is on (general.lua's
    -- sequence reads these via ctx). Also read by the SSD button, so compute
    -- it whenever a bow/xbow is present rather than gating on the shadows opts.
    do
        S.live = S.live or {}
        local want = sleep_ammo_for_ranged()
        S.live.sleep_ammo_name = want
        if want ~= '' then
            local eq = equipped_ammo_is(want:lower())
            S.live.sleep_ammo_equipped = eq
            S.live.sleep_ammo_available = eq or bolt_in_inventory(want:lower())
        else
            S.live.sleep_ammo_equipped = false
            S.live.sleep_ammo_available = false
        end
    end

    -- Bolt counts for the ranged UI. Independent of mode toggles so the
    -- header shows what you have at all times, not only while the checkbox
    -- is on. Cached to 1s per needle inside bolt_count_in_inventory.
    do
        S.live = S.live or {}
        S.live.acid_bolt_count  = bolt_count_in_inventory('acid bolt')
        S.live.blood_bolt_count = bolt_count_in_inventory('bloody bolt')
        S.live.blind_bolt_count = bolt_count_in_inventory('blind bolt')
        local want = S.live.sleep_ammo_name or ''
        if want ~= '' then
            S.live.sleep_ammo_count = bolt_count_in_inventory(want:lower())
        else
            S.live.sleep_ammo_count = 0
        end
    end

    -- Pull-ammo picker. tick_auto_pull reads this to decide whether to swap
    -- ammo before /ra <t>. Rules:
    --   * Never pull with sleep ammo (mob wakes on the shot).
    --   * Otherwise prefer the highest-priority debuff bolt available:
    --         acid > blind > bloody
    --     A Bloody Bolt loaded with Acids in inventory means swap to acid.
    --   * Regular arrows / gun ammo / anything else: leave alone unless
    --     the ammo slot is empty and we CAN pick a debuff bolt.
    do
        S.live = S.live or {}
        local eq_name  = tostring(S.live.equipped_ammo_name or '')
        local eq_lower = eq_name:lower()
        local eq_is_sleep = eq_lower ~= ''
            and (eq_lower:find('sleep bolt',  1, true) ~= nil
              or eq_lower:find('sleep arrow', 1, true) ~= nil)
        local eq_missing = eq_lower == '' or (S.live.ranged_ammo_present ~= true)
        local eq_is_debuff_bolt = eq_lower ~= ''
            and (eq_lower:find('acid bolt',   1, true) ~= nil
              or eq_lower:find('blind bolt',  1, true) ~= nil
              or eq_lower:find('bloody bolt', 1, true) ~= nil)

        S.live.pull_ammo_needs_swap = false
        S.live.pull_ammo_swap_target = ''

        -- Priority pick from what's in inventory. Reads the counts already
        -- computed above -- no extra inventory walk.
        local pick = nil
        if     (tonumber(S.live.acid_bolt_count  or 0) or 0) > 0 then pick = 'Acid Bolt'
        elseif (tonumber(S.live.blind_bolt_count or 0) or 0) > 0 then pick = 'Blind Bolt'
        elseif (tonumber(S.live.blood_bolt_count or 0) or 0) > 0 then pick = 'Bloody Bolt'
        end

        if eq_is_sleep or eq_missing then
            -- Sleep loaded / empty slot: swap to picked bolt if any.
            -- If no bolts available and eq is sleep, refuse to fire.
            if pick then
                S.live.pull_ammo_needs_swap = true
                S.live.pull_ammo_swap_target = pick
            elseif eq_is_sleep then
                S.live.pull_ammo_needs_swap = true
                S.live.pull_ammo_swap_target = ''
            end
        elseif eq_is_debuff_bolt and pick and pick:lower() ~= eq_lower then
            -- Already have a debuff bolt loaded, but a higher-priority one is
            -- available in inventory (e.g. Bloody equipped, Acid in bag).
            -- Swap to the priority pick.
            S.live.pull_ammo_needs_swap = true
            S.live.pull_ammo_swap_target = pick
        end
    end

    -- Auto-pause the whole system when the player is dead.
    -- The user must manually click Unpause to resume.
    local status = S.live and S.live.player_status
    local is_dead = (status == GeneralLua.status.DEAD1 or status == GeneralLua.status.DEAD2)
    if is_dead and cfg.auto.paused ~= true then
        cfg.auto.paused = true
        settings.save()
    end
end

local function run_runtime()
    return GeneralLua.runtime.tick{
        state        = S,
        atk_list     = atk_list,
        def_list     = def_list,
        general_list = general_list,
        dispatch     = dispatch,
    }
end

local function run_idle_rest_engage(ctx)
    return IdleRestEngage.tick{
        state    = S,
        ctx      = ctx,
        cfgget   = cfg_get,
        movement = movement,
        dispatch = dispatch,
        now_sec  = now_sec,
        dbg      = dbg,
    }
end

local function bovinebattle_present()
    -- Non-blocking: picks up an in-flight GitHub check. Does nothing at all
    -- when no check is pending, so this costs one table lookup per frame.
    if Updater then Updater.poll() end

    refresh_frame_state()
    update_ws_for_weapon_swap()
    keep_picked_ammo_equipped()
    local ctx = run_runtime()

    if GeneralLua.runtime.zoning_paused(S, now_sec()) then
        if movement and type(movement.force_release) == 'function' then
            movement.force_release()
        end
    elseif GeneralLua.runtime.ssd_is_active(S) then
        -- SSD is the busy-lock: it owns targeting, movement, and the /attack
        -- lifecycle for the sequence's duration. Auto-target / auto-pull /
        -- engaged-run would race it for the same mob.
    else
        run_idle_rest_engage(ctx)
    end

    if cfg.ui.visible ~= true then
        return
    end

    imgui.SetNextWindowPos({ cfg.ui.x, cfg.ui.y }, ImGuiCond_FirstUseEver)
    imgui.SetNextWindowBgAlpha(cfg.ui.alpha or 0.85)

    -- Global theme: pushed BEFORE Begin / popped AFTER End so counts always
    -- balance regardless of which early-return path fires inside the window.
    local _bg_a = cfg.ui.alpha or 0.85
    imgui.PushStyleVar(ImGuiStyleVar_WindowRounding,   8.0)
    imgui.PushStyleVar(ImGuiStyleVar_FrameRounding,    5.0)
    imgui.PushStyleVar(ImGuiStyleVar_ChildRounding,    6.0)
    imgui.PushStyleVar(ImGuiStyleVar_PopupRounding,    5.0)
    imgui.PushStyleVar(ImGuiStyleVar_GrabRounding,     4.0)
    imgui.PushStyleVar(ImGuiStyleVar_FramePadding,     {7, 4})
    imgui.PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0)

    imgui.PushStyleColor(ImGuiCol_WindowBg,       {0.07, 0.07, 0.09, _bg_a})
    imgui.PushStyleColor(ImGuiCol_Border,         {0.30, 0.32, 0.40, 0.60})
    imgui.PushStyleColor(ImGuiCol_FrameBg,        {0.16, 0.17, 0.21, 1.0})
    imgui.PushStyleColor(ImGuiCol_FrameBgHovered, {0.22, 0.24, 0.30, 1.0})
    imgui.PushStyleColor(ImGuiCol_FrameBgActive,  {0.28, 0.30, 0.38, 1.0})
    imgui.PushStyleColor(ImGuiCol_Header,         {0.20, 0.22, 0.28, 1.0})
    imgui.PushStyleColor(ImGuiCol_HeaderHovered,  {0.28, 0.31, 0.40, 1.0})
    imgui.PushStyleColor(ImGuiCol_HeaderActive,   {0.34, 0.37, 0.48, 1.0})
    imgui.PushStyleColor(ImGuiCol_CheckMark,      {0.45, 0.85, 0.50, 1.0})
    imgui.PushStyleColor(ImGuiCol_Separator,      {0.30, 0.32, 0.40, 0.50})
    imgui.PushStyleColor(ImGuiCol_Text,           {0.92, 0.92, 0.94, 1.0})
    -- Action buttons: a bright blue-steel so they read as clickable, not
    -- greyed-out. Category = color: a plain button is an "action". The few
    -- state-carrying buttons (Pause/Unpause) tint themselves inline.
    imgui.PushStyleColor(ImGuiCol_Button,         {0.28, 0.42, 0.66, 1.0})
    imgui.PushStyleColor(ImGuiCol_ButtonHovered,  {0.36, 0.53, 0.80, 1.0})
    imgui.PushStyleColor(ImGuiCol_ButtonActive,   {0.44, 0.63, 0.92, 1.0})
    -- Title bar: slate to match the rest (it was falling through to
    -- imgui's default red-ish title color, the loudest thing in the panel).
    imgui.PushStyleColor(ImGuiCol_TitleBg,        {0.13, 0.14, 0.18, 1.0})
    imgui.PushStyleColor(ImGuiCol_TitleBgActive,  {0.18, 0.20, 0.26, 1.0})
    imgui.PushStyleColor(ImGuiCol_TitleBgCollapsed, {0.13, 0.14, 0.18, 1.0})

    local flags = bit.bor(ImGuiWindowFlags_AlwaysAutoResize)
    local open = { true }

    if imgui.Begin('Bovine Battle', open, flags) then
        maybe_autosave_window_pos()

        if open[1] == false then
            send_cmd('/addon unload bovinebattle')
            imgui.End()
            imgui.PopStyleColor(17)
            imgui.PopStyleVar(7)
            return
        end

        render_header_controls()
        imgui.Separator()

        render_top_status(ctx)

        -- Updates: collapsed by default, sits above Config the same way it
        -- does in bovinefh so the two panels read the same.
        if Updater then
            Updater.render(
                (cfg.update and cfg.update.auto) == true,
                function(v)
                    cfg_ensure('update.auto', false)
                    cfg_set('update.auto', v)
                    settings.save()
                end)
        end

        if imgui.CollapsingHeader('Config', ImGuiTreeNodeFlags_DefaultOpen) then
            render_core_controls()
            imgui.Separator()
            render_ranged_controls()
            imgui.Separator()
            render_ui_from_lists({ atk_list, def_list }, ctx)
            render_other_emergency(ctx)
        end

        -- Entity List -- top-level collapse, OUTSIDE the Config section.
        EntityList.render()

        render_debug(ctx)
    end

    imgui.End()
    imgui.PopStyleColor(17)
    imgui.PopStyleVar(7)
end

--------------------------------------------------------------------------------
-- AUTO-UPDATER
--------------------------------------------------------------------------------

-- Applying means overwriting lua files and reloading the addon. Doing that
-- with a ladder session live would drop the session mid-fight and can strand
-- a held movement key, so the gate is PAUSED. Same rule bovinefh uses (it
-- refuses while the bot is running); this is the bovinebattle equivalent.
if Updater then
    Updater.setup{
        name    = addon.name,
        version = addon.version,
        path    = addon.path,
        repo    = 'cowrevenge/bovinebattle',   -- <-- EDIT HERE (owner/name)
        branch  = 'main',
        token   = '',                          -- leave empty; use gitvar.dat
        is_busy = function()
            if (cfg.auto and cfg.auto.paused) == true then return false end
            return true, 'PAUSE the bot before updating'
        end,
        note    = send_echo,
    }

    -- On-load check. Only fires with the toggle on, and only auto-applies
    -- when is_busy() says it is safe -- otherwise it reports what it found
    -- and waits for the button.
    if (cfg.update and cfg.update.auto) == true then
        Updater.check(true)
    end
end

--------------------------------------------------------------------------------
-- EVENT WIRING
--------------------------------------------------------------------------------

ashita.events.register('packet_in', 'bovinebattle_packet_in', function(e)
    GeneralLua.events.on_packet_in{
        event = e,
        state = S,
    }
end)

ashita.events.register('text_in', 'bovinebattle_text_in', function(e)
    GeneralLua.events.on_text_in{
        event = e,
        state = S,
        current_time = now_sec(),
    }
end)

ashita.events.register('command', 'bovinebattle_command', function(e)
    local raw = tostring(e.command or '')

    if raw:match('^%s*/mncmd%s+') then
        e.blocked = true
        local inner = raw:gsub('^%s*/mncmd%s+', '', 1)
        send_cmd(inner)
        return
    end

    GeneralLua.events.on_command{
        event = e,
        state = S,
    }

    cfg.ui.visible    = S.ui.is_visible == true
    cfg.debug.enabled = S.ui.debug_enabled == true
    settings.save()
end)

ashita.events.register('d3d_present', 'bovinebattle_present', bovinebattle_present)

ashita.events.register('unload', 'bovinebattle_unload', function()
    if movement and type(movement.force_release) == 'function' then
        movement.force_release()
    end
end)