--[[---------------------------------------------------------------------------
idle_rest_engage.lua

Purpose
  Own non-ladder behavior for MeleeNostrum.

Owns
  - idle phase behavior
  - rest phase behavior
  - auto engage decision
  - bot-mode target pick / engage
  - bot home-center hold / return
  - run / chase decision
  - party-mode chase clamp
  - pre-attack shadows
  - idle HB
  - post-stand shadows
---------------------------------------------------------------------------]]--

local IdleRestEngage = {}

local bit = require('bit')
local GeneralLua = require('general')

local function n(v, fallback)
    v = tonumber(v)
    if v == nil then return fallback end
    return v
end

-- Approx walk speed in yalms/sec (FFXI with /run off ~3, with /run ~6)
local WALK_SPEED_YALMS_SEC = 3.5
local WALK_MIN_SEC         = 0.3
local WALK_MAX_SEC         = 4.0

local function dbg(args, text)
    if args and type(args.dbg) == 'function' then
        args.dbg(tostring(text))
    end
end

local function ire_state(state)
    state.idle_rest_engage = state.idle_rest_engage or {
        mobs_present_since_ts = 0.0,
        rest_wait_since = 0.0,
        stood_up_ts = 0.0,
        heal_toggle_until = 0.0,
        rest_after_prep_pending = false,
        run_active = false,
        idle_hb_retry_until = 0.0,
        idle_hb_party_retry_until = 0.0,
        idle_hb_party_started_at = 0.0,
        pre_attack_hb_retry_until = 0.0,
        pre_attack_retry_until = 0.0,
        prep_action_settle_until = 0.0,
        engage_retry_until = 0.0,

        bot_retry_until = 0.0,
        bot_target_server_id = 0,
        bot_target_name = nil,
        bot_target_index = 0,
        bot_target_pending_until = 0.0,

        bot_center_x = nil,
        bot_center_y = nil,
        bot_center_z = nil,

        -- HOME: the spot we were standing when the bot was started (or when
        -- Rehome was pressed). Auto-target measures from HERE instead of
        -- from the player, so chasing one mob can't drag the camp across
        -- the zone -- each pick is judged against the anchor, not against
        -- wherever the last fight ended.
        home_x = nil,
        home_y = nil,
        home_z = nil,
        home_rehome_req = false,
        bot_returning = false,

        bot_enemy_list = T{},
        bot_enemy_count = 0,
        bot_enemy_free_count = 0,
        bot_enemy_party_count = 0,
        bot_enemy_other_count = 0,

        bot_debug_last = nil,
        bot_debug_last_at = 0.0,

        -- auto-target state machine
        at_clear_since     = 0.0,
        at_sent_at         = 0.0,
        at_sent_sid        = 0,
        at_tries           = 0,
        at_cooldown_until  = 0.0,

        -- auto-pull (armed by auto-target, fired by tick_auto_pull)
        at_pull_at         = 0.0,
        at_pull_sid        = 0,
        at_pull_idx        = 0,
        at_sent_idx        = 0,

        -- auto-target stale-lock watchdog. Persists across auto_target_reset:
        -- reset() runs on every successful cur_sid, so clearing these there
        -- would defeat the whole watchdog. Only meaningful when auto.pull is on.
        at_locked_sid      = 0,
        at_locked_at       = 0.0,
        at_locked_engaged  = false,

        -- Wrong-target dwell + one-shot latch. at_wrong_since is when we
        -- first saw a bad target this stretch (0 = current target is fine
        -- or nothing targeted); at_wrong_fired is true once we've already
        -- issued the repick and clears when the target goes back to
        -- something valid (or to nothing). See AT_WRONG_DWELL_SEC.
        at_wrong_since     = 0.0,
        at_wrong_fired     = false,

        -- chase-to-range state for tick_auto_pull. Kicked when a pull is due
        -- but the mob is beyond the pull method's range. Owns the movement
        -- keys (W) while active; releases them on completion or timeout.
        -- With lock-on active, W walks toward target and A/D strafe -- no
        -- separate facing step needed.
        at_chase_active       = false,
        at_chase_started_at   = 0.0,
        at_chase_h_sent       = false, -- H pressed once this chase (H is a TOGGLE)

        -- 'stuck on this sid' tracking for the auto-target blacklist. Persists
        -- across backoffs so 10s of failure on the same mob is measurable.
        -- Cleared by auto_target_reset on success. at_blacklist entries
        -- are sid -> expiry_ts; filter loop skips any sid whose entry is
        -- still in the future.
        at_last_pick_sid       = 0,
        at_last_pick_first_at  = 0.0,
        at_blacklist           = {},

        -- Rising-edge tracker for "engaged". The blacklist wipe fires ONCE
        -- on the not-engaged -> engaged transition, never per-tick: the
        -- attack-range watchdog blacklists a mob and THEN sends /attack
        -- off, which takes a tick or two to resolve, so a per-tick wipe
        -- would erase the entry the watchdog just wrote.
        was_engaged            = false,

        -- Sleep Other facing prep. Presses A or D to orbit around <t> until
        -- the player is on the opposite side from the sleep-other mob.
        -- Owns A/D while active; pre-empts tick_engaged_run so W isn't
        -- fighting the strafe. Released on any exit condition.
        sleep_facing_active     = false,
        sleep_facing_key        = 'none',
        sleep_facing_started_at = 0.0,
        sleep_facing_release_at = 0.0,

        -- Auto Antidote: last-fire timestamp for the local cooldown. Uses
        -- os-clock seconds; compared against ANTIDOTE_COOLDOWN_SEC.
        antidote_last_at        = 0.0,

        -- Attack-range watchdog. Timestamp of the last frame where we
        -- were engaged AND within ATTACK_MAX_RANGE_YALMS of the target.
        -- Sustained over-range while engaged for ATTACK_OUT_OF_RANGE_TIMEOUT_SEC
        -- triggers a disengage + target-drop.
        attack_last_in_range_at = 0.0,
    }
    return state.idle_rest_engage
end

local function dbg_bot(args, key, text, min_sec)
    local state = args and args.state
    if not state then return end
    local ire = ire_state(state)
    local now = tonumber(args.now or 0.0) or 0.0
    local gap = tonumber(min_sec or 1.0) or 1.0

    if ire.bot_debug_last == key and now < (tonumber(ire.bot_debug_last_at or 0.0) + gap) then
        return
    end

    ire.bot_debug_last = key
    ire.bot_debug_last_at = now
    dbg(args, text)
end

local function party_manager()
    local mm = AshitaCore:GetMemoryManager()
    return mm and mm:GetParty() or nil
end

-- Player's own server id, from party slot 0. Matches the read pattern
-- general.lua uses in get_packet_target_debuff_ids.
local function get_self_server_id()
    local party = party_manager()
    if not party or type(party.GetMemberServerId) ~= 'function' then return 0 end
    local ok, sid = pcall(function() return party:GetMemberServerId(0) end)
    return (ok and tonumber(sid)) or 0
end

local function entity_manager()
    local mm = AshitaCore:GetMemoryManager()
    return mm and mm:GetEntity() or nil
end

local function target_manager()
    local mm = AshitaCore:GetMemoryManager()
    return mm and mm:GetTarget() or nil
end

local function movement_state(movement)
    if movement and type(movement.debug_state) == 'function' then
        return movement.debug_state()
    end
    return nil
end

local function movement_is_w_down(movement)
    local st = movement_state(movement)
    if st and st.w_down ~= nil then
        return st.w_down == true
    end
    return nil
end

local function movement_is_a_down(movement)
    local st = movement_state(movement)
    if st and st.a_down ~= nil then
        return st.a_down == true
    end
    return nil
end

local function movement_stop(movement)
    local w_down = movement_is_w_down(movement)
    if w_down == false then
        return false
    end

    if movement and type(movement.stop) == 'function' then
        return movement.stop()
    end
    if movement and type(movement.force_release) == 'function' then
        return movement.force_release()
    end
    return false
end

local function movement_release_all(movement)
    local w_down = movement_is_w_down(movement)
    local a_down = movement_is_a_down(movement)

    if w_down == false and a_down == false then
        return false
    end

    if movement and type(movement.force_release) == 'function' then
        return movement.force_release()
    end
    return false
end

local function movement_walk(movement)
    local w_down = movement_is_w_down(movement)
    if w_down == true then
        return false
    end

    if movement and type(movement.walk_forward) == 'function' then
        return movement.walk_forward()
    end
    if movement and type(movement.key_w_down) == 'function' then
        return movement.key_w_down()
    end
    return false
end

local POST_KILL_NO_ATTACK_SEC = 1.5

local function post_kill_blocked(state)
    local last_kill = tonumber(state and state.combat and state.combat.last_kill_at or 0) or 0
    if last_kill <= 0 then return false end
    return (os.clock() - last_kill) < POST_KILL_NO_ATTACK_SEC
end

local function do_attack_bt(dispatch)
    if type(dispatch) ~= 'function' then return false end
    return dispatch('/attack <bt>', 1.0)
end

local function do_attack_t(dispatch)
    if type(dispatch) ~= 'function' then return false end
    return dispatch('/attack <t>', 1.0)
end

local function do_heal(dispatch)
    if type(dispatch) ~= 'function' then return false end
    return dispatch('/heal', 1.0)
end

local function get_entity(index)
    local ok, entity = pcall(GetEntity, index)
    return ok and entity or nil
end

local function get_player_entity()
    local ok, player = pcall(GetPlayerEntity)
    return ok and player or nil
end



local function entity_distance(ent)
    if not ent then return nil end
    local d = tonumber(ent.Distance)
    if not d or d < 0 then return nil end
    return math.sqrt(d)
end

local function entity_hp_percent(ent)
    if not ent then return nil end

    local hp = tonumber(ent.HPPercent)
    if hp and hp >= 0 and hp <= 100 then
        return hp
    end

    hp = tonumber(ent.HPP)
    if hp and hp >= 0 and hp <= 100 then
        return hp
    end

    return nil
end

local function entity_server_id(ent)
    if not ent then return 0 end
    return tonumber(
        ent.ServerId or
        ent.ServerID or
        ent.Id or
        ent.ID or
        ent.EntityId or
        ent.EntityID or
        0
    ) or 0
end

-- Read a mob's claim owner (server id of whoever claimed it), 0 = unclaimed.
--
-- ClaimStatus MUST come first. Ashita v4 exposes the field as ClaimStatus;
-- none of ClaimId/ClaimOwnerId/ClaimServerId exist on the entity, so the
-- previous list returned nil for every mob -> 0 -> get_claim_state() saw
-- claim_id == 0 -> 'free' -> free_or_party was TRUE FOR EVERYTHING. The
-- claim filter silently passed every mob in the zone, including ones other
-- players were actively fighting. This ordering is copied from bovinemage,
-- which reads claims correctly in production.
local function entity_claim_id(ent)
    if not ent then return 0 end
    return tonumber(
        ent.ClaimStatus or
        ent.ClaimId or
        ent.claim_status or
        ent.claim_id or
        ent.ClaimID or
        ent.ClaimOwnerId or
        ent.ClaimOwnerID or
        ent.ClaimServerId or
        ent.ClaimServerID or
        0
    ) or 0
end

local function entity_position(ent)
    if not ent then return nil, nil, nil end

    local lp = ent.Movement and ent.Movement.LocalPosition
    local x = tonumber((lp and lp.X) or ent.X or ent.x)
    local y = tonumber((lp and lp.Y) or ent.Y or ent.y)
    local z = tonumber((lp and lp.Z) or ent.Z or ent.z)

    if x == nil or y == nil or z == nil then
        return nil, nil, nil
    end

    return x, y, z
end

local function player_position()
    return entity_position(get_player_entity())
end

-- Horizontal ground distance. X and Y are the ground plane; Z is HEIGHT and
-- is deliberately excluded.
--
-- NOTE the older dist2d(ax, az, bx, bz) below feeds X and Z into a "2d"
-- distance -- i.e. it mixes height into a planar measure. That is a latent
-- bug; it only survives because bot-centre camps are flat. Do not copy it.
-- New code uses this.
local function dist_ground(ax, ay, bx, by)
    if ax == nil or ay == nil or bx == nil or by == nil then return nil end
    local dx = ax - bx
    local dy = ay - by
    return math.sqrt((dx * dx) + (dy * dy))
end

local function dist2d(ax, az, bx, bz)
    if ax == nil or az == nil or bx == nil or bz == nil then return nil end
    local dx = ax - bx
    local dz = az - bz
    return math.sqrt((dx * dx) + (dz * dz))
end

local function entity_render_valid(idx)
    local entities = entity_manager()
    if not entities then return true end
    if type(entities.GetRenderFlags0) ~= 'function' then return true end

    local ok, flags = pcall(entities.GetRenderFlags0, entities, idx)
    if not ok or type(flags) ~= 'number' then
        return true
    end

    if bit.band(flags, 0x4000) ~= 0 then
        return false
    end

    return true
end

local function target_dead_or_invalid(ctx)
    if not ctx then return true end
    if ctx.target_valid == false then return true end

    local hp = tonumber(ctx.target_hp)
    if hp ~= nil and hp <= 0 then
        return true
    end

    return false
end

local function pre_attack_suppressed(state, now)
    local ire = ire_state(state)
    return now < n(ire.pre_attack_retry_until, 0.0)
end

local function prep_action_settling(state, now)
    local ire = ire_state(state)
    return now < n(ire.prep_action_settle_until, 0.0)
end

local function set_prep_action_settle(state, now, sec)
    local ire = ire_state(state)
    local until_t = now + (tonumber(sec or 1.0) or 1.0)
    if until_t > n(ire.prep_action_settle_until, 0.0) then
        ire.prep_action_settle_until = until_t
    end
end

local function try_heal_toggle(args, reason, on_success)
    local state    = args.state
    local dispatch = args.dispatch
    local now      = args.now
    local ire      = ire_state(state)

    if now < n(ire.heal_toggle_until, 0.0) then
        return false
    end

    dbg(args, reason)

    if do_heal(dispatch) then
        ire.heal_toggle_until = now + 2.0
        if type(on_success) == 'function' then
            on_success(ire, now)
        end
        return true
    end

    return false
end

local function player_hp_percent()
    local party = party_manager()
    if not party then return nil end
    if type(party.GetMemberHPPercent) ~= 'function' then return nil end

    local ok, v = pcall(function() return party:GetMemberHPPercent(0) end)
    if not ok then return nil end
    return tonumber(v)
end

local function player_mp_percent()
    local party = party_manager()
    if not party then return nil end

    if type(party.GetMemberMPPercent) == 'function' then
        local ok, v = pcall(function() return party:GetMemberMPPercent(0) end)
        if ok and v ~= nil then
            return tonumber(v)
        end
    end

    local mp = nil
    local mpmax = nil

    if type(party.GetMemberMP) == 'function' then
        local ok, v = pcall(function() return party:GetMemberMP(0) end)
        if ok and v ~= nil then
            mp = tonumber(v)
        end
    end

    if type(party.GetMemberMPMax) == 'function' then
        local ok, v = pcall(function() return party:GetMemberMPMax(0) end)
        if ok and v ~= nil then
            mpmax = tonumber(v)
        end
    end

    if mp ~= nil and mpmax ~= nil and mpmax > 0 then
        return (mp / mpmax) * 100
    end

    return nil
end

local function hb_threshold_ok(cfgget)
    local hp = player_hp_percent()
    if hp == nil then return false end

    local hb_hp = n(cfgget('hb_hp'), 25)
    if hb_hp <= 0 then return false end

    return hp > 0 and hp <= hb_hp
end

local function player_hpmp_pet_full_flags(cfgget)
    local party = party_manager()
    if not party then return nil, nil, nil end

    local hpPct = nil
    if type(party.GetMemberHPPercent) == 'function' then
        local ok, v = pcall(function() return party:GetMemberHPPercent(0) end)
        if ok then hpPct = tonumber(v) end
    end

    local mpPct = player_mp_percent()

    local petFull = true
    if type(party.GetMemberPetHPPercent) == 'function' then
        local ok, v = pcall(function() return party:GetMemberPetHPPercent(0) end)
        if ok and v ~= nil then
            petFull = (tonumber(v) or 0) >= 100
        end
    end

    local hpEnabled = (cfgget('auto.rest') == true)
    local mpEnabled = (cfgget('auto.rest_mp') == true)

    local hpFull = true
    if hpEnabled then
        hpFull = (tonumber(hpPct) or 0) >= 100
    end

    local mpFull = true
    if mpEnabled then
        mpFull = (tonumber(mpPct) or 0) >= 100
    end

    return hpFull, mpFull, petFull
end

local function all_full_now(cfgget)
    local hpFull, mpFull, petFull = player_hpmp_pet_full_flags(cfgget)
    if hpFull == nil or mpFull == nil or petFull == nil then return false end
    return hpFull and mpFull and petFull
end

local function should_rest_now(cfgget)
    local party = party_manager()
    if not party then return false end

    local hpEnabled = (cfgget('auto.rest') == true)
    local mpEnabled = (cfgget('auto.rest_mp') == true)

    if not hpEnabled and not mpEnabled then
        return false
    end

    local hpPct = nil
    if type(party.GetMemberHPPercent) == 'function' then
        local ok, v = pcall(function() return party:GetMemberHPPercent(0) end)
        if ok and v ~= nil then
            hpPct = tonumber(v)
        end
    end

    local mpPct = player_mp_percent()

    local petPct = nil
    if type(party.GetMemberPetHPPercent) == 'function' then
        local ok, v = pcall(function() return party:GetMemberPetHPPercent(0) end)
        if ok and v ~= nil then
            petPct = tonumber(v)
        end
    end

    local hpNeed = false
    if hpEnabled then
        local rest_hp = tonumber(cfgget('rest_hp'))
        if rest_hp ~= nil then
            hpNeed = (hpPct ~= nil and hpPct > 0 and hpPct < rest_hp)
            if petPct ~= nil and petPct < rest_hp then
                hpNeed = true
            end
        end
    end

    local mpNeed = false
    if mpEnabled then
        local rest_mp = tonumber(cfgget('rest_mp'))
        if rest_mp ~= nil then
            mpNeed = (mpPct ~= nil and mpPct >= 0 and mpPct < rest_mp)
        end
    end

    return hpNeed or mpNeed
end

local function compute_mobs_ready(state, now)
    local ire = ire_state(state)
    local ua_cnt = n(state.live and state.live.mobs_attacking, 0)

    if ua_cnt > 0 then
        if n(ire.mobs_present_since_ts, 0.0) == 0.0 then
            ire.mobs_present_since_ts = now
        end
    else
        ire.mobs_present_since_ts = 0.0
    end

    local ready =
        (ua_cnt > 0) and
        (ire.mobs_present_since_ts ~= 0.0) and
        ((now - ire.mobs_present_since_ts) >= 2.5)

    return ua_cnt, ready
end

local function get_party_member_ids()
    local out = T{}
    local party = party_manager()
    if not party then return out end

    for i = 0, 17 do
        local active = tonumber(party:GetMemberIsActive(i) or 0) or 0
        if active == 1 then
            local sid = tonumber(party:GetMemberServerId(i) or 0) or 0
            if sid > 0 then
                out[#out + 1] = sid
            end
        end
    end

    return out
end

local function get_player_server_id()
    local party = party_manager()
    if not party then return 0 end
    return tonumber(party:GetMemberServerId(0) or 0) or 0
end

local function build_party_member_id_set()
    local out = T{}
    local ids = get_party_member_ids()
    for i = 1, #ids do
        local sid = tonumber(ids[i] or 0) or 0
        if sid > 0 then
            out[sid] = true
        end
    end
    return out
end

local function claim_is_party_or_free(claim_id)
    claim_id = tonumber(claim_id or 0) or 0
    if claim_id == 0 then
        return true
    end

    local ids = get_party_member_ids()
    for i = 1, #ids do
        if tonumber(ids[i] or 0) == claim_id then
            return true
        end
    end

    return false
end

local function get_claim_state(claim_id, player_sid, party_sid_set)
    claim_id = tonumber(claim_id or 0) or 0
    player_sid = tonumber(player_sid or 0) or 0

    if claim_id == 0 then
        return 'free'
    end

    if player_sid > 0 and claim_id == player_sid then
        return 'self'
    end

    if party_sid_set and party_sid_set[claim_id] == true then
        return 'party'
    end

    return 'other'
end

local function home_valid(ire)
    return ire.home_x ~= nil and ire.home_y ~= nil
end

-- Capture Home on start, and on an explicit Rehome request.
--
-- "Start" = the first tick we run while not paused and not already homed.
-- Deliberately NOT captured while engaged/resting: the anchor should be
-- where you chose to stand, not where a fight happened to end.
local function maybe_capture_home(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local ire    = ire_state(state)

    if ire.home_rehome_req == true then
        local x, y, z = player_position()
        if x ~= nil and y ~= nil then
            ire.home_x, ire.home_y, ire.home_z = x, y, z
            ire.home_rehome_req = false
            dbg(args, ('[home] rehomed to x=%.1f y=%.1f z=%.1f'):format(x, y, z))
        end
        return
    end

    if home_valid(ire) then return end
    if ctx.engaged01 == 1 or ctx.resting01 == 1 then return end

    local x, y, z = player_position()
    if x == nil or y == nil then return end
    ire.home_x, ire.home_y, ire.home_z = x, y, z
    dbg(args, ('[home] set x=%.1f y=%.1f z=%.1f'):format(x, y, z))
end

-- Where auto-target measures from. Home unless Home is disabled or unset,
-- in which case fall back to the player so the bot still works.
local function anchor_position(args)
    local ire = ire_state(args.state)
    if args.cfgget('home.disabled') ~= true and home_valid(ire) then
        return ire.home_x, ire.home_y, ire.home_z, true
    end
    local x, y, z = player_position()
    return x, y, z, false
end

local function bot_center_valid(ire)
    return ire.bot_center_x ~= nil and ire.bot_center_z ~= nil
end

local function maybe_capture_bot_center(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local ire = ire_state(state)

    if cfgget('auto.bot') ~= true then
        ire.bot_center_x = nil
        ire.bot_center_y = nil
        ire.bot_center_z = nil
        ire.bot_returning = false
        return
    end

    if bot_center_valid(ire) then
        return
    end

    if ctx.engaged01 == 1 or ctx.resting01 == 1 then
        return
    end

    local x, y, z = player_position()
    if x == nil or z == nil then
        return
    end

    ire.bot_center_x = x
    ire.bot_center_y = y
    ire.bot_center_z = z
    ire.bot_returning = false
    dbg(args, ('bot center set x=%.2f z=%.2f'):format(x, z))
end

local function build_live_mob_list(state)
    local ire = ire_state(state)
    local list = T{}

    ire.bot_enemy_list = list
    ire.bot_enemy_count = 0
    ire.bot_enemy_free_count = 0
    ire.bot_enemy_party_count = 0
    ire.bot_enemy_other_count = 0

    local player_sid = get_player_server_id()
    local party_sid_set = build_party_member_id_set()

    for idx = 0, 2047 do
        local is_mob = false
        if type(GetIsMobByIndex) == 'function' then
            local ok, result = pcall(GetIsMobByIndex, idx)
            is_mob = (ok and result == true)
        end

        if is_mob then
            local ent = get_entity(idx)
            if ent then
                local name = ent.Name
                local hp = entity_hp_percent(ent)
                local dist_player = entity_distance(ent)
                local ex, ey, ez = entity_position(ent)

                if type(name) == 'string'
                    and name ~= ''
                    and hp ~= nil and hp > 0
                    and dist_player ~= nil
                then
                    local claim_id = entity_claim_id(ent)
                    local claim_state = get_claim_state(claim_id, player_sid, party_sid_set)

                    local dist_center = nil
                    if bot_center_valid(ire) then
                        dist_center = dist2d(ex, ez, ire.bot_center_x, ire.bot_center_z)
                    end

                    list[#list + 1] = {
                        index = idx,
                        server_id = entity_server_id(ent),
                        claim_id = claim_id,
                        claim_state = claim_state,
                        free_or_party = (claim_state == 'free' or claim_state == 'self' or claim_state == 'party'),
                        name = name,
                        hp = hp,
                        dist = dist_player,
                        center_dist = dist_center,
                        x = ex,
                        y = ey,
                        z = ez,
                    }
                end
            end
        end
    end

    table.sort(list, function(a, b)
        local ad = tonumber(a.dist or 999999) or 999999
        local bd = tonumber(b.dist or 999999) or 999999
        if ad ~= bd then
            return ad < bd
        end

        local ac = tonumber(a.center_dist or 999999) or 999999
        local bc = tonumber(b.center_dist or 999999) or 999999
        if ac ~= bc then
            return ac < bc
        end

        return (tonumber(a.index or 0) or 0) < (tonumber(b.index or 0) or 0)
    end)

    ire.bot_enemy_list = list
    ire.bot_enemy_count = #list

    local free_cnt, party_cnt, other_cnt = 0, 0, 0
    for i = 1, #list do
        local cs = tostring(list[i].claim_state or '')
        if cs == 'free' or cs == 'self' then
            free_cnt = free_cnt + 1
        elseif cs == 'party' then
            party_cnt = party_cnt + 1
        else
            other_cnt = other_cnt + 1
        end
    end

    ire.bot_enemy_free_count = free_cnt
    ire.bot_enemy_party_count = party_cnt
    ire.bot_enemy_other_count = other_cnt

    return list
end

local function find_best_bot_candidate(state, ctx)
    local ire = ire_state(state)
    local mobs = ire.bot_enemy_list or T{}

    -- If bot center was never captured (e.g. bot mode enabled while already engaged),
    -- we still proceed using player distance as the range check fallback.
    -- The early bail that used to be here caused "no candidate found" whenever
    -- the center hadn't been set yet.

    local best = nil
    local cur_sid = tonumber(ctx and ctx.target_server_id or 0) or 0
    local cur_dist = tonumber(ctx and (ctx.target_distance or ctx.dist) or 999999) or 999999

    local function claim_priority(mob)
        local cs = mob.claim_state
        if cs == 'self'  then return 0 end
        if cs == 'party' then return 1 end
        return 2  -- free
    end

    for i = 1, #mobs do
        local mob = mobs[i]

        local within_center =
            (mob.center_dist ~= nil and mob.center_dist <= 25.0) or
            (mob.center_dist == nil and mob.dist ~= nil and mob.dist <= 25.0)
        local targetable_claim = (mob.claim_state == 'free' or mob.claim_state == 'self' or mob.claim_state == 'party')

        if within_center and targetable_claim then
            local cur_ok =
                cur_sid == mob.server_id and
                (ctx and ctx.target_valid == true) and
                (ctx and ctx.target_dead ~= true) and
                (cur_dist <= 25.0) and
                ((ctx.target_claim_free_or_party == true) or claim_is_party_or_free(ctx.target_claim_id))

            if cur_ok then
                return mob, mobs
            end

            if best == nil then
                best = mob
            else
                -- Always pick closest - list is already sorted by dist
                local best_dist = tonumber(best.dist or 999999) or 999999
                local mob_dist  = tonumber(mob.dist or 999999) or 999999
                if mob_dist < best_dist then
                    best = mob
                end
            end
        end
    end

    return best, mobs
end

local function current_target_matches_pending(ctx, ire)
    if not ctx or not ire then return false end
    if (ctx.target_valid ~= true) or (ctx.target_dead == true) then return false end

    local pending_sid = tonumber(ire.bot_target_server_id or 0) or 0
    local target_sid  = tonumber(ctx.target_server_id or 0) or 0

    -- Match by index first - SID may not have propagated yet after SetTargetIndex
    local pending_idx = tonumber(ire.bot_target_index or 0) or 0
    local target_idx  = tonumber(ctx.target_index or 0) or 0
    local idx_match   = (pending_idx > 0 and target_idx == pending_idx)

    -- Also accept SID match in case index changed (mob repop)
    local sid_match = (pending_sid > 0 and target_sid == pending_sid)

    if not idx_match and not sid_match then
        return false
    end

    local dist = tonumber(ctx.target_distance or ctx.dist or 999999) or 999999
    if dist > 20.0 then return false end

    if not ((ctx.target_claim_free_or_party == true) or claim_is_party_or_free(ctx.target_claim_id)) then
        return false
    end

    return true
end

local function player_is_near_bot_center(state)
    local ire = ire_state(state)
    if not bot_center_valid(ire) then return true end

    local x, y, z = player_position()
    if x == nil or z == nil then return true end

    local d = dist2d(x, z, ire.bot_center_x, ire.bot_center_z)
    if d == nil then return true end

    return d <= 2.0
end

local function try_return_to_bot_center(args)
    local state = args.state
    local ctx = args.ctx
    local movement = args.movement
    local ire = ire_state(state)

    if not bot_center_valid(ire) then
        return false
    end

    if ctx.engaged01 == 1 or ctx.resting01 == 1 then
        ire.bot_returning = false
        return false
    end

    if player_is_near_bot_center(state) then
        if ire.bot_returning == true then
            dbg_bot(args, 'bot_return_complete', 'bot return complete', 1.5)
        end
        ire.bot_returning = false
        movement_stop(movement)
        return false
    end

    ire.bot_returning = true

    -- Skip if a timed walk is already in progress
    if movement and type(movement.walk_timed_active) == 'function' and movement.walk_timed_active() then
        return true
    end

    local px, _, pz = player_position()
    local dist_to_center = (px and pz)
        and dist2d(px, pz, ire.bot_center_x, ire.bot_center_z)
        or 5.0

    local hold_sec = math.max(WALK_MIN_SEC,
        math.min(WALK_MAX_SEC, dist_to_center / WALK_SPEED_YALMS_SEC))

    dbg_bot(args, 'bot_return_walk',
        ('bot return walk center x=%.2f z=%.2f dist=%.1f hold=%.2fs'):format(
            ire.bot_center_x, ire.bot_center_z, dist_to_center, hold_sec), 1.5)

    if movement and type(movement.walk_timed) == 'function' then
        return movement.walk_timed(hold_sec)
    end

    return movement_walk(movement)
end

-- Sleep Other facing prep. See GeneralLua.utils.sleep_facing_plan for the
-- math. When there's an eligible sleep-other target and the player isn't
-- on the far side of <t> from it, hold A or D to orbit into position, then
-- release. Owns the tick while active so tick_engaged_run's W-hold doesn't
-- muddle the strafe with forward movement. Once released, the next tick
-- (RANGED entry in the ladder) fires the bolt normally.
local function tick_sleep_facing(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local movement = args.movement
    local now      = args.now
    local ire      = ire_state(state)

    local function release_and_clear()
        if movement then
            if type(movement.key_a_up) == 'function' then movement.key_a_up() end
            if type(movement.key_d_up) == 'function' then movement.key_d_up() end
        end
        ire.sleep_facing_active     = false
        ire.sleep_facing_key        = 'none'
        ire.sleep_facing_release_at = 0.0   -- kept for schema compatibility; unused
        state.combat = state.combat or {}
        state.combat.sleep_facing_active_lane = false
    end

    -- Only meaningful while engaged with Sleep Other on and Auto Ranged
    -- itself on -- without auto.ranged the RANGED ladder entry never
    -- fires the bolt, so strafing "to prepare the shot" is just moving
    -- the character for no reason. Any of these off: release and bail.
    if ctx.engaged01 ~= 1
       or cfgget('auto.ranged') ~= true
       or cfgget('ranged.sleep_other') ~= true
       or ctx.spells_locked
    then
        if ire.sleep_facing_active then release_and_clear() end
        return false
    end

    -- Do NOT strafe while W is held: tick_engaged_run holds W to close
    -- melee distance, and a strafe here fights that. Wait until we're
    -- stationary (in range, chase released W) before correcting the angle.
    if state.live and state.live.player_moving_w == true then
        if ire.sleep_facing_active then release_and_clear() end
        return false
    end

    if type(ctx.sleep_other_target) ~= 'function' then
        if ire.sleep_facing_active then release_and_clear() end
        return false
    end
    local sleep_sid, sleep_idx = ctx.sleep_other_target()
    if not sleep_sid or not sleep_idx or sleep_idx == 0 then
        if ire.sleep_facing_active then release_and_clear() end
        return false
    end

    -- Closed-loop: re-plan every tick using live heading. No hold_sec.
    -- If plan says we're within tolerance, release and let the shot fire.
    -- If it says we need to strafe, hold the key one more tick and check
    -- again. Direction (A vs D) is re-derived each tick from the current
    -- delta, so we can't overshoot and keep going -- the sign flips the
    -- moment we cross the target angle.
    -- Closed-loop: re-plan every tick using live positions. The pivot is
    -- whatever we're locked on (state.live.player_target_index). If we
    -- lose the pivot, tick_engaged_run's own gates catch it; sleep_facing
    -- just bails.
    local pivot_idx = tonumber(state.live and state.live.player_target_index or 0) or 0
    if pivot_idx == 0 then
        if ire.sleep_facing_active then release_and_clear() end
        return false
    end

    local plan = GeneralLua.utils.sleep_facing_plan(pivot_idx, sleep_idx)
    if not plan then
        if ire.sleep_facing_active then release_and_clear() end
        return false
    end
    if plan.key == 'none' then
        if ire.sleep_facing_active then release_and_clear() end
        return false   -- aligned; ladder fires this or next tick
    end

    -- STRAFE TIMEOUT. If we've held a key for more than SLEEP_STRAFE_TIMEOUT_SEC
    -- without ever falling within tolerance, something about this sleep mob's
    -- geometry isn't matchable (mob rotating, on a different z-plane, wall
    -- between us). Blacklist the sid so sleep_other_target skips it, and
    -- release keys. Runs before we push the key-down again so the timeout
    -- fires the same tick, not one tick late.
    local SLEEP_STRAFE_TIMEOUT_SEC = 5.0
    if ire.sleep_facing_active
       and (now - (tonumber(ire.sleep_facing_started_at or 0.0) or 0.0)) >= SLEEP_STRAFE_TIMEOUT_SEC
    then
        state.combat = state.combat or {}
        state.combat.sleep_other_blacklist = state.combat.sleep_other_blacklist or {}
        state.combat.sleep_other_blacklist[sleep_sid] = now + 60.0
        dbg(args, ('[sleep-facing] timeout after %.1fs, blacklisting sid %d for 60s'):format(
            SLEEP_STRAFE_TIMEOUT_SEC, sleep_sid))
        safe_send(('/echo [bovinebattle] sleep-other unreachable (5s strafe), skipping sid %d'):format(sleep_sid))
        release_and_clear()
        return false
    end

    -- Not aligned. Hold the key this plan chose.
    if not ire.sleep_facing_active then
        ire.sleep_facing_active     = true
        ire.sleep_facing_started_at = now
        state.combat = state.combat or {}
        state.combat.sleep_facing_active_lane = true
        -- W could be held from tick_engaged_run's previous frame; release
        -- it so we're purely orbiting (locked = A/D circles pivot).
        if movement and type(movement.key_w_up) == 'function' then
            movement.key_w_up()
        end
        dbg(args, ('[sleep-facing] start strafe %s (delta=%+.1fdeg)'):format(
            plan.key, math.deg(plan.delta_rad)))
    elseif plan.key ~= ire.sleep_facing_key then
        -- Direction flipped mid-strafe -- release the old key before we
        -- press the new one so we don't have both down for a frame.
        if movement then
            if ire.sleep_facing_key == 'a' and type(movement.key_a_up) == 'function' then movement.key_a_up() end
            if ire.sleep_facing_key == 'd' and type(movement.key_d_up) == 'function' then movement.key_d_up() end
        end
        dbg(args, ('[sleep-facing] flip %s -> %s (delta=%+.1fdeg)'):format(
            ire.sleep_facing_key, plan.key, math.deg(plan.delta_rad)))
    end
    ire.sleep_facing_key = plan.key

    if movement then
        if plan.key == 'a' and type(movement.key_a_down) == 'function' then
            movement.key_a_down()
        elseif plan.key == 'd' and type(movement.key_d_down) == 'function' then
            movement.key_d_down()
        end
    end
    return true
end

-- ---------------------------------------------------------------------------
-- STUCK-WALL DETECTOR
--
-- Fires when a movement round has W held (or a strafe key held) for a while
-- with no meaningful XY progress. Ground plane is X/Y (Z is height per the
-- FFXI axis rule -- ignore for planar stuck detection).
--
-- Design:
--   * Per-caller state under ire.stuck[key] so chase / engaged-run / rear-
--     walk don't stomp each other.
--   * Anchor point (x, y, t) rolled forward whenever we've moved > EPSILON.
--     Stuck fires when we've been sitting on the same anchor for WINDOW
--     while intending to move.
--   * Suppression: casting, ranged in flight, no target -- movement is not
--     really "intended" so we don't false-positive on those.
--
-- Reactions live at the call site: chase does random-strafe + blacklist;
-- rear-walk swaps the strafe direction the loop is already holding.
-- ---------------------------------------------------------------------------
local STUCK_EPSILON_YALMS = 0.5
local STUCK_WINDOW_SEC    = 1.0
local STUCK_STRAFE_SEC    = 0.8

local function stuck_state(ire, key)
    ire.stuck = ire.stuck or {}
    local s = ire.stuck[key]
    if not s then
        s = { anchor_x = 0.0, anchor_y = 0.0, anchor_at = 0.0,
              strafe_key = 'none', strafe_until = 0.0,
              attempts = 0, seeded = false }
        ire.stuck[key] = s
    end
    return s
end

local function stuck_reset(ire, key)
    if not ire.stuck then return end
    ire.stuck[key] = nil
end

-- Roll the anchor forward if we've moved. Returns true if we've been
-- anchored (no meaningful movement) for at least STUCK_WINDOW_SEC.
local function stuck_check(state, ire, now, key, ctx)
    if ctx and (ctx.spells_locked == true or ctx.ranged_busy == true) then
        return false
    end
    if ctx and ctx.target_valid ~= true then return false end

    local px = tonumber(state.live and state.live.player_x)
    local py = tonumber(state.live and state.live.player_y)
    if px == nil or py == nil then return false end

    local s = stuck_state(ire, key)

    if not s.seeded then
        s.anchor_x  = px
        s.anchor_y  = py
        s.anchor_at = now
        s.seeded    = true
        return false
    end

    local dx = px - s.anchor_x
    local dy = py - s.anchor_y
    local moved = math.sqrt(dx * dx + dy * dy)
    if moved >= STUCK_EPSILON_YALMS then
        s.anchor_x  = px
        s.anchor_y  = py
        s.anchor_at = now
        return false
    end

    return (now - (s.anchor_at or now)) >= STUCK_WINDOW_SEC
end

local function stuck_strafe_active(ire, now, key)
    local s = stuck_state(ire, key)
    if s.strafe_until <= 0.0 then return false end
    return now < s.strafe_until
end

local function stuck_start_strafe(state, ire, movement, now, key, prev_key)
    if not movement then return 'none' end
    local pick
    if prev_key == 'a' then
        pick = 'd'
    elseif prev_key == 'd' then
        pick = 'a'
    else
        pick = (math.random(2) == 1) and 'a' or 'd'
    end

    if type(movement.key_a_up) == 'function' then movement.key_a_up() end
    if type(movement.key_d_up) == 'function' then movement.key_d_up() end

    if pick == 'a' and type(movement.key_a_down) == 'function' then
        movement.key_a_down()
    elseif pick == 'd' and type(movement.key_d_down) == 'function' then
        movement.key_d_down()
    else
        return 'none'
    end

    local s = stuck_state(ire, key)
    s.strafe_key   = pick
    s.strafe_until = now + STUCK_STRAFE_SEC
    s.attempts     = (s.attempts or 0) + 1
    s.anchor_x  = tonumber(state.live and state.live.player_x) or s.anchor_x
    s.anchor_y  = tonumber(state.live and state.live.player_y) or s.anchor_y
    s.anchor_at = now
    return pick
end

local function stuck_end_strafe(ire, movement, key)
    if movement then
        if type(movement.key_a_up) == 'function' then movement.key_a_up() end
        if type(movement.key_d_up) == 'function' then movement.key_d_up() end
    end
    local s = stuck_state(ire, key)
    s.strafe_until = 0.0
    s.strafe_key   = 'none'
end

-- Thief action state machine. Drives sneak_only (walk behind mob + SA)
-- and trick_attack (walk behind tank + TA, optionally followed by WS).
-- Runs from the engaged branch AFTER tick_sleep_facing (sleep other is
-- higher priority; if it owns the movement lane we don't). Once a phase
-- starts, it runs to completion (or timeout) per spec: whichever action
-- started first finishes first.
local THIEF_RECORRECT_RAD    = math.rad(5)    -- align target AND re-correct band: get within 5 deg to fire, re-align if we drift past it
local THIEF_STRAFE_INVERT    = false   -- flip if strafe direction is reversed
local THIEF_TA_DIST_TARGET   = 3.5     -- yalms behind tank
local THIEF_TA_DIST_HYST     = 0.5     -- deadband so W/S doesn't oscillate
local THIEF_ACTION_TIMEOUT   = 5.0     -- give up on the whole action after this

local function tick_thief_action(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local movement = args.movement
    local now      = args.now

    state.combat = state.combat or {}
    local ta = state.combat.thief_action
    if ta == nil then return false end

    -- Universal release: A/D/W/S up + clear the slot.
    local function release_and_end(reason)
        if movement then
            if type(movement.key_a_up) == 'function' then movement.key_a_up() end
            if type(movement.key_d_up) == 'function' then movement.key_d_up() end
            if type(movement.key_w_up) == 'function' then movement.key_w_up() end
            if type(movement.key_s_up) == 'function' then movement.key_s_up() end
        end
        state.combat.thief_action = nil
        if reason and reason ~= '' then
            dbg(args, '[thief] ' .. reason)
        end
    end

    -- Global bailouts: engagement dropped, target dead, wrong state.
    if ctx.engaged01 ~= 1 or ctx.target_dead then
        release_and_end('engagement/target lost')
        return false
    end
    if ctx.spells_locked then
        -- Don't fire keys while a cast is in flight; resume after.
        return true
    end
    if (now - (tonumber(ta.started_at) or 0)) > THIEF_ACTION_TIMEOUT then
        release_and_end('timeout')
        return false
    end

    -- First tick of a freshly staged action: tick_engaged_run held W last
    -- frame to close melee, and press_key only manages keys IT staged --
    -- so lift W (and S) explicitly once, same as sleep_facing does at
    -- strafe start. Without this the strafe fights a still-held W.
    if ta.entered ~= true then
        ta.entered = true
        if movement then
            if type(movement.key_w_up) == 'function' then movement.key_w_up() end
            if type(movement.key_s_up) == 'function' then movement.key_s_up() end
        end
    end

    -- Currently-held-key management: swap keys cleanly on direction flip.
    local function press_key(new_key)
        if new_key == ta.fire_key then return end
        if movement then
            if ta.fire_key == 'a' then movement.key_a_up() end
            if ta.fire_key == 'd' then movement.key_d_up() end
            if ta.fire_key == 'w' then movement.key_w_up() end
            if ta.fire_key == 's' then movement.key_s_up() end
            if new_key    == 'a' then movement.key_a_down() end
            if new_key    == 'd' then movement.key_d_down() end
            if new_key    == 'w' then movement.key_w_down() end
            if new_key    == 's' then movement.key_s_down() end
        end
        ta.fire_key = new_key
    end

    ----------------------------------------------------------------
    -- SNEAK ONLY
    ----------------------------------------------------------------
    if ta.kind == 'sneak_only' then
        if ta.phase == 'align' then
            local plan = GeneralLua.utils.rear_facing_plan(ta.target_idx)
            if not plan then
                -- Transient: heading/entity reads hiccup for a frame now
                -- and then. Bailing here cleared the action, let
                -- tick_engaged_run hold W for a frame, then the ladder
                -- re-staged -- the A/W/A/W tapping. HOLD instead: keep
                -- the current key, wait for a readable frame; the 5s
                -- action timeout backstops a persistent failure.
                if ta.plan_nil_logged ~= true then
                    ta.plan_nil_logged = true
                    dbg(args, '[thief] sneak_only: rear plan unreadable, holding')
                end
                return true
            end
            ta.plan_nil_logged = false
            -- Advance to fire once inside the 5 deg re-correct band --
            -- NOT rear_facing_plan's own 'none' (10 deg), or align and
            -- the fire re-check would ping-pong for a mob sitting between
            -- 5 and 10 deg. Direction still comes from plan.key.
            if math.abs(plan.delta_rad or 0) <= THIEF_RECORRECT_RAD then
                press_key('none')
                ta.phase = 'fire'
                return true
            end
            press_key(plan.key)
            return true
        end

        if ta.phase == 'fire' then
            -- Trigger only WHEN in position: the align tick released the
            -- key a frame ago and drift (ours or the mob turning) can
            -- carry us out of the window before the JA lands. Re-verify
            -- at the trigger -- movement keys idle AND still behind the
            -- mob -- and drop back to align if we slipped.
            press_key('none')
            local plan = GeneralLua.utils.rear_facing_plan(ta.target_idx)
            if not plan then
                if ta.plan_nil_logged ~= true then
                    ta.plan_nil_logged = true
                    dbg(args, '[thief] sneak_only: rear plan unreadable at fire, holding')
                end
                return true
            end
            ta.plan_nil_logged = false
            -- Re-correct at 5 deg (tighter than the 10 deg align entry):
            -- align gets us into the window, this keeps us there. If we
            -- drifted past 5 deg, go re-align before firing.
            if math.abs(plan.delta_rad or 0) > THIEF_RECORRECT_RAD then
                ta.phase = 'align'
                return true
            end
            if not ctx.do_ja('Sneak Attack', '<me>', 'SNEAK_ATTACK') then
                return true   -- do_ja gates (ranged busy, etc); retry
            end
            GeneralLua.cooldowns.set('SNEAK_ATTACK', 60.0)
            -- SA is a buff (id 65) that sits on us until the next melee
            -- swing consumes it. The mob can turn during that window --
            -- if it does, our swing lands from the front and the JA is
            -- wasted. Hold position (keep re-correcting behind) until the
            -- buff clears.
            ta.phase        = 'hold_buff'
            ta.buff_since   = now
            dbg(args, '[thief] sneak_only: SA fired, holding rear until swing')
            return true
        end

        if ta.phase == 'hold_buff' then
            -- Buff gone (swing consumed it) -> done. Also cap at a
            -- generous timeout in case the buff read is flaky or the
            -- swing never comes (mob died, we got disengaged).
            local sa_up = false
            local ids = ctx.player_buff_ids
            if type(ids) == 'table' then
                for i = 1, #ids do
                    if ids[i] == 65 then sa_up = true break end
                end
            end
            if not sa_up then
                release_and_end('sneak_only: buff consumed, done')
                return true
            end
            if (now - (ta.buff_since or 0)) > 8.0 then
                release_and_end('sneak_only: buff hold timeout')
                return true
            end
            -- Keep re-correcting: same 5 deg band. Buff up = we still
            -- want to be behind when the swing lands.
            local plan = GeneralLua.utils.rear_facing_plan(ta.target_idx)
            if not plan then return true end
            if math.abs(plan.delta_rad or 0) > THIEF_RECORRECT_RAD then
                press_key(plan.key)
            else
                press_key('none')
            end
            return true
        end
        return true
    end

    ----------------------------------------------------------------
    -- TRICK ATTACK (with optional +WS)
    ----------------------------------------------------------------
    if ta.kind == 'trick_attack' then
        -- Live lookups -- tank + player + mob can all move.
        -- All lookups are per-frame and can hiccup individually. A nil
        -- here is treated as TRANSIENT: hold current keys, wait for a
        -- readable frame, let the 5s action timeout backstop persistent
        -- failure. Hard-bailing on one bad frame produced the same
        -- key-tapping churn the sneak align had.
        local function hold_transient(what)
            if ta.plan_nil_logged ~= true then
                ta.plan_nil_logged = true
                dbg(args, '[thief] trick_attack: ' .. what .. ' unreadable, holding')
            end
            return true
        end
        local px, py = GeneralLua.utils.player_position()
        local ply    = GeneralLua.utils.get_player_entity()
        local ph     = GeneralLua.utils.entity_heading(ply)
        if px == nil or ph == nil then return hold_transient('player pos/heading') end
        local tank_ent = GeneralLua.utils.get_entity(ta.tank_idx)
        if not tank_ent then return hold_transient('tank entity') end
        local tx, ty = GeneralLua.utils.entity_position(tank_ent)
        local th     = GeneralLua.utils.entity_heading(tank_ent)
        if tx == nil or th == nil then return hold_transient('tank pos/heading') end
        local mob_ent = GeneralLua.utils.get_entity(ta.target_idx)
        if not mob_ent then return hold_transient('mob entity') end
        local mx, my = GeneralLua.utils.entity_position(mob_ent)
        if mx == nil then return hold_transient('mob pos') end
        ta.plan_nil_logged = false

        local function norm_pi(a)
            while a >   math.pi do a = a - 2 * math.pi end
            while a <= -math.pi do a = a + 2 * math.pi end
            return a
        end

        if ta.phase == 'align_heading' then
            -- Orbit mob (A/D) until player heading equals tank heading.
            -- Both point at mob when the player is on tank's ray from mob.
            local delta = norm_pi(th - ph)
            if math.abs(delta) <= THIEF_RECORRECT_RAD then
                -- Verify we're BEHIND tank (further from mob than tank),
                -- not between tank and mob. If in front, keep orbiting.
                local dp_to_mob = math.sqrt((mx-px)*(mx-px) + (my-py)*(my-py))
                local dt_to_mob = math.sqrt((mx-tx)*(mx-tx) + (my-ty)*(my-ty))
                if dp_to_mob > dt_to_mob then
                    press_key('none')
                    ta.phase = 'align_distance'
                    return true
                end
            end
            local key
            if delta > 0 then
                key = THIEF_STRAFE_INVERT and 'a' or 'd'
            else
                key = THIEF_STRAFE_INVERT and 'd' or 'a'
            end
            press_key(key)
            return true
        end

        if ta.phase == 'align_distance' then
            -- Behind tank on the line to mob. W closes distance to tank,
            -- S opens it. Deadband hysteresis avoids oscillation.
            local dt_now = math.sqrt((tx-px)*(tx-px) + (ty-py)*(ty-py))
            if dt_now > THIEF_TA_DIST_TARGET + THIEF_TA_DIST_HYST then
                press_key('w')
                return true
            elseif dt_now < THIEF_TA_DIST_TARGET - THIEF_TA_DIST_HYST then
                press_key('s')
                return true
            end
            press_key('none')
            ta.phase = 'fire'
            return true
        end

        if ta.phase == 'fire' then
            -- Same when-in-position rule as sneak: re-verify heading and
            -- distance at the trigger (lookups above are this-tick live)
            -- and drop back to the right align phase if we slipped.
            press_key('none')
            local delta_now = norm_pi(th - ph)
            if math.abs(delta_now) > THIEF_RECORRECT_RAD then
                ta.phase = 'align_heading'
                return true
            end
            local dt_chk = math.sqrt((tx-px)*(tx-px) + (ty-py)*(ty-py))
            if dt_chk > THIEF_TA_DIST_TARGET + THIEF_TA_DIST_HYST
               or dt_chk < THIEF_TA_DIST_TARGET - THIEF_TA_DIST_HYST then
                ta.phase = 'align_distance'
                return true
            end
            if not ctx.do_ja('Trick Attack', '<me>', 'TRICK_ATTACK') then
                return true   -- do_ja gate blocked; retry
            end
            GeneralLua.cooldowns.set('TRICK_ATTACK', 60.0)
            if ta.with_ws then
                ta.phase    = 'wait_ws_window'
                ta.ws_since = now
                return true
            end
            release_and_end('trick_attack: TA fired')
            return true
        end

        if ta.phase == 'wait_ws_window' then
            -- After TA lands, fire the configured WS via the standard
            -- do_ws helper (same WS Name dropdown as auto.ws). Small
            -- settle delay so TA's server-side processing lands first.
            if (now - (ta.ws_since or 0)) < 0.5 then return true end
            -- A /ra pull rolling straight into TA+WS hits the same ranged
            -- recovery lock the ladder WS entry gates on, and 0.5s of
            -- ws_since is nowhere near enough to clear it. HOLD (return
            -- true) rather than bail -- bailing here would be read as a
            -- failed sequence, and this check has to sit ahead of the TP
            -- gate so a hold isn't mistaken for "TP dropped". The 5s
            -- THIEF_ACTION_TIMEOUT from ta.started_at backstops the hold.
            if ctx.ranged_ws_busy == true then return true end
            if (tonumber(ctx.tp) or 0) < 1000 then
                release_and_end('trick_attack: TP dropped before WS')
                return false
            end
            if not (ctx.dist and ctx.dist <= 4) then
                release_and_end('trick_attack: out of WS range')
                return false
            end
            if not ctx.do_ws then
                release_and_end('trick_attack: no ws helper')
                return false
            end
            ctx.do_ws()
            release_and_end('trick_attack: TA+WS fired')
            return true
        end
        return true
    end

    return true
end

local function tick_engaged_run(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local movement = args.movement

    -- Local helper: full stop + strafe release + run_active clear. Used by
    -- every early-return path so a strafe key can't stay held past the
    -- moment the mob dies / spells lock / whatever.
    local function full_stop()
        movement_stop(movement)
        local ire = ire_state(state)
        ire.run_active = false
        if ire.stuck and ire.stuck.engaged then
            if movement then
                if type(movement.key_a_up) == 'function' then movement.key_a_up() end
                if type(movement.key_d_up) == 'function' then movement.key_d_up() end
            end
            ire.stuck.engaged = nil
        end
    end

    if ctx.engaged01 ~= 1 then
        full_stop()
        return false
    end

    if cfgget('auto.run') ~= true then
        full_stop()
        return false
    end

    -- Standoff ranged wins over Run. The whole point of the top-row
    -- 'Ranged' checkbox is that we stand still and shoot, so the
    -- engaged-run loop must not close to melee underneath it. Gated here
    -- rather than by force-unticking Run, so unticking Ranged restores
    -- whatever the user actually had set.
    if cfgget('auto.rangedmode') == true then
        full_stop()
        return false
    end

    -- Target gate: when the mob dies (or becomes invalid) while we're still in
    -- the engaged-window, stop running. Without this, a cast that finishes
    -- after target death drops spells_locked and we resume walking toward a
    -- corpse / blank distance reading until the engaged status finally clears.
    if (ctx.target_dead == true) or (ctx.target_valid == false) then
        full_stop()
        return false
    end

    if ctx.spells_locked == true then
        full_stop()
        return false
    end

    -- Ranged shots cancel / retarget wrong if we move mid-fire. spells_locked
    -- covers casts (Ashita clears it when the cast finishes/interrupts), but
    -- /ra rides ranged_busy instead -- separate flag, set true from dispatch
    -- through RANGED_POST_RESOLVE_SEC after the projectile resolves. Without
    -- this the engaged-run loop kept W held straight through the shot and
    -- the first bolt at an enraged, moving mob whiffed / cancelled every
    -- time.
    if ctx.ranged_busy == true then
        full_stop()
        return false
    end

    local dist = tonumber(ctx.target_distance or ctx.dist)
    if dist == nil then
        full_stop()
        return false
    end

    local party_mode = (cfgget('auto.party') == true)
    local run_stop_dist = 3.3
    local party_run_start = 8.0

    if state.flags and state.flags.player_cannot_see_target == true and dist <= run_stop_dist then
        state.flags.player_cannot_see_target = false
        if movement and type(movement.tap_left_for_los) == 'function' then
            dbg(args, 'tapped A for LOS')
            movement.tap_left_for_los()
            return true
        end
    end

    if dist <= run_stop_dist then
        full_stop()
        return false
    end

    if party_mode and dist > party_run_start then
        full_stop()
        return false
    end

    local ire = ire_state(state)
    if ire.run_active ~= true then
        dbg(args, ('run/chase dist=%.1f'):format(dist))
        ire.run_active = true
    end

    movement_walk(movement)

    -- STUCK-WALL DETECTION. Same shape as chase: A/D strafe on first stuck,
    -- flip on second, blacklist + /attack off on the third. Blacklist window
    -- is 30s so if the mob is still on hate and reachable later, auto-target
    -- can pick it up again.
    local skey = 'engaged'
    local s = stuck_state(ire, skey)
    if stuck_strafe_active(ire, args.now or 0.0, skey) then
        return true    -- own the tick while strafe runs
    end
    if s.strafe_until > 0.0 and (args.now or 0.0) >= s.strafe_until then
        stuck_end_strafe(ire, movement, skey)
        s.seeded = false
    end
    if stuck_check(state, ire, args.now or 0.0, skey, ctx) == true then
        if (s.attempts or 0) >= 2 then
            local stuck_sid = tonumber(ctx.target_server_id or 0) or 0
            if stuck_sid ~= 0 and ire.at_blacklist then
                ire.at_blacklist[stuck_sid] = (args.now or 0.0) + 30.0
                dbg(args, ('[engaged-run] stuck on wall (sid %d): blacklisting 30s, /attack off'):format(
                    stuck_sid))
            else
                dbg(args, '[engaged-run] stuck on wall: /attack off')
            end
            movement_stop(movement)
            stuck_reset(ire, skey)
            ire.run_active = false
            if type(args.dispatch) == 'function' then
                args.dispatch('/attack off', 1.0)
            end
            return true
        end
        local pick = stuck_start_strafe(state, ire, movement, args.now or 0.0, skey, s.strafe_key)
        if pick ~= 'none' then
            dbg(args, ('[engaged-run] stuck detected, strafe %s (attempt %d)'):format(
                pick, s.attempts or 0))
        end
    end

    return true
end

local function try_pre_attack_shadows_for_target(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local now = args.now
    local ire = ire_state(state)

    if pre_attack_suppressed(state, now) then return false end

    if target_dead_or_invalid(ctx) then
        ire.pre_attack_retry_until = math.max(n(ire.pre_attack_retry_until, 0.0), now + 1.0)
        ire.engage_retry_until = math.max(n(ire.engage_retry_until, 0.0), now + 1.0)
        ire.bot_retry_until = math.max(n(ire.bot_retry_until, 0.0), now + 1.0)
        return false
    end

    if cfgget('auto.shadows') ~= true then return false end
    if type(ctx.shadows_can_attempt) ~= 'function' then return false end
    if type(ctx.do_shadows) ~= 'function' then return false end
    if ctx.shadows_can_attempt('pre_attack', false) ~= true then return false end

    dbg(args, 'pre-attack shadows')

    if ctx.do_shadows(false, 'pre_attack') then
        ire.pre_attack_retry_until = now + 1.0
        ire.engage_retry_until = math.max(n(ire.engage_retry_until, 0.0), now + 1.0)
        ire.bot_retry_until = math.max(n(ire.bot_retry_until, 0.0), now + 1.0)
        set_prep_action_settle(state, now, 1.0)
        return true
    end

    return false
end

local function try_pre_attack_hb_for_target(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local now = args.now
    local ire = ire_state(state)

    if pre_attack_suppressed(state, now) then return false end

    if target_dead_or_invalid(ctx) then
        ire.pre_attack_retry_until = math.max(n(ire.pre_attack_retry_until, 0.0), now + 1.0)
        ire.engage_retry_until = math.max(n(ire.engage_retry_until, 0.0), now + 1.0)
        ire.bot_retry_until = math.max(n(ire.bot_retry_until, 0.0), now + 1.0)
        return false
    end

    if now < n(ire.pre_attack_hb_retry_until, 0.0) then return false end
    if cfgget('auto.hb') ~= true then return false end
    if tostring(cfgget('auto.hb_mode') or 'atk') ~= 'atk' then return false end
    if ctx.hb_ready ~= true then return false end
    if ctx.spells_locked_soft == true then return false end
    if ctx.resting01 == 1 then return false end
    if ctx.engaged01 == 1 then return false end
    if ctx.pet_present ~= true then return false end
    if not hb_threshold_ok(cfgget) then return false end
    if type(ctx.do_hb) ~= 'function' then return false end

    dbg(args, 'pre-attack hb')

    if ctx.do_hb('HB') then
        ire.pre_attack_hb_retry_until = now + 1.0
        ire.pre_attack_retry_until = now + 1.0
        ire.engage_retry_until = math.max(n(ire.engage_retry_until, 0.0), now + 1.0)
        ire.bot_retry_until = math.max(n(ire.bot_retry_until, 0.0), now + 1.0)
        set_prep_action_settle(state, now, 1.0)
        return true
    end

    ire.pre_attack_hb_retry_until = now + 1.0
    return false
end

local function try_pre_attack_shadows_auto(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local now = args.now
    local ire = ire_state(state)

    if pre_attack_suppressed(state, now) then return false end
    if cfgget('auto.shadows') ~= true then return false end
    if type(ctx.shadows_can_attempt) ~= 'function' then return false end
    if type(ctx.do_shadows) ~= 'function' then return false end
    if ctx.shadows_can_attempt('pre_attack', false) ~= true then return false end

    dbg(args, 'pre-attack shadows')

    if ctx.do_shadows(false, 'pre_attack') then
        ire.pre_attack_retry_until = now + 1.0
        ire.engage_retry_until = math.max(n(ire.engage_retry_until, 0.0), now + 1.0)
        set_prep_action_settle(state, now, 1.0)
        return true
    end

    return false
end

local function try_pre_attack_hb_auto(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local now = args.now
    local ire = ire_state(state)

    if pre_attack_suppressed(state, now) then return false end
    if now < n(ire.pre_attack_hb_retry_until, 0.0) then return false end
    if cfgget('auto.hb') ~= true then return false end
    if tostring(cfgget('auto.hb_mode') or 'atk') ~= 'atk' then return false end
    if ctx.hb_ready ~= true then return false end
    if ctx.spells_locked_soft == true then return false end
    if ctx.resting01 == 1 then return false end
    if ctx.engaged01 == 1 then return false end
    if ctx.pet_present ~= true then return false end
    if not hb_threshold_ok(cfgget) then return false end
    if type(ctx.do_hb) ~= 'function' then return false end

    dbg(args, 'pre-attack hb')

    if ctx.do_hb('HB') then
        ire.pre_attack_hb_retry_until = now + 1.0
        ire.pre_attack_retry_until = now + 1.0
        ire.engage_retry_until = math.max(n(ire.engage_retry_until, 0.0), now + 1.0)
        set_prep_action_settle(state, now, 1.0)
        return true
    end

    ire.pre_attack_hb_retry_until = now + 1.0
    return false
end

local function try_idle_hb(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local now = args.now
    local ire = ire_state(state)

    if now < n(ire.idle_hb_retry_until, 0.0) then return false end
    if cfgget('auto.hb') ~= true then return false end
    if ctx.hb_ready ~= true then return false end
    if ctx.spells_locked_soft == true then return false end
    if ctx.resting01 == 1 then return false end
    if ctx.engaged01 == 1 then return false end
    if ctx.pet_present ~= true then return false end
    if not hb_threshold_ok(cfgget) then return false end
    if type(ctx.do_hb) ~= 'function' then return false end

    dbg(args, 'idle hb')

    if ctx.do_hb('HB') then
        ire.idle_hb_retry_until = now + 1.0
        return true
    end

    ire.idle_hb_retry_until = now + 1.0
    return false
end

local function try_idle_hb_party(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local now    = args.now
    local ire    = ire_state(state)

    if cfgget('auto.hb_party') ~= true then
        ire.idle_hb_party_retry_until   = nil
        ire.idle_hb_party_started_at    = nil
        return false
    end

    -- Only fires when idle (status 0). Not resting, not engaged.
    if ctx.resting01 == 1 then return false end
    if ctx.engaged01 == 1 then return false end
    if ctx.spells_locked_soft == true then return false end
    if not ctx.hb_party_hp_ok then
        ire.idle_hb_party_started_at = nil
        return false
    end
    if not ctx.hb_ready_notarget then return false end
    if type(ctx.do_hb) ~= 'function' then return false end

    -- Force-retry: see try_engaged_hb_party for the rationale. Same
    -- flag, same effect -- bot bypasses retry gate + started_at
    -- timeout immediately after a notify_hb_cast_interrupted or a
    -- safety-timeout expiry.
    if state.hb and state.hb.force_retry_now == true then
        state.hb.force_retry_now = false
        ire.idle_hb_party_started_at  = nil
        ire.idle_hb_party_retry_until = 0.0
    end

    -- Retry gate: 1s between attempts
    if now < (ire.idle_hb_party_retry_until or 0.0) then return false end

    -- 10s window: if we started trying and haven't confirmed in 10s, give up
    local started = ire.idle_hb_party_started_at or 0.0
    if started > 0.0 and (now - started) >= 10.0 then
        ire.idle_hb_party_started_at  = nil
        ire.idle_hb_party_retry_until = now + 2.0  -- short cooldown before trying again
        return false
    end

    dbg(args, 'idle hb party')

    if ctx.do_hb('HB_PARTY') then
        if (ire.idle_hb_party_started_at or 0.0) == 0.0 then
            ire.idle_hb_party_started_at = now
        end
        ire.idle_hb_party_retry_until = now + 1.0
        return true
    end

    ire.idle_hb_party_retry_until = now + 1.0
    return false
end

-- Engaged-only variant: same as try_idle_hb_party but allows engaged state.
local function try_engaged_hb_party(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local now    = args.now
    local ire    = ire_state(state)

    if cfgget('auto.hb_party') ~= true then return false end
    if ctx.resting01 == 1 then return false end
    if ctx.spells_locked_soft == true then return false end
    if not ctx.hb_party_hp_ok then
        ire.idle_hb_party_started_at = nil
        return false
    end
    if not ctx.hb_ready_notarget then return false end
    if type(ctx.do_hb) ~= 'function' then return false end

    -- Force-retry: notify_hb_cast_interrupted (cast interrupted) and
    -- the safety-expiry handler in hb_shadows set this so the bot
    -- can immediately fire another trigger after a failure instead
    -- of waiting out the polite 1s retry gate and 10s started_at
    -- timeout that exist to throttle steady-state attempts. Consumed
    -- on first read and the throttle state is wiped clean.
    if state.hb and state.hb.force_retry_now == true then
        state.hb.force_retry_now = false
        ire.idle_hb_party_started_at  = nil
        ire.idle_hb_party_retry_until = 0.0
    end

    if now < (ire.idle_hb_party_retry_until or 0.0) then return false end

    local started = ire.idle_hb_party_started_at or 0.0
    if started > 0.0 and (now - started) >= 10.0 then
        ire.idle_hb_party_started_at  = nil
        ire.idle_hb_party_retry_until = now + 2.0
        return false
    end

    dbg(args, 'engaged hb party')

    if ctx.do_hb('HB_PARTY') then
        if (ire.idle_hb_party_started_at or 0.0) == 0.0 then
            ire.idle_hb_party_started_at = now
        end
        ire.idle_hb_party_retry_until = now + 1.0
        return true
    end

    ire.idle_hb_party_retry_until = now + 1.0
    return false
end

local function try_rest_prep(args)
    local state  = args.state
    local ire    = ire_state(state)

    if try_pre_attack_shadows_for_target(args) then
        ire.rest_after_prep_pending = true
        return true
    end

    if try_pre_attack_hb_for_target(args) then
        ire.rest_after_prep_pending = true
        return true
    end

    return false
end

local function maybe_shadows_after_stand(args)
    local state = args.state
    local ctx = args.ctx
    local cfgget = args.cfgget
    local now = args.now

    local ire = ire_state(state)

    if cfgget('auto.shadows') ~= true then return false end
    if n(ire.stood_up_ts, 0.0) == 0.0 then return false end
    if ctx.engaged01 == 1 then return false end
    if ctx.resting01 == 1 then return false end
    if ctx.spells_locked == true then return false end
    if type(ctx.shadows_can_attempt) ~= 'function' then return false end
    if type(ctx.do_shadows) ~= 'function' then return false end

    local dt = now - ire.stood_up_ts
    if dt < 1.0 then return false end
    if dt > 3.0 then
        ire.stood_up_ts = 0.0
        return false
    end

    if ctx.shadows_can_attempt('idle_post_stand', false) ~= true then
        return false
    end

    dbg(args, 'post-stand shadows')
    if ctx.do_shadows(false, 'idle_post_stand') then
        ire.stood_up_ts = 0.0
        return true
    end

    return false
end

local function tick_autorest(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local now      = args.now

    local ire = ire_state(state)
    local ua_cnt, mobs_ready = compute_mobs_ready(state, now)

    if ctx.self_poison_active == true then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        return false
    end

    if cfgget('auto.rest') ~= true and cfgget('auto.rest_mp') ~= true then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        return false
    end

    if ctx.engaged01 == 1 then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        return false
    end

    if mobs_ready then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false

        if cfgget('auto.attack') == true and ctx.resting01 == 1 then
            return try_heal_toggle(args, 'stand because mobs are near', function(ire2, tnow)
                ire2.stood_up_ts = tnow
            end)
        end

        return false
    end

    if ctx.resting01 == 1 and all_full_now(cfgget) then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        return try_heal_toggle(args, 'stand because full', function(ire2, tnow)
            ire2.stood_up_ts = tnow
        end)
    end

    if should_rest_now(cfgget) ~= true then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        return false
    end

    if ua_cnt ~= 0 then
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        return false
    end

    if n(ire.rest_wait_since, 0.0) == 0.0 then
        ire.rest_wait_since = now
    end

    if (now - ire.rest_wait_since) < 3.0 then
        return false
    end

    if ctx.resting01 == 1 then
        ire.rest_after_prep_pending = false
        return false
    end

    if ctx.spells_locked == true then
        return false
    end

    if prep_action_settling(state, now) then
        return false
    end

    if ire.rest_after_prep_pending == true then
        return try_heal_toggle(args, 'start rest after prep', function(ire2, _tnow)
            ire2.rest_after_prep_pending = false
        end)
    end

    if try_rest_prep(args) then
        return true
    end

    return try_heal_toggle(args, 'start rest', function(_ire2, _tnow)
    end)
end

local function tick_bot_autoengage(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local now      = args.now
    local ire      = ire_state(state)

    if cfgget('auto.bot') ~= true then
        ire.bot_retry_until = 0.0
        ire.bot_target_server_id = 0
        ire.bot_target_name = nil
        ire.bot_target_index = 0
        ire.bot_target_pending_until = 0.0
        ire.bot_returning = false
        ire.bot_debug_scanned = false
        return false
    end

    -- Post-kill cooldown for bot mode too. Same reason as tick_autoengage:
    -- avoids /attack <t> firing at a just-killed mob whose corpse still
    -- accepts targeting for a short window.
    if post_kill_blocked(state) then
        ire.bot_retry_until = 0.0
        ire.bot_target_pending_until = 0.0
        return false
    end

    if not ire.bot_debug_scanned then
        ire.bot_debug_scanned = true
        local em = entity_manager()
        local found = 0
        for idx = 0, 2303 do
            local ent = get_entity(idx)
            if ent then
                local hp   = entity_hp_percent(ent)
                local dist = entity_distance(ent)
                local name = ent.Name
                if dist ~= nil and dist <= 20 and hp ~= nil and hp > 0
                    and type(name) == 'string' and name ~= '' then
                    found = found + 1
                    local rf = 0
                    if em and type(em.GetRenderFlags0) == 'function' then
                        local ok, v = pcall(em.GetRenderFlags0, em, idx)
                        if ok then rf = v or 0 end
                    end
                    local ismob = type(GetIsMobByIndex) == 'function' and GetIsMobByIndex(idx) or 'n/a'
                end
            end
        end
        dbg(args, string.format(
            '[BOT-DBG] scan done nearby=%d list_total=%d',
            found, tonumber(ire.bot_enemy_count or 0) or 0
        ))
    end

    if cfgget('auto.bot') ~= true then
        ire.bot_retry_until = 0.0
        ire.bot_target_server_id = 0
        ire.bot_target_name = nil
        ire.bot_target_index = 0
        ire.bot_target_pending_until = 0.0
        ire.bot_returning = false
        return false
    end

    if cfgget('auto.attack') ~= true then
        ire.bot_retry_until = 0.0
        ire.bot_target_server_id = 0
        ire.bot_target_name = nil
        ire.bot_target_index = 0
        ire.bot_target_pending_until = 0.0
        ire.bot_returning = false
        return false
    end

    if ctx.engaged01 == 1 then
        ire.bot_retry_until = 0.0
        ire.bot_target_pending_until = 0.0
        ire.bot_returning = false
        return false
    end

    if ctx.spells_locked == true then
        return false
    end

    if prep_action_settling(state, now) then
        return false
    end

    if ctx.resting01 == 1 then
        return try_heal_toggle(args, 'stand before bot engage', function(ire2, tnow)
            ire2.stood_up_ts = tnow
            ire2.rest_after_prep_pending = false
            ire2.bot_retry_until = tnow + 0.5
            ire2.bot_target_pending_until = 0.0
            ire2.bot_returning = false
        end)
    end

    if now < n(ire.bot_retry_until, 0.0) then
        return false
    end

    local pending_sid = tonumber(ire.bot_target_server_id or 0) or 0
    local pending_until = n(ire.bot_target_pending_until, 0.0)

    if pending_sid > 0 and now < pending_until then
        if current_target_matches_pending(ctx, ire) then
            if try_pre_attack_shadows_for_target(args) then
                return true
            end

            if try_pre_attack_hb_for_target(args) then
                return true
            end

            if target_dead_or_invalid(ctx) then
                ire.bot_retry_until = now + 0.25
                ire.bot_target_pending_until = 0.0
                return false
            end

            dbg_bot(args, 'bot_engage_confirmed', ('bot engage confirmed target %s dist=%.1f'):format(
                tostring(ire.bot_target_name or '?'),
                tonumber(ctx.target_distance or ctx.dist or 0) or 0
            ), 0.75)

            if do_attack_t(args.dispatch) then
                ire.bot_retry_until = now + 1.0
                ire.bot_target_pending_until = 0.0
                return true
            end

            ire.bot_retry_until = now + 0.5
            return false
        end

        return false
    end

    if pending_sid > 0 and pending_until > 0.0 and now >= pending_until then
        ire.bot_target_pending_until = 0.0
        ire.bot_retry_until = now + 0.15
    end

    local cand, mobs = find_best_bot_candidate(state, ctx)

    if not cand then
        local total = mobs and #mobs or 0
        local free_cnt = tonumber(ire.bot_enemy_free_count or 0) or 0
        local party_cnt = tonumber(ire.bot_enemy_party_count or 0) or 0
        local other_cnt = tonumber(ire.bot_enemy_other_count or 0) or 0

        dbg_bot(args, 'bot_no_candidate',
            ('bot: no candidate found total=%d free=%d party=%d other=%d'):format(
                total, free_cnt, party_cnt, other_cnt
            ),
            3.0
        )

        ire.bot_target_server_id = 0
        ire.bot_target_name = nil
        ire.bot_target_pending_until = 0.0
        ire.bot_retry_until = 0.0

        return try_return_to_bot_center(args)
    end

    dbg_bot(args, 'bot_candidate_' .. tostring(cand.server_id), ('bot: candidate idx=%d sid=%d name=%s dist=%.1f center=%.1f claim=%s'):format(
        tonumber(cand.index or 0),
        tonumber(cand.server_id or 0),
        tostring(cand.name or '?'),
        tonumber(cand.dist or 0),
        tonumber(cand.center_dist or 0),
        tostring(cand.claim_state or '?')
    ), 3.0)

    local cur_sid = tonumber(ctx.target_server_id or 0) or 0
    local cur_dist = tonumber(ctx.target_distance or ctx.dist or 999999) or 999999
    local cur_ok =
        cur_sid == cand.server_id and
        (ctx.target_valid == true) and
        (ctx.target_dead ~= true) and
        (cur_dist <= 20.0) and
        ((ctx.target_claim_free_or_party == true) or claim_is_party_or_free(ctx.target_claim_id))

    if cur_ok then
        ire.bot_returning = false

        if try_pre_attack_shadows_for_target(args) then
            return true
        end

        if try_pre_attack_hb_for_target(args) then
            return true
        end

        if target_dead_or_invalid(ctx) then
            ire.bot_retry_until = now + 0.25
            return false
        end

        dbg_bot(args, 'bot_engage_current_' .. tostring(cand.server_id), ('bot engage current target %s dist=%.1f'):format(tostring(cand.name), cand.dist), 0.75)

        if do_attack_t(args.dispatch) then
            ire.bot_target_server_id = cand.server_id
            ire.bot_target_name = cand.name
            ire.bot_target_pending_until = 0.0
            ire.bot_retry_until = now + 1.0
            return true
        end

        ire.bot_retry_until = now + 0.5
        return false
    end

    dbg_bot(args, 'bot_target_' .. tostring(cand.server_id), ('bot target index=%d name=%s dist=%.1f'):format(
        cand.index,
        tostring(cand.name),
        cand.dist
    ), 0.75)

    -- Force target via 0x058 packet inject (GeneralLua.utils.set_target).
    -- Prefer server id (stable across index churn); fall back to index.
    local target_ok
    if cand.server_id and tonumber(cand.server_id) and tonumber(cand.server_id) ~= 0 then
        target_ok = GeneralLua.utils.set_target_by_server_id(cand.server_id)
    else
        target_ok = GeneralLua.utils.set_target(cand.index)
    end
    dbg(args, ('[bot] target idx=%d sid=%d name=%s -> %s'):format(
        tonumber(cand.index or 0) or 0,
        tonumber(cand.server_id or 0) or 0,
        tostring(cand.name or '?'),
        target_ok and 'OK' or 'FAIL'
    ))

    if target_ok then
        ire.bot_target_server_id = cand.server_id
        ire.bot_target_name = cand.name
        ire.bot_target_index = cand.index
        ire.bot_returning = false
        -- Fire attack immediately after targeting - don't wait for SID propagation
        do_attack_t(args.dispatch)
        ire.bot_retry_until = now + 2.0
        ire.bot_target_pending_until = 0.0
        return true
    end

    ire.bot_retry_until = now + 3.0
    return false
end

local function tick_autoengage(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local now      = args.now
    local ire      = ire_state(state)

    local _, mobs_ready = compute_mobs_ready(state, now)

    if cfgget('auto.attack') ~= true then
        ire.engage_retry_until = 0.0
        return false
    end

    if cfgget('auto.bot') == true then
        ire.engage_retry_until = 0.0
        return false
    end

    -- Post-kill cooldown: refuse to autoengage anything for a short window
    -- after a tracked mob died. Without this, /attack <bt> resolves to the
    -- still-on-aggro-list corpse and the game prints "You cannot attack that
    -- target." Re-aggro from a fresh mob will repopulate all_claimed_targets
    -- and this gate will pass naturally on the next tick.
    if post_kill_blocked(state) then
        ire.engage_retry_until = 0.0
        return false
    end

    if ctx.engaged01 == 1 then
        ire.engage_retry_until = 0.0
        ire.pre_attack_retry_until = 0.0
        ire.prep_action_settle_until = 0.0
        return false
    end

    if ctx.spells_locked == true then
        return false
    end

    if prep_action_settling(state, now) then
        return false
    end

    if now < n(ire.engage_retry_until, 0.0) then
        return false
    end

    -- Use ONLY nearest_hate_distance (live aggressor count). compute_under_attack
    -- already filters dead/0-HP mobs out, so nil here means "nothing live wants
    -- to engage me right now." Falling back to ctx.target_distance fires
    -- /attack <bt> at a dying mob: the current target's distance is still
    -- readable from the corpse, but <bt> resolves to that same dying mob.
    local dist = tonumber(state.live and state.live.nearest_hate_distance)
    if dist == nil then return false end

    local engage_dist = (cfgget('auto.party') == true) and 8.0 or 20.0
    if not mobs_ready and n(state.live and state.live.mobs_attacking, 0) <= 0 then
        ire.engage_retry_until = 0.0
        return false
    end
    if dist > engage_dist then
        return false
    end

    if ctx.resting01 == 1 then
        return try_heal_toggle(args, 'stand before engage', function(ire2, tnow)
            ire2.stood_up_ts = tnow
            ire2.rest_after_prep_pending = false
            ire2.engage_retry_until = 0.0
        end)
    end

    if ctx.target_valid == true and ctx.target_dead ~= true then
        if try_pre_attack_shadows_for_target(args) then
            return true
        end

        if try_pre_attack_hb_for_target(args) then
            return true
        end
    else
        if try_pre_attack_shadows_auto(args) then
            return true
        end

        if try_pre_attack_hb_auto(args) then
            return true
        end
    end

    dbg(args, ('auto engage dist=%.1f'):format(dist))

    -- Target the actual aggressor before /attack. <bt> resolves to whatever
    -- the client considers the last "battle target" -- which during the
    -- ~1-2s corpse-linger after a kill is the dead mob you just finished,
    -- not the fresh add smacking you. That produces the "cannot use that
    -- command" spam and misses the engage window entirely. compute_under
    -- _attack already picked the nearest live claimed attacker; retarget
    -- to it via 0x058 and fire /attack <t> instead.
    local hate_idx = tonumber(state.live and state.live.nearest_hate_index or 0) or 0
    local hate_sid = tonumber(state.live and state.live.nearest_hate_server_id or 0) or 0
    local cur_sid  = tonumber(ctx.target_server_id or 0) or 0
    if hate_sid ~= 0 and hate_sid ~= cur_sid
       and type(GeneralLua.utils.set_target_by_server_id) == 'function' then
        GeneralLua.utils.set_target_by_server_id(hate_sid)
    elseif hate_sid == 0 and hate_idx ~= 0
       and type(GeneralLua.utils.set_target) == 'function' then
        GeneralLua.utils.set_target(hate_idx)
    end

    if do_attack_t(args.dispatch) then
        ire.engage_retry_until = now + 1.0
        return true
    end

    return false
end

-- AUTO TARGET
-- When idle (not engaged, not resting) and there has been NO current
-- target for >= 5 seconds, target the nearest MOB within 15 yalms via the
-- 0x058 packet method. Uses the same live mob list build_live_mob_list
-- produces (sorted nearest-first). Gated behind cfg 'auto.target' so it
-- can be toggled independently of auto.attack.
--
-- Anti-spam design (state machine on ire.at_*):
--   * We only START the 5s no-target countdown once idle+targetless.
--   * We send at most ONE 0x058 per acquisition. After sending we enter a
--     SETTLE window: we stop sending and wait for the client to register
--     the target (ctx.target_server_id becomes non-zero). If it takes, we
--     go quiet. If it does NOT take within the settle window, we allow
--     exactly one retry (bounded), then back off on a cooldown so a mob
--     that refuses to target can't cause a packet flood.
--   * If NO mob is in range we simply keep scanning quietly (no send, no
--     log spam) until one walks into range or pops -- that's the "wait
--     for a mob" behaviour, and it never emits a packet while waiting.
local AUTO_TARGET_DELAY_SEC   = 5.0    -- idle+no-target time before we act
local AUTO_TARGET_SETTLE_SEC  = 1.0    -- wait this long for a send to register
local AUTO_TARGET_COOLDOWN_SEC = 3.0   -- back-off after a failed acquisition
local AUTO_TARGET_MAX_TRIES   = 2      -- sends per acquisition before cooldown

-- Auto Pull: how long after the target lands before we open on it. Gives
-- the client a beat to settle the target so <t> resolves to the mob we
-- just picked rather than whatever it was pointing at before.
local AUTO_PULL_DELAY_SEC     = 1.0

-- WORMS. Longer arm delay, because a worm is very often underground at the
-- moment auto-target lands on it -- burrowing is most of what they do. Open
-- on one while it is down and the server just says "You cannot attack that
-- target." and the pull is wasted.
--
-- This is the PROACTIVE half. text_parser has the reactive half (a longer
-- backoff once that line has already been printed); this one is what stops
-- the line being printed in the first place. Both are wanted -- the delay
-- covers the common case, the backoff covers a worm that submerges again
-- between the re-check and the dispatch.
local WORM_PULL_DELAY_SEC     = 2.0

-- How long a mob that said "You cannot attack that target" stays out of the
-- pick list. Long enough that we do not immediately re-pick the same one
-- (it is usually still the nearest), short enough that a mob which was only
-- temporarily unattackable comes back. Worms never reach this -- they get
-- the delay above instead.
local CANNOT_ATTACK_BLACKLIST_SEC = 30

-- Same idea for a lock that went stale: we held this mob 15s with auto-pull
-- on and never engaged it. Whatever the cause -- LOS we cannot path around,
-- a ledge, a mob that refuses every action -- it is not going to resolve by
-- picking the identical mob one tick later.
local STALE_LOCK_BLACKLIST_SEC = 30

-- Settle after dropping a target, before acquiring the next one.
--
-- THIS IS NOT COSMETIC. The escape tap is a QUEUED CHAT COMMAND; the 0x058
-- that sets the next target is an INJECTED PACKET. Packets fire immediately
-- and jump ahead of anything sitting in the command queue. Repick in the same
-- tick as the drop and the order on the wire is:
--
--   1. 0x058 -> new target set          (immediate)
--   2. /sendkey escape -> target cleared (queued, lands after)
--
-- ...which wipes the target we just acquired. From the outside that looks
-- exactly like 'it retargeted fine and then just stood there', because it
-- did retarget fine, and then the escape caught up with it.
--
-- 0.6s is comfortably longer than a queued command takes to drain.
local DROP_SETTLE_SEC = 0.6

-- Worm name list, generated from LSB. pcall so a missing worm_list costs the
-- worm handling and nothing else -- this file runs every tick and must not be
-- able to fail at load over an optional data table.
local WormList = nil
do
    local ok, mod = pcall(require, 'worm_list')
    if ok and type(mod) == 'table' and type(mod.is_worm) == 'function' then
        WormList = mod
    end
end

-- Is the entity at this index a worm? Reads the entity first (that is the
-- name we actually locked) and falls back to the stamped target name.
local function index_is_worm(state, idx)
    if WormList == nil then return false end

    idx = tonumber(idx or 0) or 0
    if idx > 0 then
        local ok, ent = pcall(get_entity, idx)
        if ok and ent and ent.Name and WormList.is_worm(ent.Name) then
            return true
        end
    end

    return WormList.is_worm(state and state.live and state.live.player_target_name) == true
end

-- Chase-to-range for tick_auto_pull. If the target sits outside the pull
-- method's range, close distance first: press H (lock on -- with lock,
-- W walks toward the target and A/D strafe around it), then hold W until
-- we're inside the game's cap for that method (minus the 1y hysteresis
-- from CHASE_STOP_MARGIN_SEC).
--
-- Values are the actual engine caps per method, from the HorizonXI wiki.
-- Chase stops one yalm inside so the pull fires within game range even
-- with small drift.
--   /ra:     25y max Ranged Attack range        -> stops at 24y
--   Dia:     22y max targeted-spell range (~21.8) -> stops at 21y
--   /attack: 30y max auto-attack range          -> stops at 29y, then
--            the on-dispatch W hold takes over to close melee (engaged
--            auto-face keeps direction toward the target).
local PULL_RANGE_YALMS = {
    [1] = 22.0,  -- /ra: was 25 (max). Mob moving during the shot's flight
                 --      time eats the last few yalms and produces "too far
                 --      away" refusals. 22 leaves a 3y buffer so a fresh
                 --      approach doesn't push us out of range mid-shot.
    [2] = 22.0,  -- /ma Dia
    [3] = 30.0,  -- /attack
}
local CHASE_STOP_MARGIN_SEC   = 1.0    -- yalms of hysteresis inside range
local CHASE_TIMEOUT_SEC       = 20.0   -- whole-chase watchdog

-- Wrong-target watchdog: how long we tolerate the cursor sitting on
-- something we shouldn't be attacking (self / NPC / PC / pet / other-
-- claim / dead mob) before we drop it and repick. Dwell absorbs the
-- momentary snapback after a kill; the one-shot latch stops us from
-- retriggering every tick while the fresh 0x058 is settling.
local AT_WRONG_DWELL_SEC = 2.0

-- Hard-cap intentionally EMPTY. Earlier versions bailed if the target was
-- beyond a per-mode cap, but with PULL_RANGE_YALMS matching the actual
-- engine caps, a hard-cap here duplicates the chase gate and prevents
-- chase from ever running. CHASE_TIMEOUT_SEC handles genuinely unreachable
-- mobs and blacklists them the same way.
local PULL_HARD_MAX_YALMS = {}
local ATTACK_MAX_RANGE_YALMS          = 30.0
local ATTACK_OUT_OF_RANGE_TIMEOUT_SEC = 10.0

-- Vertical separation filter.
--
-- The client leaks entities from other floors into the entity table and
-- ent.Distance does not save us, so auto-target can lock a mob that can
-- never be reached.
--
-- AXIS: height is Z. VERIFIED against bovinescan.lua, whose compass is
-- live and correct:
--
--     "In FFXI's position_t struct the horizontal axes are X and Y. Z is
--      the VERTICAL (height) axis. Confusingly, the struct field order in
--      memory is X, Z, Y -- but the Lua wrapper exposes them by name, so
--      ent.Movement.LocalPosition.Y is the horizontal north-south.
--      Reading .Z gives you height..."
--
-- and its row fields: x = "horizontal east-west", y = "horizontal
-- north-south". So in Lua: X/Y are the GROUND PLANE, Z is HEIGHT.
-- This agrees with ffxi_pos_tool.py, which reads raw memory slots and
-- labels slot 2 "Z ... Down/Up". Both frames agree. Height is Z.
--
-- TRAPS -- read before "fixing" this to Y:
--   1. bovinescan's HEADER comment (the compass section) claims "Y is
--      vertical". It is STALE. The comment at its scan_entities() is the
--      corrected one, and the code follows the corrected one.
--   2. dist2d(ax, az, bx, bz) in this file feeds X and Z into a "2d"
--      ground distance -- i.e. it mixes HEIGHT into a planar distance.
--      That is a latent bug, not evidence about axes. It survives only
--      because bot-centre camps are flat.
--   3. The memory field ORDER is X, Z, Y. That is layout, not naming.
--      The Lua wrapper resolves by name. Do not reason from the order.
local AUTO_TARGET_FILTER_Z    = true
local AUTO_TARGET_MAX_Z_DIFF  = 8.0

-- Print player + picked-mob raw x/y/z once per acquisition (debug only).
-- One line per pull, never inside the mob loop.
local AUTO_TARGET_DEBUG_POS   = true

-- Range is user-set (15 / 20 / 30 / 40 / 50) via cfg 'auto.targetrange'.
local function auto_target_range(cfgget)
    local r = tonumber(cfgget('auto.targetrange')) or 15
    if r ~= 15 and r ~= 20 and r ~= 30 and r ~= 40 and r ~= 50 then r = 15 end
    return r
end

-- Resets the TARGETING state machine only. Pull state (at_pull_at /
-- at_pull_sid) is deliberately NOT touched here: acquiring a target
-- resets targeting and arms the pull in the same tick, so clearing pull
-- state here would disarm it immediately. Pull clears itself when it
-- fires, or when the mob it was armed for is no longer our target.
local function auto_target_reset(ire)
    ire.at_clear_since  = 0.0   -- when we first became idle+targetless
    ire.at_sent_at      = 0.0   -- when we last sent a 0x058
    ire.at_sent_sid     = 0     -- server id we aimed at (fire-once guard)
    ire.at_sent_idx     = 0     -- entity index we aimed at
    ire.at_tries        = 0     -- sends in the current acquisition
    ire.at_cooldown_until = 0.0 -- back-off gate
    -- Pick-tracking: success = start fresh on the next target. Do NOT touch
    -- at_blacklist -- entries there expire on their own timers.
    ire.at_last_pick_sid       = 0
    ire.at_last_pick_first_at  = 0.0
end

-- ---------------------------------------------------------------------------
-- LOCK-ON HELPERS
--
-- Used by chase_step (lock before walking in) AND by tick_auto_target (break
-- the lock before repicking), so they live above BOTH rather than next to the
-- chase code where they started.
-- ---------------------------------------------------------------------------

local _chase_windowerinput_loaded    = false
local _chase_windowerinput_last_try  = 0.0
-- NOTE: this file has no module-level now_sec (unlike general.lua) -- time
-- arrives via args.now. Take it as a param rather than reaching for a
-- global that doesn't exist here.
local function chase_ensure_windowerinput(now)
    if _chase_windowerinput_loaded then return true end
    now = tonumber(now or 0.0) or 0.0
    if (now - _chase_windowerinput_last_try) < 5.0 then return false end
    _chase_windowerinput_last_try = now
    local ok = pcall(function()
        AshitaCore:GetChatManager():QueueCommand(1, '/plugin load windowerinput')
    end)
    if ok then _chase_windowerinput_loaded = true end
    return ok == true
end

-- One key tap through windowerinput. Was inlined in chase_press_h; pulled out
-- so the target-drop path can tap escape through the same plugin-load guard
-- rather than growing a second copy of it.
local function chase_tap_key(key, now)
    key = tostring(key or '')
    if key == '' then return false end
    if not chase_ensure_windowerinput(now) then return false end
    pcall(function()
        AshitaCore:GetChatManager():QueueCommand(1, '/sendkey ' .. key .. ' down')
        AshitaCore:GetChatManager():QueueCommand(1, '/sendkey ' .. key .. ' up')
    end)
    return true
end

local function chase_press_h(now)
    return chase_tap_key('h', now)
end

-- Escape = cancel target. This is what actually CLEARS the cursor; H only
-- releases the lock and leaves the mob targeted.
local function chase_press_escape(now)
    return chase_tap_key('escape', now)
end

-- Read lock-on state -- ported directly from XIUI's libs/target.lua.
-- Same fix as general.lua's ssd_read_locked: GetIsLockedOn returns 1/0
-- not true/false, and the fallback method is Target.GetLockedOnFlags
-- (bit 0 = lock). Returns true/false when readable, nil only if neither
-- method exists on this build.
local function chase_is_locked()
    local locked = nil
    pcall(function()
        local mm = AshitaCore and AshitaCore:GetMemoryManager()
        if not mm then return end
        local tm = mm.GetTarget and mm:GetTarget()
        if not tm then return end

        if tm.GetIsLockedOn ~= nil then
            locked = (tm:GetIsLockedOn() == 1)
            return
        end
        if tm.GetLockedOnFlags ~= nil then
            local flags = tm:GetLockedOnFlags()
            locked = (bit.band(tonumber(flags) or 0, 0x01) == 0x01)
            return
        end
    end)
    return locked
end

-- Give up on the mob under the cursor: blacklist it AND stop targeting it.
--
-- Blacklisting alone was never enough. The list is only consulted when
-- CHOOSING a mob, so a blacklisted target still sitting under the cursor got
-- shot by ranged_mode_step, swung at by auto-attack, and generally treated as
-- a live target by everything that reads state.live.player_target_server_id.
-- 'Done with this mob' has to include not pointing at it any more.
--
-- SELF-TARGET is how this codebase drops a target -- tick_attack_range_watchdog
-- and the out-of-range error watchdog both already do exactly this. There is
-- no 'clear target' packet; targeting yourself is the closest thing, and it
-- leaves auto-target in its normal no-mob-targeted state so the next pick
-- runs cleanly.
--
-- H FIRST, and only when we can read that we are locked. Lock-on is purely
-- client-side (LSB has no concept of it), so a self-target while locked can
-- be dragged straight back onto the mob. H is a toggle, so guessing on an
-- unreadable state would lock us ON to the thing we are escaping.
local function drop_target(args, ire, sid, secs, why)
    sid  = tonumber(sid or 0) or 0
    secs = tonumber(secs or 30) or 30
    local now = args.now or 0.0

    if sid ~= 0 then
        ire.at_blacklist = ire.at_blacklist or {}
        ire.at_blacklist[sid] = now + secs
    end

    -- H FIRST, then ESCAPE. Two different jobs and both are needed:
    --   H      releases the LOCK. Without it the client can drag the cursor
    --          straight back onto the mob.
    --   ESCAPE cancels the TARGET. This is the part that was missing -- H on
    --          its own left the mob targeted, so ranged_mode_step and
    --          auto-attack carried on treating it as live.
    --
    -- Order matters: escape while still locked does not stick.
    if chase_is_locked() == true then
        chase_press_h(now)
    end
    local dropped = chase_press_escape(now)

    -- FALLBACK: self-target. Only when the keypress could not be sent at all
    -- (windowerinput missing or refusing to load), because it is strictly
    -- worse -- targeting yourself leaves cur_sid non-zero, so auto-target
    -- takes its bad-target branch and burns AT_WRONG_DWELL_SEC before it
    -- repicks. Escape clears the cursor outright and the acquisition path
    -- runs on the very next tick.
    local how = 'escape'
    if not dropped then
        local self_sid = get_self_server_id()
        if self_sid ~= 0 then
            dropped = GeneralLua.utils.set_target_by_server_id(self_sid) == true
            how = 'self-target (no windowerinput)'
        end
    end

    -- Hold off acquiring until the escape has actually landed. See
    -- DROP_SETTLE_SEC -- without this the next 0x058 overtakes the queued
    -- keypress and the fresh target gets cleared out from under us.
    --
    -- Reuses the existing acquisition cooldown gate rather than adding a
    -- second timer for the pick loop to consult.
    ire.at_cooldown_until = math.max(
        tonumber(ire.at_cooldown_until or 0.0) or 0.0,
        now + DROP_SETTLE_SEC)

    dbg(args, ('[auto-target] dropping sid %d (%s): blacklist %ds, %s %s, settle %.1fs'):format(
        sid, tostring(why or '?'), secs, how, dropped and 'OK' or 'FAIL', DROP_SETTLE_SEC))

    return dropped
end

local function tick_auto_target(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local now    = args.now
    local ire    = ire_state(state)

    -- opt-in
    if cfgget('auto.target') ~= true then
        auto_target_reset(ire)
        ire.at_blacklist = {}   -- fresh state on toggle
        return false
    end

    -- idle only; any engage/rest fully resets the machine.
    -- NOTE: the engaged01 half is effectively dead -- IdleRestEngage.tick
    -- returns inside its own engaged branch and never calls us. The
    -- blacklist wipe therefore lives on the engage RISING EDGE in tick(),
    -- not here. Resting deliberately does NOT wipe: standing back up and
    -- immediately re-picking the mob we just gave up on is not useful.
    if ctx.engaged01 == 1 or ctx.resting01 == 1 then
        auto_target_reset(ire)
        return false
    end

    -- HP/MP GATE -- rest intent beats acquiring a new mob.
    --
    -- tick_autorest runs BEFORE us in the chain, but it has a 3s settle
    -- (rest_wait_since) before it actually sits down, and during that
    -- window it returns FALSE. That let us grab a mob in the gap and
    -- cancel the rest outright: at 60% HP with a 75% rest threshold the
    -- bot would pull a fresh target instead of ever resting.
    --
    -- So we check the rest INTENT, not the rest STATE. If a rest is
    -- wanted, we stay out of the way entirely.
    if should_rest_now(cfgget) == true then
        auto_target_reset(ire)
        return false
    end


    -- SHOT IN FLIGHT -- HANDS OFF THE TARGET.
    --
    -- A /ra is not instant. There is roughly a second between the command
    -- going out and the arrow resolving, and the target has to stay put for
    -- the whole of it. Every watchdog below repicks by sending a 0x058, and
    -- doing that mid-flight retargets us out from under our own shot -- the
    -- arrow is already away, so it is simply lost.
    --
    -- This is the same reason tick_engaged_run bails on ranged_busy rather
    -- than trusting spells_locked: /ra rides its own flag, and everything
    -- that can disturb a shot has to check it.
    --
    -- Deliberately placed ABOVE every watchdog and the acquisition path, and
    -- it changes no state on the way out. Whatever the watchdogs were about
    -- to conclude is still true a second from now; nothing is lost by
    -- letting the arrow land first.
    if ctx.ranged_busy == true then
        return false
    end

    -- if we already have a target, we're done -- reset everything so the
    -- next targetless period starts clean. This is the success exit and
    -- the reason we never spam once a target sticks.
    local cur_sid = tonumber(ctx.target_server_id or 0) or 0
    local force_repick = false

    -- "YOU CANNOT ATTACK THAT TARGET" -- DROP IT AND MOVE ON.
    --
    -- Raised by text_parser, and only for NON-worms; a burrowed worm gets a
    -- longer pause there instead, because it surfaces on its own. Everything
    -- else that answers this way is not a mob we can fight, and re-picking it
    -- is how the log fills with identical yellow lines.
    --
    -- Blacklisted for CANNOT_ATTACK_BLACKLIST_SEC rather than dropped once:
    -- without that, the very next pick is the same mob (it is still the
    -- nearest thing in the list) and we are straight back where we started.
    -- The blacklist entry expires on its own, so a mob that was briefly
    -- unattackable comes back into rotation later.
    --
    -- Cleared unconditionally, even when the sid no longer matches, so a
    -- stale flag cannot sit around and fire against an innocent target.
    if state.flags and state.flags.cannot_attack_target == true then
        local bad_sid = tonumber(state.flags.cannot_attack_sid or 0) or 0
        state.flags.cannot_attack_target = false
        state.flags.cannot_attack_sid    = 0

        if bad_sid ~= 0 and bad_sid == cur_sid then
            ire.at_locked_sid     = 0
            ire.at_locked_at      = 0.0
            ire.at_locked_engaged = false
            ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0

            -- Chase cleared INLINE, not via chase_reset. That function is a
            -- local declared several hundred lines further down the file, so
            -- from up here the name resolves as a global and is nil -- a
            -- crash in the tick, not a warning. These three fields plus the
            -- stop are what it does that matters to us.
            ire.at_chase_active     = false
            ire.at_chase_started_at = 0.0
            ire.at_chase_h_sent     = false
            movement_stop(args.movement)

            drop_target(args, ire, bad_sid, CANNOT_ATTACK_BLACKLIST_SEC,
                'cannot attack')
            force_repick = true
        end
    end

    if cur_sid ~= 0 then
        local pull_on = (cfgget('auto.pull') ~= 0)

        -- Update or seed the stale-lock snapshot. Only meaningful when
        -- auto.pull is on -- without pull, "no engagement" is expected,
        -- not stale. Fresh lock (new sid, or player retargeted) reseeds
        -- the timer; same lock flips engaged=true the moment status hits
        -- ENGAGED.
        -- RANGED MODE COUNTS SHOOTING AS PROGRESS.
        --
        -- Watchdog 2 below exists to catch a pull that silently failed, and
        -- it measures that by "never went ENGAGED". A /ra does not engage
        -- anything, so a standoff ranged camp looks identical to a dead pull
        -- to it: at 15s it repicks a mob we are in the middle of happily
        -- killing, and with a ~3s shot cadence it lands mid-cycle.
        --
        -- A shot that RESOLVED against this target is direct proof the lock
        -- is fine, so treat it the way engagement is treated and push the
        -- clock forward. The watchdog then only fires if we genuinely stop
        -- shooting for 15s, which is the thing it was always trying to
        -- detect.
        if cfgget('auto.rangedmode') == true then
            local resolved = tonumber(state.combat and state.combat.ranged_resolved_at or 0) or 0
            if resolved > (tonumber(ire.at_locked_at or 0.0) or 0.0)
                and ire.at_locked_sid == cur_sid
            then
                ire.at_locked_at = resolved
            end
        end

        if pull_on then
            if ire.at_locked_sid ~= cur_sid then
                ire.at_locked_sid     = cur_sid
                ire.at_locked_at      = now
                ire.at_locked_engaged = (ctx.engaged01 == 1)
            elseif ctx.engaged01 == 1 then
                ire.at_locked_engaged = true
            end
        end

        -- Watchdog 1: cursor on a target we shouldn't be sitting on.
        -- Runs only when auto-target could USE a different target, so it's
        -- gated to idle by tick_auto_target's own top-of-function guard.
        -- Categories:
        --   * self         -- /ra target-death snapback, dead mob, /heal
        --   * not a mob    -- NPC, other PC, gate, chocobo, etc
        --   * claimed by
        --     someone else -- can't attack it anyway
        -- Do NOT check distance / height / dead-mob here: those move on
        -- their own (mob walks toward you, dies, decays) and firing on
        -- them would fight the auto-target's own pick loop.
        --
        -- ANTISPAM (log spam AND packet spam): the cursor sits on the bad
        -- target for many ticks. Two guards:
        --   (a) dwell: AT_WRONG_DWELL_SEC of continuous bad-target before
        --       firing. Absorbs the momentary snapback after a kill.
        --   (b) latch: fire ONCE per stretch. at_wrong_fired stays true
        --       until we see a GOOD target -- resets when auto-target
        --       lands a new mob.
        local self_sid = get_self_server_id()
        local bad_reason = nil

        if self_sid ~= 0 and cur_sid == self_sid then
            bad_reason = 'self'
        else
            local cur_idx = tonumber(state.live and state.live.player_target_index or 0) or 0
            if cur_idx > 0 then
                if not GeneralLua.utils.is_valid_mob(cur_idx) then
                    bad_reason = 'not a mob'
                else
                    local ok_e, ent = pcall(get_entity, cur_idx)
                    if ok_e and ent then
                        local claim_id = entity_claim_id(ent)
                        local cs = get_claim_state(claim_id,
                            get_player_server_id(), build_party_member_id_set())
                        if cs == 'other' then
                            bad_reason = 'claimed by other'
                        end
                    end
                end
            end
        end

        if bad_reason then
            if (tonumber(ire.at_wrong_since or 0.0) or 0.0) == 0.0 then
                ire.at_wrong_since = now
            end
        else
            ire.at_wrong_since = 0.0
            ire.at_wrong_fired = false
        end

        if bad_reason
           and (not ire.at_wrong_fired)
           and (now - (tonumber(ire.at_wrong_since or 0.0) or 0.0)) >= AT_WRONG_DWELL_SEC
        then
            dbg(args, ('[auto-target] bad target (%s) %.1fs, repicking'):format(
                bad_reason, now - ire.at_wrong_since))
            ire.at_wrong_fired     = true
            ire.at_locked_sid     = 0
            ire.at_locked_at      = 0.0
            ire.at_locked_engaged = false
            force_repick = true

        elseif bad_reason then
            -- Bad target but not yet time to fire (dwell not met, or
            -- already fired). Do NOT fall through to the success arm-pull
            -- branch -- that would arm a pull against the bad target,
            -- which is exactly what we're trying to escape.
            return false

        -- Watchdog 2: stale acquisition. auto.pull on, we've held this lock
        -- 15s, and we never went ENGAGED. The pull silently failed
        -- (out-of-range, /ra failed, mob wandered off, LOS blocked). Drop
        -- and repick. Gated on at_locked_sid == cur_sid so a manual
        -- retarget mid-window is untouched.
        --
        -- CHASE EXEMPTION: an active chase is not a stale lock, it is the
        -- pull working as designed. At the long target ranges (40y / 50y)
        -- the walk-in can outlast 15s once terrain or a wandering mob is
        -- involved, and this watchdog firing mid-walk would repick and
        -- chase_reset every time -- the bot would never actually reach
        -- anything much past 30y. chase_step owns its own watchdog
        -- (CHASE_TIMEOUT_SEC, 20s) plus the stuck-wall detector, and both
        -- clear at_chase_active on abort. The moment either does, this
        -- branch sees a lock already older than 15s and repicks on the
        -- next tick -- nothing is lost, only deferred until the chase has
        -- had its say.
        elseif pull_on
           and ire.at_locked_sid == cur_sid
           and (not ire.at_locked_engaged)
           and (ire.at_chase_active ~= true)
           and (now - (tonumber(ire.at_locked_at or 0.0) or 0.0)) >= 15.0
        then
            -- DROP it, do not merely stop choosing it. force_repick alone
            -- hands straight back to the pick loop, which sorts by distance
            -- and returns THE SAME MOB -- still the nearest, nothing about it
            -- changed -- while the cursor never moved off it. Watchdog fires,
            -- repicks it, fails for another 15s, forever, on one mob.
            drop_target(args, ire, cur_sid, STALE_LOCK_BLACKLIST_SEC,
                ('stale lock %.1fs'):format(now - ire.at_locked_at))

            ire.at_locked_sid     = 0
            ire.at_locked_at      = 0.0
            ire.at_locked_engaged = false
            force_repick = true

        else
            -- Original success behaviour: arm pull if applicable, reset,
            -- return. Only when the landed target matches the sid we aimed
            -- at -- if the player targeted something themselves we leave
            -- it alone.
            if cfgget('auto.pull') ~= 0
                and ire.at_sent_sid ~= 0
                and cur_sid == ire.at_sent_sid
                and ire.at_pull_sid ~= cur_sid
            then
                ire.at_pull_sid = cur_sid
                ire.at_pull_idx = tonumber(ire.at_sent_idx or 0) or 0
                -- Worms get the longer arm. The target is already acquired at
                -- this point, so this is purely "how long before we open on
                -- it", and the pre-dispatch re-checks below run after the
                -- wait, not before it.
                local pull_delay = AUTO_PULL_DELAY_SEC
                if index_is_worm(state, ire.at_pull_idx) then
                    pull_delay = WORM_PULL_DELAY_SEC
                end
                ire.at_pull_at  = now + pull_delay
                -- Fresh acquisition -- fresh LOS retry token. Prevents an
                -- already-burned retry flag from a prior mob blocking a
                -- legit retry against this new one.
                ire.at_pull_ra_retry_used  = false
                ire.at_pull_ra_retry_sid   = 0
                ire.at_pull_ra_retry_until = 0.0
                dbg(args, ('[auto-target] pull armed for sid %d in %.1fs%s'):format(
                    cur_sid, pull_delay,
                    pull_delay ~= AUTO_PULL_DELAY_SEC and ' (worm)' or ''))
            end
            auto_target_reset(ire)
            return false
        end
    end

    -- ---- from here down: idle AND (no current target OR watchdog forced repick) ----

    -- If we recently SENT, sit in the settle window and wait for the
    -- client to register it. Do NOT send again during settle.
    local sent_at = tonumber(ire.at_sent_at or 0.0) or 0.0
    if sent_at > 0.0 and (now - sent_at) < AUTO_TARGET_SETTLE_SEC then
        return false
    end

    -- Settle window elapsed and still no target => the send didn't take.
    -- Allow bounded retries, then cool down.
    if sent_at > 0.0 then
        local tries = tonumber(ire.at_tries or 0) or 0
        if tries >= AUTO_TARGET_MAX_TRIES then
            -- BLACKLIST: if we've been chewing on the same sid for >= 10s
            -- with no acquisition, give up on it for 30s so the next pick
            -- lands on the next candidate. Same-sid check protects against
            -- blacklisting a fresh mob that happened to fail once.
            local stuck_sid = tonumber(ire.at_last_pick_sid or 0) or 0
            local first_at  = tonumber(ire.at_last_pick_first_at or 0.0) or 0.0
            if stuck_sid ~= 0
               and stuck_sid == (tonumber(ire.at_sent_sid or 0) or 0)
               and first_at > 0.0
               and (now - first_at) >= 10.0
            then
                ire.at_blacklist[stuck_sid] = now + 30.0
                dbg(args, ('[auto-target] blacklisting sid %d for 30s (%.1fs no acquisition)'):format(
                    stuck_sid, now - first_at))
                ire.at_last_pick_sid      = 0
                ire.at_last_pick_first_at = 0.0
            end
            -- back off; clear the send state and gate future attempts
            ire.at_sent_at = 0.0
            ire.at_sent_sid = 0
            ire.at_tries = 0
            ire.at_cooldown_until = now + AUTO_TARGET_COOLDOWN_SEC
            ire.at_clear_since = 0.0
            dbg_bot(args, 'auto_target_backoff',
                '[auto-target] target did not take after retries, backing off', 1.0)
            return false
        end
        -- else fall through and retry (still counts against MAX_TRIES)
    end

    -- honor cooldown after a failed acquisition
    if now < (tonumber(ire.at_cooldown_until or 0.0) or 0.0) then
        return false
    end

    -- start / continue the no-target countdown (only when not mid-send).
    -- Skipped entirely when a watchdog forced a repick -- the 5s wait is
    -- for organic "idle, no target" gaps, not for kicking a bad lock.
    if sent_at == 0.0 and not force_repick then
        if (tonumber(ire.at_clear_since or 0.0) or 0.0) == 0.0 then
            ire.at_clear_since = now
            return false
        end
        if (now - ire.at_clear_since) < AUTO_TARGET_DELAY_SEC then
            return false
        end
    end

    -- countdown satisfied (or retrying): look for the nearest eligible mob.
    -- build_live_mob_list only runs on auto.attack; build on demand so
    -- auto.target works standalone.
    build_live_mob_list(state)
    local list = ire.bot_enemy_list
    if not list or #list == 0 then
        -- No mobs at all: keep waiting quietly. No send, no spam. This is
        -- the "scan and wait for a mob to pop/approach" path.
        return false
    end

    -- list is sorted nearest-first. Filter order is deliberate:
    --   1. Z height   -- another floor is not a mob, at ANY distance
    --   2. claim      -- someone else's mob is not ours, at any distance
    --   3. distance   -- only now does "how far" matter
    -- Z is a straight height compare (mz vs pz). It is NOT distance and
    -- never gets folded into one: height is height. A mob 20y up is on
    -- another floor whether it is 2y or 30y away horizontally.
    local range = auto_target_range(cfgget)
    local px, py, pz = player_position()

    -- Measure from HOME, not from where we happen to be standing. This is
    -- what stops the camp drifting: chase a mob 20y east, and from the new
    -- spot a mob 20y further east now looks "close" -- repeat and the bot
    -- walks across the map one reasonable-looking step at a time. Judging
    -- every candidate against a fixed anchor makes range mean "how far from
    -- camp", which is the thing we actually care about.
    -- Height (z) is NOT used here: X/Y are the ground plane.
    local ax, ay, _az, using_home = anchor_position(args)
    local pick, pick_dist = nil, nil
    local rej_total, rej_h, rej_claim, rej_dist, rej_bl, rej_ignore = 0, 0, 0, 0, 0, 0
    local rej_ex = nil

    -- Snapshot the ignore list once per pick and lowercase it. The pick loop
    -- runs over every mob every tick, and doing a lower() + walk-the-list
    -- per mob was cheap for 3 entries but grows with user config. Snapshot
    -- once, reuse for the whole pass.
    local ignore_lower = nil
    do
        local ig = cfgget('auto.target_ignore_list')
        if type(ig) == 'table' and #ig > 0 then
            ignore_lower = {}
            for i = 1, #ig do
                local s = tostring(ig[i] or ''):lower()
                if s ~= '' then ignore_lower[#ignore_lower + 1] = s end
            end
            if #ignore_lower == 0 then ignore_lower = nil end
        end
    end

    for i = 1, #list do
        local m = list[i]

        -- NO LOGGING IN THIS LOOP. It runs over every mob every tick; a
        -- log line here is a guaranteed wall of text (and dbg_bot cannot
        -- save us -- it remembers a single key, so rotating per-mob keys
        -- defeat its throttle entirely). Diagnostics for the ONE mob we
        -- actually pick are emitted after the loop.

        -- 0. BLACKLIST. Skip mobs auto-target already gave up on (10s+ of
        -- failed acquisition). Entries expire on their own timer; expired
        -- ones get pruned as we walk past them.
        local ok_bl = true
        local m_sid = tonumber(m.server_id or 0) or 0
        if m_sid ~= 0 then
            local exp = ire.at_blacklist[m_sid]
            if exp then
                if now < exp then
                    ok_bl = false
                else
                    ire.at_blacklist[m_sid] = nil
                end
            end
        end

        -- 0.5. IGNORE LIST. User-configured mob-name blacklist. Case-
        -- insensitive substring match so "Water Elemental" catches
        -- variants like "Angry Water Elemental" without needing every
        -- name. Empty list is a no-op (skipped by the snapshot above).
        local ok_ignore = true
        if ignore_lower then
            local nm = tostring(m.name or ''):lower()
            for j = 1, #ignore_lower do
                if nm:find(ignore_lower[j], 1, true) then
                    ok_ignore = false
                    break
                end
            end
        end

        -- 1. HEIGHT (Z). Reject anything above/below us: the client leaks
        -- entities from other floors and they can never be reached.
        local ok_h = true
        if AUTO_TARGET_FILTER_Z and pz ~= nil then
            local ok_e, ent = pcall(get_entity, m.index)
            if ok_e and ent then
                local _, _, mz = entity_position(ent)
                -- z = HEIGHT (see block comment above). Only reject on a
                -- reading we actually got: an unreadable position must
                -- never silently stop the bot from working.
                if mz ~= nil and math.abs(mz - pz) > AUTO_TARGET_MAX_Z_DIFF then
                    ok_h = false
                end
            end
        end

        -- 2. CLAIM. free / self / party only -- never steal.
        local ok_claim = (m.free_or_party == true)

        -- 3. DISTANCE (and alive), measured from the ANCHOR (home unless
        -- disabled). m.dist is distance from the PLAYER, so it is only
        -- correct when we are not using home.
        local dist = tonumber(m.dist or 999999) or 999999
        if using_home and ax ~= nil then
            local oke, ent = pcall(get_entity, m.index)
            if oke and ent then
                local ex, ey, _ez = entity_position(ent)
                local dh = dist_ground(ex, ey, ax, ay)
                if dh ~= nil then dist = dh end
            end
        end
        local ok_dist = (dist <= range) and ((tonumber(m.hp or 0) or 0) > 0)

        if ok_bl and ok_ignore and ok_h and ok_claim and ok_dist then
            -- Keep the NEAREST-TO-ANCHOR candidate rather than breaking on
            -- the first pass. build_live_mob_list sorts by distance from the
            -- PLAYER, so with Home on that order is not the order we want --
            -- breaking early would pick "first acceptable", not "closest to
            -- camp". Cheap: the list is small and we already walk all of it.
            if pick == nil or dist < (pick_dist or 1e9) then
                pick, pick_dist = m, dist
            end
        end

        -- Tally WHY each mob was rejected. Counters only -- still zero
        -- logging in this loop. Summarised once after the loop if nothing
        -- was picked, so "bot just stands there" is always explainable
        -- without a wall of text.
        rej_total = rej_total + 1
        if not ok_bl     then rej_bl     = rej_bl + 1
        elseif not ok_ignore then rej_ignore = rej_ignore + 1
        elseif not ok_h      then rej_h      = rej_h + 1
        elseif not ok_claim  then rej_claim  = rej_claim + 1
        elseif not ok_dist   then rej_dist   = rej_dist + 1 end
        if rej_ex == nil then
            rej_ex = m   -- keep one example for the summary
        end
    end

    if not pick then
        -- Nothing eligible. Say WHY, once every 5s, with a worked example.
        -- A silent bot is indistinguishable from a broken one -- and both
        -- the height gate and the claim read are all-or-nothing filters,
        -- so a bad axis or a misread claim field rejects EVERY mob and
        -- looks exactly like "no mobs around".
        if rej_total > 0 then
            local ex = ''
            if rej_ex ~= nil then
                local exz = nil
                local oke, ent = pcall(get_entity, rej_ex.index)
                if oke and ent then
                    local _, _, mz = entity_position(ent)
                    if mz ~= nil and pz ~= nil then exz = mz - pz end
                end
                ex = (' eg %s idx=%d dist=%.1f dZ=%s claim=%s'):format(
                    tostring(rej_ex.name or '?'), tonumber(rej_ex.index or 0) or 0,
                    tonumber(rej_ex.dist or 0) or 0,
                    exz and ('%.1f'):format(exz) or '?',
                    tostring(rej_ex.claim_state or rej_ex.claim_id or '?'))
            end
            dbg_bot(args, 'auto_target_none',
                ('[auto-target] %d mobs, none eligible: height %d, claim %d, range %d, blacklisted %d, ignore %d (max %dy).%s'):format(
                    rej_total, rej_h, rej_claim, rej_dist, rej_bl, rej_ignore, range, ex), 5.0)
        end
        return false
    end

    -- Fire-once guard: if we already aimed at this exact server id in this
    -- acquisition and it's still our pick, don't resend within settle.
    local pick_sid = tonumber(pick.server_id or 0) or 0

    -- ENGAGED: use the real Switch Target action instead of injecting.
    --
    -- ActionID 0x0F ChangeTarget is what the in-game menu's "Switch Target"
    -- sends. The server actually processes it -- ChangeTarget, then
    -- OnChangeTarget which RelinquishClaims the old mob and pushes a genuine
    -- 0x058 back -- so client and server agree afterwards. Injecting 0x058
    -- ourselves only ever convinced the client.
    --
    -- Engaged-only by the server's own rules: the validator in
    -- 0x01a_action.cpp gates ChangeTarget behind .isEngaged(), so while idle
    -- it is silently dropped and the inject below is the only way. Hence the
    -- branch rather than a replacement.
    local ok = false
    if pick_sid ~= 0
        and ctx.engaged01 == 1
        and type(GeneralLua.utils.switch_target) == 'function'
    then
        ok = GeneralLua.utils.switch_target(pick_sid)
        if ok then
            dbg(args, ('[auto-target] switch_target (0x01A ChangeTarget) -> sid %d'):format(pick_sid))
        end
    end

    -- Idle, or the action was refused / unavailable: fall back to the inject.
    if not ok then
        if pick_sid ~= 0 then
            ok = GeneralLua.utils.set_target_by_server_id(pick_sid)
        else
            ok = GeneralLua.utils.set_target(pick.index)
        end
    end

    -- record the send (settle window + try count start/increment)
    ire.at_sent_at  = now
    ire.at_sent_sid = pick_sid
    ire.at_sent_idx = tonumber(pick.index or 0) or 0
    ire.at_tries    = (tonumber(ire.at_tries or 0) or 0) + 1

    -- Track first-send-per-sid for the 10s blacklist window. Same sid as
    -- last time = keep the original timestamp (accumulating across
    -- retries and backoffs). Different sid = fresh start.
    if pick_sid ~= (tonumber(ire.at_last_pick_sid or 0) or 0) then
        ire.at_last_pick_sid      = pick_sid
        ire.at_last_pick_first_at = now
    end

    -- debug report: always report WHAT we targeted when debug is on. dbg()
    -- already no-ops when debug is off, so this is quiet in normal play.
    --
    -- BOTH distances, always. They are different numbers and confusing them
    -- wastes an evening: pick.dist is from the PLAYER (sqrt of ent.Distance),
    -- pick_dist is from the ANCHOR and is the one the range filter actually
    -- tested. With Home on and the character standing away from camp these
    -- diverge hard -- 'why did it grab something 100y away' is exactly that
    -- gap, and one number on its own cannot show it.
    dbg(args, ('[auto-target] SEND -> %s idx=%d sid=%d player=%.1fy anchor=%.1fy%s (try %d/%d) %s'):format(
        tostring(pick.name or '?'),
        tonumber(pick.index or 0) or 0,
        pick_sid,
        tonumber(pick.dist or 0) or 0,
        tonumber(pick_dist or 0) or 0,
        using_home and ' [HOME]' or ' [self]',
        ire.at_tries, AUTO_TARGET_MAX_TRIES,
        ok and 'OK' or 'FAIL'))

    -- Raw coordinate dump for the ONE mob we picked. Emitted once per
    -- acquisition, never in the mob loop. dZ is the vertical delta -- the
    -- number the filter acts on. Change floors / stand on a ramp and dZ
    -- should be the field that tracks height.
    if AUTO_TARGET_DEBUG_POS then
        local ok_e, ent = pcall(get_entity, pick.index)
        if ok_e and ent then
            local mx, my, mz = entity_position(ent)
            if mx and px then
                -- dY is HEIGHT (Ashita LocalPosition). dX/dZ are the ground
                -- plane. Labelled explicitly so nobody has to guess again.
                -- THREE distances, because they have disagreed in the wild:
                --   ground : recomputed here from X/Y, the ground plane
                --   ent    : sqrt(ent.Distance), what the pick sorted on
                --   anchor : what the range filter tested against
                -- If ground and ent disagree, one of the two reads is wrong
                -- and no amount of staring at a single number will say which.
                local ground = dist_ground(mx, my, px, py)
                dbg(args, ('[auto-target] POS me(%.1f,%.1f,%.1f) mob(%.1f,%.1f,%.1f) dX=%.1f dY=%.1f dZ(height)=%.1f | ground=%s ent=%.1f anchor=%.1f%s | claim=%s/%s'):format(
                    px, py, pz, mx, my, mz,
                    mx - px, my - py, mz - pz,
                    ground and ('%.1f'):format(ground) or '?',
                    tonumber(pick.dist or 0) or 0,
                    tonumber(pick_dist or 0) or 0,
                    using_home and ' [HOME]' or ' [self]',
                    tostring(pick.claim_id or 0),
                    tostring(pick.claim_state or '?')))

                -- Anchor position itself. When Home is on and stale, every
                -- pick is judged against a spot you are no longer standing
                -- in, and the answer is Rehome -- not a targeting bug.
                if using_home and ax ~= nil then
                    local home_off = dist_ground(px, py, ax, ay)
                    dbg(args, ('[auto-target] anchor home(%.1f,%.1f) you are %s from it'):format(
                        ax, ay,
                        home_off and ('%.1fy'):format(home_off) or '?'))
                end
            end
        end
    end

    -- consume the tick either way; the next ticks handle settle/confirm.
    return true
end

-- ---------------------------------------------------------------------------
-- Chase-to-range helpers for tick_auto_pull.
--
-- H press + lock-on read reuses the same /sendkey approach general.lua uses
-- for SSD, kept local here so idle_rest_engage doesn't depend on internal
-- SSD helpers.
--
-- Sequence:
--   1. Press H ONCE (lock on) -- and only if we aren't already locked.
--      H is a TOGGLE: pressing it twice turns lock back OFF, so this is
--      never retried. Once locked, W walks toward target and A/D strafe;
--      FFXI's own targeting handles the facing.
--   2. Hold W until dist <= range - CHASE_STOP_MARGIN_SEC. Release W and
--      report done.
--   3. Timeout the whole chase at CHASE_TIMEOUT_SEC (lock never took,
--      target unreachable, pathing stuck) so we don't hold W forever.
-- ---------------------------------------------------------------------------

-- The lock-on helpers (chase_ensure_windowerinput / chase_press_h /
-- chase_is_locked) MOVED UP, above tick_auto_target. They are needed there
-- to break a lock before repicking, and a local declared here is simply not
-- in scope for code earlier in the file -- the name would resolve as a nil
-- global. See their new home just above tick_auto_target.

local function chase_reset(ire, movement)
    ire.at_chase_active      = false
    ire.at_chase_started_at  = 0.0
    ire.at_chase_h_sent      = false
    if movement then movement_stop(movement) end
    -- Also release any active strafe from the stuck-wall detector, and
    -- forget its state so a new chase gets a clean anchor + attempt count.
    if ire.stuck and ire.stuck.chase then
        if movement then
            if type(movement.key_a_up) == 'function' then movement.key_a_up() end
            if type(movement.key_d_up) == 'function' then movement.key_d_up() end
        end
        ire.stuck.chase = nil
    end
end

-- ---------------------------------------------------------------------------
-- STUCK-WALL DETECTOR: moved earlier in the file (above tick_engaged_run)
-- so both callers can reference it. See the block just before
-- tick_engaged_run for the implementation.
-- ---------------------------------------------------------------------------

-- Is a /ra in flight RIGHT NOW?
--
-- Delegates to general.lua rather than reimplementing. This USED to be a
-- copy of ranged_in_progress carrying its own 1.0s and 6.0s constants, which
-- is a trap: the two would agree until the day someone retuned one side, and
-- the failure mode is the bot walking through its own shots again with no
-- obvious cause.
--
-- ctx.ranged_busy is NOT a substitute. ctx is snapshotted at the start of
-- general.lua's tick, which runs BEFORE this file in the frame, so a shot
-- fired by the standoff loop during that same tick is invisible in ctx until
-- the next frame -- exactly the frame where we would start walking on top of
-- a fresh shot. The exported function reads state.combat live.
--
-- Missing export means a version mismatch between these two files. Degrade to
-- 'not busy' (the behaviour from before the interlock existed, i.e. a lost
-- shot now and then) rather than 'busy', which would freeze every chase
-- forever. Reported once so it cannot hide.
local _ranged_busy_export_warned = false
local function ranged_busy_live(state)
    local G = GeneralLua
    if G and G.runtime and type(G.runtime.ranged_in_progress) == 'function' then
        return G.runtime.ranged_in_progress(state) == true
    end

    if not _ranged_busy_export_warned then
        _ranged_busy_export_warned = true
        print('[bovinebattle] general.lua is missing runtime.ranged_in_progress; '
            .. 'chase cannot yield to ranged shots. Update general.lua.')
    end
    return false
end

-- Returns: 'fire' when chase is complete and pull should fire this tick,
-- 'chasing' while still closing, 'abort' on timeout.
local function chase_step(args, ire, dist, range)
    local state    = args.state
    local movement = args.movement
    local now      = args.now

    -- SHOT IN FLIGHT -- STAND STILL.
    --
    -- "You move and interrupt your aim" is this, every time: the arrow is
    -- away, the chase is still holding W, and the shot dies. tick_engaged_run
    -- has bailed on ranged_busy for a long time; chase never learned to.
    --
    -- Release W and report 'chasing' rather than aborting -- we still want to
    -- close, just not during the second the arrow is in the air. The chase
    -- timeout keeps running underneath, so a wedged shot cannot stall this
    -- forever.
    if ranged_busy_live(state) then
        movement_stop(movement)
        return 'chasing'
    end

    -- First entry: mark active. H is handled below (once).
    if not ire.at_chase_active then
        ire.at_chase_active     = true
        ire.at_chase_started_at = now
        ire.at_chase_h_sent     = false
        dbg(args, ('[chase] start dist=%.1f range=%.1f'):format(dist, range))
    end

    -- Timeout: abort and release keys. Covers "lock never took", "mob is
    -- unreachable", "pathing stuck" -- all the same from here.
    if (now - (tonumber(ire.at_chase_started_at or 0.0) or 0.0)) >= CHASE_TIMEOUT_SEC then
        dbg(args, ('[chase] timeout after %.1fs at dist=%.1f, aborting'):format(
            CHASE_TIMEOUT_SEC, dist))
        chase_reset(ire, movement)
        return 'abort'
    end

    -- LOCK ON, ONCE, AND ONLY IF WE KNOW WE'RE UNLOCKED.
    -- H is a TOGGLE. Pressing it when already locked UNLOCKS. So:
    --   false -> definitely unlocked, press once.
    --   true  -> already locked, do nothing.
    --   nil   -> can't read it. DO NOT PRESS. Guessing here is a coin flip
    --            that breaks the player's lock, and the chase re-arming
    --            makes it flip on/off/on/off. Just walk: if we aren't
    --            locked, distance won't close and CHASE_TIMEOUT_SEC aborts.
    if not ire.at_chase_h_sent then
        ire.at_chase_h_sent = true
        local locked = chase_is_locked()
        if locked == false then
            chase_press_h(now)
            dbg(args, '[chase] H sent (was unlocked)')
        elseif locked == nil then
            dbg(args, '[chase] lock state unreadable, not touching H')
        end
    end

    -- Locked (or assumed). With lock-on active, W walks toward the target.
    -- In-range check with hysteresis: stop a yalm inside range so we don't
    -- oscillate at the boundary.
    local stop_at = range - CHASE_STOP_MARGIN_SEC
    if stop_at < 1.0 then stop_at = 1.0 end
    if dist <= stop_at then
        dbg(args, ('[chase] in range dist=%.1f stop_at=%.1f'):format(dist, stop_at))
        chase_reset(ire, movement)
        return 'fire'
    end

    -- Still too far: hold W. movement_walk is idempotent -- safe to call
    -- every tick.
    movement_walk(movement)

    -- STUCK-WALL DETECTION. While we're chasing (W held, going nowhere),
    -- watch for XY position not changing. When we're stuck: strafe A or D
    -- for STUCK_STRAFE_SEC with W still held to slide along the wall. Two
    -- strafes and still no progress -> blacklist and abort; auto-target
    -- repicks after the 30s cool-off.
    local ctx = args.ctx
    local skey = 'chase'
    local s = stuck_state(ire, skey)
    if stuck_strafe_active(ire, now, skey) then
        return 'chasing'    -- hold the strafe out
    end
    if s.strafe_until > 0.0 and now >= s.strafe_until then
        stuck_end_strafe(ire, movement, skey)
        -- Reset anchor so the next stuck window judges post-strafe progress.
        s.seeded = false
    end
    if stuck_check(state, ire, now, skey, ctx) == true then
        if (s.attempts or 0) >= 2 then
            -- Two strafe attempts failed. Blacklist and abort.
            local stuck_sid = tonumber(ire.at_pull_sid or 0) or 0
            if stuck_sid ~= 0 and ire.at_blacklist then
                ire.at_blacklist[stuck_sid] = now + 30.0
                dbg(args, ('[chase] stuck on wall (sid %d): blacklisting 30s, aborting'):format(
                    stuck_sid))
            else
                dbg(args, '[chase] stuck on wall: aborting')
            end
            chase_reset(ire, movement)
            return 'abort'
        end
        local pick = stuck_start_strafe(state, ire, movement, now, skey, s.strafe_key)
        if pick ~= 'none' then
            dbg(args, ('[chase] stuck detected, strafe %s (attempt %d)'):format(
                pick, s.attempts or 0))
        end
    end

    return 'chasing'
end

-- AUTO PULL
-- Fires once, AUTO_PULL_DELAY_SEC after auto-target acquired a mob.
--   1 = /ra <t>   2 = /ma "Dia" <t>   3 = /attack <t>
-- Safety: only fires while the armed mob is still our target, only once
-- per acquisition (at_pull_at is cleared on the attempt, win or lose),
-- and never while engaged/resting.
local ANTIDOTE_COOLDOWN_SEC = 8.0    -- ~4s /item cast + buffer; also anti-spam on empty inventory

-- Attack-range watchdog. When engaged (auto.attack on) and the target
-- sits beyond /attack's 30y ceiling for a sustained period, the /attack
-- command isn't landing -- mob may have teleported, walled off, or is
-- running faster than us. Disengage with /attack off, blacklist the sid,
-- and self-target so the auto-target watchdog (#3) picks a new mob.
-- Gated on auto.attack so manual play isn't hijacked.
local function tick_attack_range_watchdog(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local now      = args.now
    local ire      = ire_state(state)

    -- Only run when combat automation is on and we're engaged.
    if cfgget('auto.attack') ~= true then
        ire.attack_last_in_range_at = now
        return false
    end
    if ctx.engaged01 ~= 1 then
        ire.attack_last_in_range_at = now
        return false
    end

    local dist = tonumber(ctx.target_distance or ctx.dist)
    if dist == nil then
        -- Can't read distance -- treat as in-range (safer than firing off).
        ire.attack_last_in_range_at = now
        return false
    end

    if dist <= ATTACK_MAX_RANGE_YALMS then
        ire.attack_last_in_range_at = now
        return false
    end

    -- Beyond the ceiling. How long?
    local last_ok = tonumber(ire.attack_last_in_range_at or 0.0) or 0.0
    if last_ok == 0.0 then
        -- Never been in range on this engage; seed and wait.
        ire.attack_last_in_range_at = now
        return false
    end
    if (now - last_ok) < ATTACK_OUT_OF_RANGE_TIMEOUT_SEC then
        return false
    end

    local cur_sid = tonumber(ctx.target_server_id or 0) or 0
    dbg(args, ('[atk-watchdog] out of range %.1fy for %.1fs, disengaging sid %d'):format(
        dist, now - last_ok, cur_sid))

    if type(args.dispatch) == 'function' then
        args.dispatch('/attack off', 1.0)
    end
    if cur_sid ~= 0 then
        ire.at_blacklist[cur_sid] = now + 30.0
        local self_sid = get_self_server_id()
        if self_sid ~= 0 then
            GeneralLua.utils.set_target_by_server_id(self_sid)
        end
    end

    -- Reset the timer so we don't retrigger every tick while /attack off
    -- resolves through the dispatch pipe.
    ire.attack_last_in_range_at = now
    return true
end

-- Engaged out-of-range ERROR-count watchdog. Separate from the distance-
-- based tick_attack_range_watchdog above: this one counts server-emitted
-- "The X is out of range." lines during engaged auto-swings. Three hits
-- in a row means our target is unreachable (killed by someone else and
-- client target drifted, teleported, walled off, etc.) even if our own
-- distance read looks fine. Same recovery as the distance watchdog:
-- /attack off, blacklist the sid, self-target so auto-target picks
-- something new.
local OOR_ERROR_LIMIT = 3
local function tick_engaged_oor_error_watchdog(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local now    = args.now
    local ire    = ire_state(state)

    if cfgget('auto.attack') ~= true then
        state.combat.oor_swing_count = 0
        return false
    end
    if ctx.engaged01 ~= 1 then
        state.combat.oor_swing_count = 0
        return false
    end

    -- Target change resets the counter -- an old sid's errors shouldn't
    -- carry over to a fresh acquisition.
    local cur_sid = tonumber(ctx.target_server_id or 0) or 0
    local last_sid = tonumber(state.combat.oor_swing_sid or 0) or 0
    if cur_sid ~= last_sid then
        state.combat.oor_swing_sid   = cur_sid
        state.combat.oor_swing_count = 0
        return false
    end

    local n = tonumber(state.combat.oor_swing_count or 0) or 0
    if n < OOR_ERROR_LIMIT then return false end

    dbg(args, ('[oor-watchdog] %d out-of-range swings, disengaging sid %d'):format(
        n, cur_sid))

    if type(args.dispatch) == 'function' then
        args.dispatch('/attack off', 1.0)
    end
    if cur_sid ~= 0 then
        ire.at_blacklist[cur_sid] = now + 30.0
        local self_sid = get_self_server_id()
        if self_sid ~= 0 then
            GeneralLua.utils.set_target_by_server_id(self_sid)
        end
    end

    state.combat.oor_swing_count = 0
    state.combat.oor_swing_sid   = 0
    return true
end

-- Auto Antidote. Runs from the main tick regardless of engaged/idle, so
-- being poisoned at low HP gets a cure whenever we're not mid-action.
-- Explicitly NOT a ladder entry -- ladder entries only fire during their
-- round type, and the whole point is to fire in the gaps.
local function tick_auto_antidote(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local now      = args.now
    local ire      = ire_state(state)

    if cfgget('auto.antidote') ~= true then return false end
    if not ctx.self_poison_active then return false end

    -- HP < 25%. Ignore nil / 0 (target-just-died style flapping).
    local hp = tonumber(ctx.player_hp)
    if hp == nil or hp <= 0 or hp >= 25 then return false end

    -- "Not busy": no cast in progress, no /ra in flight. Explicitly do NOT
    -- gate on resting01 -- if we're resting and poison is out-draining
    -- our regen, breaking rest to antidote is the correct move (the game
    -- auto-stands you on /item).
    if ctx.spells_locked then return false end
    if ctx.ranged_busy   then return false end
    -- Don't steal the WS tick: if TP is up and Auto WS + HP gate are
    -- satisfied, WS fires this tick. Antidote next round.
    if cfgget('auto.ws') and (tonumber(ctx.tp or 0) or 0) >= 1000 and ctx.ws_hp_ok then
        return false
    end

    -- Local cooldown: at most one fire per ANTIDOTE_COOLDOWN_SEC. Survives
    -- the /item animation and rate-limits attempts if the inventory is
    -- empty (fails silently in-game).
    local last_at = tonumber(ire.antidote_last_at or 0.0) or 0.0
    if (now - last_at) < ANTIDOTE_COOLDOWN_SEC then return false end

    if type(args.dispatch) ~= 'function' then return false end
    local ok = args.dispatch('/item "Antidote" <me>', 1.0)
    if ok then
        ire.antidote_last_at = now
        dbg(args, ('[antidote] fired at HP=%d%% (poisoned)'):format(hp))
        return true
    end
    return false
end

-- LOS CORRECTION FOR STANDOFF RANGED.
--
-- This is the ORIGINAL Auto Battle correction, restored. It predates the
-- pull entirely: tick_engaged_run has always answered
-- player_cannot_see_target with movement.tap_left_for_los() -- a short A
-- strafe that shifts the character off the corner it is stuck behind.
--
-- I broke it twice over:
--   1. tick_engaged_run early-returns when auto.rangedmode is on (my gate,
--      so Run could not drag us into melee). The A tap lives BELOW that
--      return, so standoff mode lost it outright.
--   2. Even without the gate it would not have fired: that branch also
--      requires dist <= run_stop_dist (3.3y). Standing off at 20y is never
--      inside 3.3, so the correction was melee-only by construction.
--
-- Hence a separate tick rather than loosening the one in tick_engaged_run:
-- the melee version wants the distance gate (it taps, then keeps closing),
-- the standoff version must not have one.
--
-- A, NOT W. tap_left_for_los strafes; walk_timed drives forward. Forward is
-- wrong twice over -- it does not change the angle the way a sidestep does,
-- and repeated forward nudges march the character out of camp.
local LOS_TAP_COOLDOWN_SEC = 2.0
local function tick_ranged_los_correction(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local now    = args.now
    local ire    = ire_state(state)

    if cfgget('auto.rangedmode') ~= true then return false end
    if not (state.flags and state.flags.player_cannot_see_target == true) then
        return false
    end

    -- Consume the flag either way. Leaving it set would re-tap every tick.
    state.flags.player_cannot_see_target = false

    -- Nothing to correct toward.
    if (tonumber(ctx.target_server_id or 0) or 0) == 0 or ctx.target_dead then
        return false
    end

    -- Never tap through a shot in flight -- that is the interrupted-aim bug
    -- from the other direction.
    if ranged_busy_live(state) then return false end

    -- Rate limit. The message can arrive several times for one bad angle and
    -- tapping on each would walk us out of the camp a nudge at a time.
    if now < (tonumber(ire.los_tap_until or 0.0) or 0.0) then return false end
    ire.los_tap_until = now + LOS_TAP_COOLDOWN_SEC

    local mv = args.movement
    if mv and type(mv.tap_left_for_los) == 'function' then
        dbg(args, '[ranged] cannot see target -- tapped A for LOS')
        mv.tap_left_for_los()
        return true
    end

    return false
end

local function tick_auto_pull(args)
    local state  = args.state
    local ctx    = args.ctx
    local cfgget = args.cfgget
    local now    = args.now
    local ire    = ire_state(state)

    local mode = tonumber(cfgget('auto.pull')) or 0
    if mode == 0 then
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        return false
    end

    -- TOO-FAR RECOVERY. If the last dispatch was refused for range (text_
    -- parser sets this on "target is out of range" / "too far away"), the
    -- arm has already been consumed. Re-seed the pull against the current
    -- client target and clear the flag so the chase-to-range block below
    -- runs a fresh close. Only fires when we're not engaged/resting and
    -- have a valid mob target -- if the player moved on, don't chase.
    if state.flags and state.flags.target_too_far == true then
        state.flags.target_too_far = false
        local cur_sid_now = tonumber(ctx.target_server_id or 0) or 0
        local cur_idx_now = tonumber(ctx.target_index or 0) or 0
        if ctx.engaged01 ~= 1 and ctx.resting01 ~= 1
           and cur_sid_now ~= 0 and ctx.target_valid == true
           and ctx.target_dead ~= true
        then
            ire.at_pull_sid  = cur_sid_now
            ire.at_pull_idx  = cur_idx_now
            ire.at_pull_at   = now       -- fire this tick, chase block gates
            ire.at_pull_aligned = false
            ire.at_pull_swapped = false
            ire.at_pull_settle_until = 0.0
            dbg(args, ('[auto-pull] re-arm: server refused for range, re-chasing sid %d'):format(cur_sid_now))
        end
    end

    -- LOS-FAIL RETRY. If the pull /ra just fired and the game said
    -- "You cannot see the X" within the retry window, redo ONE align tap
    -- and re-fire against the same sid. This covers the lag case where
    -- /ra leaves the client before the character has finished rotating
    -- and the server rejects the shot for LOS. One retry per acquisition
    -- -- if it fails again, fall through to normal error handling
    -- (target repick, blacklist, etc.). Retry uses the same arm path as
    -- everything else so align tap + settle + dispatch all rerun cleanly.
    local retry_sid   = tonumber(ire.at_pull_ra_retry_sid or 0) or 0
    local retry_until = tonumber(ire.at_pull_ra_retry_until or 0.0) or 0.0
    if retry_sid ~= 0 and now < retry_until
       and state.flags and state.flags.player_cannot_see_target == true
       and not ire.at_pull_ra_retry_used
    then
        state.flags.player_cannot_see_target = false
        local cur_sid_now = tonumber(ctx.target_server_id or 0) or 0
        local cur_idx_now = tonumber(ctx.target_index or 0) or 0
        if mode == 1 and cur_sid_now == retry_sid
           and ctx.engaged01 ~= 1 and ctx.resting01 ~= 1
           and ctx.target_valid == true and ctx.target_dead ~= true
        then
            ire.at_pull_ra_retry_used = true
            ire.at_pull_sid  = cur_sid_now
            ire.at_pull_idx  = cur_idx_now
            ire.at_pull_at   = now
            ire.at_pull_aligned = false
            ire.at_pull_swapped = false
            ire.at_pull_settle_until = 0.0
            dbg(args, ('[auto-pull] LOS retry: re-aligning + re-firing /ra at sid %d'):format(cur_sid_now))
        else
            -- Retry window tripped but conditions aren't clean (target
            -- changed, engaged, etc.). Burn the retry token so we don't
            -- try again next tick when things settle -- one shot only.
            ire.at_pull_ra_retry_used  = true
            ire.at_pull_ra_retry_sid   = 0
            ire.at_pull_ra_retry_until = 0.0
        end
    elseif retry_sid ~= 0 and now >= retry_until then
        -- Window closed without a LOS trip -- shot presumably landed.
        -- Clear the arm so the NEXT acquisition gets a fresh retry token.
        ire.at_pull_ra_retry_sid   = 0
        ire.at_pull_ra_retry_until = 0.0
        ire.at_pull_ra_retry_used  = false
    end

    local when = tonumber(ire.at_pull_at or 0.0) or 0.0
    if when == 0.0 then return false end

    -- RA pull needs an actual bow/xbow/gun. Without one, /ra throws the
    -- stat stick sitting in the ammo slot. Checked BEFORE the chase so we
    -- don't run 20y toward a mob we were never going to shoot.
    if mode == 1 and (state.live and state.live.ranged_weapon_ok) ~= true then
        dbg_bot(args, 'pull_no_ranged_weapon',
            '[auto-pull] RA pull needs a bow/xbow/gun equipped', 5.0)
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        chase_reset(ire, args.movement)
        return false
    end

    -- Rest intent beats a pending pull too. Otherwise a pull armed just
    -- before HP dropped still fires and drags us into a fight we wanted
    -- to rest out of. Disarm rather than defer -- by the time we are
    -- healed the mob is stale.
    if should_rest_now(cfgget) == true then
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        chase_reset(ire, args.movement)
        return false
    end

    -- Disarm if we're no longer idle, or the armed mob stopped being our
    -- target (player retargeted, mob died, claim changed).
    local cur_sid = tonumber(ctx.target_server_id or 0) or 0
    if ctx.engaged01 == 1 or ctx.resting01 == 1
        or cur_sid == 0 or cur_sid ~= (tonumber(ire.at_pull_sid or 0) or 0)
    then
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        chase_reset(ire, args.movement)
        return false
    end

    if now < when then return false end

    -- PRE-ATTACK SHADOWS (/attack only). Get Utsusemi up BEFORE closing
    -- distance -- 4s cast finishes as chase closes ~20y, so we arrive at
    -- melee already shadowed. Casting AFTER chase would leave us standing
    -- 2.5y from the mob for 4s, guaranteed aggro + cast interrupt.
    --
    -- Not for /ra or Dia -- those don't leave us in melee getting swung on.
    -- Not gated on auto.shadows_mode -- shadows_can_attempt('pre_attack')
    -- only checks target_dead + shadow count, so this fires under both
    -- SAtk and SDef radios.
    --
    -- Two-part hold. The cast must complete BEFORE any W-hold starts,
    -- otherwise chase runs during the cast and defeats the whole point.
    -- Firing the cast is just the first tick; the remaining ~4s the cast
    -- is in flight also has to block chase, so:
    --   (a) if spells_locked (cast in progress -- likely the shadow cast
    --       we started a tick ago, but any cast will do), own the tick
    --       and skip chase entirely.
    --   (b) otherwise try to start a fresh pre-attack cast; if it fires,
    --       own the tick.
    -- Either way, when both are false -- shadows are already up, or the
    -- job can't cast them, or the mode is wrong -- fall through to chase.
    if mode == 3 and cfgget('auto.shadows') == true then
        if ctx.spells_locked then
            return true
        end
        if try_pre_attack_shadows_for_target(args) then
            return true
        end
    end

    -- STILL VALID? The wait above is a whole second or two, and the mob does
    -- not stand still for it. The claim gets re-read further down; this is
    -- the cheaper half -- did the thing die, or stop being a targetable
    -- entity, while we were waiting to open on it.
    --
    -- Disarm rather than defer: a dead or vanished mob is not coming back,
    -- and leaving the arm set would have us re-checking a corpse every tick
    -- until something else cleared it.
    if ctx.target_dead == true or ctx.target_valid == false then
        dbg(args, ('[auto-pull] target no longer valid (dead=%s valid=%s), disarming'):format(
            tostring(ctx.target_dead), tostring(ctx.target_valid)))
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        chase_reset(ire, args.movement)
        return false
    end

    -- HARD-CAP: bail if the target sits outside the pull method's engine
    -- ceiling. PULL_HARD_MAX_YALMS IS EMPTY BY DESIGN -- see its comment
    -- at the top of the file. No mode has an entry, so this block never
    -- fires and every mode falls through to CHASE-TO-RANGE below. That is
    -- deliberate: a mob picked at 40y or 50y is meant to be locked and
    -- walked in to the pull method's range, not abandoned. The block is
    -- kept only as the hook for a genuine engine ceiling if one turns up.
    local dist_pre = tonumber(ctx.target_distance or ctx.dist or 999999) or 999999
    -- No entry = no engine hard-cap for this mode. See PULL_HARD_MAX_YALMS.
    local hard_max = PULL_HARD_MAX_YALMS[mode]
    if hard_max ~= nil and dist_pre > hard_max then
        local label = (mode == 1 and '/ra') or (mode == 2 and 'Dia') or '/attack'
        dbg(args, ('[auto-pull] target beyond %s hard-max (dist=%.1f > %.1f), abort'):format(
            label, dist_pre, hard_max))
        if cur_sid ~= 0 then
            ire.at_blacklist[cur_sid] = now + 30.0
        end
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        chase_reset(ire, args.movement)
        return false
    end

    -- CHASE-TO-RANGE. If the mob sits outside the pull method's range, close
    -- distance first (press H for lock, hold W -- lock-on makes W walk
    -- toward target). Chase step returns 'fire' when we're in range and
    -- the pull should proceed, 'chasing' while still closing, or 'abort'
    -- on timeout / lock failure. Does NOT consume the pull arm -- fire
    -- falls through only when chase reports ready.
    local dist  = tonumber(ctx.target_distance or ctx.dist or 999999) or 999999
    local range = PULL_RANGE_YALMS[mode] or 20.0
    if ire.at_chase_active or dist > range then
        local status = chase_step(args, ire, dist, range)
        if status == 'chasing' then
            return true    -- own the tick while chasing
        elseif status == 'abort' then
            -- Consume the arm so we don't loop on an unreachable mob. The
            -- stale-lock watchdog in tick_auto_target repicks a new target
            -- after 15s of no engagement.
            ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
            return false
        end
        -- status == 'fire': chase ran W toward the mob, so we're already
        -- facing. Skip the align tap below, and stamp the settle timer so
        -- we hold still for 0.5s before dispatching (stumbling into the
        -- shot cancels /ra).
        ire.at_pull_aligned = true
        ire.at_pull_settle_until = now + 0.5
    end

    -- CLAIM RE-CHECK. This is the whole point: auto-target only verified
    -- the claim when it ACQUIRED the mob, and the pull fires a full second
    -- later. In that window another player can engage it -- which is
    -- exactly how the bot ended up opening on a mob someone else was
    -- already fighting. A free mob at target-time is not a free mob at
    -- pull-time, so we re-read the claim right before dispatching and
    -- abandon silently if anyone outside the party has taken it.
    local idx = tonumber(ire.at_pull_idx or 0) or 0
    if idx > 0 then
        local ok_e, ent = pcall(get_entity, idx)
        if ok_e and ent then
            local claim_id    = entity_claim_id(ent)
            local claim_state = get_claim_state(claim_id,
                get_player_server_id(), build_party_member_id_set())
            if claim_state == 'other' then
                dbg(args, ('[auto-pull] abort: sid %d claimed by another player (claim=%s)'):format(
                    tonumber(ire.at_pull_sid or 0) or 0, tostring(claim_id)))
                ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
                ire.at_pull_aligned = false
                ire.at_pull_swapped = false
                ire.at_pull_settle_until = 0.0
                return false
            end
        end
    end

    -- PULL AMMO SWAP. /ra pulls should never fire sleep ammo -- the mob is
    -- aggro'd by the shot itself and wakes on the next tick, so the sleep
    -- bolt is wasted. bovinebattle sets pull_ammo_needs_swap / _swap_target
    -- every frame based on what's currently in the ammo slot. When a swap
    -- is required and we have a valid replacement, send /equip and burn a
    -- tick to let the swap land before dispatching /ra.
    if mode == 1 and not ire.at_pull_swapped then
        local live = state.live or {}
        if live.pull_ammo_needs_swap == true then
            local target = tostring(live.pull_ammo_swap_target or '')
            if target == '' then
                -- Sleep is equipped and no acid/blind/bloody are on hand.
                -- Aborting is better than pulling with a sleep bolt.
                dbg(args, ('[auto-pull] refuse /ra: equipped ammo is sleep type and no acid/blind/bloody in inventory'))
                ire.at_pull_at = 0.0
                ire.at_pull_sid = 0
                ire.at_pull_idx = 0
                ire.at_pull_aligned = false
                return false
            end
            if type(args.dispatch) == 'function' then
                -- gate_time=0: the /equip is instant server-side and we DO
                -- NOT want its gate outlasting the settle window below and
                -- silently blocking the /ra dispatch. The 0.5s settle is
                -- already our pacing.
                --
                -- dispatch() returns false if the pipe is currently gated
                -- (a prior command this tick, or a recent action's
                -- gate_until still in the future). We MUST NOT mark
                -- at_pull_swapped=true unless the /equip actually left the
                -- client, or the next tick will skip the swap block and
                -- fire /ra with the wrong ammo still loaded. If dispatch
                -- returns false, leave the flag alone and re-try next tick.
                local ok = args.dispatch(('/equip ammo "%s"'):format(target), 0.0)
                if ok then
                    ire.at_pull_swapped = true
                    dbg(args, ('[auto-pull] swap ammo -> %s'):format(target))
                    return true    -- own this tick; align+dispatch next
                else
                    dbg_bot(args, 'pull_ammo_swap_gated',
                        '[auto-pull] ammo swap gated, retry next tick', 2.0)
                    return true    -- own this tick, don't fall through to /ra
                end
            end
            return true    -- own this tick; align+dispatch next
        end
        ire.at_pull_swapped = true    -- no swap needed; skip on future ticks
    end

    -- FACING TAP. /ra and Dia both need us pointed at the mob or the shot
    -- misses / cancels. If we chased in, W has been held and we're already
    -- facing. If we started in-range, we might be pointed anywhere. A brief
    -- W tap while locked on turns the character to face the target -- Ashita
    -- does the rotation server-side once movement input starts. One tick to
    -- fire the tap, one tick to let it complete + settle, then dispatch.
    -- /attack skips this: the engage itself server-side-faces us.
    if mode == 1 or mode == 2 then
        local mv = args.movement
        if mv and type(mv.walk_timed_active) == 'function' and mv.walk_timed_active() then
            return true    -- own the tick while the tap is running
        end
        if not ire.at_pull_aligned then
            ire.at_pull_aligned = true
            if mv and type(mv.walk_timed) == 'function' then
                mv.walk_timed(0.15)
                -- 0.5s settle AFTER the tap completes. The tap itself is
                -- 0.15s, so total quiet-before-shot is ~0.65s: enough for
                -- the character to stop stumbling before /ra fires.
                ire.at_pull_settle_until = now + 0.15 + 0.5
                dbg(args, ('[auto-pull] align tap for %s'):format(
                    (mode == 1) and '/ra' or 'Dia'))
                return true    -- own this tick; settle+dispatch next
            end
        end
    end

    -- SETTLE. After any movement (chase run OR align tap), hold still for
    -- 0.5s before firing. /ra cancels if the character is still walking
    -- when the shot goes out, and the mob's own aggro-approach animation
    -- can nudge us just enough to break it. Waiting here defeats that.
    local settle_until = tonumber(ire.at_pull_settle_until or 0.0) or 0.0
    if settle_until > 0.0 and now < settle_until then
        return true    -- own the tick until settle window elapses
    end

    -- Consume the arm BEFORE dispatching: win or lose, this acquisition
    -- gets exactly one pull attempt. Never a retry loop.
    ire.at_pull_at  = 0.0
    ire.at_pull_aligned = false
    ire.at_pull_swapped = false
    ire.at_pull_settle_until = 0.0
    local sid = ire.at_pull_sid
    ire.at_pull_sid = 0
    ire.at_pull_idx = 0

    -- MELEE-DISTANCE COLLAPSE for /ra pulls. If the mob is already inside
    -- 5y, firing /ra is pointless -- the shot's travel time is longer than
    -- the /attack round-trip, and it wastes an ammo. Skip straight to
    -- /attack (mode 3 behaviour). Applies only to /ra; Dia still fires
    -- for its debuff.
    local dist_now = tonumber(ctx.target_distance or ctx.dist or 999999) or 999999
    local effective_mode = mode
    if mode == 1 and dist_now <= 5.0 then
        effective_mode = 3
        dbg(args, ('[auto-pull] within melee (dist=%.1f) -> /attack instead of /ra'):format(dist_now))
    end

    -- WHO OWNS THE OPENING SHOT: THE PULL. It has exactly one job -- put a
    -- shot into a mob we do not have hate on -- and it keeps it here.
    --
    -- I briefly had this the other way round, standing the pull down whenever
    -- Ranged mode was on, on the theory that two loops firing /ra at the same
    -- mob was the duplication. It is not. They are different jobs that happen
    -- to use the same command: the pull opens, the standoff loop sustains.
    -- Handing the opener to a loop whose whole premise is 'we are already
    -- shooting this thing' also took the pull's align tap, ammo swap and LOS
    -- retry out of the opening shot, which is where they matter most.
    --
    -- The other half of the rule lives in ranged_mode_step: it holds off
    -- while we have no hate, so it is not racing the opener. See
    -- state.live.have_hate_on_target.
    local cmd
    if effective_mode == 1 then cmd = '/ra <t>'
    elseif effective_mode == 2 then cmd = '/ma "Dia" <t>'
    elseif effective_mode == 3 then cmd = '/attack <t>'
    else return false end

    -- BACKSTOP for the other two ranged loops.
    --
    -- The rangedmode overlap is settled above by ownership, so that path never
    -- reaches here. This catches the two that are independently toggleable and
    -- have no such rule: the RANGED ladder entry (auto.ranged) and the RA Skill
    -- button. Both live in general.lua's tick, which runs BEFORE this file, so
    -- either can have a shot in the air by the time the pull runs.
    --
    -- ranged_busy_live reads state.combat directly rather than ctx, because
    -- ctx was snapshotted before general.lua fired -- see its comment.
    if effective_mode == 1 and ranged_busy_live(state) then
        dbg(args, ('[auto-pull] /ra already in flight for sid %d, pull satisfied'):format(sid))
        ire.at_pull_at = 0.0; ire.at_pull_sid = 0; ire.at_pull_idx = 0
        ire.at_pull_aligned = false
        ire.at_pull_swapped = false
        ire.at_pull_settle_until = 0.0
        return true
    end

    -- For /ra pulls, stamp ranged_fired_at so ranged_busy flips true this
    -- tick. tick_engaged_run reads that flag to hold W stationary through
    -- the shot -- without the stamp, the pull's engage would immediately
    -- start closing to melee and cancel the outgoing /ra. The normal
    -- RANGED entry stamps this itself; the pull bypasses that path so we
    -- do it here.
    if effective_mode == 1 then
        state.combat.ranged_fired_at    = now
        state.combat.ranged_resolved_at = 0.0

        -- LOS RETRY ARM. Clear any stale "cannot see" flag so we detect a
        -- fresh trip from THIS shot. Stamp the sid we just shot at so the
        -- retry block at the top of the next tick knows which mob to
        -- re-align + re-shoot against. Lag can put /ra out the door
        -- before the character has fully finished rotating; one retry
        -- with a fresh align tap fixes it. Only one retry per acquisition.
        if state.flags then
            state.flags.player_cannot_see_target = false
        end
        if not ire.at_pull_ra_retry_used then
            ire.at_pull_ra_retry_sid   = sid
            ire.at_pull_ra_retry_until = now + 2.0
        end
    end

    local ok, why = false, 'no dispatch'
    if type(args.dispatch) == 'function' then
        ok, why = args.dispatch(cmd, 1.0)
    end
    -- Say WHY on a refusal. A bare FAIL here reads as "the shot did not go"
    -- when the usual cause is 'gated' -- another /ra had already gone out and
    -- this second one was correctly suppressed. The shot you saw land was the
    -- first one; nothing was lost.
    dbg(args, ('[auto-pull] %s -> sid %d -> %s'):format(
        cmd, sid, ok and 'OK' or ('FAIL (' .. tostring(why or '?') .. ')')))

    -- For /attack: start closing to melee IMMEDIATELY on the same tick as
    -- the dispatch, don't wait for engaged01 to flip and tick_engaged_run
    -- to pick it up next tick. Engaged auto-face swings the character to
    -- the target the moment /attack lands, so W walks toward it. This
    -- covers the ~50-200ms gap between /attack dispatch and engaged
    -- state activation. Not for /ra or Dia -- those are shots, we should
    -- stay stationary after firing.
    if ok and effective_mode == 3 and args.movement then
        movement_walk(args.movement)
    end

    return ok == true
end

-- Rehome: bovinebattle's button calls this. We only REQUEST -- the capture
-- happens inside the tick where player_position() is known good, rather
-- than from a UI callback mid-render.
function IdleRestEngage.rehome(state)
    local ire = ire_state(state)
    ire.home_rehome_req = true
end

function IdleRestEngage.get_home(state)
    local ire = ire_state(state)
    return ire.home_x, ire.home_y, ire.home_z
end

function IdleRestEngage.tick(args)
    local state    = args.state
    local ctx      = args.ctx
    local cfgget   = args.cfgget
    local movement = args.movement
    local now_sec  = args.now_sec

    if not state then return false end
    if not ctx then return false end
    if type(cfgget) ~= 'function' then return false end
    if type(now_sec) ~= 'function' then return false end

    args.now = now_sec()

    -- Stamp W-held state so the runtime's do_shadows (which lives one call
    -- earlier in the frame in general.lua, no direct movement handle) can
    -- gate on it. One-frame lag is negligible for this: W is held for
    -- whole seconds at a time by chase / tick_engaged_run, not flickered.
    state.live = state.live or {}
    state.live.player_moving_w = movement_is_w_down(movement) == true

    local ire = ire_state(state)

    -- MOVEMENT BUSY, for general.lua's standoff ranged loop.
    --
    -- player_moving_w alone is not enough for it. W is only DOWN once the
    -- chase has already committed, so a shot fired the instant before that
    -- still gets walked out from under. An ACTIVE CHASE is the real signal:
    -- it means we are about to move, are moving, or are strafing a wall, and
    -- none of those are moments to be firing an arrow.
    --
    -- Read one frame late by general.lua (runtime.tick runs before this
    -- one), which is fine because a chase lasts seconds, not frames. The
    -- other half of the interlock -- chase yielding to a shot already in
    -- flight -- is in chase_step and does not depend on this flag.
    state.live.movement_busy =
        (state.live.player_moving_w == true)
        or (ire.at_chase_active == true)
        or (ire.stuck ~= nil and ire.stuck.chase ~= nil)

    -- IS THE CURRENT TARGET BLACKLISTED?
    --
    -- The blacklist lived entirely inside auto-target's pick loop, which made
    -- it mean 'do not CHOOSE this mob' and nothing more. Blacklisting the mob
    -- under the cursor therefore changed nothing about what was shooting it:
    -- ranged_mode_step fires at whatever is targeted, knows nothing about
    -- ire.at_blacklist, and carried straight on. Blacklist a Hornet for LOS,
    -- watch it get shot four seconds later.
    --
    -- Stamping it on state.live promotes it to what it always should have
    -- been: a statement that we are DONE WITH THIS MOB, readable by anyone.
    -- general.lua cannot see ire, so this is the only way across.
    --
    -- Read one frame late (runtime.tick runs first), which is irrelevant
    -- against a 30s entry.
    do
        local tsid = tonumber(state.live.player_target_server_id or 0) or 0
        local blocked_until = (tsid ~= 0 and ire.at_blacklist)
            and tonumber(ire.at_blacklist[tsid] or 0) or 0
        state.live.target_blacklisted =
            (blocked_until > 0) and ((args.now or 0.0) < blocked_until) or false
    end

    -- DO WE HAVE HATE ON THE CURRENT TARGET?
    --
    -- The dividing line between the two ranged jobs. The PULL exists to put a
    -- shot into a mob we do NOT have hate on; the standoff loop exists to
    -- keep shooting one we DO. Without a shared answer to this question both
    -- fire at the opener and one loses to the dispatch gate.
    --
    -- Claim is the honest read: 'self' or 'party' means the mob is ours and
    -- the opener has already happened, by us or by someone we are with.
    -- 'free' means nobody has touched it. 'other' means it is not ours to
    -- shoot at all, which the pick filters already refuse.
    --
    -- Engaged counts too, for the melee case where hate came from a swing
    -- rather than a shot.
    do
        local tidx = tonumber(state.live.player_target_index or 0) or 0
        local claim_state = nil
        if tidx > 0 then
            local ok_e, ent = pcall(get_entity, tidx)
            if ok_e and ent then
                claim_state = get_claim_state(entity_claim_id(ent),
                    get_player_server_id(), build_party_member_id_set())
            end
        end
        state.live.target_claim_state = claim_state
        state.live.have_hate_on_target =
            (claim_state == 'self' or claim_state == 'party')
            or (ctx.engaged01 == 1)
    end
    ire.engage_retry_until = tonumber(ire.engage_retry_until or 0.0) or 0.0
    ire.bot_retry_until = tonumber(ire.bot_retry_until or 0.0) or 0.0
    ire.bot_target_pending_until = tonumber(ire.bot_target_pending_until or 0.0) or 0.0
    -- Table, not a number: a missing at_blacklist is a hard index crash
    -- rather than a benign nil, so guard it the same way.
    ire.at_blacklist = ire.at_blacklist or {}

    maybe_capture_bot_center(args)

    maybe_capture_home(args)

    if cfgget('auto.attack') == true then
        build_live_mob_list(state)
    else
        ire.bot_enemy_list = T{}
        ire.bot_enemy_count = 0
        ire.bot_enemy_free_count = 0
        ire.bot_enemy_party_count = 0
        ire.bot_enemy_other_count = 0
    end

    if cfgget('auto.paused') == true then
        movement_release_all(movement)
        ire.rest_wait_since = 0.0
        ire.rest_after_prep_pending = false
        ire.run_active = false
        ire.engage_retry_until = 0.0
        ire.pre_attack_retry_until = 0.0
        ire.prep_action_settle_until = 0.0
        ire.bot_retry_until = 0.0
        ire.bot_target_server_id = 0
        ire.bot_target_name = nil
        ire.bot_target_pending_until = 0.0
        ire.bot_returning = false
        return false
    end

    -- Auto Antidote: runs BEFORE the engaged/idle split so it fires in
    -- both states. Owns the tick when it dispatches -- the item takes
    -- ~4s in-game and shouldn't be raced with other actions.
    if tick_auto_antidote(args) then
        return true
    end

    if ctx.engaged01 == 1 then
        -- RISING EDGE ONLY. Once we're actually fighting something, the
        -- old acquisition failures are stale -- wipe the blacklist. Must
        -- be edge-triggered, not per-tick: tick_attack_range_watchdog
        -- blacklists a runaway mob and then sends /attack off, and we stay
        -- engaged for a tick or two while that resolves. A per-tick wipe
        -- would erase the entry it just wrote.
        if ire.was_engaged ~= true then
            ire.was_engaged = true
            ire.at_blacklist = {}
            dbg(args, '[auto-target] engaged, blacklist cleared')
        end
        ire.engage_retry_until = 0.0
        ire.pre_attack_retry_until = 0.0
        ire.prep_action_settle_until = 0.0
        ire.bot_retry_until = 0.0
        ire.bot_target_pending_until = 0.0
        ire.bot_returning = false
        if tick_sleep_facing(args) then
            return true
        end
        -- Thief movement (Sneak Only + Trick Attack ±WS). Priority sits
        -- BELOW sleep_facing (Sleep Other's lane). Once staged by the
        -- atk_list entries, this machine owns the movement until it
        -- completes or times out.
        if tick_thief_action(args) then
            return true
        end
        if tick_attack_range_watchdog(args) then
            return true
        end
        if tick_engaged_oor_error_watchdog(args) then
            return true
        end
        try_engaged_hb_party(args)
        return tick_engaged_run(args)
    end

    ire.was_engaged = false
    ire.run_active = false

    if tick_autorest(args) then
        return true
    end

    if maybe_shadows_after_stand(args) then
        return true
    end

    if try_idle_hb(args) then
        return true
    end

    if try_idle_hb_party(args) then
        return true
    end

    -- LOS correction before the pull: a bad angle blocks the standoff loop's
    -- shots, and fixing the angle is cheaper than re-acquiring.
    if tick_ranged_los_correction(args) then
        return true
    end

    -- Pull first: if auto-target already armed a pull, fire it before
    -- looking for another mob to acquire.
    if tick_auto_pull(args) then
        return true
    end

    if tick_auto_target(args) then
        return true
    end

    if tick_bot_autoengage(args) then
        return true
    end

    if tick_autoengage(args) then
        return true
    end

    movement_stop(movement)
    return false
end

return IdleRestEngage